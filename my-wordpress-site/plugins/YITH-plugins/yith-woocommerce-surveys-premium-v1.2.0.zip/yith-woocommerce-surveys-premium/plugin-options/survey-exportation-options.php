<?php
if( !defined( 'ABSPATH' ) )
    exit;

return array(
    'survey-exportation' => array(
        'survey-exportation-action' => array(
            'type'   => 'custom_tab',
            'action' => 'yith_wc_survey_export_tab'
        )
    )
);