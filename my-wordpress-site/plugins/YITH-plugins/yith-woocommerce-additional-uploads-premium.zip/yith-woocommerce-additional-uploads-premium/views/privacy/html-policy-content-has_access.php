<p><?php _ex( 'Members of our team have access to the information you provide us. For example, both Administrators and Shop Managers can access:', 'Privacy Policy Content', 'yith-woocommerce-additional-uploads' ) ?></p>

<ul>
    <li><?php _ex( 'Files uploaded related to an order or to the products of an order', 'Privacy Policy Content', 'yith-woocommerce-additional-uploads' ); ?></li>
</ul>