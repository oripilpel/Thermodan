== YITH WordPress Title Bar Effects ===

== Changelog ==

= 1.1.8 - Released: Nov 05, 2019 =

* Update: plugin framework

= 1.1.7 - Released: Oct 30, 2019 =

* New: support for WordPress 5.3
* Update: plugin framework

= 1.1.6 - Released: June 25, 2019 =

* Update: plugin framework

= 1.1.5 - Released: May 31, 2019 =

* Update: plugin framework

= 1.1.4 - Released: May 21, 2019 =

* Update: plugin framework 3.2.1
* Update: Spanish language
* Fix: animation not working switching tab

= 1.1.3 - Released: Feb 20, 2019 =

* Update: Core Framework 3.1.20
* Update: Italian translation
* Update: Dutch translation

= 1.1.2 - Released: Oct 23, 2018 =

* Update: Core Framework 3.0.27

= 1.1.1 - Released: Sept 27, 2018 =

* Update: Core Framework 3.0.23

= 1.1.0 - Released: Apr 24, 2018 =

* New: plugin fw version 3.0.15
* New: Spanish translation
* New: Dutch translation
* New: Italian translation

= 1.0.1 - Released: Jan 12, 2017 =

* New: integration with YITH Desktop Notifications for WooCommerce

= 1.0.0 - Released: Oct 24, 2016 =

* Initial release