jQuery(function ($) {

    $('body')
        .on('click', 'button.ywsfd-purge-coupon', function () {

            var result = $('.ywsfd-clear-result'),
                data = {
                    action: 'ywsfd_clear_expired_coupons'
                };

            result.show();
            $(this).hide();

            $.post(ywsfd_admin.ajax_url, data, function (response) {

                result.removeClass('clear-progress');

                if (response.success) {

                    result.addClass('clear-success');
                    result.html(response.message);

                } else {

                    result.addClass('clear-fail');
                    result.html(response.error);

                }

            });

        });

});
