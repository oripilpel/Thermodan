<div class="ywsfd-social-button tw-btn">
    <a href="#" data-href="<?php echo $social_params['sharing']['url'] ?>" class="ywsfd-tweet-button">
        <i class="fa fa-twitter"></i>
		<?php echo apply_filters( 'ywsfd_tweet_label', __( 'Tweet', 'yith-woocommerce-share-for-discounts' ) ) ?>
    </a>
</div>