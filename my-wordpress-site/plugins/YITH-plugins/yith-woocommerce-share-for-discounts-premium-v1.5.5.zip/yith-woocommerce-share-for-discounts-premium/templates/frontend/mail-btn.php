<div class="ywsfd-social-button email-btn">
    <div class="ywsfd-email">
        <i class="fa fa-envelope-o"></i>
		<?php _e( 'Send to a friend', 'yith-woocommerce-share-for-discounts' ) ?>
    </div>
</div>