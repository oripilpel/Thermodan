<?php

require_once ( YITH_COG_PATH . '/includes/admin/reports/stock-reports/class.yith-cog-report-stock-table.php' );

/**
 * Initialize the Stock Report Table
 **/

$report_class = new YITH_COG_Report_Stock();
$report_class->output_report();


















