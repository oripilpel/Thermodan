<?php

require_once ( YITH_COG_PATH . '/includes/admin/reports/class.yith-cog-report-table.php' );


/**
 * Initialize the Report Table
 **/

$test = new YITH_COG_Report();
$test->output_report();













