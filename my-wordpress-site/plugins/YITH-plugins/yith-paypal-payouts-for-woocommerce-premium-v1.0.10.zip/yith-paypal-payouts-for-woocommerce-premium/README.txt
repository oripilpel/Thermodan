== YITH PayPal PayOuts for WooCommerce ==
= 1.0.10 =
* New: Support for WooCommerce 3.8
* New: Support for WordPress 5.3
* Update: Plugin Framework
* Update: Spanish language

= 1.0.9 =
* New: Support to WooCommerce 3.7 RC1
* Update: Plugin framework

= 1.0.8 =
* Update: Plugin Framework
* Dev: New filter "yith_payouts_panel_capability"
* Dev: New filter "yith_payouts_view_payouts_list_shortcode_args"

= 1.0.7 =
* Update: Plugin Framework

= 1.0.6 =
* New: Support to WordPress 5.2
* Update: Plugin Framework
* Update: Italian language

= 1.0.5 =
* New: Support to WooCommerce 3.6.0 RC1
* New: Support to WordPress 5.1.1
* Update: Plugin Framework

= 1.0.4 =

* New: Support to WooCommerce 3.5.4
* Update: Plugin Framework

= 1.0.3 =

* New: Support to WordPress 5.0
* Update: Plugin Framework

= 1.0.2 =
* Update: Plugin Framework
* Update: Language files

= 1.0.1 =
* New: View payout item details in the popup
* New: Supports WooCommerce 3.4.5
* New: Supports WordPress 4.9.8
* New: Plugin framework template
* Tweak: Payout list structure
* Update: Language files
* Update: Plugin framework

= 1.0.0 =

* Initial release
