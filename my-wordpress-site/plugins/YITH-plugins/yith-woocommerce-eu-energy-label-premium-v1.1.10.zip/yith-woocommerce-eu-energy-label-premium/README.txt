=== YITH WooCommerce EU Energy Label Premium ===

== Changelog ==

= Version 1.1.10 - Released: 05 Aug 2019 =
* New - support to WooCommerce 3.7
* Update - plugin framework
* Update - language files

= Version 1.1.9 - Released: 29 May 2019 =
* New - compatibility with WooCommerce Show Single Variations plugin
* Update - plugin framework

= Version 1.1.8 - Released: 17 Apr 2019 =

* New - support to WooCommerce 3.6
* New - bulk edit energy label
* Fix - issue when energy label is in product gallery
* Update - plugin framework
* Update - language files

= Version 1.1.7 - Released: 08 Feb 2019 =

* New - support to WooCommerce 3.5.4
* Update - plugin framework
* Update - language files

= Version 1.1.6 - Released: 11 Dec 2018 =
* New -  support to WordPress 5.0
* Update - plugin framework
* Update - language files

= Version 1.1.5 - Released: 23 Oct 2018 =

* Update - plugin framework

= Version 1.1.4 - Released: 17 Oct 2018 =

* New - support to WooCommerce 3.5.x
* New - yith_eu_energy_label shortcode to print EU Energy Label in product pages
* Update - plugin framework

= Version 1.1.3 - Released: 13 Jun 2018 =

* New - support to WooCommerce 3.4.x
* New - support to WordPress 4.9.6
* Update - Italian language
* Update - Spanish language
* Update - Dutch language
* Update - plugin framework

= Version 1.1.2 - Released: 31 Jan 2018 =

* New - support to WooCommerce 3.3
* New - Dutch language
* Update - Plugin Framework 3.0.11

= Version 1.1.1 - Released: 11 Oct 2017 =

* New - support to Support to WooCommerce 3.2.0 RC2
* Fix - display energy label
* Dev - added yith_wceue_show_energy_label_on_product filter

= Version 1.1.0 - Released: 30 Mar 2017 =

* New - support to WooCommerce 3.0-RC2

= Version 1.0.5 - Released: 05 Aug 2016 =

* New - Italian language
* New - Spanish language

= Version 1.0.4 - Released: 10 Mar 2016 =

* Fix - js script bug on plugin settings page

= Version 1.0.3 - Released: 31 Dec 2015 =

* New - support to WooCommerce 2.5 BETA 3

= Version 1.0.2 - Released: 30 Oct 2015=

* Fix - minor bug

= Version 1.0.0 - Released: 11 Sep 2015 =

* Initial release