jQuery( function ( $ ) {
    var link_to = $('#yith-wceue-link-to' ),
        custom_url_container = $('#yith-wceue-link-custom-url' ).closest('tr');

    link_to.on('change', function(){
        if ($(this)[0].selectedIndex != 2){
            custom_url_container.hide();
        }else{
            custom_url_container.show();
        }
    });
    link_to.trigger('change');

} );