<?php

return array(
	'carts' => array(
		'home' => array(
			'type'   => 'custom_tab',
			'action' => 'yith_ywrac_carts'
		)
	)
);