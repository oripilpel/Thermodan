<p><?php _ex( 'While you visit our site, we collect information about you during the checkout process on our store. We’ll track:', 'Privacy Policy Content', 'yith-woocommerce-additional-uploads' ); ?></p>

<ul>
    <li><?php _ex( 'Files uploaded related to an order or to the products of an order: we’ll add this information to the order details', 'Privacy Policy Content', 'yith-woocommerce-additional-uploads' ); ?></li>
</ul>