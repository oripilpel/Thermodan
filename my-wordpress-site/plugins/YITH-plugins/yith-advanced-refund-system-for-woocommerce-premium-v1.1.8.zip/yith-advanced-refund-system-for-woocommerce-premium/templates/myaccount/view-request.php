<div class="ywcars_view_request" id="request_<?php echo $request_id; ?>">
    <?php echo do_shortcode( '[ywcars_view_request id="' . $request_id . '"]' ); ?>
</div>