<?php
/**
 * This file belongs to the YIT Plugin Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

/**
 * Main class
 *
 * @class   YITH_WC_Anti_Fraud
 * @package Yithemes
 * @since   1.0.0
 * @author  Your Inspiration Themes
 */

if ( ! class_exists( 'YITH_WC_Review_For_Discounts' ) ) {

	class YITH_WC_Review_For_Discounts {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WC_Review_For_Discounts
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Panel object
		 *
		 * @var     /Yit_Plugin_Panel object
		 * @since   1.0.0
		 * @see     plugin-fw/lib/yit-plugin-panel.php
		 */
		protected $_panel = null;

		/**
		 * @var string Premium version landing link
		 */
		protected $_premium_landing = 'https://yithemes.com/themes/plugins/yith-woocommerce-review-for-discounts/';

		/**
		 * @var string Plugin official documentation
		 */
		protected $_official_documentation = 'https://docs.yithemes.com/yith-woocommerce-review-for-discounts/';

		/**
		 * @var string YITH WooCommerce Review For Discounts panel page
		 */
		protected $_panel_page = 'yith-wc-review-for-discounts';

		/**
		 * @var bool
		 */
		protected $_moderation_on = false;

		/**
		 * @var null
		 */
		var $_logger = null;

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WC_Review_For_Discounts
		 * @since 1.0.0
		 */
		public static function get_instance() {

			if ( is_null( self::$instance ) ) {

				self::$instance = new self;

			}

			return self::$instance;

		}

		/**
		 * Constructor
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function __construct() {

			if ( ! function_exists( 'WC' ) ) {
				return;
			}

			$this->_logger = new WC_Logger();

			// register plugin to licence/update system
			add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
			add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );
			//Load plugin framework
			add_action( 'plugins_loaded', array( $this, 'plugin_fw_loader' ), 12 );
			add_filter( 'plugin_action_links_' . plugin_basename( YWRFD_DIR . '/' . basename( YWRFD_FILE ) ), array( $this, 'action_links' ) );
			add_filter( 'yith_show_plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 5 );
			add_action( 'admin_menu', array( $this, 'add_menu_page' ), 5 );

			$this->includes();

			if ( is_admin() ) {
				add_action( 'admin_enqueue_scripts', array( $this, 'admin_scripts' ) );
				add_action( 'ywrfd_howto', array( $this, 'get_howto_content' ) );
				add_filter( 'ywrfd_admin_scripts_filter', array( $this, 'admin_scripts_filter' ) );
			}

			if ( get_option( 'ywrfd_enable_plugin' ) == 'yes' ) {


				add_action( 'admin_enqueue_scripts', array( $this, 'dismissable_notice' ) );
				add_action( 'admin_notices', array( $this, 'set_notices' ) );


				add_filter( 'woocommerce_email_classes', array( $this, 'add_ywrfd_custom_email' ) );
				add_action( 'init', array( $this, 'init_multivendor_compatibility' ), 20 );
				add_action( 'comment_post', array( $this, 'on_comment_written' ), 10, 1 );
				add_filter( 'yith_wcet_email_template_types', array( $this, 'add_yith_wcet_template' ) );

				if ( get_option( 'ywrfd_coupon_purge' ) == 'yes' ) {

					add_action( 'ywrfd_trash_coupon_cron', array( $this, 'trash_expired_coupons' ) );

				}

				if ( $this->is_advanced_reviews_active() ) {
					add_action( 'ywar_review_approve_status_changed', array( $this, 'on_comment_approvation_ywar' ), 10, 2 );
				} else {
					add_action( 'comment_unapproved_to_approved', array( $this, 'on_comment_approvation' ) );
				}

			}

		}

		/* === GLOBAL FUNCTIONS === */

		/**
		 * Files inclusion
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		private function includes() {

			include_once( 'includes/class-ywrfd-discounts.php' );
			include_once( 'includes/class-ywrfd-emails.php' );
			include_once( 'includes/class-ywrfd-mandrill.php' );
			include_once( 'includes/class-ywrfd-discounts-helper.php' );

			if ( is_admin() ) {

				include_once( 'includes/class-ywrfd-ajax.php' );
				include_once( 'templates/admin/class-ywrfd-custom-send.php' );
				include_once( 'templates/admin/class-yith-wc-custom-textarea.php' );
				include_once( 'templates/admin/class-ywrfd-custom-vendor-panel.php' );
				include_once( 'templates/admin/class-ywrfd-custom-coupon-purge.php' );
			}

			if ( defined( 'YITH_FUNDS_PREMIUM' ) && YITH_FUNDS_PREMIUM ) {
				include_once( 'includes/class-ywrfd-funds-emails.php' );
			}

		}

		/**
		 * Write send log
		 *
		 * @since   1.3.1
		 *
		 * @param   $args
		 *
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function write_log( $args ) {

			switch ( $args['type'] ) {

				case 'fund_email':
				case 'notification':
					$log = 'ERROR - Email not sent. User: ' . $args['user_email'] . ' - Type: ' . $args['type'];

					break;
				default:
					$log = 'ERROR - Email not sent. Code: ' . $args['coupon_code'] . ' - Type: ' . $args['type'];

			}

			$this->_logger->add( 'ywrfd-' . current_time( 'Y-m' ), $log );

		}

		/**
		 * On comment sending
		 *
		 * @since   1.0.0
		 *
		 * @param   $comment_id
		 *
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function on_comment_written( $comment_id ) {

			$comment = get_comment( $comment_id );

			if ( ! $this->user_already_commented( $comment ) && ! $this->is_moderation_required() ) {

				$this->get_coupons( $comment );

			}

		}

		/**
		 * Count approved Reviews
		 *
		 * @since   1.0.0
		 *
		 * @param   $author_email
		 *
		 * @return  int
		 * @author  Alberto Ruggiero
		 */
		public function count_reviews( $author_email ) {

			$approved = $this->is_moderation_required();

			if ( $this->is_advanced_reviews_active() ) {

				if ( $approved ) {

					$args = array(
						'post_type'      => 'ywar_reviews',
						'post_status'    => 'publish',
						'posts_per_page' => - 1,
						'meta_query'     => array(
							'relation' => 'AND',
							array(
								'key'     => '_ywar_review_author_email',
								'value'   => $author_email,
								'compare' => '='
							),
							array(
								'key'     => '_ywar_approved',
								'value'   => '1',
								'compare' => '='
							)
						)
					);

				} else {

					$args = array(
						'post_type'      => 'ywar_reviews',
						'post_status'    => 'publish',
						'posts_per_page' => - 1,
						'meta_query'     => array(
							'relation' => 'AND',
							array(
								'key'     => '_ywar_review_author_email',
								'value'   => $author_email,
								'compare' => '='
							),
						)
					);

				}

				$query = new WP_Query( $args );

				$count = $query->post_count;

				wp_reset_query();
				wp_reset_postdata();

			} else {

				if ( $approved ) {

					$args = array(
						'author_email' => $author_email,
						'status'       => 'approve',
						'count'        => true,
					);

				} else {

					$args = array(
						'author_email' => $author_email,
						'status'       => 'all',
						'count'        => true,
					);

				}

				$comments = new WP_Comment_Query();

				$count = $comments->query( $args );

			}

			return $count;

		}

		/**
		 * Get saved discounts
		 *
		 * @since   1.0.0
		 *
		 * @param   $author_email
		 * @param   $product_id
		 *
		 * @return  array
		 * @author  Alberto Ruggiero
		 */
		public function get_discounts( $product_id, $author_email ) {

			$value = array();

			//get coupon for single review
			$single_args = array(
				'post_type'      => 'ywrfd-discount',
				'post_status'    => 'publish',
				'posts_per_page' => - 1,
				'meta_query'     => array(
					array(
						'key'   => 'ywrfd_trigger',
						'value' => 'review',
					)
				)
			);

			$single_query = new WP_Query( $single_args );

			if ( $single_query->have_posts() ) {

				while ( $single_query->have_posts() ) {

					$valid = false;

					$single_query->the_post();

					$discount = new YWRFD_Discounts( $single_query->post->ID );

					if ( in_array( $product_id, $discount->trigger_product_ids ) ) {

						$valid = true;

					} else {

						$categories = wp_get_post_terms( $product_id, 'product_cat', array( 'fields' => 'ids' ) );

						if ( $categories ) {

							foreach ( $categories as $category_id ) {

								if ( in_array( $category_id, $discount->trigger_product_categories ) ) {

									$valid = true;

								}

							}

						}

					}

					if ( empty( $discount->trigger_product_ids ) && empty( $discount->trigger_product_categories ) ) {

						$valid = true;

					}

					if ( $valid ) {
						$value[] = $discount;
					}

				}

			}

			wp_reset_query();
			wp_reset_postdata();

			//get coupon for multiple review
			$count = $this->count_reviews( $author_email );

			$multiple_args = array(
				'post_type'      => 'ywrfd-discount',
				'post_status'    => 'publish',
				'posts_per_page' => - 1,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => 'ywrfd_trigger',
						'value' => 'multiple',
					),
					array(
						'key'   => 'ywrfd_vendor_id',
						'value' => '0',
					),
					array(
						'key'   => 'ywrfd_trigger_threshold',
						'value' => $count,
					),
				)
			);

			$multiple_query = new WP_Query( $multiple_args );

			if ( $multiple_query->have_posts() ) {

				while ( $multiple_query->have_posts() ) {

					$multiple_query->the_post();

					$discount = new YWRFD_Discounts( $multiple_query->post->ID );

					$value[] = $discount;

				}

			}

			wp_reset_query();
			wp_reset_postdata();

			return apply_filters( 'ywrfd_get_vendors_multiple_reviews_discounts', $value, $author_email );

		}

		/**
		 * Count reviews and sent notification if near to some threshold
		 *
		 * @since   1.0.0
		 *
		 * @param   $user_id
		 * @param   $user_email
		 * @param   $nickname
		 * @param   $product_id
		 *
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function notification_sending( $user_id, $user_email, $nickname, $product_id ) {

			$count     = $this->count_reviews( $user_email );
			$discounts = array();
			$args      = array(
				'post_type'      => 'ywrfd-discount',
				'post_status'    => 'publish',
				'posts_per_page' => - 1,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => 'ywrfd_trigger',
						'value' => 'multiple',
					),
					array(
						'key'   => 'ywrfd_trigger_enable_notify',
						'value' => 'yes',
					),
					array(
						'key'     => 'ywrfd_trigger_threshold_notify',
						'value'   => $count,
						'compare' => '<=',
						'type'    => 'NUMERIC'
					),
					array(
						'key'     => 'ywrfd_trigger_threshold',
						'value'   => $count,
						'compare' => '>',
						'type'    => 'NUMERIC'
					),
					array(
						'key'   => 'ywrfd_vendor_id',
						'value' => '0',
					),
				)
			);

			$query = new WP_Query( $args );

			if ( $query->have_posts() ) {

				while ( $query->have_posts() ) {

					$query->the_post();

					$discounts[] = new YWRFD_Discounts( $query->post->ID );

				}

			}

			wp_reset_query();
			wp_reset_postdata();

			$discounts = apply_filters( 'ywrfd_get_vendors_multiple_reviews_notify', $discounts, $user_email, $product_id );

			if ( ! empty( $discounts ) ) {

				foreach ( $discounts as $discount ) {

					$count = apply_filters( 'ywrfd_vendor_review_count', $count, $user_email, $product_id );

					$remaining_reviews = $discount->trigger_threshold - $count;

					$email_result = YWRFD_Emails()->prepare_coupon_mail( $user_id, '', 'notify', array( 'nickname' => $nickname, 'remaining_reviews' => $remaining_reviews ), $user_email, $discount->vendor_id );

					if ( ! $email_result ) {
						$this->write_log( array(
							                  'user_email' => $user_email,
							                  'type'       => 'notification'
						                  ) );
					}

				}

			}

		}

		/* === ADMIN ONLY FUNCTIONS === */

		/**
		 * Add a panel under YITH Plugins tab
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Alberto Ruggiero
		 * @use     /Yit_Plugin_Panel class
		 * @see     plugin-fw/lib/yit-plugin-panel.php
		 */
		public function add_menu_page() {

			if ( ! empty( $this->_panel ) ) {
				return;
			}

			$admin_tabs = array();

			if ( defined( 'YWRFD_PREMIUM' ) ) {
				$admin_tabs['premium-general'] = __( 'General Settings', 'yith-woocommerce-review-for-discounts' );
				$admin_tabs['mandrill']        = __( 'Mandrill Settings', 'yith-woocommerce-review-for-discounts' );
			} else {
				$admin_tabs['general']         = __( 'General Settings', 'yith-woocommerce-review-for-discounts' );
				$admin_tabs['premium-landing'] = __( 'Premium Version', 'yith-woocommerce-review-for-discounts' );
			}

			$admin_tabs['howto'] = __( 'How To', 'yith-woocommerce-review-for-discounts' );


			$args = array(
				'create_menu_page' => true,
				'parent_slug'      => '',
				'page_title'       => _x( 'Review For Discounts', 'plugin name in admin page title', 'yith-woocommerce-review-for-discounts' ),
				'menu_title'       => 'Review For Discounts',
				'capability'       => 'manage_options',
				'parent'           => '',
				'parent_page'      => 'yit_plugin_panel',
				'page'             => $this->_panel_page,
				'admin-tabs'       => $admin_tabs,
				'options-path'     => YWRFD_DIR . 'plugin-options'
			);

			$this->_panel = new YIT_Plugin_Panel_WooCommerce( $args );

		}

		/**
		 * Initializes CSS and javascript
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function admin_scripts() {

			global $post;

			$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';

			wp_enqueue_style( 'ywrfd-admin', YWRFD_ASSETS_URL . '/css/ywrfd-admin' . $suffix . '.css', array(), YWRFD_VERSION );

			wp_enqueue_script( 'ywrfd-admin', YWRFD_ASSETS_URL . '/js/ywrfd-admin' . $suffix . '.js', array( 'jquery' ), YWRFD_VERSION );

			$params = apply_filters( 'ywrfd_admin_scripts_filter', array(
				'ajax_url'                   => admin_url( 'admin-ajax.php' ),
				'post_id'                    => isset( $post->ID ) ? $post->ID : '',
				'vendor_id'                  => '0',
				'ywar_active'                => false,
				'comment_moderation'         => $this->is_moderation_required(),
				'comment_moderation_warning' => __( 'This option cannot be modified because it is essential for YITH WooCommerce Review for Discounts to work correctly.', 'yith-woocommerce-review-for-discounts' ),
				'before_send_test_email'     => __( 'Sending test email...', 'yith-woocommerce-review-for-discounts' ),
				'after_send_test_email'      => __( 'Test email has been sent successfully!', 'yith-woocommerce-review-for-discounts' ),
				'test_mail_wrong'            => __( 'Please insert a valid email address', 'yith-woocommerce-review-for-discounts' )
			) );

			wp_localize_script( 'ywrfd-admin', 'ywrfd_admin', $params );

		}

		/**
		 * Get placeholder reference content.
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function get_howto_content() {

			?>
            <div id="plugin-fw-wc">
                <h3>
					<?php _e( 'Placeholder list', 'yith-woocommerce-review-for-discounts' ); ?>
                </h3>
                <table class="form-table">
                    <tbody>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <b>{coupon_description}</b>
                        </th>
                        <td class="forminp">
							<?php _e( 'How coupon works. This placeholder must be included.', 'yith-woocommerce-review-for-discounts' ); ?>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <b>{site_title}</b>
                        </th>
                        <td class="forminp">
							<?php _e( 'Site title', 'yith-woocommerce-review-for-discounts' ); ?>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <b>{customer_name}</b>
                        </th>
                        <td class="forminp">
							<?php _e( 'Customer\'s name', 'yith-woocommerce-review-for-discounts' ) ?>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <b>{customer_last_name}</b>
                        </th>
                        <td class="forminp">
							<?php _e( 'Customer\'s last name', 'yith-woocommerce-review-for-discounts' ) ?>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <b>{customer_email}</b>
                        </th>
                        <td class="forminp">
							<?php _e( 'Customer\'s email', 'yith-woocommerce-review-for-discounts' ) ?>
                        </td>
                    </tr>
                    <tr valign="top">
                        <th scope="row" class="titledesc">
                            <b>{product_name}</b>
                        </th>
                        <td class="forminp">
							<?php _e( 'Name of the reviewed product', 'yith-woocommerce-review-for-discounts' ) ?>
                        </td>
                    </tr>

					<?php if ( defined( 'YWRFD_PREMIUM' ) ) : ?>

                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <b>{total_reviews}</b>
                            </th>
                            <td class="forminp">
								<?php _e( 'Total reviews of an user', 'yith-woocommerce-review-for-discounts' ) ?>
                            </td>
                        </tr>

                        <tr valign="top">
                            <th scope="row" class="titledesc">
                                <b>{remaining_reviews}</b>
                            </th>
                            <td class="forminp">
								<?php _e( 'How many reviews the user has to write to achieve an objective', 'yith-woocommerce-review-for-discounts' ) ?>
                            </td>
                        </tr>

						<?php if ( $this->is_multivendor_active() ): ?>
                            <tr valign="top">
                                <th scope="row" class="titledesc">
                                    <b>{vendor_name}</b>
                                </th>
                                <td class="forminp">
									<?php _e( 'Name of the vendor', 'yith-woocommerce-review-for-discounts' ) ?>
                                </td>
                            </tr>
						<?php endif; ?>

						<?php if ( defined( 'YITH_FUNDS_PREMIUM' ) && YITH_FUNDS_PREMIUM ): ?>
                            <tr valign="top">
                                <th scope="row" class="titledesc">
                                    <b>{funds_amount}</b>
                                </th>
                                <td class="forminp">
									<?php _e( 'Amount of the funds', 'yith-woocommerce-review-for-discounts' ) ?>
                                </td>
                            </tr>
						<?php endif; ?>

					<?php endif; ?>
                    </tbody>
                </table>
            </div>
			<?php
		}

		/**
		 * Check if Comment moderation is required
		 *
		 * @since   1.0.0
		 * @return  bool
		 * @author  Alberto Ruggiero
		 */
		public function is_moderation_required() {

			$coupon_send = get_option( 'ywrfd_coupon_sending' );

			return ( $coupon_send == '' || $coupon_send == 'moderated' );

		}

		/**
		 * Advise if comment moderation is activated
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function set_notices() {

			if ( ! apply_filters( 'ywrfd_multivendor_rfd_active_notice', true ) ) {
				return;
			}

			if ( ! $this->is_advanced_reviews_active() ) {

				if ( $this->is_moderation_required() ) {

					if ( get_option( 'comment_moderation' ) == 0 && empty( $_COOKIE['ywrfd_warning_1'] ) ) {

						update_option( 'comment_moderation', 1 );
						?>
                        <div id="ywrfd-warning-1" class="notice notice-warning" style="position: relative;">
                            <p>
								<?php _e( 'Comment moderation has been enabled to make YITH WooCommerce Review for Discounts work correctly.', 'yith-woocommerce-review-for-discounts' ); ?>
                            </p>
                            <span class="notice-dismiss ywrfd-warning-1"></span>
                        </div>
						<?php
					}

				} else {

					if ( get_option( 'comment_moderation' ) == 1 && empty( $_COOKIE['ywrfd_warning_2'] ) ) {

						?>
                        <div id="ywrfd-warning-2" class="notice notice-warning" style="position: relative;">
                            <p>
								<?php printf( __( 'Comment moderation is enabled but is not essential to make YITH WooCommerce Review for Discounts work correctly. If you want to change this option click %s here %s', 'yith-woocommerce-review-for-discounts' ), '<a href="' . esc_url( admin_url( 'options-discussion.php' ) ) . '" target="_blank">', '</a>' ); ?>
                            </p>
                            <span class="notice-dismiss ywrfd-warning-2"></span>
                        </div>
						<?php

					}

				}

			} else {

				if ( $this->is_moderation_required() ) {

					if ( get_option( 'ywar_review_moderation' ) == 'no' && empty( $_COOKIE['ywrfd_warning_3'] ) ) {

						update_option( 'ywar_review_moderation', 'yes' );
						?>
                        <div id="ywrfd-warning-3" class="notice notice-warning" style="position: relative;">
                            <p>
								<?php _e( 'Comment moderation has been enabled to make YITH WooCommerce Review for Discounts work correctly.', 'yith-woocommerce-review-for-discounts' ); ?>
                            </p>
                            <span class="notice-dismiss ywrfd-warning-3"></span>
                        </div>
						<?php
					}

				} else {

					if ( get_option( 'ywar_review_moderation' ) == 'yes' && empty( $_COOKIE['ywrfd_warning_4'] ) ) {

						?>
                        <div id="ywrfd-warning-4" class="notice notice-warning" style="position: relative;">
                            <p>
								<?php printf( __( 'Comment moderation is enabled but is not essential to make YITH WooCommerce Review for Discounts work correctly. If you want to change this option click %s here %s', 'yith-woocommerce-review-for-discounts' ), '<a href="' . esc_url( add_query_arg( array( 'page' => 'yith_ywar_panel', 'tab' => 'premium' ), admin_url( 'admin.php' ) ) ) . '" target="_blank">', '</a>' ); ?>
                            </p>
                            <span class="notice-dismiss ywrfd-warning-4"></span>
                        </div>
						<?php

					}

				}

			}

		}

		/**
		 * Manages notice dismissing
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function dismissable_notice() {
			if ( ! wp_script_is( 'js-cookie', 'registered' ) ) {
				$suffix = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
				wp_register_script( 'js-cookie', WC()->plugin_url() . '/assets/js/js-cookie/js.cookie' . $suffix . '.js', array(), WC_VERSION, true );
			}

			wp_enqueue_script( 'js-cookie' );
			$js = "jQuery(document).on( 'click', '.ywrfd-warning-1', function(){jQuery( '#ywrfd-warning-1' ).animate({ opacity: 0.25, height: 'toggle' }, 650 );Cookies.set( 'ywrfd_warning_1', 'dismiss', {path: '/'} );}); ";
			$js .= "jQuery(document).on( 'click', '.ywrfd-warning-2', function(){jQuery( '#ywrfd-warning-2' ).animate({ opacity: 0.25, height: 'toggle' }, 650 );Cookies.set( 'ywrfd_warning_2', 'dismiss', {path: '/'} );}); ";
			$js .= "jQuery(document).on( 'click', '.ywrfd-warning-3', function(){jQuery( '#ywrfd-warning-3' ).animate({ opacity: 0.25, height: 'toggle' }, 650 );Cookies.set( 'ywrfd_warning_3', 'dismiss', {path: '/'} );}); ";
			$js .= "jQuery(document).on( 'click', '.ywrfd-warning-4', function(){jQuery( '#ywrfd-warning-4' ).animate({ opacity: 0.25, height: 'toggle' }, 650 );Cookies.set( 'ywrfd_warning_4', 'dismiss', {path: '/'} );});";
			wp_add_inline_script( 'js-cookie', $js );
		}

		/**
		 * On comment approvation
		 *
		 * @since   1.0.0
		 *
		 * @param   $comment
		 *
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function on_comment_approvation( $comment ) {

			if ( ! $this->user_already_commented( $comment ) && $this->is_moderation_required() && ! $this->comment_already_approved( $comment ) ) {

				$this->get_coupons( $comment );

			}

		}

		/**
		 * Check if the comment has already approved
		 *
		 * @since   1.0.0
		 *
		 * @param   $comment
		 *
		 * @return  bool
		 * @author  Alberto Ruggiero
		 */
		public function comment_already_approved( $comment ) {

			$result = get_comment_meta( $comment->comment_ID, '_ywrfd_approved', true );

			return $result;

		}

		/**
		 * Check if an user has already commented
		 *
		 * @since   1.0.0
		 *
		 * @param   $comment
		 *
		 * @return  bool
		 * @author  Alberto Ruggiero
		 */
		public function user_already_commented( $comment ) {

			$args = array(
				'author_email' => $comment->comment_author_email,
				'post_id'      => $comment->comment_post_ID,
				'status'       => apply_filters( 'ywrfd_comment_status', 'all' ),
				'count'        => true,

			);

			$comments = new WP_Comment_Query();

			$count = $comments->query( $args );

			if ( $count > 1 ) {

				return true;

			}

			return false;

		}

		/**
		 * Get coupons to be sent
		 *
		 * @since   1.0.0
		 *
		 * @param   $comment
		 *
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function get_coupons( $comment ) {

			if ( apply_filters( 'ywrfd_cannot_get_coupon', false, $comment ) ) {
				return;
			}

			if ( 'product' != get_post_type( $comment->comment_post_ID ) ) {
				return;
			}

			if ( $comment->comment_parent ) {
				return;
			}

			$product_id = $comment->comment_post_ID;
			$user_id    = $comment->user_id;
			$user_mail  = $comment->comment_author_email;

			$user_info = array(
				'nickname' => str_replace( ' ', '-', ( ( $user_id ) ? get_user_meta( $user_id, 'nickname', true ) : $comment->comment_author ) ),
				'email'    => $user_mail,
			);

			$discounts = $this->get_discounts( $product_id, $user_mail );

			if ( ! empty( $discounts ) ) {

				foreach ( $discounts as $discount ) {

					if ( $discount->discount_type == 'funds' ) {

						if ( is_user_logged_in() && defined( 'YITH_FUNDS_PREMIUM' ) && YITH_FUNDS_PREMIUM ) {
							$this->give_funds( $discount, $user_id, $product_id, $user_mail );
						}

					} else {

						$coupon_code  = $this->create_coupon( $discount, $user_info );
						$email_result = YWRFD_Emails()->prepare_coupon_mail( $user_id, $coupon_code, $discount->trigger, array( 'nickname' => $user_info['nickname'], 'product_id' => $product_id, 'total_reviews' => $discount->trigger_threshold ), $user_mail, $discount->vendor_id );

						if ( ! $email_result ) {
							$this->write_log( array(
								                  'coupon_code' => $coupon_code,
								                  'type'        => 'coupon_email'
							                  ) );
						}

					}

				}

			}

			update_comment_meta( $comment->comment_ID, '_ywrfd_approved', 1 );

			$this->notification_sending( $user_id, $user_mail, $user_info['nickname'], $product_id );

		}

		/**
		 * Creates a coupon with specific settings
		 *
		 * @since   1.0.0
		 *
		 * @param   $discount
		 * @param   $user_info
		 *
		 * @return  string
		 * @author  Alberto Ruggiero
		 */
		public function create_coupon( $discount, $user_info ) {

			$coupon_first_part  = apply_filters( 'ywrfd_coupon_code_first_part', $user_info['nickname'] );
			$coupon_separator   = apply_filters( 'ywrfd_coupon_code_separator', '-' );
			$coupon_second_part = apply_filters( 'ywrfd_coupon_code_second_part', current_time( 'YmdHis' ) );

			$coupon_code = $coupon_first_part . $coupon_separator . $coupon_second_part;

			$coupon_data = array(
				'post_title'     => $coupon_code,
				'post_author'    => apply_filters( 'ywrfd_set_coupon_author', 0, $discount->vendor_id ),
				'post_excerpt'   => $discount->description,
				//'post_date'      => date( "Y-m-d H:i:s", time() ),
				'post_status'    => 'publish',
				'comment_status' => 'closed',
				'ping_status'    => 'closed',
				'post_name'      => $coupon_code,
				'post_parent'    => 0,
				'menu_order'     => 0,
				'post_type'      => 'shop_coupon'
			);

			$coupon_id = wp_insert_post( $coupon_data );


			//Set coupon expiration date
			$expiry_date = '';
			if ( $discount->expiry_days > 0 && ! empty( $discount->expiry_days ) ) {
				$ve          = get_option( 'gmt_offset' ) > 0 ? '+' : '-';
				$expiry_date = date( 'Y-m-d', strtotime( '+' . $discount->expiry_days . ' days' . $ve . get_option( 'gmt_offset' ) . ' HOURS' ) );
			}

			//Set products to apply coupon
			$product_ids = '';
			if ( ! empty( $discount->product_ids ) ) {
				$product_ids = implode( ',', $discount->product_ids );
			}

			//Exclude products to apply coupon
			$excluded_product_ids = '';
			if ( ! empty( $discount->excluded_product_ids ) ) {
				$excluded_product_ids = implode( ',', $discount->excluded_product_ids );
			}

			//Set categories to apply coupon
			$product_categories = '';
			if ( ! empty( $discount->product_categories ) ) {
				$product_categories = implode( ',', $discount->product_categories );
			}

			//exclude categories to apply coupon
			$excluded_product_categories = '';
			if ( ! empty( $discount->excluded_product_categories ) ) {
				$excluded_product_categories = implode( ',', $discount->excluded_product_categories );
			}

			update_post_meta( $coupon_id, 'discount_type', $discount->discount_type );
			update_post_meta( $coupon_id, 'coupon_amount', $discount->coupon_amount );
			update_post_meta( $coupon_id, 'expiry_date', $expiry_date );
			update_post_meta( $coupon_id, 'free_shipping', $discount->free_shipping );
			update_post_meta( $coupon_id, 'individual_use', $discount->individual_use );
			update_post_meta( $coupon_id, 'product_ids', $product_ids );
			update_post_meta( $coupon_id, 'exclude_product_ids', $excluded_product_ids );
			update_post_meta( $coupon_id, 'product_categories', $product_categories );
			update_post_meta( $coupon_id, 'exclude_product_categories', $excluded_product_categories );
			update_post_meta( $coupon_id, 'minimum_amount', $discount->minimum_amount );
			update_post_meta( $coupon_id, 'maximum_amount', $discount->maximum_amount );
			update_post_meta( $coupon_id, 'usage_limit', 1 );
			update_post_meta( $coupon_id, 'usage_limit_per_user', 1 );
			update_post_meta( $coupon_id, 'customer_email', $user_info['email'] );

			do_action( 'ywrfd_additional_coupon_features', $coupon_id, $discount );


			if ( $discount->vendor_id != 0 ) {

				$vendor = yith_get_vendor( $discount->vendor_id, 'vendor' );
				update_post_meta( $coupon_id, 'vendor_id', $discount->vendor_id );

				if ( $product_ids == '' ) {
					$product_ids = implode( ',', $vendor->get_products() );
					update_post_meta( $coupon_id, 'product_ids', $product_ids );
				}
			}

			update_post_meta( $coupon_id, 'generated_by', 'ywrfd' );

			return $coupon_code;

		}

		/**
		 * Add the YWRFD_Coupon_Mail class to WooCommerce mail classes
		 *
		 * @since   1.0.0
		 *
		 * @param   $email_classes
		 *
		 * @return  array
		 * @author  Alberto Ruggiero
		 */
		public function add_ywrfd_custom_email( $email_classes ) {

			$email_classes['YWRFD_Coupon_Mail'] = include( 'includes/class-ywrfd-coupon-email.php' );

			return $email_classes;

		}

		/**
		 * Add premium strings for localization
		 *
		 * @since   1.0.0
		 *
		 * @param   $strings
		 *
		 * @return  array
		 * @author  Alberto Ruggiero
		 */
		public function admin_scripts_filter( $strings ) {

			$strings['comment_moderation_warning'] = __( 'This option cannot be modified because you have set YITH WooCommerce Review for Discounts to send coupons only after approval.', 'yith-woocommerce-review-for-discounts' );

			if ( $this->is_multivendor_active() ) {

				if ( function_exists( 'YWRFD_MultiVendor' ) && YWRFD_MultiVendor()->vendors_coupon_reviews_active() ) {

					$vendor               = yith_get_vendor( 'current', 'user' );
					$strings['vendor_id'] = $vendor->id;

				}

			}

			if ( $this->is_advanced_reviews_active() ) {

				$strings['ywar_active'] = true;

			}

			return $strings;

		}

		/**
		 * Trash expired coupons
		 *
		 * @since   1.0.0
		 *
		 * @param   $return
		 *
		 * @return  mixed
		 * @author  Alberto Ruggiero
		 */
		public function trash_expired_coupons( $return = false ) {

			$args = array(
				'post_type'      => 'shop_coupon',
				'post_status'    => 'publish',
				'posts_per_page' => - 1,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => 'generated_by',
						'value' => 'ywrfd',
					),
					array(
						'relation' => 'OR',
						array(
							'key'     => 'expiry_date',
							'value'   => date( 'Y-m-d', strtotime( "today" ) ),
							'compare' => '<',
							'type'    => 'DATE'
						),
						array(
							'key'     => 'usage_count',
							'value'   => 1,
							'compare' => '>='
						)
					)
				)
			);

			$query = new WP_Query( $args );
			$count = $query->post_count;

			if ( $query->have_posts() ) {

				while ( $query->have_posts() ) {

					$query->the_post();

					wp_trash_post( $query->post->ID );

				}

			}

			wp_reset_query();
			wp_reset_postdata();

			if ( $return ) {

				return $count;

			}

			return null;

		}

		/* === Multi Vendor Compatibility Functions === */

		/**
		 * Check if YITH WooCommerce Multi Vendor is active
		 *
		 * @since   1.0.0
		 * @return  bool
		 * @author  Alberto Ruggiero
		 */
		public function is_multivendor_active() {

			return defined( 'YITH_WPV_PREMIUM' ) && YITH_WPV_PREMIUM;

		}

		/**
		 * Initialize compatibility module for YITH WooCommerce Multi Vendor
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function init_multivendor_compatibility() {

			if ( $this->is_multivendor_active() ) {

				include_once( 'includes/class-ywrfd-multivendor.php' );

			}

		}

		/* === Email Templates Compatibility Functions === */

		/**
		 * Check if YITH WooCommerce Email Templates is active
		 *
		 * @since   1.0.0
		 * @return  bool
		 * @author  Alberto Ruggiero
		 */
		public function is_email_templates_active() {

			return defined( 'YITH_WCET_PREMIUM' ) && YITH_WCET_PREMIUM;

		}

		/**
		 * If is active YITH WooCommerce Email Templates, add YWRFD to list
		 *
		 * @since   1.0.0
		 *
		 * @param   $templates
		 *
		 * @return  array
		 * @author  Alberto Ruggiero
		 */
		public function add_yith_wcet_template( $templates ) {

			$templates[] = array(
				'id'   => 'yith-review-for-discounts',
				'name' => 'YITH WooCommerce Review for Discounts',
			);

			return $templates;

		}

		/* === Advanced Reviews Compatibility Functions === */

		/**
		 * Check if YITH WooCommerce Advanced Reviews is active
		 *
		 * @since   1.0.0
		 * @return  bool
		 * @author  Alberto Ruggiero
		 */
		public function is_advanced_reviews_active() {

			return defined( 'YITH_YWAR_PREMIUM' ) && YITH_YWAR_PREMIUM;

		}

		/**
		 * On comment approvation with YITH WooCommerce Advanced Reviews
		 *
		 * @since   1.0.0
		 *
		 * @param   $comment_id
		 * @param   $approved
		 *
		 * @return  void
		 * @author  Alberto Ruggiero
		 */
		public function on_comment_approvation_ywar( $comment_id, $approved ) {

			if ( $approved ) {

				$comment                       = new stdClass();
				$comment->comment_author       = get_post_meta( $comment_id, '_ywar_review_author', true );
				$comment->comment_author_email = get_post_meta( $comment_id, '_ywar_review_author_email', true );
				$comment->comment_post_ID      = get_post_meta( $comment_id, '_ywar_product_id', true );
				$comment->comment_parent       = wp_get_post_parent_id( $comment_id );
				$comment->user_id              = get_post_meta( $comment_id, '_ywar_review_user_id', true );

				if ( ! $this->user_already_commented_ywar( $comment ) && $this->is_moderation_required() ) {

					$this->get_coupons( $comment );

				}

			}

		}

		/**
		 * Check if an user has already commented with YITH WooCommerce Advanced Reviews
		 *
		 * @since   1.0.0
		 *
		 * @param   $comment
		 *
		 * @return  bool
		 * @author  Alberto Ruggiero
		 */
		public function user_already_commented_ywar( $comment ) {

			$args  = array(
				'post_type'      => 'ywar_reviews',
				'post_status'    => array( 'any', 'trash' ),
				'posts_per_page' => - 1,
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'     => '_ywar_review_author_email',
						'value'   => $comment->comment_author_email,
						'compare' => '='
					),
					array(
						'key'     => '_ywar_product_id',
						'value'   => $comment->comment_post_ID,
						'compare' => '='
					),
				)
			);
			$query = new WP_Query( $args );

			if ( $query->post_count > 1 ) {
				return true;
			}

			wp_reset_query();
			wp_reset_postdata();

			return false;

		}

		/* === Account Funds Compatibility Functions === */
		public function give_funds( $discount, $user_id, $product_id, $user_mail ) {

			$fund_user = new YITH_YWF_Customer( $user_id );
			$new_funds = $discount->coupon_amount + $fund_user->get_funds();

			$fund_user->set_funds( $new_funds );

			$log_args = array(
				'user_id'        => $user_id,
				'type_operation' => 'review',
				'fund_user'      => $discount->coupon_amount,
				'description'    => $discount->description
			);

			YWF_Log()->add_log( $log_args );
			$email_result = YWRFD_Fund_Emails()->prepare_coupon_mail( $user_id, $discount->trigger, array( 'product_id' => $product_id, 'total_reviews' => $discount->trigger_threshold, 'amount' => $discount->coupon_amount ), $user_mail, $discount->vendor_id );

			if ( ! $email_result ) {
				$this->write_log( array(
					                  'user_email' => $user_mail,
					                  'type'       => 'fund_email'
				                  ) );
			}

		}

		/* === YITH FRAMEWORK === */

		/**
		 * Register plugins for activation tab
		 *
		 * @since   2.0.0
		 * @return  void
		 * @author  Andrea Grillo <andrea.grillo@yithemes.com>
		 */
		public function register_plugin_for_activation() {
			if ( ! class_exists( 'YIT_Plugin_Licence' ) ) {
				require_once 'plugin-fw/licence/lib/yit-licence.php';
				require_once 'plugin-fw/licence/lib/yit-plugin-licence.php';
			}
			YIT_Plugin_Licence()->register( YWRFD_INIT, YWRFD_SECRET_KEY, YWRFD_SLUG );
		}

		/**
		 * Register plugins for update tab
		 *
		 * @since   2.0.0
		 * @return  void
		 * @author  Andrea Grillo <andrea.grillo@yithemes.com>
		 */
		public function register_plugin_for_updates() {
			if ( ! class_exists( 'YIT_Upgrade' ) ) {
				require_once( 'plugin-fw/lib/yit-upgrade.php' );
			}
			YIT_Upgrade()->register( YWRFD_SLUG, YWRFD_INIT );
		}

		/**
		 * Load plugin framework
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Andrea Grillo
		 * <andrea.grillo@yithemes.com>
		 */
		public function plugin_fw_loader() {
			if ( ! defined( 'YIT_CORE_PLUGIN' ) ) {
				global $plugin_fw_data;
				if ( ! empty( $plugin_fw_data ) ) {
					$plugin_fw_file = array_shift( $plugin_fw_data );
					require_once( $plugin_fw_file );
				}
			}
		}

		/**
		 * Get the premium landing uri
		 *
		 * @since   1.0.0
		 * @return  string The premium landing link
		 * @author  Andrea Grillo
		 * <andrea.grillo@yithemes.com>
		 */
		public function get_premium_landing_uri() {
			return defined( 'YITH_REFER_ID' ) ? $this->_premium_landing . '?refer_id=' . YITH_REFER_ID : $this->_premium_landing;
		}

		/**
		 * Action Links
		 *
		 * add the action links to plugin admin page
		 * @since   1.0.0
		 *
		 * @param   $links | links plugin array
		 *
		 * @return  mixed
		 * @author  Andrea Grillo <andrea.grillo@yithemes.com>
		 * @use     plugin_action_links_{$plugin_file_name}
		 */
		public function action_links( $links ) {

			$links = yith_add_action_links( $links, $this->_panel_page, true );

			return $links;

		}

		/**
		 * Plugin row meta
		 *
		 * add the action links to plugin admin page
		 *
		 * @since   1.0.0
		 *
		 * @param   $plugin_meta
		 * @param   $plugin_file
		 * @param   $plugin_data
		 * @param   $status
		 * @param   $init_file
		 *
		 * @return  array
		 * @author  Andrea Grillo <andrea.grillo@yithemes.com>
		 * @use     plugin_row_meta
		 */
		public function plugin_row_meta( $new_row_meta_args, $plugin_meta, $plugin_file, $plugin_data, $status, $init_file = 'YWRFD_INIT' ) {

			if ( defined( $init_file ) && constant( $init_file ) == $plugin_file ) {
				$new_row_meta_args['slug']       = YWRFD_SLUG;
				$new_row_meta_args['is_premium'] = true;
			}

			return $new_row_meta_args;

		}

	}

}