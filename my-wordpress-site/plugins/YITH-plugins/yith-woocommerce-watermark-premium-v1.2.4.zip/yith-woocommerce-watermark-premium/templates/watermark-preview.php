<?php
?>
<style>
    .ui-dialog-titlebar {
        font-size: 15px;
        border: none;
        border-bottom: 1px solid #cdcdcd;
    }
    .ui-dialog {
        width: auto!important;
    }
</style>
<div id="ywcwat_preview_image" title="<?php _e( 'Preview', 'yith-woocommerce-watermark' );?>" style="text-align: center;">
    <img alt="preview" style="display: none;"/>
</div>
