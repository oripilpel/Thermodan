<?php
$html_tag = !empty( $section_html_tag ) ? $section_html_tag : 'p';
?>

</<?php echo $html_tag; ?>>