<p><?php _ex( 'While you visit our site, we’ll track:', 'Privacy Policy Content', 'yith-woocommerce-membership' ) ?></p>
<p><?php _ex( 'Information about memberships users belong to.', 'Privacy Policy Content', 'yith-woocommerce-membership' ) ?></p>
<p><?php _ex( 'The report of the memberships and the products in them downloaded by the user.', 'Privacy Policy Content', 'yith-woocommerce-membership' ) ?></p>
