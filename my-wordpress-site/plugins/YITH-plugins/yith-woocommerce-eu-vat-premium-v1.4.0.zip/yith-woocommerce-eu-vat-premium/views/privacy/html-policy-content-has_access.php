<p><?php _ex( 'Members of our team have access to the information you provide us. For example, both Administrators and Shop Managers can access:', 'Privacy Policy Content', 'yith-woocommerce-eu-vat' ) ?></p>

<ul>
    <li><?php _ex( 'Customer information like your name, email address, and billing and shipping information', 'Privacy Policy Content', 'yith-woocommerce-eu-vat' ); ?></li>
</ul>