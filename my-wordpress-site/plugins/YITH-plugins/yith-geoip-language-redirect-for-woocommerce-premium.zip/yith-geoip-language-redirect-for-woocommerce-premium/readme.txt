=== YITH GeoIP Language Redirect for WooCommerce ===

Contributors: yithemes
Tags:
Requires at least: 4.0
Tested up to: 4.9.6
Stable tag: 1.0.4
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html/

Redirects your pages to another urls from specific countries.

== Description ==
The admin can handle what pages could be redirected to another pages to users from specific countries. Just select the country, the origin and destination page for redirects the pages.

= Features: =
- Make any URL of the website redirect to a specific URL based on the users country of origin. Admin can set either one or more origin countries.
- Once Redirect, choose whether users can go back to the previous page or not.
- Based WordPress logic, make one of the files on the website redirect to a specific URL file on the users country of origin. Admin can set either one or more origin countries.
- Redirect traffic coming from one country to a specific page.

= Premium features: =
- Make an entire category/taxonomy of the website redirect to a specific URL based on the users country of origin. Admin can set either one or more origin countries.
- Choose whether to make each option work only on mobile, desktop or both of them.
- Choose the cookie duration
- Choose to exclude some IP addresses from the rules set it


= Premium Live Demo =
Do you want to discover all plugin features? Would you like to try it?

Visit our **[test sandbox](http://plugins.yithemes.com/yith-geoip-language-redirect-for-woocommerce/)**
By accessing our testing platform, you will be able to discover all plugin features and test it as your prefer, both in back end and in front end.

What are you waiting for, visit the official "**[live demo](http://plugins.yithemes.com/yith-geoip-language-redirect-for-woocommerce/)**" of the plugin and click on "LAUNCH ADMIN DEMO" link that you find in the topbar to make test our plugin right now.

= Languages =

Also abalable in:

* English (default), Italian, Dutch and Spanish

== Frequently Asked Questions ==

= Can redirect all media files? =

No, it depends on the rule you want to create. For example, you can redirect image to another image but image to audio or video is not possible. WordPress logic have different way to load images, we can�t handle html output for it. However redirect video or auido to image can be possible, whenever you make use of the shortcode that WordPress facilitates for it.

== Screenshots ==

== Installation ==

**Important**: First of all, you have to download and activate [WooCommerce](https://wordpress.org/plugins/woocommerce) plugin, because without it YITH GeoIP Language Redirect for WooCommerce cannot work.

1. Unzip the downloaded zip file.
2. Upload the plugin folder into the `wp-content/plugins/` directory of your WordPress site.
3. Activate `YITH GeoIP Language Redirect for WooCommerce` from Plugins page.

== Changelog ==

= 1.0.4 - Released: May, 28 - 2018 =

* New: WooCommerce 3.4 compatibility
* New: WordPress 4.9.6 compatibility
* New: GDPR compliance
* Updated: plugin framework to latest revision
* Updated: dutch language


= 1.0.3 - Released: Apr, 24 - 2018 =

* New: Spanish translation
* New: Italian translation
* New: Dutch translation

= 1.0.2 - Released: Jan, 30 - 2018 =

* New: Support to WooCommercer 3.3.x version.
* Update: YITH Plugin Framework 3.0.11
* Tweak: Added filter to avoid attachments redirect.

= 1.0.1 - Released: Oct, 05 - 2017 =

* Tweak: Improve redirects with subdomains.
* Fix: Minor issues.

= 1.0.0 =

* Initial release

