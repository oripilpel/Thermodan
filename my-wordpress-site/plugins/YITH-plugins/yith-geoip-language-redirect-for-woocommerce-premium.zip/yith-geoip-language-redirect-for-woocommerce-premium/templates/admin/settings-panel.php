<form id="yith_wcgeoip_settings_form"
      method="post">

    <table class="form-table">
        <tr>
            <th scope="row"><?php echo __( 'Exclude IP', 'yith-geoip-language-redirect-for-woocommerce' ); ?> :</th>
            <td>
                <input type="hidden" style=""
                       name="list_exclude_ips"
                       id="list_exclude_ips"
                       class="yith_wcgeoip_add_ip_field"
                       value="<?php
				       if ( is_array( $list_exclude_ips ) ) {
					       foreach ( $list_exclude_ips as $key => $exclude_ip ) {
						       if ( $key != count( $list_exclude_ips ) & ! empty( $exclude_ip ) ) {
							       echo $exclude_ip . ',';
						       } else {
							       echo $exclude_ip;
						       }
					       }
				       } ?>">
                <input type="text" style=""
                       name="add_exclude_ips"
                       id="add_exclude_ips"
                       class="yith_wcgeoip_add_ip_field"
                       value=""
                       placeholder="0.0.0.0, 1.1.1.1">
                <button id="add_exclude_ips_button" class="yith_wcgeoip_add_ips_button button"> <?php echo __( 'Add' ); ?> </button>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php echo __( 'List of IPs that will be ignored by the rules...', 'yith-geoip-language-redirect-for-woocommerce' );
				?></th>
            <td>
                <div class="tagchecklist">
					<?php
					if ( is_array( $list_exclude_ips ) ) {
						foreach ( $list_exclude_ips as $key => $exclude_ip ) {
							if ( ! empty( ! empty( $exclude_ip ) ) ) {
								?>
                                <span>
                                <button class="ntdelbutton" id="ip_check-num-<?php echo $key; ?>">
                                    <span class="remove-tag-icon" aria-hidden="true"></span>
                                    <span class="screen-reader-text"><?php echo __( 'Remove excluded IP', 'yith-geoip-language-redirect-for-woocommerce' ); ?></span>
                                </button>
                                <p class="ip_text"
                                   data-value="<?php echo $exclude_ip; ?>"><?php echo $exclude_ip; ?></p>
                            </span>
								<?php
							}
						}
					}
					?>
                </div>
            </td>
        </tr>
        <tr>
            <th scope="row"><?php echo __( 'Cookie duration', 'yith-geoip-language-redirect-for-woocommerce' ); ?>:</th>
            <td>

                <select
                    id="cookie_duration"
                    name="once_redirect_cookie_duration">
                    <option value="1-min"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '1-min' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '1 min.', 'yith-event-tickets-for-woocommerce' ) ?></option>
                    <option value="2-min"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '2-min' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '2 min.', 'yith-event-tickets-for-woocommerce' ) ?></option>
                    <option value="10-min"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '10-min' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '10 min.', 'yith-event-tickets-for-woocommerce' ) ?></option>
                    <option value="15-min"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '15-min' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '15 min.', 'yith-event-tickets-for-woocommerce' ) ?></option>
                    <option value="20-min"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '20-min' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '20 min.', 'yith-event-tickets-for-woocommerce' ) ?></option>
                    <option value="30-min"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '30-min' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '30 min.', 'yith-event-tickets-for-woocommerce' ) ?></option>
                    <option value="45-min"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '45-min' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '45 min.', 'yith-event-tickets-for-woocommerce' ) ?></option>
                    <option value="1-hour"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '1-hour' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '1 hour', 'yith-event-tickets-for-woocommerce' ) ?></option>
                    <option value="2-hour"
						<?php if ( isset( $once_redirect_cookie_duration ) ) {
							if ( '2-hour' == $once_redirect_cookie_duration ) {
								echo 'selected';
							}
						} ?>
                    ><?php echo __( '2 hours', 'yith-event-tickets-for-woocommerce' ) ?></option>
                </select>
            </td>
        </tr>
        <tfoot>
        <tr>
            <td>
                <button id="save_ip_excluded_list" class="button save_rules button-primary button-large">
					<?php _e( 'Save changes', 'yith-geoip-language-redirect-for-woocommerce' ); ?>
                </button>
            </td>
        </tr>
        </tfoot>
    </table>
</form>

