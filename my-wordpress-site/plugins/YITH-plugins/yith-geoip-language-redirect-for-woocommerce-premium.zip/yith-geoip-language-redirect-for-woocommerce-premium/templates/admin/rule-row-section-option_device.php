<td class="form-field _rules_<?php echo $index ?>_device_field option-device">
    <select name="_rules[<?php echo $index ?>][device]"
            id="_rules_<?php echo $index ?>_device"
            class="_rule">
		<?php
		foreach ( $device_list as $key => $device_item ) {
			$device = isset( $rule_row['device'] ) ? $rule_row['device'] : '';
			?>
            <option value="<?php echo $key ?>" <?php selected( $device == $key ) ?> ><?php echo $device_item['text']; ?></option>
			<?php
		}
		?>
    </select>
</td>
