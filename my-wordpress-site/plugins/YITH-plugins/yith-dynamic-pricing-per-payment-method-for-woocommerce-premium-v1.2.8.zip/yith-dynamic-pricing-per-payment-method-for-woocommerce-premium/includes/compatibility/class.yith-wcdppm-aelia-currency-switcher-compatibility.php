<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCDPPM_VERSION' ) ) {
    exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_WCDPPM_Aelia_Currency_Switcher_Compatibility
 * @package    Yithemes
 * @since      Version 1.1.5
 * @author     Your Inspiration Themes
 *
 */
if ( ! class_exists( 'YITH_WCDPPM_Aelia_Currency_Switcher_Compatibility' ) ) {

    class YITH_WCDPPM_Aelia_Currency_Switcher_Compatibility
    {
        protected  static $base_currency;

        public function __construct()
        {

            add_filter('yith_wcdppm_get_amount_rule',array($this,'convert_base_currency_amount_to_user_currency'),10,2);
            add_filter('yith_wcdppm_get_tax_fee_rule',array($this,'convert_base_currency_amount_to_user_currency'),10,2);
        }


        /**
         * Convenience method. Returns WooCommerce base currency.
         *
         * @return string
         * @since 1.1.5
         */
        public static function base_currency() {

            if ( empty( self::$base_currency ) ) {
                self::$base_currency = get_option( 'woocommerce_currency' );
            }

            return self::$base_currency;
        }


        /**
         * Convert the amount from base currency to current currency
         *
         * @param float                  $amount
         * @param WC_Product $product
         *
         * @return float
         * @author Lorenzo Giuffrida
         * @since  1.1.5
         */
        public function convert_base_currency_amount_to_user_currency ( $funds, $currency = null ) {

            $funds = self::get_amount_in_currency ( $funds, null, $currency );

            return $funds;
        }

        /**
         * Basic integration with WooCommerce Currency Switcher, developed by Aelia
         * (https://aelia.co). This method can be used by any 3rd party plugin to
         * return prices converted to the active currency.
         *
         * @param double $amount        The source price.
         * @param string $to_currency   The target currency. If empty, the active currency
         *                              will be taken.
         * @param string $from_currency The source currency. If empty, WooCommerce base
         *                              currency will be taken.
         *
         * @return double The price converted from source to destination currency.
         * @author Aelia <support@aelia.co>
         * @link   https://aelia.co
         * @since  1.1.5
         */
        public static function get_amount_in_currency( $amount, $to_currency = null, $from_currency = null ) {


            if ( empty( $from_currency ) ) {
                $from_currency = self::base_currency();
            }
            if ( empty( $to_currency ) ) {
                $to_currency = get_woocommerce_currency();
            }

            return apply_filters( 'wc_aelia_cs_convert', $amount, $from_currency, $to_currency );
        }



    }
}

return new YITH_WCDPPM_Aelia_Currency_Switcher_Compatibility();
