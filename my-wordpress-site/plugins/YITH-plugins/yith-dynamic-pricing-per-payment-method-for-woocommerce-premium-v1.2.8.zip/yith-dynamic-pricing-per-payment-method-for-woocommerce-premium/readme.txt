=== YITH Dynamic Princing per Payment Method for WooCommerce Premium  ===

== Changelog ==

= Version 1.2.8 - Released: Oct 24, 2019 =

* Tweak : get payment method fee
* Update: Plugin-Fw

= Version 1.2.7 - Released: Oct 24, 2019 =

* New: Support to WooCommerce 3.8.0 RC1
* New: Allow apply rules also to guest users
* Update: Plugin-Fw

= Version 1.2.6 - Released: May 22, 2019 =

* New: Support to WooCommerce 3.7.0 RC2
* Update: Plugin-Fw

= Version 1.2.5 - Released: May 22, 2019 =

* New: Support to WooCommerce 3.6.0 RC1
* Update: Plugin-Fw
* Update. Italian language
* Update: Spanish language

= Version 1.2.4 - Released: Apr 11, 2019 =

* New: Support to WooCommerce 3.6.0 RC1
* Update: Plugin-Fw
* Update. Italian language
* Update: Spanish language

= Version 1.2.3 - Released: Feb 18, 2019 =

* Fix: Disable tax on rule if set it to none
* Update: Dutch translation
* Update: Update Plugin-fw
* Dev: filter yith_wcdppm_order_fee_title

= Version 1.2.2 - Released: Dic 31, 2018 =

* Tweak: Add tax when order complete
* Tweak: Improve get total row payment method
* Update: Dutch translation
* Update: Plugin framework
* Update: .pot language

= Version 1.2.1 - Released: Oct 23, 2018 =

* Update: Dutch translation
* Update: Plugin framework

= Version 1.2.0 - Released: May 24, 2018 =

* New: Support to WordPress 4.9.6
* New: Support to WooCommerce 3.4.0
* New: Persian translation thanks to Sadra
* Fix: Problem if the rule doesn't have tax
* Fix: Display tax when the product has the tax included
* Update: Spanish language
* Update: Plugin Framework
* Dev : yith_wcdppm_recalculate_taxes_and_total

= Version 1.1.12 - Released: Feb 09, 2018 =

* New: support to WordPress 4.9.4
* New: support to WooCommerce 3.3.1
* New: Spanish translation
* Fix: recalculate tax amount in order
* Fix: calculate totals in order

= Version 1.1.11 - Released: Feb 01, 2018 =

* New: support to WordPress 4.9.2
* New: support to WooCommerce 3.3.0
* New: Italian translation
* New: Dutch translation
* Update: plugin framework 3.0.11

= Version 1.1.10 - Released: Jan 08, 2018 =

* New: added condition to check if in current page plugin scripts should be loaded
* Fix: get amount and the tax if the amount doesn't include tax
* Fix: check if exists payment method
* Dev: added filter yith_wcgpf_order_total_with_shipping

= Version 1.1.9 - Released: Oct 10, 2017 =

* New: Support to WooCommerce 3.2.0 RC2
* Update: Plugin core

= Version 1.1.8 - Released: Sep 19, 2017 =

* Fix - Problem with order total
* Fix - Compatibility issue with  WooCommerce version < 3.0.0
* Dev - Filter yith_wcdppm_add_tax_in_amount

= Version 1.1.7 - Released: Aug 28, 2017 =

* New - apply rule if products are in cart
* Fix - amount if aelia currency switcher plugin is installed
* Dev - filter yith_wcdppm_localized_frontend_dom

= Version 1.1.6 - Released: Aug 10, 2017 =

* New - compatibility with YITH WooCommerce Account Funds
* Fix - Price rounding issue on checkout page

= Version 1.1.5 - Released: Jul 18, 2017 =

* New - compatibility with Aelia Currency Switcher Plugin
* Dev - added new filter yith_wcdppm_get_amount_rule
* Dev - added new filter yith_wcdppm_get_tax_fee_rule

= Version 1.1.4 - Released: Jun 12, 2017 =

* New - possibility to apply tax to rule using WooCommerce tax class
* New - added fee row to order received page
* Fix - total amount issues

= Version 1.1.3 - Released: May 16, 2017 =

* New - apply tax to a payment method fee
* Update - YITH Plugin Framework
* Fix - total amount issues
* Dev - filter yith_wcdppm_gateway_title added 

= Version 1.1.2 - Released: Mar 21, 2017 =

* Fix - total amount with Paypal gateway

= Version 1.1.1 - Released: Mar 17, 2017 =

* New - support to WooCommerce 3.0.0-RC1
* Update - YITH Plugin Framework

= Version 1.1.0 - Released: Mar 09, 2017 =

* New - support to WooCommerce 2.7.0-RC1
* Update - YITH Plugin Framework
* Fix - total amount issues
* Fix - pagination on payment method rules

= Version 1.0.1 - Released: Jan 20, 2017 =

* Fix - textdomain.

= Version 1.0.0 - Released: Jan 18, 2017 =

* Initial release