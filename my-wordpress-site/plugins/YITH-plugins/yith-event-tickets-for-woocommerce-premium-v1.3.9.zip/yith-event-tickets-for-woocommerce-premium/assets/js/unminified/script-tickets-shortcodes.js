jQuery(document).ready(function ($) {

    (function ($) {
        $.each(['show', 'hide'], function (i, ev) {
            var el = $.fn[ev];
            $.fn[ev] = function () {
                this.trigger(ev);
                return el.apply(this, arguments);
            };
        });
    })(jQuery);

    init_calendar();

    init_map();

    init_check_in();

    function init_map() {

        if (typeof google != "undefined") {
            var maps = new Array();

            $('.yith_wcevti_address_map').each(function (i) {
                $(this).attr('id', '_map_event_ticket_' + i);
                var latlng = new google.maps.LatLng($(this).data('latitude'), $(this).data('longitude'));
                var options = {
                    zoom: 15,
                    center: latlng,
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                };

                var map = new google.maps.Map(this, options);

                var marker = new google.maps.Marker(
                    {
                        position: latlng,
                        map: map,
                    });

                maps[$(this).attr('id')] = map;

            });

            $('.woocommerce-Tabs-panel').each(function () {
                $(this).on('show', function () {
                    var display = ($(this).css('display') === 'none' ||
                    $(this).css('display') === '') ? 'block' : 'none';
                    $(this).css('display', display);
                    var latlng = new google.maps.LatLng($(this).find('.yith_wcevti_address_map').data('latitude'), $(this).find('.yith_wcevti_address_map').data('longitude'));
                    var map_id = $(this).find('.yith_wcevti_address_map').attr('id');

                    if (typeof(map_id) != 'undefined') {
                        google.maps.event.trigger(maps[map_id], 'resize');
                        maps[map_id].setCenter(latlng);
                    }
                });
            });
        }
    }
    
    function init_calendar() {
        // Post_data must be have our action registered when we call wp_ajax hooks, in this case 'load_calendar_events_action';.
        var post_data =
        {
            action: 'load_calendar_events_action'
        };

        $('.monthly').each(function (i) {
            $(this).attr('id',  'mycalendar' + i);

            if (typeof $(this).monthly === "function") {
                $(this).monthly({
                    mode: 'event',
                    eventList: false,
                    linkCalendarToEventUrl: true,
                    jsonUrl: event_tickets_shortcodes.ajaxurl + '?' + jQuery.param(post_data),
                    dataType: 'json'
                });

                $.ajax({
                    type: "POST",
                    data: post_data,
                    url: event_tickets_shortcodes.ajaxurl
                }).success(function (data) {

                });
            }
        });
    }

    function init_check_in() {

        if (typeof yith_wcevti_frontend_checkin_shortcode_tickets != "undefined") {
            var product_id = yith_wcevti_frontend_checkin_shortcode_tickets.product.id;

            $('#check_in_form_dialog').find('.message').text(yith_wcevti_frontend_checkin_shortcode_tickets.messages.start_check);

            $('.check_in_panel').on('click', '.toggle', function (event) {
                var $row_panel = $(this).closest('.list_row_panel');
                $row_panel.find('.row_more_info').toggle();

                var caret = '';
                if ($(this).hasClass('fa-caret-down')) {
                    $(this).removeClass('fa-caret-down');
                    caret = 'up';
                }
                if ($(this).hasClass('fa-caret-up')) {
                    $(this).removeClass('fa-caret-up');
                    caret = 'down';
                }

                $(this).addClass('fa-caret-' + caret);
            });

            $('.check_in_panel').on('click', '.make_checkin_button', function (event) {
                event.preventDefault();

                var $container = $('body'),
                    $check_in_button = $(this),
                    $check_in_form_dialog = $('#check_in_form_dialog'),
                    $list_row_panel = $check_in_button.closest('.list_row_panel');

                $check_in_form_dialog.block({message: null, overlayCSS: {background: "#fff", opacity: .6}});
                $list_row_panel.block({message: null, overlayCSS: {background: "#fff", opacity: .6}});
                ;

                $container.scrollTop(
                    $check_in_form_dialog.offset().top - 300
                );

                $.ajax({
                    url: yith_wcevti_frontend_checkin_shortcode_tickets.api_rest.base_url + 'change_ticket_status/',
                    method: 'POST',
                    beforeSend: function (xhr) {
                        xhr.setRequestHeader('X-WP-Nonce', yith_wcevti_frontend_checkin_shortcode_tickets.api_rest.nonce);
                    },
                    data: {
                        id: $(this).data('ticket_id'),
                        status: $(this).data('status')
                    }
                }).done(function (data) {
                    $check_in_form_dialog.unblock();
                    $list_row_panel.unblock();
                    $list_row_panel.find('.ticket_status_icon').removeClass('fa-hand-paper-o status_pending_check');
                    $list_row_panel.find('.ticket_status_icon').addClass('fa-thumbs-o-up status_checked');
                    $check_in_button.remove();

                    $check_in_form_dialog.find('.message').text('#' + $check_in_button.data('ticket_id') + ' checked');
                    $check_in_form_dialog.addClass('checked_dialog_panel');
                    $list_row_panel.find('.row_more_info').show();
                    $('.back_search_button').show();
                }).fail(function (jqXHR, textStatus, errorThrown) {
                })

            });

            $('.search_ticket_button').click(function (event) {
                event.preventDefault();
                var $search_ticket_number = $('.search_ticket_number'),
                    $check_in_form_dialog = $('#check_in_form_dialog'),
                    ticket_number = $search_ticket_number.val(),
                    product_id = yith_wcevti_frontend_checkin_shortcode_tickets.product.id;
                    $check_in_form_dialog.removeClass('founded_and_checked_dialog_panel warning_dialog_panel checked_dialog_panel');
                if( 0 < ticket_number.length){
                    $check_in_form_dialog.block({message: null, overlayCSS: {background: "#fff", opacity: .6}});
                    $.ajax({
                        url: yith_wcevti_frontend_checkin_shortcode_tickets.api_rest.base_url + 'search_ticket/',
                        method: 'POST',
                        beforeSend: function (xhr) {
                            xhr.setRequestHeader('X-WP-Nonce', yith_wcevti_frontend_checkin_shortcode_tickets.api_rest.nonce);
                        },
                        data: {
                            ticket_number: ticket_number,
                            product_id: product_id
                        }
                    }).done(function (data) {
                        $check_in_form_dialog.unblock();
                        $('.list_row_panel').remove();
                        $check_in_form_dialog.find('.message').text(data.message[data.message_key]);
                        console.log(data.message_key);
                        if(data.message_key == 'founded') {
                            $check_in_form_dialog.removeClass('warning_dialog_panel checked_dialog_panel');
                            $check_in_form_dialog.addClass('checked_dialog_panel');
                        }else if(data.message_key == 'founded_and_checked'){
                            $check_in_form_dialog.removeClass('warning_dialog_panel checked_dialog_panel');
                            $check_in_form_dialog.addClass('founded_and_checked_dialog_panel');
                        }else if(data.message_key == 'not_founded' || data.message_key == 'not_belong'){
                            $check_in_form_dialog.removeClass('founded_and_checked_dialog_panel checked_dialog_panel');
                            $check_in_form_dialog.addClass('warning_dialog_panel');
                        }
                        if(data.request) {
                            $('.list_rows_panel').append(data.template_output);
                        }
                        $('.list_row_panel').find('.row_more_info').show();

                        if($('#enable_automatic_checkin').is(':checked')){
                            var $make_checking_button = $('.list_row_panel').find('.make_checkin_button');
                            $make_checking_button.each(function (event) {
                              $(this).trigger('click');
                            });
                            $search_ticket_number.val('');
                            $search_ticket_number.focus();
                        }
                        $('.back_search_button').show();
                        //$('.search_ticket_value').val(ticket_number);
                    }).fail(function (jqXHR, textStatus, errorThrown) {
                    });

                } else {

                }
            });

            $('.search_ticket_number').keyup(function (event) {
                if(0 == $(this).val().length){
                    if(0 <= $('.list_row_panel').length){
                        $('.list_row_panel').remove();
                        load_tickets_purchased();
                        $('.back_search_button').hide();
                        $('#check_in_form_dialog').removeClass('warning_dialog_panel founded_and_checked_dialog_panel checked_dialog_panel')
                    }
                }
            });

            $('.back_search_button').click(function (event) {
                event.preventDefault();
                $('.search_ticket_number').val('');
                $('.list_row_panel').remove();
                load_tickets_purchased();
                $('.back_search_button').hide();
                $('#check_in_form_dialog').removeClass('warning_dialog_panel checked_dialog_panel founded_and_checked_dialog_panel')
            });

            $('.export_csv_ahref').click(function (event) {
                event.preventDefault();
                var product_id = yith_wcevti_frontend_checkin_shortcode_tickets.product.id,
                    $search_ticket_number = $('.search_ticket_number'),
                    ticket_number = $search_ticket_number.val();
                window.open(yith_wcevti_frontend_checkin_shortcode_tickets.api_rest.export_csv_action  + '&ticket_number=' + ticket_number + '&product_id=' + product_id);
            });

            $('.print_result').click(function (event) {
                event.preventDefault();
                var product_id = yith_wcevti_frontend_checkin_shortcode_tickets.product.id,
                    $search_ticket_number = $('.search_ticket_number'),
                    ticket_number = $search_ticket_number.val();
                window.open(yith_wcevti_frontend_checkin_shortcode_tickets.api_rest.print_table_action + '&ticket_number=' + ticket_number + '&product_id=' + product_id);
            });
            load_tickets_purchased();
        }
    }

    function load_tickets_purchased() {
        var $check_in_form_dialog = $('#check_in_form_dialog'),
            product_id = yith_wcevti_frontend_checkin_shortcode_tickets.product.id;

        $check_in_form_dialog.block({message: null, overlayCSS: {background: "#fff", opacity: .6}});

        $.ajax({
            url: yith_wcevti_frontend_checkin_shortcode_tickets.api_rest.base_url + 'load_tickets/',
            method: 'POST',
            beforeSend: function (xhr) {
                xhr.setRequestHeader('X-WP-Nonce', yith_wcevti_frontend_checkin_shortcode_tickets.api_rest.nonce);
            },
            data:{
                product_id: product_id
            }
        }).done(function (data) {
            $check_in_form_dialog.unblock();
            $check_in_form_dialog.find('.message').text(data.message[data.message_key]);
            if(data.request) {
                $('.list_rows_panel').append(data.template_output);
            }
        }).fail(function (jqXHR, textStatus, errorThrown) {

        });


    }
    
});
