/* Yith Event Tickets for WooCommerce*/

jQuery(document).ready(function($){

    $('.wp-list-table').on('click', '.make_checkin_button', function (event) {
        event.preventDefault();
        var $make_checkin_button = $(this),
        $ticket_row = $make_checkin_button.closest('.type-ticket'),
        $ticket_colum_status = $ticket_row.find('.column-ticket-status');

        $make_checkin_button.block({message:null, overlayCSS:{background:"#fff",opacity:.6}});
        $ticket_colum_status.block({message:null, overlayCSS:{background:"#fff",opacity:.6}});

        $.ajax({
            url: yith_wcevti_admin_table_tickets.api_rest.base_url + 'change_ticket_status/',
            method: 'POST',
            beforeSend: function(xhr) {
                xhr.setRequestHeader( 'X-WP-Nonce', yith_wcevti_admin_table_tickets.api_rest.nonce);
            },
            data: {
                id : $(this).data('ticket_id'),
                status: $(this).data('status')
            }
        }).done(function(data) {
            console.log('finish');
            $make_checkin_button.unblock();
            $ticket_colum_status.unblock();
            $ticket_colum_status.find('.ticket_status_icon').removeClass('fa-hand-paper-o status_pending_check');
            $ticket_colum_status.find('.ticket_status_icon').addClass('fa-thumbs-o-up status_checked');
            $make_checkin_button.remove();
        }).fail(function(jqXHR, textStatus, errorThrown) {
        })
    });
});