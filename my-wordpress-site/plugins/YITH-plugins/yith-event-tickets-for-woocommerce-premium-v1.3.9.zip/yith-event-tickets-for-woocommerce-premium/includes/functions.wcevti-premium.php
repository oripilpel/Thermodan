<?php
if ( ! function_exists( 'yith_wcevti_get_service_stocks' ) ) {
    /**
     * return array stocks services from product.
     *
     * @param $post_id
     */
    function yith_wcevti_get_service_stocks( $post_id ) {
        global $wpdb;

        $query = 'select meta_key from ' . $wpdb->postmeta .
            ' where meta_key like "service_%_stock"
            and post_id=' . $post_id;

        $stocks_services = $wpdb->get_results( $query, ARRAY_A );

        return $stocks_services;

    }
}
if ( ! function_exists( 'yith_wcevti_clean_service_stock' ) ) {
    /**
     * Loop current_stock services from event and compare with news service to add. If no coincidence, remove from database.
     *
     * @param $post_id
     * @param $services
     * @param $current_stock
     */
    function yith_wcevti_clean_service_stock( $post_id, $services, $current_stock ) {
        foreach ( $current_stock as $service_stock ) {
            $delete = true;
            foreach ( $services as $service ) {
                if ( 'select' == $service['_type'] ) {
                    foreach ( $service['_select'] as $select ) {
                        if ( '_service_' . $select['_label'] . '_stock' == $service_stock['meta_key'] ) {
                            $delete = false;
                        }
                    }
                }
                if ( 'checkbox' == $service['_type'] ) {
                    if ( '_service_' . $service['_label'] . '_stock' == $service_stock['meta_key'] ) {
                        $delete = false;
                    }
                }
            }
            if ( $delete ) {
                delete_post_meta( $post_id, $service_stock['meta_key'] );
            }
        }
    }
}
if ( ! function_exists( 'yith_wcevti_get_dates' ) ) {
    /**
     * Return the date data on monthly library format.
     * @return  date formatted to monthly.js external library
     */
    function yith_wcevti_get_dates() {
        $dates = array(
            'monthly' => array()
        );

        $args = array(
            'numberposts' => - 1,
            'meta_key'    => '_start_date_picker',
            'post_type'   => 'product'
        );

        $posts = get_posts( $args );

        foreach ( $posts as $post ) {
            $product       = wc_get_product( $post->ID );
            $message_stock = ( null != $product->get_stock_quantity() ) ? ' (' . $product->get_stock_quantity() . ' ' . __( 'in stock', 'yith-event-tickets-for-woocommerce' ) . ')' : ''; //@since 1.1.3

            if ( empty( $message_stock ) ) {
                if ( ! $product->is_in_stock() ) {
                    $message_stock = ' '. __( '(out of stock)', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.8
                } else {
                    $message_stock = ' '. __( '(in stock)', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.8
                }
            }

            $visible_option = get_option( 'yith_wcte_visible_expired' );
            $print_date     = true;

            if ( $visible_option == 'yes' ) {
                $start_date_event = yit_get_prop( $product, '_start_date_picker' );
                $start_time_event = yit_get_prop( $product, '_start_time_picker' );

                $print_date = yith_check_if_expired_event( $start_date_event, $start_time_event, 'expired' );
            }
            if ( $print_date ) {
                $event = array(
                    'id'        => $post->ID,
                    'name'      => apply_filters( 'yith_wcevti_get_event_name', $post->post_title . $message_stock, $post->post_title, $message_stock ),
                    'startdate' => get_post_meta( $post->ID, '_start_date_picker', true ),
                    'enddate'   => get_post_meta( $post->ID, '_end_date_picker', true ),
                    'starttime' => get_post_meta( $post->ID, '_start_time_picker', true ),
                    'endtime'   => get_post_meta( $post->ID, '_end_time_picker', true ),
                    'color'     => '#7BA7CE',
                    'url'       => get_permalink( $post->ID )
                );

                $dates['monthly'][] = $event;
            }
        }

        return $dates;
    }
}
if ( ! function_exists( 'yith_wcevti_check_service_sold' ) ) {
    /**TODO
     * Check stock service for Event Ticket
     *
     * @param $post_id the id of Event.
     * @param $service the service to check stock
     *
     * @return $value Different string accord to result 'sold'...
     */
    function yith_wcevti_check_service_sold( $post_id, $service, $check_service, $order_items_from_product = '' ) {
        global $wpdb;
        if ( ! empty( $service['_label'] ) ) {
            $label = sanitize_title( $service['_label']);
            $label = strtolower($label);
            $label = str_replace( ' ', '-', $label);

            //If service is select...
            if ( 'select' == $service['_type'] ) {
                //Check if service was buyed...
                if ( isset( $service['_value'][ $label  ] ) ) {
                    $queryexist    = 'select count(meta_value) from ' . $wpdb->postmeta .
                        ' where meta_key like "_service_' . $label . '_%range"
                                      and meta_value = ' . $service['_value'][  $label ] .
                        ' and post_id =' . $post_id;
                    $count_service = $wpdb->get_var( $queryexist );
                    if ( 0 < $count_service ) {
                        $check_service = 'sold';
                    }
                }

                if ( '' != $order_items_from_product ) {
                    foreach ( $order_items_from_product as $order_item ) {
                        if ( $order_item['label'] == '_service_' . $label ) {
                            if ( isset( $service['_value'] ) ) {
                                if ( $order_item['value'] == $service['_value'][  $label ] ) {
                                    $check_service = 'sold';
                                }
                            }
                        }
                    }
                }
            }
        }


        return $check_service;
    }
}
if ( ! function_exists( 'yith_wcevti_add_service_sold' ) ) {
    /**
     * Add service sold on product postmeta.
     *
     * @param $post_id the id product
     * @param $service the service to add
     */
    function yith_wcevti_add_service_sold( $post_id, $service ) {
        global $wpdb;
        $product = wc_get_product( $post_id );
        //Check if select service...
        if ( ! empty( $service['_label'] ) ) {

            switch ( $service['_type'] ) {

                case 'select':
                    if ( ! empty( $service['_value'][ sanitize_title( $service['_label'] ) ] ) ) {

                        //Get the count of the current services added for index...
                        $querycount = 'select count(meta_value) from ' . $wpdb->postmeta .
                            ' where meta_key like "_service_' . $service['_label'] . '_%range"
                                                    and post_id =' . $post_id;
                        $count      = $wpdb->get_var( $querycount );

                        yit_save_prop( $product, '_service_' . $service['_label'] . '_' . $count ++ . '_range', $service['_value'][ sanitize_title( $service['_label'] ) ] );
                        //update_post_meta($post_id, '_service_' . $service['_label'] . '_' . $count++ . '_range', $service['_value'][sanitize_title($service['_label'])]);
                    } else {

                        //Behavior simple select just the same than checkbox service.
                        add_check_service_sold( $post_id, $service );
                    }
                    break;

                case 'checkbox':
                    if ( isset( $service['_value'] ) ) {
                        add_check_service_sold( $post_id, $service );
                    }
                    break;
            }
        }
    }
}
if ( ! function_exists( 'yith_wcevti_remove_service_sold' ) ) {
    /**
     * Remove service sold on product postmeta.
     *
     * @param $post_id the id product
     * @param $service the service to add
     */
    function yith_wcevti_remove_service_sold( $order_id ) {
        global $wpdb;
        $order = wc_get_order( $order_id );

        $order_items = $order->get_items();

        foreach ( $order_items as $key => $order_item ) {
            $product_type = wc_get_order_item_meta( $key, '_product_type' );
            if ( 'ticket-event' == $product_type ) {
                $product_id = wc_get_order_item_meta( $key, '_product_id' );

                $query_purchased_services = 'select meta_key, meta_value from ' . $wpdb->prefix . 'woocommerce_order_itemmeta' .
                    ' where meta_key like "_service_%"' .
                    ' and order_item_id = ' . $key;

                $purchased_services    = $wpdb->get_results( $query_purchased_services );
                $services_from_product = get_post_meta( $product_id, '_services', true );
                foreach ( $purchased_services as $purchased_service ) {
                    $type_service  = '';
                    $service_label = substr( $purchased_service->meta_key, strlen( '_service_' ) );

                    foreach ( $services_from_product as $service_from_product ) {
                        if ( $service_label == $service_from_product['_label'] ) {
                            $type_service = $service_from_product['_type'];
                            break;
                        }
                        if ( isset( $service_from_product['_select'] ) ) {
                            foreach ( $service_from_product['_select'] as $service_from_product_item ) {
                                if ( $service_label == $service_from_product_item['_label'] ) {
                                    $type_service = $service_from_product['_type'];
                                    break;
                                }
                            }
                        }
                    }

                    if ( 'select' == $type_service ) {

                        $remove_purchased_select_service = 'delete from ' . $wpdb->postmeta .
                            ' where meta_key like "' . $purchased_service->meta_key . '_%range"
					                                     and meta_value = ' . $purchased_service->meta_value .
                            ' and post_id = ' . $product_id;

                        $wpdb->get_var( $remove_purchased_select_service );
                    }
                    if ( 'checkbox' == $type_service ) {
                        $querycount = 'select meta_key, meta_value from ' . $wpdb->postmeta .
                            ' where meta_key like "' . $purchased_service->meta_key . '_range"
                                     and post_id =' . $product_id;

                        $check_stock = $wpdb->get_results( $querycount );

                        if ( isset( $check_stock[0] ) ) {
                            if ( 0 != $check_stock[0]->meta_value ) {
                                $meta_value = $check_stock[0]->meta_value - 1;
                                update_post_meta( $product_id, $check_stock[0]->meta_key, $meta_value );
                            }
                        }
                    }
                }
            }
        }
    }
}

if ( ! function_exists( 'add_check_service_sold' ) ) {
    /**
     * Add service check sold on product postmeta.
     *
     * @param $post_id the product id
     * @param $service the check service
     */
    function add_check_service_sold( $post_id, $service ) {
        global $wpdb;
        $product = wc_get_product( $post_id );

        //Get the value check service, this will contain the current check service buyed...
        $querycheck  = 'select meta_value from ' . $wpdb->postmeta .
            ' where meta_key like "_service_' . $service['_label'] . '_%range"
                                                    and post_id =' . $post_id;
        $check_stock = $wpdb->get_var( $querycheck );

        //If service not buyed, we initilize variable to starting add.
        if ( empty( $check_stock ) ) {
            $check_stock = 0;
        }
        $check_stock = $check_stock + $service['_quantity'];

        yit_save_prop( $product, '_service_' . $service['_label'] . '_range', $check_stock );
        //update_post_meta($post_id, '_service_' . $service['_label'] . '_range', $check_stock);
    }
}
if ( ! function_exists( 'yith_wcevti_count_services_cart' ) ) {
    /**
     * Loop cart finding same product service and return array with number services for each product...
     * For example...:
     * [302] = array( [seats] = 2, [vegetarian] = 5)
     * [420] = array( [vip] = 8, [platea] = 85)
     * @return array
     */
    function yith_wcevti_count_services_cart() {
        $cart           = WC()->cart;
        $count_services = array();

        foreach ( $cart->cart_contents as $key => $cart_item ) {
            $product_id = $cart_item['product_id'];

            if ( 'ticket-event' == $cart_item['data']->get_type() & isset( $cart_item['_field_service'] ) ) {

                if ( isset( $cart_item['_field_service']['_services'] ) ) {
                    if ( is_array( $cart_item['_field_service']['_services'] ) ) {
                        foreach ( $cart_item['_field_service']['_services'] as $service ) {
                            $count_services = yith_wcevti_count_service( $product_id, $service, $count_services, $cart_item['quantity'] );
                        }
                    }
                }
            }
        }

        return $count_services;
    }
}
if ( ! function_exists( 'yith_wcevti_count_services_product' ) ) {
    /**
     * Count the services that product belong
     *
     * @param $product_id
     * @param $array_services
     *
     * @return $count_product_service
     */
    function yith_wcevti_count_services_product( $product_id, $array_services ) {
        $count_product_service[ $product_id ] = array();
        foreach ( $array_services as $item_services ) {
            foreach ( $item_services as $service ) {
                $count_product_service = yith_wcevti_count_service( $product_id, $service, $count_product_service );
            }
        }

        $services_cart = yith_wcevti_count_services_cart();

        foreach ( $count_product_service as $id_product_a => &$product_services_a ) {
            foreach ( $services_cart as $id_product_b => $product_services_b ) {
                if ( $id_product_a == $id_product_b ) {
                    foreach ( $product_services_a as $label_a => &$service_a ) {
                        foreach ( $product_services_b as $label_b => $service_b ) {
                            if ( $label_b == $label_a ) {
                                $service_a['_value'] += $service_b['_value'];
                            }
                        }
                    }
                }
            }
        }

        return $count_product_service;
    }
}
if ( ! function_exists( 'yith_wcevti_count_service' ) ) {
    /** Ask for the service pass by param and if have some condition add the sum value to especific part to array returned
     *
     * @param $product_id
     * @param $service
     * @param $count_product_service
     *
     * @return mixed
     */
    function yith_wcevti_count_service( $product_id, $service, $count_product_service, $quantity = 1 ) {
        $label     = $service['_label'];
        $add_count = false;

        if ( ! empty( $label ) ) {
            switch ( $service['_type'] ) {
                case 'select':
                    $add_count = true;
                    break;
                case 'checkbox':
                    if ( isset( $service['_value'] ) ) {
                        if ( 'on' == $service['_value'] ) {
                            $add_count = true;
                        }
                    }
                    break;
            }

            if ( $add_count ) {

                if ( isset( $count_product_service[ $product_id ][ $label ] ) ) {
                    $count_product_service[ $product_id ][ $label ]['_value'] = $count_product_service[ $product_id ][ $label ]['_value'] + $quantity;
                } else {
                    $count_product_service[ $product_id ][ $label ] = array(
                        '_type'  => $service['_type'],
                        '_value' => $quantity
                    );
                    if ( 'select' == $service['_type'] & ! isset( $service['_value'] ) ) {
                        $count_product_service[ $product_id ][ $label ]['_simple'] = 'on';
                    }
                }
            }
        }

        return $count_product_service;
    }
}
if ( ! function_exists( 'yith_wcevti_exist_service_cart' ) ) {
    /**
     * Check if service with expecific value exist on the cart...
     *
     * @param $product_id the product id to check service
     * @param $service    to check
     *
     * @return true or false
     */
    function yith_wcevti_exist_service_cart( $product_id, $service ) {
        $exist = false;

        $cart_contents = WC()->cart->cart_contents;
        if ( ! empty( $cart_contents ) ) {
            foreach ( $cart_contents as $cart_item ) {
                if ( $product_id == $cart_item['product_id'] ) {
                    if ( isset( $cart_item['_field_service']['_services'] ) ) {
                        if ( is_array( $cart_item['_field_service']['_services'] ) ) {
                            foreach ( $cart_item['_field_service']['_services'] as $i_service ) {
                                if ( 'select' == $i_service['_type'] && $service['_label'] == $i_service['_label'] ) {
                                    $label = sanitize_title( $service['_label'] );
                                    if ( isset( $service['_value'][ $label ] ) && $service['_value'][ $label ] == $i_service['_value'][ $label ] ) {
                                        $exist = true;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        return $exist;
    }
}
if ( ! function_exists( 'yith_wcevti_check_current_stock_service' ) ) {
    /**
     * Check the stock limit and compare if is greater than services what we want add.
     *
     * @param $post_id
     * @param $label
     * @param $value
     * @param $check_stock
     *
     * @return string
     */
    function yith_wcevti_check_current_stock_service( $post_id, $label, $service, $check_stock ) {
        global $wpdb;
        $value = $service['_value'];

        switch ( $service['_type'] ) {
            case 'select':
                if ( ! isset( $service['_simple'] ) ) {
                    //Get the current number services buyed...
                    $querycount = 'select count(meta_value) from ' . $wpdb->postmeta .
                        ' where meta_key like "_service_' . $label . '_%range"
                    and post_id=' . $post_id;
                    $count      = $wpdb->get_var( $querycount );
                    //Add to number service what we want add.
                    $value += $count;
                } else {
                    //Get the number of service buyed...
                    $querycount = 'select meta_value from ' . $wpdb->postmeta .
                        ' where meta_key like "_service_' . $label . '_%range"
                                     and post_id =' . $post_id;
                    $count      = $wpdb->get_var( $querycount );

                    $value += $count;
                }
                break;
            case 'checkbox':
                //Get the number of service buyed...
                $querycount = 'select meta_value from ' . $wpdb->postmeta .
                    ' where meta_key like "_service_' . $label . '_%range"
                                     and post_id =' . $post_id;
                $count      = $wpdb->get_var( $querycount );

                $value += $count;
                break;
        }
        //Get the limit stock define by admin...
        $stock = get_post_meta( $post_id, '_service_' . $label . '_stock', true );
        //Check if greater than services number what we want to add.
        if ( $stock < $value && ! empty( $stock ) ) {
            $check_stock = 'out_range';
        }

        return $check_stock;
    }
}
if ( ! function_exists( 'yith_wcevti_get_order_item_meta' ) ) {
    /**
     * Get order item meta from $oder_item_id
     *
     * @param $order_item_id
     * @param $meta_key
     *
     * @return array|bool
     */
    function yith_wcevti_get_order_item_meta( $order_item_id, $meta_key ) {
        global $wpdb;

        $meta_key_arg     = '_' . $meta_key . '%';
        $query            = 'select * from ' . $wpdb->prefix . 'woocommerce_order_itemmeta' .
            ' where order_item_id = %d and meta_key like %s';
        $order_item_metas = $wpdb->get_results( $wpdb->prepare( $query, $order_item_id, $meta_key_arg ) );
        $item_metas       = array();
        foreach ( $order_item_metas as $order_item_meta ) {
            $item_meta = array(
                'label' => substr( $order_item_meta->meta_key, strlen( '_' . $meta_key . '_' ), strlen( $order_item_meta->meta_key ) ),
                'value' => $order_item_meta->meta_value
            );
            array_push( $item_metas, $item_meta );
        }

        return ! empty( $order_item_metas ) ? $item_metas : false;
    }
}

if ( ! function_exists( 'yith_wcevti_get_orders_from_product' ) ) {
    /** Get all orders filtered by product. After count the numbers of tickets from each order.
     *  Some users can have diferents orders from the same tickets. This is a reason to loop our return table,
     *  to sum the current tickets purchased with the current order on loop.
     *
     * @param $id_product
     *
     * @return array
     */
    function yith_wcevti_get_orders_from_product( $id_product ) {
        $order_items = yith_wcevti_get_orders_items_from_product( $id_product );

        $purchased_data = array();
        foreach ( $order_items as $item ) {
            $customer      = get_post_meta( $item->order_id, '_customer_user', true );
            $customer_user = $customer ? get_userdata( $customer ) : false;
            $order         = wc_get_order( $item->order_id );
            if ( ! $customer_user ) {
                $customer_user                      = new WP_User();
                $customer_user->data->ID            = 0;
                $customer_user->data->user_nicename = yit_get_prop( $order, 'billing_first_name' );
                $customer_user->data->display_name  = yit_get_prop( $order, 'billing_first_name' );
            }

            $order_status = yit_get_prop( $order, 'status' );
            if ( 'processing' == $order_status || 'completed' == $order_status ) {
                if ( $customer_user && ! isset( $purchased_data[ $customer_user->data->user_nicename ] ) ) {
                    $purchased_data[ $customer_user->data->user_nicename ] = array(
                        'display_name'      => $customer_user->data->display_name,
                        'avatar'            => get_avatar( $customer_user->data->ID ),
                        'purchased_tickets' => 1
                    );
                } elseif ( $customer_user ) {
                    $purchased_data[ $customer_user->data->user_nicename ]['purchased_tickets'] ++;
                }
            }
        }

        return $purchased_data;
    }
}
if ( ! function_exists( 'yith_wecvti_get_reduced_price' ) ) {
    /**
     * Return the reduced price from $product_id
     *
     * @param $product_id
     *
     * @return float|int
     */
    function yith_wecvti_get_reduced_price( $product_id ) {
        $to_subtract = 0;

        $product            = wc_get_product( $product_id );
        $reduced_price_data = yit_get_prop( $product, '_reduce_ticket', true );
        $price_product      = $product->get_price();

        if ( 'fixed' == $reduced_price_data['_event_type'] ) {
            $to_subtract = $reduced_price_data['_price_fixed'];
        } elseif ( 'percentage' == $reduced_price_data['_event_type'] ) {
            $to_subtract = ( $price_product * $reduced_price_data['_price_relative'] ) / 100;
        }


        return $to_subtract;
    }
}

if ( ! function_exists( 'yith_wcevti_before_cart_service_validation' ) ) {
    /**
     * Ask if the current services can be added.
     *
     * @param $product_id
     * @param $services_customer
     *
     * @return bool
     */
    function yith_wcevti_before_cart_service_validation( $product_id, $services_customer ) {
        $can_add_to_cart = true;
        $count_services  = yith_wcevti_count_services_product( $product_id, $services_customer );
        foreach ( $services_customer as $service_customer ) {
            foreach ( $service_customer as $service ) {
                $check_stock = '';
                if ( isset( $count_services[ $product_id ][ $service['_label'] ] ) ) {
                    $check_stock = yith_wcevti_check_current_stock_service( $product_id, $service['_label'], $count_services[ $product_id ][ $service['_label'] ], '' );
                }
                if ( 'out_range' != $check_stock | 'sold' != $check_stock ) {
                    $check_stock = yith_wcevti_check_service_sold( $product_id, $service, $check_stock );
                }

                switch ( $check_stock ) {
                    case 'sold':
                        $can_add_to_cart = false;
                        wc_add_notice( $service['_label'] . ' :' . __( ' Service selected have been already bought!', 'yith-event-tickets-for-woocommerce' ), 'error' ); //@since 1.1.3
                        break;
                    case  'out_range':
                        $can_add_to_cart = false;
                        wc_add_notice( apply_filters( 'yith_wcevti_print_service_out_range', $service['_label'] . ' :' . __( ' Service its out ranged!', 'yith-event-tickets-for-woocommerce' ), $service), 'error' ); //@since 1.1.3
                        break;
                    default:
                        $can_add_to_cart = $can_add_to_cart;
                        break;
                }

            }
        }

        return $can_add_to_cart;
    }
}
if ( ! function_exists( 'yith_wcevti_checkout_service_validation' ) ) {
    /**
     * Set the validation on checkout process
     * @return bool
     */
    function yith_wcevti_checkout_service_validation() {
        $update         = true;
        $cart           = WC()->cart;
        $count_services = yith_wcevti_count_services_cart();
        $check_service  = 'free';
        foreach ( $cart->cart_contents as $cart_item ) {
            $services = isset( $cart_item['_field_service']['_services'] ) ? $cart_item['_field_service']['_services'] : array();
            if ( isset( $cart_item['_field_service'] ) && ! empty( $services ) ) {
                foreach ( $services as $service ) {
                    $product_id = $cart_item['product_id'];
                    $label      = $service['_label'];
                    if ( isset( $count_services[ $product_id ][ $label ] ) ) {
                        $count_service_item = $count_services[ $product_id ][ $label ];
                        $check_service      = yith_wcevti_check_current_stock_service( $product_id, $label, $count_service_item, $check_service );
                    }
                    if ( 'out_range' != $check_service | 'sold' != $check_service ) {
                        $check_service = yith_wcevti_check_service_sold( $cart_item['product_id'], $service, $check_service );
                    } else {
                        break;
                    }
                }
            }
        }

        switch ( $check_service ) {
            case 'sold':
                $update = false;
                wc_add_notice( __( 'Some of the selected services have been already bought!', 'yith-event-tickets-for-woocommerce' ), 'error' ); //@since 1.1.3
                break;
            case  'out_range':
                $update = false;
                wc_add_notice( __( 'You are trying to add more services than available!', 'yith-event-tickets-for-woocommerce' ), 'error' ); //@since 1.1.3
                break;
            default:
                $update = true;
                break;
        }

        return $update;
    }
}
if ( ! function_exists( 'yith_wcevti_cart_session_services' ) ) {
    /**
     * Set the validation on checkout process
     * @return bool
     */
    function yith_wcevti_cart_session_services( $cart ) {
        $order_id       = absint( WC()->session->get( 'order_awaiting_payment' ) );
        $count_services = yith_wcevti_count_services_cart();
        $check_service  = 'free';
        if ( 0 != $order_id ) {
            $order        = wc_get_order( $order_id );
            $order_status = yit_get_prop( $order, 'status' );
            if ( 'pending' == $order_status ) {
                $order_items = $order->get_items();
                foreach ( $cart->cart_contents as $cart_item_key => $cart_item ) {
                    $services = isset( $cart_item['_field_service']['_services'] ) ? $cart_item['_field_service']['_services'] : array();
                    if ( isset( $cart_item['_field_service'] ) && ! empty( $services ) ) {
                        foreach ( $order_items as $key => $order_item ) {
                            if ( $order_item['product_id'] == $cart_item['product_id'] ) {
                                foreach ( $services as $service ) {
                                    $product_id = $cart_item['product_id'];
                                    $label      = $service['_label'];
                                    if ( isset( $count_services[ $product_id ][ $label ] ) ) {
                                        $count_service_item = $count_services[ $product_id ][ $label ];
                                        $check_service      = yith_wcevti_check_current_stock_service( $product_id, $label, $count_service_item, $check_service );
                                    }
                                    if ( 'select' == $service['_type'] ) {
                                        $service_value = isset( $service['_value'][ sanitize_title( $service['_label'] ) ] ) ? $service['_value'][ sanitize_title( $service['_label'] ) ] : '';

                                        $value = wc_get_order_item_meta( $key, '_service_' . $service['_label'], true );
                                        if ( $value == $service_value & ! empty( $service_value ) ) {
                                            $product    = wc_get_product( $product_id );
                                            $title      = yit_get_prop( $product, 'title' );
                                            $order_text = '<a href="' . $order->get_checkout_payment_url() . '"> #' . $order_id . '</a>';

                                            WC()->cart->remove_cart_item( $cart_item_key );
                                            $text_notice = sprintf( __( 'The service "%s %s" chosen on "%s" has been added to order %s' ), $service['_label'], $value, $title, $order_text ); //@since 1.1.6
                                            wc_add_notice( $text_notice );
                                        }
                                    } else if ( 'out_range' == $check_service ) {
                                        $product    = wc_get_product( $product_id );
                                        $title      = yit_get_prop( $product, 'title' );
                                        $order_text = '<a href="' . $order->get_checkout_payment_url() . '"> #' . $order_id . '</a>';

                                        WC()->cart->remove_cart_item( $cart_item_key );
                                        $text_notice = sprintf( __( 'The service "%s" chosen on "%s" has been added to order %s' ), $service['_label'], $title, $order_text ); //@since 1.1.6
                                        wc_add_notice( $text_notice );
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
if ( ! function_exists( 'yith_wcevti_get_services' ) ) {
    /**
     * Get the services post meta from post
     *
     * @param $post
     *
     * @return array
     */
    function yith_wcevti_get_services( $post ) {
        $post_meta = get_post_meta( $post->ID, '', true );

        if ( version_compare( WC()->version, '3.0.0', '<' ) ) {
            $item_meta = $post_meta;
        } else {
            $item_meta = isset( $post_meta['wc_order_item_id'][0] ) ? wc_get_order_item_meta( $post_meta['wc_order_item_id'][0], '', $single = true ) : array();
        }

        $services = array();
        foreach ( $item_meta as $key => $meta ) {
            if ( preg_match( '/service_/i', $key ) ) {
                $label = str_replace( array( 'service_' ), '', $key );
                $label = str_replace( array( '_' ), '', $label );

                //TODO future feature, display surcharge on ticket template...
                //$surcharge = yith_wcevti_get_service_surcharge($post_meta['wc_event_id'][0], $label);
                $value = $meta[0];

                $services[] = array(
                    $label => $value
                );
            }
        }

        return $services;
    }
}
if ( ! function_exists( 'get_service_surcharge' ) ) {
    /**
     * Return the surchage service
     *
     * @param $product_id
     * @param $service
     *
     * @return string
     */
    function yith_wcevti_get_service_surcharge( $product_id, $service ) {
        $surcharge = '';
        $product   = wc_get_product( $product_id );
        $services  = yit_get_prop( $product, '_services', true );
        //See service_row.php structure to display surcharge...
        if ( is_array( $services ) ) {
            foreach ( $services as $index => $service_item ) {
                switch ( $service_item['_type'] ) {
                    case 'checkbox':

                        break;
                    case 'select':

                        break;
                }
            }
        }

        return $surcharge;
    }
}

if ( ! function_exists( 'yith_wcevti_get_orders_items_from_product' ) ) {
    /** Get order items especified from $id_product
     *
     * @param $id_product
     *
     * @return array|null|object
     * @since 1.1.2
     */
    function yith_wcevti_get_orders_items_from_product( $id_product ) {
        global $wpdb;

        $query = 'select oi.* from ' . $wpdb->prefix . 'woocommerce_order_itemmeta oim' .
            ' left join ' . $wpdb->prefix . 'woocommerce_order_items oi' .
            ' on  oim.order_item_id = oi.order_item_id' .
            ' where meta_key = "_product_id" and meta_value = %d';

        $order_items = $wpdb->get_results( $wpdb->prepare( $query, $id_product ) );

        return $order_items;
    }
}
if ( ! function_exists( 'yith_wcevti_get_order_services_sold_from_ticket' ) ) {
    //TODO
    function yith_wcevti_get_order_services_sold_from_ticket( $id_product ) {
        $order_items = yith_wcevti_get_orders_items_from_product( $id_product );
        global $wpdb;
        $services_sold = array();
        foreach ( $order_items as $order_item ) {
            $status = get_post_status( $order_item->order_id );
            if ( 'wc-completed' == $status | 'wc-processing' == $status | 'wc-pending' == $status | 'wc-on-hold' == $status ) {

                $query = 'select meta_key, meta_value from ' . $wpdb->prefix . 'woocommerce_order_itemmeta' .
                    ' where order_item_id = %d and meta_key like %s';

                $services = $wpdb->get_results( $wpdb->prepare( $query, $order_item->order_item_id, "_service_%" ), ARRAY_N );

                foreach ( $services as $service ) {
                    $services_sold[] = array(
                        'label' => $service[0],
                        'value' => $service[1]
                    );
                }
            }
        }

        return $services_sold;

    }
}
if ( ! function_exists( 'yith_wcevti_get_order_item_from_ticket' ) ) {
    /**
     * Get order item from $id_ticket
     *
     * @param $id_ticket
     *
     * @return bool
     * @since 1.1.2
     */
    function yith_wcevti_get_order_item_from_ticket( $id_ticket ) {
        global $wpdb;

        $query = 'select order_item_id from ' . $wpdb->prefix . 'woocommerce_order_itemmeta' .
            ' where meta_key like "_event_id" and meta_value = %d';

        $order_item = $wpdb->get_results( $wpdb->prepare( $query, $id_ticket ) );

        return isset( $order_item[0]->order_item_id ) ? $order_item[0]->order_item_id : false;
    }
}
if ( ! function_exists( 'yith_wcevti_get_user_purchased_from' ) ) {
    /**
     * Can get user purchased from order or ticket
     *
     * @param $id
     * @param $from
     *
     * @return array
     * @since 1.1.3
     */
    function yith_wcevti_get_user_purchased_from( $id, $from ) {
        $user_purchased = array();
        switch ( $from ) {
            case 'order':
                $user_purchased = yith_wcevti_get_user_from_order( wc_get_order( $id ) );
                break;
            case 'ticket':
                $order_id       = yith_wecvti_get_order_id_by_order_item_id( $id );
                $user_purchased = yith_wcevti_get_user_from_order( wc_get_order( $order_id ) );
                break;
        }

        return $user_purchased;
    }
}
if ( ! function_exists( 'yith_wcevti_get_tickets_purchased_by_product' ) ) {
    /**
     * Get the tickets purchased from $id_product
     *
     * @param $id_product
     *
     * @return array
     * @since 1.1.3
     */
    function yith_wcevti_get_tickets_purchased_by_product( $id_product ) {
        $order_items = yith_wcevti_get_orders_items_from_product( $id_product );

        return yith_wcevti_get_tickets_purchased_by_order_items( $order_items );
    }
}
if ( ! function_exists( 'yith_wcevti_get_tickets_purchased_by_order_items' ) ) {
    /**
     * Get tickets purchased from $order_items
     *
     * @param $order_items
     *
     * @return array
     * @since 1.1.3
     */
    function yith_wcevti_get_tickets_purchased_by_order_items( $order_items ) {
        $tickets_purchased = array();

        foreach ( $order_items as $order_item ) {
            $order_item_id = isset( $order_item->order_item_id ) ? $order_item->order_item_id : yit_get_prop( $order_item, 'id' );

            $event_id    = wc_get_order_item_meta( $order_item_id, '_event_id' );
            $ticket_item = yith_wcevti_get_ticket_purchased( $event_id, $order_item_id );

            if ( 0 != $event_id ) {
                array_push( $tickets_purchased, $ticket_item );
            }
        }

        return apply_filters('yith_wcevt_get_tickets_purchased_by_order_items',$tickets_purchased,$order_items);
    }
}
if ( ! function_exists( 'yith_wcevti_get_ticket_purchased' ) ) {
    /**
     * Get ticket puschased from $order_item_id. If is empty get the $order_item_id from $event_id
     *
     * @param        $event_id
     * @param string $order_item_id
     *
     * @return array|bool
     * @since 1.1.3
     */
    function yith_wcevti_get_ticket_purchased( $event_id, $order_item_id = '' ) {
        $ticket_item = array();
        if ( get_post_status( $event_id ) ) {
            $order_item_id = empty( $order_item_id ) ? yith_wcevti_get_order_item_from_ticket( $event_id ) : $order_item_id;
            if ( $order_item_id ) {
                $order_id = get_post_meta( $event_id, 'wc_order_id', true );
                $order = wc_get_order( $order_id );
                $product_id = wc_get_order_item_meta( $order_item_id, '_product_id' );
                $product = wc_get_product( $product_id );

                $ticket_item = array(
                    'event_id'      => $event_id,
                    'product_id'    => $product_id,
                    'sku'           => $product->get_sku(),
                    'order_id'      => $order_id,
                    'order_number'  => $order_id,
                    'ticket_status' => get_post_status( $event_id ),
                    'purchased_by'  => yith_wcevti_get_user_purchased_from( $order_item_id, 'ticket' ),
                    'fields'        => yith_wcevti_get_order_item_meta( $order_item_id, 'field' ),
                    'service'       => yith_wcevti_get_order_item_meta( $order_item_id, 'service' )
                );
            }
        }

        return ! empty( $ticket_item ) ? $ticket_item : false;
    }
}
if ( ! function_exists( 'yith_wcevti_get_ticket_purchased_template' ) ) {
    /**
     * Print on buffer the ticket purchased template row panel
     *
     * @param $ticket_purchased
     *
     * @return string
     * @since 1.1.3
     */
    function yith_wcevti_get_ticket_purchased_template( $ticket_purchased ) {
        if ( ! empty( $ticket_purchased ) ) {
            $ticket_status = isset( $ticket_purchased['ticket_status'] ) ? ( 'publish' != $ticket_purchased['ticket_status'] ) ? $ticket_purchased['ticket_status'] : 'yi-pending-check' : 'yi-pending-check';
            $ticket_id     = isset( $ticket_purchased['event_id'] ) ? $ticket_purchased['event_id'] : '';
            $purchased_by  = isset( $ticket_purchased['purchased_by'] ) ? $ticket_purchased['purchased_by'] : array();
            $fields        = isset( $ticket_purchased['fields'] ) ? $ticket_purchased['fields'] : array();
            $services      = isset( $ticket_purchased['service'] ) ? $ticket_purchased['service'] : array();

            $args = array(
                'ticket_status' => $ticket_status,
                'ticket_id'     => $ticket_id,
                'purchased_by'  => $purchased_by,
                'fields'        => $fields,
                'services'      => $services
            );

            ob_start();

            yith_wcevti_get_template( 'check_in_row_panel', $args, 'frontend' );

            return ob_get_clean();
        }
    }
}
if ( ! function_exists( 'yith_wcevti_get_tickets_purchased_template' ) ) {
    /**
     * Save in $output variable all rows tickets purchased templates.
     *
     * @param $tickets_purchased
     *
     * @return string
     * @since 1.1.3
     */
    function yith_wcevti_get_tickets_purchased_template( $tickets_purchased ) {
        $output = '';
        foreach ( $tickets_purchased as $ticket_purchased ) {
            $output .= yith_wcevti_get_ticket_purchased_template( $ticket_purchased );
        }

        return $output;
    }
}
if ( ! function_exists( 'yith_wecvti_update_ticket_status' ) ) {
    /**
     * Change ticket status.
     *
     * @param $id
     * @param $status
     *
     * @return false|int
     * @since 1.1.3
     */
    function yith_wecvti_update_ticket_status( $id, $status ) {
        global $wpdb;

        $updated = $wpdb->update( $wpdb->posts, array( 'post_status' => $status ), array( 'ID' => $id ) );

        if ( ! get_post_meta( $id, '_barcode_display_value_order', true ) ) {
            update_post_meta( $id, '_barcode_display_value_order', '' );
        }
        if ( ! get_post_meta( $id, '_barcode_display_value_ticket', true ) ) {
            update_post_meta( $id, '_barcode_display_value_ticket', '' );
        }
        if ( ! get_post_meta( $id, '_barcode_display_value_product', true ) ) {
            update_post_meta( $id, '_barcode_display_value_product', '' );
        }

        return $updated;
    }

}
if ( !function_exists('yith_wecvti_check_ticket_status')){
    function yith_wecvti_check_ticket_status( $id ){
        global $wpdb;

        $ticket_status = $wpdb->get_var("SELECT post_status FROM $wpdb->posts WHERE ID = $id");

        return $ticket_status;
    }
}
if ( ! function_exists( 'yith_wcevti_get_csv_list' ) ) {
    /**
     * Generate an array to can makes printable list to CSV.
     *
     * @param $data
     *
     * @return array
     */
    function yith_wcevti_get_csv_list( $data ) {

        if ( ! empty( $data['ticket_number'] ) ) {
            $output = YITH_Tickets_API_REST::search_ticket( $data );
        } else {
            $output = YITH_Tickets_API_REST::load_tickets( $data );
        }

        if ( isset( $data['delimiter'] ) && $data['delimiter'] == 'default'){
            $delimiter = ',';
        }
        else{
            $delimiter = 'yith_wcevti_delimiter';
        }
        $export           = get_post_meta( $data['product_id'], '_export', true );
        $disable_fields   = isset( $export['disable_fields'] ) ? ( 'on' == $export['disable_fields'] ) ? false : true : true;
        $disable_services = isset( $export['disable_services'] ) ? ( 'on' == $export['disable_services'] ) ? false : true : true;

        $tickets_purchased = isset( $output['tickets_purchased'] ) ? $output['tickets_purchased'] : array();

        $mail_template   = get_post_meta( $data['product_id'], '_mail_template', true );
        $barcode_options = isset($mail_template['data']) && ! empty( $mail_template['data']['barcode'] ) & 'on' == $mail_template['data']['barcode']['display'] ? $mail_template['data']['barcode'] : false;

        $list = array( 'columns' => '', 'rows' => array() );

        if ( 'on' == $barcode_options['display'] ) {
            $list['columns'] = 'barcode_value' . $delimiter;
        }

        $list ['columns'] .= 'event_id' . $delimiter . 'order_id' . $delimiter . 'order_number' . $delimiter . 'product_id' . $delimiter . 'sku' . $delimiter . 'ticket_status' . $delimiter . 'purchased_by';
        $list ['columns'] = apply_filters( 'yith_wcevt_get_csv_list_column',$list['columns'],$delimiter );
        $list['rows']     = array();

        foreach ( $tickets_purchased as $ticket_purchased ) {
            if( apply_filters( 'yith_wcevt_ticket_purchased_row',true,$ticket_purchased,$data ) ) {
                $row = '';
                if ('on' == $barcode_options['display']) {
                    $barcode_value = yith_wcevti_get_barcode_value($ticket_purchased['event_id'], $barcode_options);
                    $row = $barcode_value . $delimiter;
                }

                $row .= $ticket_purchased['event_id'] . $delimiter . $ticket_purchased['order_id'] . $delimiter . $ticket_purchased['order_number'] . $delimiter . $ticket_purchased['product_id'] . $delimiter . $ticket_purchased['sku'] . $delimiter . $ticket_purchased['ticket_status'] . $delimiter . $ticket_purchased['purchased_by']['display_name'] . ' <' . $ticket_purchased['purchased_by']['user_email'] . '>';

                $row = apply_filters('yith_wcevt_get_csv_row', $row, $delimiter, $ticket_purchased);

                if ($disable_fields) {
                    $product_fields = get_post_meta($ticket_purchased['product_id'], '_fields', true);
                    if (!empty($product_fields)) {
                        foreach ($product_fields as $product_field) {
                            $exist = false;
                            if (is_array($ticket_purchased['fields'])) {
                                foreach ($ticket_purchased['fields'] as $key_field => $field_item) {
                                    if ($product_field['_label'] == $field_item['label']) {
                                        if (strpos($list['columns'], $field_item['label']) === false) {

                                            $list['columns'] .= $delimiter . $field_item['label'];
                                        }

                                        $row .= $delimiter . $field_item['value'];

                                        $exist = true;
                                    }
                                }
                            }
                            if (!$exist) {
                                $row .= $delimiter . '';
                            }
                        }
                    }
                }
                $list['rows'][] = $row;
            }
        }
        /*foreach ( $tickets_purchased as $key => $ticket_purchased ) {
            if ( $disable_services ) {
                $product_services = get_post_meta( $ticket_purchased['product_id'], '_services' );
                $product_services = ! empty( $product_services[0] ) ? $product_services[0] : array();
                foreach ( $product_services as $product_service ) {
                    $exist = false;
                    if ( is_array( $ticket_purchased['service'] ) ) {
                        if ( isset( $product_service['_type'] ) ) {
                            if ( 'select' == $product_service['_type'] ) {
                                foreach ( $ticket_purchased['service'] as $key_service_select => $service_item ) {
                                    foreach ( $product_service['_select'] as $select_item ) {
                                        if ( $select_item['_label'] == $service_item['label'] ) {
                                            if ( strpos( $list['columns'], $service_item['label'] ) === false ) {
                                                $list['columns'] .= $delimiter . $service_item['label'];
                                            }
                                            $list['rows'][ $key ] .= $delimiter . $service_item['value'];
                                            $exist                = true;
                                        }
                                    }
                                }
                            } elseif ( 'checkbox' == $product_service['_type'] ) {
                                foreach ( $ticket_purchased['service'] as $key_service_check => $service_item ) {
                                    if ( $product_service['_label'] == $service_item['label'] ) {
                                        if ( strpos( $list['columns'], $service_item['label'] ) === false ) {
                                            $list['columns'] .= $delimiter . $service_item['label'];
                                        }
                                        $list['rows'][ $key ] .= $delimiter . $service_item['value'];
                                        $exist                = true;
                                    }
                                }
                            }
                        }
                    }

                    if ( ! $exist ) {
                        $list['rows'][ $key ] .= $delimiter . $delimiter;
                    }
                }
            }
        }*/
        $new_columns = array();
        foreach ( $tickets_purchased as $key => $ticket_purchased ) {
            if ( $disable_services ) {
                $product_services = get_post_meta( $ticket_purchased['product_id'], '_services' );
                $product_services = ! empty( $product_services[0] ) ? $product_services[0] : array();
                foreach ( $product_services as $product_service ) {
                    $exist = false;
                    if ( is_array( $ticket_purchased['service'] ) ) {
                        if ( isset( $product_service['_type'] ) ) {
                            if ( 'select' == $product_service['_type'] ) {
                                foreach ($ticket_purchased['service'] as $key_service_select => $service_item) {
                                    foreach ($product_service['_select'] as $select_item) {
                                        if ($select_item['_label'] == $service_item['label']) {
                                            if (strpos($list['columns'], $service_item['label']) === false) {
                                                if (!in_array($product_service['_label'], $new_columns)) {

                                                    $list['columns'] .= $delimiter . $product_service['_label'];
                                                    $new_columns[] = $product_service['_label'];
                                                }
                                            }
                                            $list['rows'][$key] .= $delimiter . $service_item['label'];
                                            $exist = true;
                                            break;
                                        }
                                    }
                                }

                            } elseif ( 'checkbox' == $product_service['_type'] ) {
                                foreach ( $ticket_purchased['service'] as $key_service_check => $service_item ) {
                                    if ( $product_service['_label'] == $service_item['label'] ) {
                                        if ( strpos( $list['columns'], $service_item['label'] ) === false ) {
                                            $list['columns'] .= $delimiter . $service_item['label'];
                                        }
                                        $list['rows'][ $key ] .= $delimiter . $service_item['value'];
                                        $exist                = true;
                                    }
                                }
                            }
                        }
                    }

                    if ( ! $exist ) {
                        $list['rows'][ $key ] .= $delimiter . '';
                    }
                }
            }
        }
        $list = apply_filters( 'yith_wcevti_customice_csv_list', $list, $tickets_purchased );

        return $list;
    }
}

if ( ! function_exists( 'yith_wecvti_get_order_id_by_order_item_id' ) ) {
    function yith_wecvti_get_order_id_by_order_item_id( $item_id ) {
        global $wpdb;
        $order_id = '';
        if ( version_compare( WC()->version, '3.0.0', '>=' ) ) {
            $order_id = wc_get_order_id_by_order_item_id( $item_id );
        } else {
            $order_id = $wpdb->get_var( $wpdb->prepare(
                "SELECT order_id FROM {$wpdb->prefix}woocommerce_order_items WHERE order_item_id = %d",
                $item_id
            ) );
        }

        return $order_id;
    }

}

if ( ! function_exists( 'yith_wcevti_check_print_for_organizers' ) ) {
    function yith_wcevti_check_print_for_organizers( $organization ) {
        $values_selected = isset( $organization['values'] ) ? is_array( $organization['values'] ) ? $organization['values'] : explode( ',', $organization['values'] ) : array();

        $organizer_is_logged = false;
        foreach ( $values_selected as $value ) {
            $user = get_user_by( 'id', $value );
            if ( is_object( $user ) ) {
                if ( $user->data->ID == get_current_user_id() ) {
                    $organizer_is_logged = true;
                }
            }
        }

        return $organizer_is_logged;
    }

}

add_filter( 'yith_wcevti_set_custom_mail_args', 'set_services_location_mail_args', 10, 3 );
if ( ! function_exists( 'set_services_location_mail_args' ) ) {
    /**
     * Define location $args on ticket mail template
     *
     * @param $args
     * @param $post_meta
     * @param $item_meta
     *
     * @return mixed
     */
    function set_services_location_mail_args( $args, $post_meta, $item_meta ) {
        $services = array();
        foreach ( $item_meta as $key => $meta ) {
            if ( preg_match( '/service_/i', $key ) ) {
                $label = str_replace( array( 'service_' ), '', $key );
                $label = str_replace( array( '_' ), '', $label );
                $value = $meta[0];

                $services[] = array(
                    $label => $value
                );
            }
        }
        $args['services'] = $services;

        $location_enabled = get_option('yith_wcte_enable_location', true);
        if('yes' == $location_enabled){
            $args['location'] = get_post_meta( $post_meta['wc_event_id'][0], '_direction_event', true );
        }


        return $args;
    }
}

add_action( 'yith_wcevti_default_html_end_fields', 'set_default_html_services_template', 10, 1 );
if ( ! function_exists( 'set_default_html_services_template' ) ) {
    /**
     * Add services on pdf template...
     *
     * @return void
     * @since 1.0.0
     */
    function set_default_html_services_template( $post ) {

        $args = array(
            'services' => yith_wcevti_get_services( $post )
        );

        yith_wcevti_get_template( 'default-html-services', $args, 'tickets' );

    }
}

add_action( 'yith_wcevti_default_html_end_fields', 'set_default_html_before_date', 15, 1 );
if ( ! function_exists( 'set_default_html_before_date' ) ) {
    function set_default_html_before_date( $post ) {
        $args = yith_wcevti_set_args_mail_template( $post );
        $args = array(
            'location' => $args['location']
        );
        yith_wcevti_get_template( 'default-html-before-date', $args, 'tickets' );
    }
}