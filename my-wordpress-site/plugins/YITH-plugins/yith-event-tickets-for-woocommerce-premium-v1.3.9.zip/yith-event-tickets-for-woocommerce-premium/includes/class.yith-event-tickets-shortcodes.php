<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCEVTI_PATH' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_Tickets_Shortcodes
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     Francsico Mateo
 *
 */

if ( ! class_exists( 'YITH_Tickets_Shortcodes' ) ) {
	/**
	 * Class YITH_Tickets_Shortcodes
	 *
	 * @author Francsico Mateo
	 */
	class YITH_Tickets_Shortcodes {

		public static function init() {
			$shortcodes = array(
				'event_map'       => __CLASS__ . '::event_map', // print map event
				'event_calendar'  => __CLASS__ . '::event_calendar', // print the calendar events
				'users_purchased' => __CLASS__ . '::print_users_purchased', // print the users tickets purchased
				'organizers'      => __CLASS__ . '::print_organizers',
				'check_in_event'  => __CLASS__ . '::check_in_event'
			);

			foreach ( $shortcodes as $shortcode => $function ) {
				add_shortcode( $shortcode, $function );
			}

			//shortcode_atts( array('id' => ''), array(), 'event_map');
			shortcode_atts( array('id' => ''), array(), 'users_purchased');
			//shortcode_atts( array('id' => ''), array(), 'organizers');
			shortcode_atts( array( 'id' => '' ), array(), 'check_in_event' );
		}

		/**
		 * ShortCode for map event
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public static function event_map( $atts ) {
			global $product;

			$attributtes = shortcode_atts( array( 'id' => '' ), $atts, 'event_map' );

			$atts_id = isset( $attributtes['id'] ) ? $attributtes['id'] : '';
			$atts_id = empty( $atts_id ) & is_product() ? yit_get_product_id( $product ) : $atts_id;

			$product = wc_get_product( $atts_id );

			$enable_location = get_option( 'yith_wcte_enable_location' );
			$api_key         = get_option( 'yith_wcte_api_key_gmaps' );

			if ( $enable_location == 'yes' && ! empty( $api_key ) ) {
				if ( ! empty( $atts_id ) ) {
					$id        = $atts_id;
					$latitude  = get_post_meta( $id, '_latitude_event', true );
					$longitude = get_post_meta( $id, '_longitude_event', true );
					$address   = get_post_meta( $id, '_direction_event', true );


					if ( isset( $latitude ) & isset( $longitude ) ) {

						$args = array(
							'latitude'  => $latitude,
							'longitude' => $longitude,
							'address'   => $address
						);

						wp_enqueue_script( 'yith-wc-script-gmaps' );
						wp_enqueue_script( 'yith-wcevti-script-frontend-shortcodes-tickets' );
						wp_enqueue_style( 'yith-wcevti-style-frontend-shortcodes-tickets' );
						wc_get_template( 'frontend/map-address-frontend.php', $args, '', YITH_WCEVTI_TEMPLATE_PATH );
					}
				}
			}
		}

		/**
		 * ShortCode for event calendar
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public static function event_calendar() {

			wp_enqueue_script( 'yith-wcevti-script-frontend-shortcodes-tickets' );
			wp_enqueue_style( 'yith-wcevti-style-frontend-shortcodes-tickets' );

			wp_enqueue_script( 'yith-wcevti-script-frontend-calendar-tickets' );
			wp_enqueue_style( 'yith-wcevti-style-frontend-calendar-tickets' );


			ob_start();
			yith_wcevti_get_template( 'event-calendar-frontend', array(), 'frontend' );

			return ob_get_clean();
		}

		/**
		 * ShorCode for users purchased
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public static function print_users_purchased( $atts ) {
			global $product;

			$attributtes = shortcode_atts( array( 'id' => '', 'visible' => '' ), $atts, 'users_purchased' );

			$atts_id = isset( $attributtes['id'] ) ? $attributtes['id'] : '';
			$atts_id = empty( $atts_id ) & is_product() ? yit_get_product_id( $product ) : $atts_id;

			$visible = isset( $attributtes['visible'] ) ? $attributtes['visible'] : '';

			$product = wc_get_product( $atts_id );

			if ( 'ticket-event' == $product->get_type() ) {
				$purchased_tickets = yith_wcevti_get_orders_from_product( yit_get_product_id( $product ) );
				$title             = __( 'Users who will take part in the event', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.3

				if ( 'organizers' == $visible ) {
					$organization         = yit_get_prop( $product, '_organization', true );
					$print_for_organizers = yith_wcevti_check_print_for_organizers( $organization );

					if ( ! $print_for_organizers ) {
						return;
					}
				}
                ob_start();
                    wp_enqueue_style( 'yith-wcevti-style-frontend-shortcodes-tickets' );
                    yith_wcevti_get_template( 'users_purchased', array(
                        'title'         => $title,
                        'users_tickets' => $purchased_tickets
                    ), 'frontend' );
                return ob_get_clean();

			}
		}

		/**
		 * ShorCode for display organizers
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public static function print_organizers( $atts ) {
			global $product;

			$attributtes = shortcode_atts( array( 'id' => '', 'visible' => '' ), $atts, 'organizers' );

			$atts_id = isset( $attributtes['id'] ) ? $attributtes['id'] : '';
			$atts_id = empty( $atts_id ) & is_product() ? yit_get_product_id( $product ) : $atts_id;

			$visible = isset( $attributtes['visible'] ) ? $attributtes['visible'] : '';

			$product = wc_get_product( $atts_id );

			if ( 'ticket-event' == $product->get_type() ) {
				$organization    = yit_get_prop( $product, '_organization', true );
				$values_selected = isset( $organization['values'] ) ? is_array( $organization['values'] ) ? $organization['values'] : explode( ',', $organization['values'] ) : array();

				$organizers = array();

				foreach ( $values_selected as $value ) {
					$user = get_user_by( 'id', $value );

					if ( is_object( $user ) ) {
						$organizers[ $user->data->user_nicename ] = array(
							'id'           => $user->data->ID,
							'display_name' => $user->data->display_name,
							'avatar'       => get_avatar( $user->data->ID )
						);
						if ( $user->data->ID == get_current_user_id() ) {
							$organizer_is_logged = true;
						}

					}
				}

				if ( 'organizers' == $visible ) {
					$print_for_organizers = yith_wcevti_check_print_for_organizers( $organization );

					if ( ! $print_for_organizers ) {
						return;
					}
				}

				$title = __( 'Organizers', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.3

                ob_start();
                    wp_enqueue_style( 'yith-wcevti-style-frontend-shortcodes-tickets' );

                    yith_wcevti_get_template( 'users_purchased', array(
                        'title'         => $title,
                        'users_tickets' => $organizers
                    ), 'frontend' );
                return ob_get_clean();

            }
		}

		public static function check_in_event( $atts ) {
			$attributtes = shortcode_atts( array( 'id' => '' ), $atts, 'check_in_event' );
			if ( ! empty( $attributtes['id'] ) ) {
				if ( current_user_can( 'manage_woocommerce' ) || apply_filters( 'yith_wcevt_display_checking_event',false ) ) {
					add_action( 'wp_ajax_barcode_actions_search_ticket', array(
						'YITH_YWBC_Shortcodes',
						'manage_barcode_search_callback'
					) );

					wp_register_style( 'yith-wc-style-admin-fontawesome-tickets', 'https://maxcdn.bootstrapcdn.com/font-awesome/4.6.3/css/font-awesome.min.css', null, YITH_WCEVTI_VERSION );
					wp_enqueue_style( 'yith-wc-style-admin-fontawesome-tickets' );

					$data_to_js = array(
						'api_rest' => array(
							'nonce'              => wp_create_nonce( 'wp_rest' ),
							'base_url'           => rest_url( 'yith_event_tickets_for_woocommerce/v1/' ),
							'print_table_action' => esc_url( add_query_arg( array( 'action' => 'print_tickets_table_action' ), admin_url( 'admin-ajax.php' ) ) ),
							'export_csv_action'  => esc_url( add_query_arg( array( 'action' => 'export_csv_action' ), admin_url( 'admin-ajax.php' ) ) ),
						),
						'messages' => array(
							'checked_complete' => __( 'Checked', 'yith-event-tickets-for-woocommerce' ),
							//@since 1.1.3
							'has_been_checked' => __( 'has been checked', 'yith-event-tickets-for-woocommerce' ),
							//@since 1.1.3
							'checked_error'    => __( 'could not be checked', 'yith-event-tickets-for-woocommerce' ),
							//@since 1.1.3
							'start_check'      => __( 'Check-in message dialog' ),
							//@since 1.1.3
						),
						'product'  => array(
                            'id' => isset( $attributtes['id'] ) ? apply_filters( 'yith_wcevti_check_in_event_id_string', $attributtes['id'] ) : ''
						)
					);

					wp_enqueue_script( 'yith-wcevti-script-frontend-shortcodes-tickets' );
					wp_localize_script( 'yith-wcevti-script-frontend-shortcodes-tickets', 'yith_wcevti_frontend_checkin_shortcode_tickets', $data_to_js );
					wp_enqueue_style( 'yith-wcevti-style-frontend-shortcodes-tickets' );

					$atts_id = isset( $atts['id'] ) ? $atts['id'] : '';
					$product = wc_get_product( $atts_id );

                    ob_start();

                        $args = array(
                            'product'           => array(
                                'title' => yit_get_prop( $product, 'title' )
                            )
                        );

                        yith_wcevti_get_template( 'check_in', $args, 'frontend' );
                    return ob_get_clean();

                }
			}
		}

	}
}