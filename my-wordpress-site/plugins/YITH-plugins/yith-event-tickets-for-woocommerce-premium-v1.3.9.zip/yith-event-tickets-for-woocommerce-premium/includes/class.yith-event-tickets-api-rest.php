<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCEVTI_PATH' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_Tickets_API_Rest
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     Francsico Mateo
 *
 */

if ( ! class_exists( 'YITH_Tickets_API_REST' ) ) {
	/**
	 * Class YITH_Tickets_Shortcodes
	 *
	 * @author Francsico Mateo
	 */
	class YITH_Tickets_API_REST {

		public static function init() {
			register_rest_route( 'yith_event_tickets_for_woocommerce/v1',
				'/tickets_purchased/',
				array(
					'methods'             => 'GET',
					'callback'            => __CLASS__ . '::get_tickets_purchased',
					'permission_callback' => function () {
						return current_user_can( 'manage_woocommerce' );
					}
				)
			);
			register_rest_route( 'yith_event_tickets_for_woocommerce/v1',
				'/change_ticket_status/',
				array(
					'methods'             => 'POST',
					'callback'            => __CLASS__ . '::set_ticket_status',
					'permission_callback' => function () {
						return current_user_can( 'manage_woocommerce' );
					}
				)
			);
			register_rest_route( 'yith_event_tickets_for_woocommerce/v1',
				'/search_ticket/',
				array(
					'methods'             => 'POST',
					'callback'            => __CLASS__ . '::search_ticket',
					'permission_callback' => function () {
						return current_user_can( 'manage_woocommerce' );
					}
				)
			);
			register_rest_route( 'yith_event_tickets_for_woocommerce/v1',
				'/load_tickets/',
				array(
					'methods'             => 'POST',
					'callback'            => __CLASS__ . '::load_tickets',
					'permission_callback' => function () {
						return current_user_can( 'manage_woocommerce' );
					}
				)
			);
		}

		public static function get_tickets_purchased( $data ) {
			$product_id       = $data['id'];
			$tikets_purchased = yith_wcevti_get_tickets_purchased_by_product( $product_id );

			return $tikets_purchased;
		}

		//http://localhost/wp_3_x_event_ticket_improves/wp-json/yith_event_tickets_for_woocommerce/v1/change_ticket_status/?id=221&status=checked
		public static function set_ticket_status( $data ) {
			$ticket_id     = $data['id'];
			$ticket_status = $data['status'];
			$res = yith_wecvti_update_ticket_status( $ticket_id, $ticket_status );

            return $res;
		}

		//http://localhost/wp_3_x_event_ticket_improves/wp-json/yith_event_tickets_for_woocommerce/v1/search_ticket/?ticket_number=216
		public static function search_ticket( $data ) {
			$ticket_number = $data['ticket_number'];
			$product_id    = $data['product_id'];

			$output = array(
				'request'         => false,
				'ticket'          => array(
					'ticket_id' => $ticket_number
				),
				'message_key'     => 'not_founded',
				'template_output' => array()
			);
			// First find ticket by ticket number.
			$ticket_purchased = apply_filters('yith_wcevti_search_ticket_output', yith_wcevti_get_ticket_purchased( $ticket_number ));
			if ( ! empty( $ticket_purchased ) ) {
				if ( ! empty( $product_id ) ) {
					if ( $ticket_purchased['product_id'] == $product_id ) {
						$output['request']           = true;
						$output['template_output']   = yith_wcevti_get_ticket_purchased_template( $ticket_purchased );
						$output['tickets_purchased'] = array( $ticket_purchased );
                        $output['message_key']    = 'founded';
                        if ('yi-checked' != yith_wecvti_check_ticket_status ( $ticket_number )) {
                            $output['message_key'] = 'founded_pending_check';
                        }
						if ( apply_filters('yith_wcevti_check_if_ticket_checked', false ) && 'yi-checked' == yith_wecvti_check_ticket_status ( $ticket_number )) {
                            $output['message_key'] = 'founded_and_checked';
                        }
					} else {
						$output['message_key'] = 'not_belong';
					}

				}
			} else {
				if ( ! $output['request'] ) {
					//Second find ticket by barcode ticket number...
                    if ( class_exists( 'YITH_YWBC_Shortcodes' ) ) {
                        $shortocodes = YITH_YWBC_Shortcodes::get_instance();
                        $event_ticket = $shortocodes->barcode_action_search($ticket_number, 'ticket');

                        $event_ticket_id = isset($event_ticket[0]->ID) ? $event_ticket[0]->ID : false;

                        if ($event_ticket_id) {
                            $ticket_number = $event_ticket_id;
                            $ticket_purchased = yith_wcevti_get_ticket_purchased($ticket_number);
                            if ($ticket_purchased['product_id'] == $product_id) {
                                $output['request'] = true;
                                $output['template_output'] = yith_wcevti_get_ticket_purchased_template($ticket_purchased);
                                $output['tickets_purchased'] = array($ticket_purchased);
                                $output['message_key'] = 'founded';
                            } else {
                                $output['message_key'] = 'not_belong';
                            }
                        } else {
                            //Third find tickets by barcode order number...
                            $tickets_order = $shortocodes->barcode_action_search($ticket_number, 'shop_order');
                            $order_id = isset($tickets_order[0]->ID) ? $tickets_order[0]->ID : false;

                            if ($order_id) {
                                $order = wc_get_order($order_id);
                                $order_items = $order->get_items();
                                $tickets_purchased_by_order_items = yith_wcevti_get_tickets_purchased_by_order_items($order_items);

                                $tickets_purchased = array();
                                foreach ($tickets_purchased_by_order_items as $ticket_by_order_item) {
                                    if ($ticket_by_order_item['product_id'] == $product_id) {
                                        array_push($tickets_purchased, $ticket_by_order_item);
                                    }
                                }

                                if (!empty($tickets_purchased)) {
                                    $ticket_number = $order_id;
                                    $output['request'] = true;
                                    $output['template_output'] = yith_wcevti_get_tickets_purchased_template($tickets_purchased);
                                    $output['tickets_purchased'] = $tickets_purchased;
                                    $output['message_key'] = 'order_founded';
                                }
                            }
                        }
                    }else{
                        $output['message_key'] = 'not_founded';
                    }
				}
			}

			$output['message'] = array(
				'founded'       => sprintf( __( 'Ticket #%d found', 'yith-event-tickets-for-woocommerce' ), $ticket_number ),
                'founded_pending_check'       => sprintf( __( 'Ticket #%d found', 'yith-event-tickets-for-woocommerce' ), $ticket_number ),
                'founded_and_checked'       => sprintf( __( 'Ticket #%d is already checked', 'yith-event-tickets-for-woocommerce' ), $ticket_number ),
                'order_founded' => sprintf( __( 'Order #%d found', 'yith-event-tickets-for-woocommerce' ), $ticket_number ),
				'not_founded'   => __( 'No tickets were found', 'yith-event-tickets-for-woocommerce' ),
				'not_belong'    => sprintf( __( 'Ticket #%d does not belong to this event' ), $ticket_number )
			);

			return $output;
		}

		public static function load_tickets( $data ) {
			$product_id        = $data['product_id'];
			$tickets_purchased = apply_filters('yith_wcevti_load_tickets_purchased', yith_wcevti_get_tickets_purchased_by_product( $product_id ));
			$title             = get_the_title( $product_id );

			$output = array(
				'request'         => false,
				'message'         => array(
					'have_tickets' => sprintf( __( 'Tickets purchased for "%s" event', 'yith-event-tickets-for-woocommerce' ), $title ),
					'not_tickets'  => sprintf( 'The event "%s", don´t have tickets purchased', $title )
				),
				'message_key'     => 'not_tickets',
				'template_output' => array()
			);
			if ( ! empty( $tickets_purchased ) ) {
				$output['request']           = true;
				$output['template_output']   = yith_wcevti_get_tickets_purchased_template( $tickets_purchased );
				$output['tickets_purchased'] = $tickets_purchased;
				$output['message_key']       = 'have_tickets';
			}

			return $output;
		}

	}
}