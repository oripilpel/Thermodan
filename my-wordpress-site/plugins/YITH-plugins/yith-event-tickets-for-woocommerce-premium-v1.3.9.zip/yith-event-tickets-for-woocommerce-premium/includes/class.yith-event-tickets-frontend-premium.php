<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCEVTI_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_Tickets_Frontend_Premium
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     Francisco Mateo
 *
 */

if ( ! class_exists( 'YITH_Tickets_Frontend_Premium' ) ) {
	/**
	 * Class YITH_Tickets_Frontend_Premium
	 *
	 * @author Francisco Mateo
	 */
	class YITH_Tickets_Frontend_Premium extends YITH_Tickets_Frontend {
		/**
		 * Construct
		 *
		 * @author Francisco Mateo
		 * @since  1.0
		 */

		protected static $instance = null;

		public function __construct() {
			parent::__construct();

			add_action( 'yith_wcevti_register_scripts', array( $this, 'register_scripts' ) );

			add_filter( 'yith_wcevti_data_to_js_custom', array( $this, 'set_data_to_js' ), 10, 1 );

			add_action( 'woocommerce_product_query', array( $this, 'set_product_query' ) );

			add_action( 'yith_wcevti_end_fields_row', array( $this, 'add_services_row' ), 10, 2 );

			add_action( 'wp_ajax_print_tickets_table_action', array( $this, 'print_tickets_table' ) );
			add_action( 'wp_ajax_export_csv_action', array( $this, 'export_csv' ) );

			add_filter( 'woocommerce_product_tabs', array( $this, 'add_custom_tab' ), 98 );

			add_filter( 'yith_wcevti_passed_custom', array( $this, 'check_services' ), 10, 3 );

			add_action( 'yith_wcevti_passed_check_service', array( $this, 'check_service_repeated' ), 10, 3 );

			add_filter( 'yith_wcevti_before_add_to_cart', array( $this, 'add_services_to_cart_item' ), 10, 2 );

			add_filter( 'yith_wcevti_get_item_data', array( $this, 'get_item_services' ), 10, 2 );

			add_filter( 'yith_wcevti_set_cart_item', array( $this, 'set_cart_item_services' ), 10, 1 );

			add_action( 'yith_wcevti_add_order_item_meta', array( $this, 'add_order_item_meta_services' ), 10, 2 );

			add_action( 'woocommerce_after_checkout_validation', array( $this, 'after_checkout_validation' ), 10, 2 );

			add_action( 'yith_wcevti_on_create_ticket_status', array( $this, 'set_ticket_status_before_create' ) );
			add_action( 'yith_end_update_post_meta_ticket', array( $this, 'set_update_post_meta_ticket' ), 10, 1 );

			add_filter( 'yith_wcevti_add_order_item_meta_display_output', array(
				$this,
				'add_order_item_meta_display_services'
			), 10, 3 );

			//add_filter( 'woocommerce_catalog_orderby', array( $this, 'set_event_sort_items' ) );

			add_action( 'woocommerce_cart_loaded_from_session', array(
				$this,
				'remove_sold_tickets_from_cart'
			), 10, 1 );
		}

		public function register_scripts() {

			$path   = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? '/unminified' : '';
			$prefix = ( defined( 'WP_DEBUG' ) && WP_DEBUG ) ? '' : '.min';

			// Register shortcode scripts
			wp_register_script( 'yith-wcevti-script-frontend-shortcodes-tickets', YITH_WCEVTI_ASSETS_URL . '/js' . $path . '/script-tickets-shortcodes' . $prefix . '.js', array(
				'jquery',
				'jquery-ui-sortable'
			), YITH_WCEVTI_VERSION );


			// Register shortcode style
			wp_register_style( 'yith-wcevti-style-frontend-shortcodes-tickets', YITH_WCEVTI_ASSETS_URL . '/css/script-tickets-shortcodes.css', null, YITH_WCEVTI_VERSION );


			wp_localize_script( 'yith-wcevti-script-frontend-shortcodes-tickets', 'event_tickets_shortcodes', array(
				'ajaxurl' => admin_url( 'admin-ajax.php' ),
			) );

			// Register external monthly script...
			wp_register_script( 'yith-wcevti-script-frontend-calendar-tickets', apply_filters ( 'yith_wcevti_calendar_script_path' ,YITH_WCEVTI_ASSETS_URL . 'monthly-master/js/monthly.js'), array( 'jquery' ), YITH_WCEVTI_VERSION, true );

			// Register external monthly style
			wp_register_style( 'yith-wcevti-style-frontend-calendar-tickets', YITH_WCEVTI_ASSETS_URL . 'monthly-master/css/monthly.css', null, YITH_WCEVTI_VERSION );
		}

		public function set_data_to_js( $data_to_js ) {

			//$product = wc_get_product($data_to_js['product']['id']);

			$data_to_js['messages']['incomplete_field_service'] = __( 'Need to fill one or more of the above fields or services!', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.3

			/*
			$data_to_js['messages']['reduced_ticket_over_services_included'] = _x('Services included', 'Admin can decide apply the ticket reduced over services too', 'yith-event-tickets-for-woocommerce');
			$data_to_js['messages']['reduced_ticket_over_services_item'] = _x('Reduced price active', 'Admin can decide apply the ticket reduced over services too', 'yith-event-tickets-for-woocommerce');
			$data_to_js['reduced_ticket'] = yit_get_prop( $product, '_reduce_ticket', true);
			$data_to_js['reduced_ticket']['_reduced_ticket_over_services'] = apply_filters('yith_wcevti_reduced_ticket_over_service', false);
			*/

			return $data_to_js;
		}

		public function set_product_query( $wc_query ) {
			global $wpdb;
			$visible_option = get_option( 'yith_wcte_visible_expired' );
			if ( $visible_option == 'yes' ) {
				$sql         = 'select id from ' . $wpdb->posts . ' as p left join ' . $wpdb->postmeta . ' as pm on p.id = pm.post_id ' .
				               'where pm.meta_key = %s and pm.meta_value <= current_date';
				$sql_prepare = $wpdb->prepare( $sql, '_start_date_picker' );

				$query_result = $wpdb->get_col( $sql_prepare );

				$exlcuded_events = array();
				foreach ( $query_result as $event_id ) {
					$product = wc_get_product( $event_id );

					if ( ! $this->expired_date( $product ) ) {
						$exlcuded_events[] = $event_id;
					}
				}
				$wc_query->set( 'post__not_in', $exlcuded_events );
			}
		}

		public function add_services_row( $product_id, $row ) {
			$product       = wc_get_product( $product_id );
			$services      = yit_get_prop( $product, '_services', true );
			$reduce_ticket = yit_get_prop( $product, '_reduce_ticket', true );
			$price         = yit_get_prop( $product, 'price' );
			$args          = array(
				'product_id'               => $product_id,
				'services'                 => $services,
				'order_items_from_product' => apply_filters( 'yith_services_row_order_items_from_product', '', $product_id ),
				'reduce_ticket'            => $reduce_ticket,
				'price'                    => $price,
				'row'                      => $row
			);

			yith_wcevti_get_template( 'services_row', $args, 'frontend' );
		}

		public function remove_sold_tickets_from_cart( $cart ) {
			/**
			 * @var $cart \WC_cart
			 */
			$cart_contents = $cart->get_cart_contents();

			if ( empty( $cart_contents ) ) {
				return;
			}

			foreach ( $cart_contents as $cart_item_key => $cart_item ) {

				$product_id = $cart_item['product_id'];
				$product    = wc_get_product( $product_id );

				if ( isset( $cart_item['_field_service'] ) && isset( $cart_item['_field_service']['_services'] ) && ! empty( $cart_item['_field_service']['_services'] ) ) {
					$services      = $cart_item['_field_service']['_services'];
					$sold_services = yith_wcevti_get_order_services_sold_from_ticket( $product_id );

					foreach ( $services as $service ) {
						$service_sold = yith_wcevti_check_service_sold( $product_id, $service, false, $sold_services );

						if ( $service_sold == 'sold' ) {
							wc_add_notice( sprintf( __( '%s has been removed from your cart because it can no longer be purchased. Please contact us if you need assistance.', 'woocommerce' ), $product->get_name() ), 'error' );
							$cart->remove_cart_item( $cart_item_key );
						}
					}
				}
			}
		}

		/**
		 * Ajax call, export csv purchased table
		 *
		 * @return void
		 */

		public static function export_csv() {
			if ( current_user_can( 'manage_woocommerce' ) || apply_filters( 'yith_wcevt_export_csv',false ) ) {
				$data['ticket_number'] = isset( $_GET['ticket_number'] ) ? $_GET['ticket_number'] : '';
				$data['product_id']    = isset( $_GET['product_id'] ) ? $_GET['product_id'] : '';

				if ( ! empty( $data['ticket_number'] ) ) {
					$number = $data['ticket_number'];
				} else {
					$number = $data['product_id'];
				}

                $delimiter = 'yith_wcevti_delimiter';

                $list = yith_wcevti_get_csv_list( $data );
				ignore_user_abort( true );

                $columns = explode( $delimiter,  $list[ 'columns' ] );

                $rows = array();
                foreach ( $list[ 'rows' ] as $row ){
                    $rows[] = explode( $delimiter,  $row );
                }

				nocache_headers();
				header( 'Content-Type: text/csv; charset=utf-8' );
				header( 'Content-Disposition: attachment; filename=' . __( 'ticket', 'yith-event-tickets-for-woocommerce' ) . '-' . str_replace( ' ', '_', $number . '.csv' ) ); //@since 1.1.3
				header( 'Expires: 0' );


                $file = fopen('php://output', 'w');

                fputcsv($file, $columns);

                foreach ( $rows as $row ){
                    fputcsv($file, $row);
                }

				exit;
			}
		}

		/**
		 * Ajax call, print tickets purchased table
		 *
		 * @return void
		 */
		public function print_tickets_table() {
			$data['ticket_number'] = isset( $_GET['ticket_number'] ) ? $_GET['ticket_number'] : '';
			$data['product_id']    = isset( $_GET['product_id'] ) ? $_GET['product_id'] : '';
			$data['delimiter']    = 'default';

			$list = yith_wcevti_get_csv_list( $data );

            $args = array(
				'product_id' => $data['product_id'],
				'list'       => $list
			);

			echo yith_wcevti_get_template( 'purchased_tickets_table', $args, 'frontend' );

			die();

		}

		public function add_custom_tab( $tabs ) {
			global $product;
			$organization = yit_get_prop( $product, '_organization', true );

			if ( isset( $organization['tab_assistants'] ) ) {
				$print_assistants_tab = false;

				if ( isset( $organization['tab_assistants'] ) &&  'on' == $organization['tab_assistants'] ) {
					if ( isset( $organization['tab_assistants_for_organizers'] ) && 'on' == $organization['tab_assistants_for_organizers'] ) {
						$print_assistants_tab = yith_wcevti_check_print_for_organizers( $organization );
					} else {
						$print_assistants_tab = true;
					}
				}

				if ( $print_assistants_tab ) {
					$tabs['assistants'] = array(
						'title'    => __( 'Assistants', 'yith-event-tickets-for-woocommerce' ), //@since 1.1.3
						'priority' => 50,
						'callback' => array( $this, 'load_assistants_tab' )
					);
				}

			}

			$direction = yit_get_prop( $product, '_direction_event', true );
			if ( ! empty( $direction ) ) {
				if ( 'on' == yit_get_prop( $product, '_map_tab_display', true ) ) {
					$tabs['location'] = array(
						'title'    => __( 'Location of the event', 'yith-event-tickets-for-woocommerce' ),
						//@since 1.1.3
						'priority' => 60,
						'callback' => array( $this, 'load_location_tab' )
					);
				}
			}

			return $tabs;
		}

		public function load_assistants_tab() {
			global $product;
			$organization = yit_get_prop( $product, '_organization', true );
			yith_wcevti_get_template( 'tab_assistants', array( 'organization' => $organization ), 'frontend' );
		}

		public function load_location_tab() {
			yith_wcevti_get_template( 'tab_location', array(), 'frontend' );
		}

		public function check_services( $passed_validation, $product_id, $quantity ) {
			if ( $passed_validation ) {
				$required_validation = $this->check_required_services( $product_id );
				if ( $required_validation ) {
					$passed_validation = $this->check_stock_repeat_services( $passed_validation, $product_id, $quantity );
				} else {
					$passed_validation = false;
				}
			}

			return $passed_validation;
		}

		public function check_required_services( $product_id ) {
			$passed_required_services = true;
			$product                  = wc_get_product( $product_id );
			$services                 = yit_get_prop( $product, '_services', true );
			if ( isset( $_POST['_services_customer'] ) ) {
				$services_customer = $_POST['_services_customer'];
				foreach ( $services_customer as $index_panel => $service_panel ) {
					foreach ( $service_panel as $index_item => $service_item ) {
						$passed_required_services = ! $this->passed_item_service( $service_item, $services ) ? false : $passed_required_services;
					}
				}
				$passed_required_services = ! yith_wcevti_before_cart_service_validation( $product_id, $services_customer ) ? false : $passed_required_services;
			}

			return $passed_required_services;
		}

		public function passed_item_service( $service_user, $services_data ) {
			$exist_select = true;
			foreach ( $services_data as $service_data ) {
				if ( $service_user['_key'] == $service_data['_key'] ) {
					if ( isset( $service_data['_required'] ) & 'select' == $service_data['_type'] ) {
						if ( 0 < strlen( $service_user['_label'] ) ) {
							$label = sanitize_title( $service_user['_label'] );
							foreach ( $service_data['_select'] as $select_data ) {
								$label_data = sanitize_title( $select_data['_label'] );
								if ( $label_data == $label ) {
									if ( ! empty( $select_data['_range_from'] ) & ! empty( $select_data['_range_to'] ) ) {
										$value = $service_user['_value'][ $label ];
										if ( 0 < strlen( $value ) ) {
											if ( $value < $select_data['_range_from'] | $value > $select_data['_range_to'] ) {
												$exist_select = false;
												wc_add_notice( sprintf( __( 'Select number: the selected value for %s service is out of range.', 'yith-event-tickets-for-woocommerce' ), $service_user['_label'] ), 'error' ); //@since 1.1.3
											}
										} else {
											$exist_select = false;
											wc_add_notice( sprintf( __( 'Select number: the selected value for %s service has not been selected. It\'s mandatory field.',
												'yith-event-tickets-for-woocommerce' ), $service_user['_label'] ), 'error' ); //@since 1.1.3
										}
									}
								}
							}
						} else {
							$exist_select = false;
							wc_add_notice( __( 'Select service required: it\'s not selected.', 'yith-event-tickets-for-woocommerce' ), 'error' ); //@since 1.1.3
						}
						if ( ! $exist_select ) {
							$exist_select = false;
							wc_add_notice( __( 'Select service: the selected value does not exist.', 'yith-event-tickets-for-woocommerce' ),//@since 1.1.3
								'error' );
						}
					}
				}
			}

			return $exist_select;
		}

		public function check_stock_repeat_services( $passed_validation, $product_id, $quantity ) {
			if ( $passed_validation ) {
				$services_customer           = ! empty( $_REQUEST['_services_customer'] ) ? $_REQUEST['_services_customer'] : array();
				$count_product_service       = yith_wcevti_count_services_product( $product_id, $services_customer, $quantity );
				$check_count_product_service = '';
				foreach ( $count_product_service as $product_service ) {
					if ( ! empty( $product_service ) ) {
						$check_count_product_service = yith_wcevti_check_current_stock_service( $product_id, key( $product_service ), $product_service[ key( $product_service ) ], $check_count_product_service );
						if ( 'out_range' == $check_count_product_service ) {
							$passed_validation = false;
							wc_add_notice( __( 'You are trying to buy more services than the available. ', 'yith-event-tickets-for-woocommerce' ) . key
								( $product_service ) . __( ' it\'s out of range.', 'yith-event-tickets-for-woocommerce' ), 'error' ); //@since 1.1.3
						}
					}
				}
				if ( 'out_range' != $check_count_product_service ) {
					for ( $i = 0; $i < $quantity; $i ++ ) {
						if ( isset( $services_customer[ $i ] ) ) {
							$service_customer   = $services_customer[ $i ];
							$service_validation = true;
							foreach ( $service_customer as $service ) {
								$passed_check_service = apply_filters( 'yith_wcevti_passed_check_service', $product_id, $service, $services_customer );
								$label                = sanitize_title( $service['_label'] );
								if ( isset( $service['_value'][ $label ] ) ) {
									switch ( $passed_check_service ) {
										case 'repeated':
											$service_validation = false;
											wc_add_notice( $service['_label'] . ' x ' . $service['_value'][ $label ] . __( ' has been already selected.',
													'yith-event-tickets-for-woocommerce' ), 'notice' ); //@since 1.1.3
											break;
										case 'repeated_cart':
											$service_validation = false;
											wc_add_notice( $service['_label'] . ' x ' . $service['_value'][ $label ] . __( ' is already in your cart.',
													'yith-event-tickets-for-woocommerce' ), 'notice' );//@since 1.1.3
											break;
										case 'out_stock':
											$service_validation = false;
											wc_add_notice( $service['_label'] . __( ' is out of stock', 'yith-event-tickets-for-woocommerce' ), 'notice' );//@since 1.1.3
											break;
										case 'sold':
											$service_validation = false;
											wc_add_notice( $service['_label'] . ' x ' . $service['_value'][ $label ] . __( ' has been bought by another user.', 'yith-event-tickets-for-woocommerce' ), 'notice' );//@since 1.1.3
											break;
									}
								}
							}
							$passed_validation = ! $service_validation ? false : $passed_validation;
						}
					}
				}
			}

			return $passed_validation;
		}

		public function check_service_repeated( $post_id, $service, $services ) {
			$check = '';
			//Check if service is repeated...
			$count = 0;
			foreach ( $services as $i_service ) {
				$label = isset( $service['_label'] ) ? sanitize_title( $service['_label'] ) : false;

				foreach ( $i_service as $item ) {
					if ( 'select' == $item['_type'] && $label == sanitize_title( $item['_label'] ) ) {
						if ( isset( $item['_value'][ $label ] ) && $service['_value'][ $label ] == $item['_value'][ $label ] ) {
							$count ++;
						}
					}
				}
			}

			if ( 1 < $count ) {
				$check = 'repeated';
			} elseif ( yith_wcevti_exist_service_cart( $post_id, $service ) ) {
				$check = 'repeated_cart';
			}

			return $check;
		}

		public function add_services_to_cart_item( $product_data, $product_id ) {
			$services_customer = ! empty( $_REQUEST['_services_customer'] ) ? $_REQUEST['_services_customer'] : array();
			$reduced_price     = ! empty( $_REQUEST['_reduced_price'] ) ? $_REQUEST['_reduced_price'] : array();
			$product           = wc_get_product( $product_id );

			$index = $product_data['_field_service']['_index'];

			$services = isset( $services_customer[ $index ] ) ? $services_customer[ $index ] : array();

			$service_price = isset( $services_customer[ $index ] ) ? $this->get_services_price( $product_id, $services_customer[ $index ] ) : 0;

			$price_reduced = isset( $reduced_price[ $index ]['_value'] ) ? $price_reduced = $reduced_price[ $index ]['_value'] : '';

			if ( 'ticket-event' == $product->get_type() ) {
				if ( 0 < $product->get_stock_overcharge() ) {
					$product_data['_field_service']['_stock_overcharge'] = $product->get_stock_overcharge();
				}
				if ( 0 < $product->get_time_overcharge() ) {
					$product_data['_field_service']['_time_overcharge'] = $product->get_time_overcharge();
				}
			}

			$product_data['_field_service']['_services']      = $services;
			$product_data['_field_service']['_service_price'] = $service_price;
			$product_data['_field_service']['_price_reduced'] = $price_reduced;

			return $product_data;
		}

		public function get_services_price( $product_id, $services_user ) {
			$price                = 0;
			$product              = wc_get_product( $product_id );
			$services_data_ticket = yit_get_prop( $product, '_services' );

			if ( isset( $services_user ) ) {
				foreach ( $services_user as $service ) {
					foreach ( $services_data_ticket as $service_data ) {
						$service_label = isset( $service['_label'] ) ? sanitize_title( $service['_label'] ) : false;

						if ( $service_data['_key'] == $service['_key'] ) {
							switch ( $service_data['_type'] ) {
								case 'checkbox':
									if ( isset( $service['_value'] ) ) {
										$price += $service_data['_item_overcharge'];
									}
									break;
								case 'select':
									foreach ( $service_data['_select'] as $select ) {
										if ( sanitize_title( $select['_label'] ) == $service_label ) {
											$price += $select['_overcharge'];
										}
									}
									break;
							}
						}

					}
				}
			}

			return $price;
		}

		public function get_item_services( $item_data, $cart_item ) {
			$print_stock_overcharge_on_cart = apply_filters( 'yith_wcecti_print_stock_overcharge_on_cart', false );
			$print_time_overcharge_on_cart  = apply_filters( 'yith_wcecti_print_time_overcharge_on_cart', false );
			if ( isset( $cart_item['_field_service']['_stock_overcharge'] ) & $print_stock_overcharge_on_cart ) {
				$item_data[] = array(
					'key'   => __( 'Last units overcharge', 'yith-stripe-connect-for-woocommerce' ),
					'value' => $cart_item['_field_service']['_stock_overcharge'] . get_woocommerce_currency_symbol()
				);
			}
			if ( isset( $cart_item['_field_service']['_time_overcharge'] ) & $print_time_overcharge_on_cart ) {
				$item_data[] = array(
					'key'   => __( 'Last days overcharge', 'yith-stripe-connect-for-woocommerce' ),
					'value' => $cart_item['_field_service']['_time_overcharge'] . get_woocommerce_currency_symbol()
				);
			}

			if ( isset( $cart_item['_field_service']['_services'] ) && is_array( $cart_item['_field_service']['_services'] ) ) {
				$product              = wc_get_product( $cart_item['product_id'] );
				$services_data_ticket = yit_get_prop( $product, '_services' );

				if( is_array( $services_data_ticket ) ) {
					foreach ( $cart_item['_field_service']['_services'] as $service ) {
						$label = isset( $service['_label'] ) ? sanitize_title( $service['_label'] ) : false;
						foreach ( $services_data_ticket as $service_data ) {
							if ( $service_data['_key'] == $service['_key'] ) {
								switch ( $service_data['_type'] ) {
									case 'checkbox':
										if ( isset( $service['_value'] ) ) {
											$item_data[] = array(
												'key'   => stripslashes( $service_data['_label'] ),
												'value' => __( 'Yes', 'yith-event-tickets-for-woocommerce' )//@since 1.1.3
											);
										}
										break;
									case 'select':
										foreach ( $service_data['_select'] as $select ) {
											if ( sanitize_title( $select['_label'] ) == $label ) {
												if ( ! empty( $service['_value'][ $label ] ) ) {
													$item_data[] = array(
														'key'   => stripslashes( $select['_label'] ),
														'value' => stripslashes( $service['_value'][ $label ] )
													);
												} else {
	                                                $item_data[] = array(

	                                                    'key'   => stripslashes($service_data['_label']),
	                                                    'value' => apply_filters( 'yith_wcevti_checkbox_cart_label', stripslashes( $select['_label'] ) )
	                                                    //@since 1.1.3
	                                                );
												}
											}
										}
										break;
								}
							}
						}
					}
				}
			}
			if ( isset( $cart_item['_field_service']['_price_reduced'] ) ) {
				if ( 'on' == $cart_item['_field_service']['_price_reduced'] ) {
					$product       = wc_get_product( $cart_item['product_id'] );
					$reduced_price = yit_get_prop( $product, '_reduce_ticket' );
					$item_data[]   = array(
						'key' => __( 'Reduced price activated', 'yith-event-tickets-for-woocommerce' ),
						//@since 1.1.3

						'value' => isset( $reduced_price[0]['_description'] ) ? $reduced_price[0]['_description'] : empty( $reduced_price[0]['_description'] ) ? __( 'Yes', 'yith-event-tickets-for-woocommerce' ) : __( 'No', 'yith-event-tickets-for-woocommerce' )
						//@since 1.1.3
					);
				}
			}

			return $item_data;
		}

		public function set_cart_item_services( $cart_item_data ) {
			$service_price = ( isset( $cart_item_data['_field_service']['_service_price'] ) ) ? $cart_item_data['_field_service']['_service_price'] : 0;
			$_product      = $cart_item_data['data'];

			$price = $_product->get_price() + $service_price;
			yit_set_prop( $_product, 'price', $price );

			$price_reduced = ( isset( $cart_item_data['_field_service']['_price_reduced'] ) ) ? $cart_item_data['_field_service']['_price_reduced'] : 'off';
			if ( 'on' == $price_reduced ) {
				$reduced_price = yith_wecvti_get_reduced_price( yit_get_product_id( $cart_item_data['data'] ) );
				yit_set_prop( $cart_item_data['data'], 'price', $cart_item_data['data']->get_price() - $reduced_price );
			}

			$services = ( isset( $cart_item_data['_field_service']['_services'] ) ) ? $cart_item_data['_field_service']['_services'] : array();
			if ( ! empty( $services ) ) {
				foreach ( $cart_item_data['_field_service']['_services'] as $service ) {
					if ( ! empty( $service['_label'] ) ) {
						yit_set_prop( $cart_item_data['data'], 'sold_individually', 'yes' );
					}
				}
			}

			return apply_filters( 'yith_wcevti_set_cart_item_services', $cart_item_data );
		}

		public function add_order_item_meta_services( $item_id, $values ) {
			$services = isset( $values['_field_service']['_services'] ) ? $values['_field_service']['_services'] : array();

			$stock_overcharge = isset( $values['_field_service']['_stock_overcharge'] ) ? $values['_field_service']['_stock_overcharge'] : 0;
			$time_overcharge  = isset( $values['_field_service']['_time_overcharge'] ) ? $values['_field_service']['_time_overcharge'] : 0;

			if ( 0 < $stock_overcharge ) {
				wc_add_order_item_meta( $item_id, '_stock_overcharge', $stock_overcharge );
			}
			if ( 0 < $time_overcharge ) {
				wc_add_order_item_meta( $item_id, '_time_overcharge', $time_overcharge );
			}

			if ( ! empty( $services ) ) {
				foreach ( $services as $i => $service ) {
					if ( ! empty( $service['_label'] ) ) {
						switch ( $service['_type'] ) {

							case 'checkbox':
								if ( isset( $service['_value'] ) ) {
									wc_add_order_item_meta( $item_id, '_service_' . $service['_label'], __( 'Yes', 'yith-event-tickets-for-woocommerce' ) );//@since 1.1.3
								}
								break;
							case 'select':
								if ( ! empty( $service['_value'][ sanitize_title( $service['_label'] ) ] ) ) {
									wc_add_order_item_meta( $item_id, '_service_' . $service['_label'], $service['_value'][ sanitize_title( $service['_label'] ) ] );
								} else {
									wc_add_order_item_meta( $item_id, '_service_' . $service['_label_selector'], $service['_label'] );//@since 1.1.3
								}
								break;
						}
					}
				}
			}
		}

		public function after_checkout_validation( $data, $errors ) {
			$cart = WC()->cart;

			if ( empty( $errors->errors ) ) {
				if ( yith_wcevti_checkout_service_validation() ) {
					foreach ( $cart->cart_contents as $key => $cart_item ) {
						$services = isset( $cart_item['_field_service']['_services'] ) ? $cart_item['_field_service']['_services'] : array();
						if ( isset( $cart_item['_field_service'] ) && ! empty( $services ) ) {
							foreach ( $services as $service ) {
								$quantity_service     = isset( $count_services[ $cart_item['product_id'] ][ $service['_label'] ]['_value'] ) ? $count_services[ $cart_item['product_id'] ][ $service['_label'] ]['_value'] : 1;
								$service['_quantity'] = $quantity_service;
								yith_wcevti_add_service_sold( $cart_item['product_id'], $service );
							}
						}
					}
				}
			}
		}

		public function set_ticket_status_before_create( $ticket_status ) {
			return 'yi-pending-check';
		}

		public function set_update_post_meta_ticket( $post_id ) {
			update_post_meta( $post_id, '_ywbc_barcode_display_value', '' );
			update_post_meta( $post_id, '_barcode_display_value_order', '' );
			update_post_meta( $post_id, '_barcode_display_value_ticket', '' );
			update_post_meta( $post_id, '_barcode_display_value_product', '' );
		}

		public function add_order_item_meta_display_services( $meta_items, $key, $item ) {
		    
			$print_stock_overcharge_on_order = apply_filters( 'yith_wcecti_print_stock_overcharge_on_order', false );
			$print_time_overcharge_on_order  = apply_filters( 'yith_wcecti_print_time_overcharge_on_order', false );

			if ( '_stock_overcharge' == $key & $print_stock_overcharge_on_order ) {
				$meta_items[] = array(
					'label' => __( 'Last days overcharge', 'yith-stripe-connect-for-woocommerce' ),
					'value' => $item->value . get_woocommerce_currency_symbol()
				);
			}
			if ( '_time_overcharge' == $key & $print_time_overcharge_on_order ) {
				$meta_items[] = array(
					'label' => __( 'Last units overcharge', 'yith-stripe-connect-for-woocommerce' ),
					'value' => $item->value . get_woocommerce_currency_symbol()
				);
			}
			if ( preg_match( '/service_/i', $key ) ) {
				$meta_items[] = array(
					'label' => str_replace( '_service_', '', stripslashes($item->key) ),
					'value' => str_replace("\\", "", stripslashes($item->value))
				);
			}


            return $meta_items;
		}

		/*public function set_event_sort_items( $sort_by ) {
			$sort_items = array(
				'start_date' => _x( 'Sort by start date', 'Admin option to sort event dates by first showing the most recent dates',
					'yith-event-tickets-for-woocommerce' ),
				//@since 1.1.5
				'end_date'   => _x( 'Sort by end date', 'Admin option to sort event dates by first showing the oldest dates',
					'yith-event-tickets-for-woocommerce' ),
				//@since 1.1.5
			);
			$sort_by    = array_merge( $sort_by, $sort_items );

			return $sort_by;
		}*/

	}


}