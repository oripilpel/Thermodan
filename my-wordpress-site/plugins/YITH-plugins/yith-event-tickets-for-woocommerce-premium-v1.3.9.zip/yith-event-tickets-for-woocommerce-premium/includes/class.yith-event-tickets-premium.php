<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCEVTI_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_Tickets_Premium_Premium
 * @package    Yithemes
 * @since      Version 2.0.0
 * @author     Your Inspiration Themes
 *
 */

if ( ! class_exists( 'YITH_Tickets_Premium' ) ) {
	/**
	 * Class YITH_Tickets_Premium
	 *
	 * @author Francisco Mateo
	 */
	class YITH_Tickets_Premium extends YITH_Tickets {

		/**
		 * Construct
		 *
		 * @author Francisco Mateo
		 * @since  1.0
		 */
		public function __construct() {

			add_action( 'yith_wcevti_require', array( $this, 'require_premium' ), 10 );
			add_filter( 'yith_wcevti_require_class', array( $this, 'require_class_premium' ), 10, 1 );
			add_action( 'init', array( 'YITH_Tickets_Shortcodes', 'init' ) );
			add_action( 'init', array( $this, 'update_postmeta_tickets' ) );
			add_action( 'init', array( $this, 'register_ticket_status' ) );

			/* === Widget Init === */
			add_action( 'widgets_init', array( $this, 'widgets_init' ) );

			/* === Rest API INIT === */
			add_action( 'rest_api_init', array( 'YITH_Tickets_API_REST', 'init' ) );

			add_action( 'yith_add_order_custom_item', array( $this, 'add_order_service_item' ), 10, 3 );
			//add_action( 'yith_update_order_custom_item', array( $this, 'add_order_service_item' ), 10, 3 );

			add_action( 'woocommerce_order_status_cancelled', array( $this, 'remove_order_ticket' ), 10, 1 );
			add_action( 'woocommerce_order_status_refunded', array( $this, 'remove_order_ticket' ), 10, 1 );
			add_action( 'woocommerce_order_status_failed', array( $this, 'remove_order_ticket' ), 10, 1 );
			add_action( 'woocommerce_cart_loaded_from_session', array( $this, 'set_cart_loaded_from_session' ), 10, 3 );

			$admins = get_role( 'yith_vendor' );


			parent::__construct();
		}

		/**
		 * Main plugin Instance
		 *
		 * @return YITH_Tickets Main instance
		 * @author Francisco Mateo
		 */
		public static function instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}

			return self::$_instance;
		}

		/**
		 * Class Initialization
		 *
		 * Instance the admin premium class
		 *
		 * @author Francisco Mateo
		 * @since  1.0
		 * @return void
		 * @access protected
		 */
		public function init() {
			global $wp_query;
			if ( is_admin() ) {
				$this->admin = new YITH_Tickets_Admin_Premium();
			}

			if ( ! is_admin() || ( defined( 'DOING_AJAX' ) && DOING_AJAX ) ) {

				$this->frontend = new YITH_Tickets_Frontend_Premium();
			}
		}

		public function require_premium() {
			require_once( YITH_WCEVTI_WIDGET_PATH . 'class.yith-event-tickets-widget-calendar.php' );
		}

		public function require_class_premium( $require ) {
			array_push( $require['common'], 'includes/class.yith-event-tickets-shortcodes.php' );
			array_push( $require['common'], 'includes/functions.wcevti-premium.php' );
			array_push( $require['common'], 'includes/class.yith-event-tickets-api-rest.php' );
			array_push( $require['frontend'], 'includes/class.yith-event-tickets-frontend-premium.php' );
			array_push( $require['admin'], 'includes/class.yith-event-tickets-admin-premium.php' );

			return $require;
		}

		public function widgets_init() {
			register_widget( 'YITH_Widget_Calendar' );
		}

		/**
		 * Refresh the DB updating the barcode post meta to make prepare the search by barcode
		 * */
		public function update_postmeta_tickets() {
			//Update barcode meta...
			if ( ! get_option( 'yith_wcevti_barcode_metas_created', false ) ) {
				global $wpdb;
				$posts_to_update = $wpdb->get_col( $wpdb->prepare( 'select id from ' . $wpdb->posts . ' where id not in ( select post_id from ' . $wpdb->postmeta . ' where meta_key = %s ) and post_type = %s', array(
					'_ywbc_barcode_display_value',
					'ticket'
				) ) );
				//$posts_to_update = $wpdb->get_col($wpdb->prepare( 'select id from ' . $wpdb->posts . ' where  post_type = %s', array('ticket')) );

				if ( ! empty( $posts_to_update ) ) {
					foreach ( $posts_to_update as $post_id ) {
						update_post_meta( $post_id, '_ywbc_barcode_display_value', '' );
						update_post_meta( $post_id, '_barcode_display_value_order', '' );
						update_post_meta( $post_id, '_barcode_display_value_ticket', '' );
						update_post_meta( $post_id, '_barcode_display_value_product', '' );
					}
				}
				update_option( 'yith_wcevti_barcode_metas_created', true );
			}
		}

		/**
		 * Set the ticket type status to pending-check and checked to implement check in feature.
		 * */
		public function register_ticket_status() {

			$ticket_statuses = apply_filters( 'woocommerce_register_ticket_statuses',
				array(
					'yi-pending-check' => array(
						'label'                     => _x( 'Pending check', 'Ticket status', 'yith-event-tickets-for-woocommerce' ),
						'public'                    => true,
						'exclude_from_search'       => false,
						'show_in_admin_all_list'    => true,
						'show_in_admin_status_list' => true,
						'label_count'               => _n_noop( 'Pending check <span class="count">(%s)</span>', 'Pending check <span class="count">(%s)</span>', 'yith-event-tickets-for-woocommerce' ),
					),
					'yi-checked'       => array(
						'label'                     => _x( 'Checked', 'Ticket status', 'yith-event-tickets-for-woocommerce' ),
						'public'                    => true,
						'exclude_from_search'       => false,
						'show_in_admin_all_list'    => true,
						'show_in_admin_status_list' => true,
						'label_count'               => _n_noop( 'Checked <span class="count">(%s)</span>', 'Checked <span class="count">(%s)</span>', 'yith-event-tickets-for-woocommerce' ),
					),
					'yi-cancelled' => array(
						'label'                     => _x( 'Cancelled', 'Ticket status', 'yith-event-tickets-for-woocommerce' ),//@since 1.1.7
						'public'                    => true,
						'exclude_from_search'       => false,
						'show_in_admin_all_list'    => true,
						'show_in_admin_status_list' => true,
						'label_count'               => _n_noop( 'Cancelled <span class="count">(%s)</span>', 'Cancelled <span class="count">(%s)</span>', 'yith-event-tickets-for-woocommerce' ),
					)
				)
			);

			foreach ( $ticket_statuses as $ticket_status => $values ) {
				register_post_status( $ticket_status, $values );
			}
		}

		/**
		 * Once ordered is cancelled we create tickets post with all information.
		 *
		 * @param $order_id
		 */
		public function remove_order_ticket( $order_id ) {
			yith_wcevti_remove_service_sold($order_id);
		}

		public function set_cart_loaded_from_session( $cart ) {
			yith_wcevti_cart_session_services($cart);
		}

		public function add_order_service_item( $post_id, $key, $event_item ) {

			if ( preg_match( '/service_/i', $key ) ) {
				update_post_meta( $post_id, $key, $event_item );
			}
		}
	}
}