<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */
if ( ! defined( 'YITH_WCEVTI_VERSION' ) ) {
	exit( 'Direct access forbidden.' );
}

/**
 *
 *
 * @class      YITH_Tickets_Admin_Premium
 * @package    Yithemes
 * @since      Version 1.0.0
 * @author     Francisco Mateo
 *
 */

if ( ! class_exists( 'YITH_Tickets_Admin_Premium' ) ) {
	/**
	 * Class YITH_Tickets_Admin_Premium
	 *
	 * @author Francisco Mateo
	 */
	class YITH_Tickets_Admin_Premium extends YITH_Tickets_Admin {

		/**
		 * @var Panel page
		 */
		protected $_panel_page = 'yith_wcevti_panel';

		/**
		 * Construct
		 *
		 * @author Francisco Mateo
		 * @since  1.0
		 */

		protected static $instance = null;

		public function __construct() {
			$this->show_premium_landing = false;
			parent::__construct();

			/* === Register Panel Settings === */
			//add_action( 'admin_menu', array( $this, 'register_panel' ), 5 );

			/* === Customs enqueues === */
			add_action( 'yith_wcevti_enqueue_script_post_ticket', array( $this, 'set_common_enqueue_scripts' ), 10, 2 );
			add_action( 'yith_wcevti_enqueue_script_post-edit_ticket', array(
				$this,
				'set_common_enqueue_scripts'
			), 10, 2 );


			/* === Register plugin to licence/update system === */
			add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
			add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );

			/* === My custom general fields === */
			add_action( 'woocommerce_product_options_pricing', array( $this, 'add_reduce_ticket' ) );
            add_action( 'woocommerce_product_options_pricing', array( $this, 'show_tickets_already_sold' ) );
			add_action( 'woocommerce_product_options_general_product_data', array(
				$this,
				'add_increase_stock_section'
			), 10, 3 );
			add_action( 'woocommerce_product_options_general_product_data', array(
				$this,
				'add_increase_time_section'
			), 10, 3 );

			/* === Redo product data tabs === */
			add_action( 'yith_wcevti_product_data_content', array( $this, 'add_product_data_content_premium' ) );

			/* === Save my custom fields === */
			add_action( 'yith_wcevti_save_custom_fields', array( $this, 'save_custom_fields_premium' ) );

			/* === Before update order === */
			add_action( 'woocommerce_process_shop_order_meta', array( $this, 'before_save_order' ), 10, 2 );

			/* === Rewrite product options === */
			add_action( 'product_type_options', array( $this, 'event_ticket_type_options' ) );

			/* === Register ajax actions for admin === */
			add_action( 'wp_ajax_load_calendar_events_action', array( $this, 'load_calendar_events_action' ) );
			add_action( 'wp_ajax_nopriv_load_calendar_events_action', array( $this, 'load_calendar_events_action' ) );

			add_action( 'wp_ajax_print_increase_stock_row_action', array( $this, 'print_increase_stock_row_action' ) );
			add_action( 'wp_ajax_print_increase_time_row_action', array( $this, 'print_increase_time_row_action' ) );

			add_action( 'wp_ajax_print_service_row_action', array( $this, 'print_service_row_action' ) );
			add_action( 'wp_ajax_print_select_service_row_action', array( $this, 'print_select_service_row_action' ) );

			add_action( 'yith_wcevti_order_metabox_end_fields', array(
				$this,
				'set_order_metabox_services_template'
			), 10, 1 );

			add_action( 'yith_wcevti_default_html_preview_end_fields', array(
				$this,
				'set_default_html_preview_services_template'
			), 10, 1 );
			add_action( 'yith_wcevti_default_html_preview_end_fields', array(
				$this,
				'set_default_html_before_date_template'
			), 15, 1 );

			/* === Tickets table === */
			add_filter( 'yith_wcevti_end_columns_tickets', array( $this, 'add_new_columns_tickets' ) );
			add_action( 'yith_wcevti_render_ticket_columns', array( $this, 'render_ticket_column' ), 10, 2 );

			add_filter( 'yith_wcevti_end_ticket_row_actions', array( $this, 'set_ticket_row_actions' ), 10, 2 );

			add_filter( 'bulk_actions-edit-ticket', array( $this, 'ticket_bulk_actions' ) );
			add_filter( 'handle_bulk_actions-edit-ticket', array( $this, 'handle_ticket_bulk_actions' ), 10, 3 );

			add_filter( 'yith_wcevti_search_ticket_for', array( $this, 'add_search_ticket_for' ), 10, 2 );

			/* === Custom Order messages === */

            /* === Show Plugin Information === */
            add_filter( 'plugin_action_links_' . plugin_basename( YITH_WCEVTI_PATH . '/' . basename( YITH_WCEVTI_FILE ) ), array( $this, 'action_links' ) );
            add_filter( 'yith_show_plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 5 );


        }


		/**
		 * Register plugins for activation tab
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function register_plugin_for_activation() {
			if ( ! class_exists( 'YIT_Plugin_Licence' ) ) {
				require_once 'plugin-fw/licence/lib/yit-licence.php';
				require_once 'plugin-fw/licence/lib/yit-plugin-licence.php';
			}

			YIT_Plugin_Licence()->register( YITH_WCEVTI_INIT, YITH_WCEVTI_SECRETKEY, YITH_WCEVTI_SLUG );
		}

		/**
		 * Register plugins for update tab
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function register_plugin_for_updates() {
			if ( ! class_exists( 'YIT_Plugin_Licence' ) ) {
				require_once( YITH_WCEVTI_PATH . 'plugin-fw/lib/yit-upgrade.php' );
			}

			YIT_Upgrade()->register( YITH_WCEVTI_SLUG, YITH_WCEVTI_INIT );
		}


		public function set_common_enqueue_scripts( $path, $prefix ) {
			$data_to_js = array(
				'api_rest' => array(
					'nonce'    => wp_create_nonce( 'wp_rest' ),
					'base_url' => rest_url( 'yith_event_tickets_for_woocommerce/v1/' )
				),
				'messages' => array(
					'checked' => __( 'Checked', 'yith-event-tickets-for-woocommerce' ) //@since 1.1.3
				)
			);
			wp_register_script( 'yith-wc-script-admin-tickets-table', YITH_WCEVTI_ASSETS_URL . '/js' . $path . '/script-tickets-admin-tickets-table' . $prefix . '.js', array(
				'jquery',
				'jquery-blockui',
				'jquery-ui-sortable',
				'jquery-ui-tooltip'
			), YITH_WCEVTI_VERSION, true );
			wp_localize_script( 'yith-wc-script-admin-tickets-table', 'yith_wcevti_admin_table_tickets', $data_to_js );
			wp_enqueue_script( 'yith-wc-script-admin-tickets-table' );
		}

		/**
		 * Custom reduce ticket fields
		 *
		 * Allow add reduce ticket price
		 *
		 * @author Francsico Mateo
		 * @since  1.0
		 * @return void
		 */
		public function add_reduce_ticket() {
			global $thepostid;
			$product       = wc_get_product( $thepostid );
			$reduce_ticket = yit_get_prop( $product, '_reduce_ticket', true );

			$args                 = array(
				'reduce_ticket' => $reduce_ticket
			);
			$print_reduced_ticket = apply_filters( 'yith_wcevti_print_admin_reduced_ticket', true );
			if ( $print_reduced_ticket ) {
				yith_wcevti_get_template( 'reduce_ticket', $args, 'admin' );
			}
		}

        /**
         * Option to show tickets already sold
         *
         *
         * @author Daniel Sanchez Saez
         * @since  1.1.9
         * @return void
         */
        public function show_tickets_already_sold() {
            global $thepostid;
            $product       = wc_get_product( $thepostid );
            $already_sold = yit_get_prop( $product, '_already_sold', true );

            $args                 = array(
                'already_sold' => $already_sold
            );
            $print_show_already_sold = apply_filters( 'yith_wcevti_print_admin_show_tickets_already_sold', true );
            if ( $print_show_already_sold ) {
                yith_wcevti_get_template( 'show_tickets_already_sold_admin', $args, 'admin' );
            }
        }

		/**
		 * Custom increase stock section
		 *
		 * Add increase stock section on our Event Ticket product
		 *
		 * @author Francsico Mateo
		 * @since  1.0
		 * @return void
		 */
		public function add_increase_stock_section() {
			global $thepostid;
			$product                      = wc_get_product( $thepostid );
			$increase_by_stock            = yit_get_prop( $product, '_increase_by_stock', true );
			$args                         = array(
				'increase_by_stock' => $increase_by_stock
			);
			$print_increase_stock_section = apply_filters( 'yith_wcevti_print_admin_increase_stock_section', true );

			if ( $print_increase_stock_section ) {
				yith_wcevti_get_template( 'increase_stock_section', $args, 'admin' );
			}
		}

		/**
		 * Custom increase time section
		 *
		 *
		 * Add increase time section on our Event Ticket product
		 *
		 * @author Francsico Mateo
		 * @since  1.0
		 * @return void
		 */
		public function add_increase_time_section() {
			global $thepostid;
			$product                     = wc_get_product( $thepostid );
			$increase_by_time            = yit_get_prop( $product, '_increase_by_time', true );
			$args                        = array(
				'increase_by_time' => $increase_by_time
			);
			$print_increase_time_section = apply_filters( 'yith_wcevti_print_admin_increase_time_section', true );
			if ( $print_increase_time_section ) {
				yith_wcevti_get_template( 'increase_time_section', $args, 'admin' );
			}
		}

		/**
		 * Set data tabs for Event Tickets
		 *
		 * @author Francsico Mateo
		 * @since  1.0
		 * @return void
		 */
		public function build_product_data_tabs( $tabs ) {

			$enable_location = get_option( 'yith_wcte_enable_location' );

			array_push( $tabs['inventory']['class'], 'show_if_ticket-event' );

			$new_map_tab = array();

			if ( $enable_location == 'yes' ) {
				$new_map_tab = array(
					'map' => array(
						'label'  => __( 'Map', 'yith-event-tickets-for-woocommerce' ), //@since 1.1.3
						'target' => 'map_product_data',
						'class'  => array( 'hide_if_grouped', 'show_if_ticket-event' )
					)
				);
			}

			$new_fields_tab = array(
				'event_fields' => array(
					'label'  => __( 'Fields', 'yith-event-tickets-for-woocommerce' ), //@since 1.1.3
					'target' => 'fields_product_data',
					'class'  => array( 'show_if_ticket-event' )
				)
			);

			$services_tab = array(
				'services' => array(
					'label'  => __( 'Services', 'yith-event-tickets-for-woocommerce' ), //@since 1.1.3
					'target' => 'services_product_data',
					'class'  => array( 'show_if_ticket-event' )
				)
			);

			$organization_tab = array(
				'organization_template' => array(
					'label'  => __( 'Organizers and assistants', 'yith-event-tickets-for-woocommerce' ), //@since 1.1.3
					'target' => 'organization_product_data',
					'class'  => array( 'show_if_ticket-event' )
				)
			);

			$mail_template_tab = array(
				'mail_template' => array(
					'label'  => __( 'Email template', 'yith-event-tickets-for-woocommerce' ), //@since 1.1.3
					'target' => 'mail_template_product_data',
					'class'  => array( 'show_if_ticket-event' )
				)
			);

			$export_template_tab = array(
				'export_template' => array(
					'label'  => __( 'Export ticket', 'yith-event-tickets-for-woocommerce' ), //@since 1.1.3
					'target' => 'export_template_product_data',
					'class'  => array( 'show_if_ticket-event' )
				)
			);

			return array_merge( $tabs, $new_fields_tab, $services_tab, $new_map_tab, $organization_tab, $mail_template_tab, $export_template_tab );

		}

		/**
		 * Set content for data tabs
		 *
		 * @author Francsico Mateo
		 * @since  1.0
		 * @return void
		 */
		public function add_product_data_content_premium() {
			global $thepostid;
			$args = array(
				'thepostid' => $thepostid
			);
			yith_wcevti_get_template( 'product_data_content_premium', $args, 'admin' );
		}

		/**
		 * Save custom fields Event Tickets
		 *
		 * @author Francsico Mateo
		 * @since  1.0
		 * @return void
		 */
		public function save_custom_fields_premium( $post_id ) {

			$product = wc_get_product( $post_id );

			//*** Save Reduce Type ***
			if ( isset( $_POST['_reduce_ticket'] ) && ! empty( $_POST['_reduce_ticket'] ) ) {
				$reduce_ticket = $_POST['_reduce_ticket'];
				//$changes['_reduce_ticket'] = $reduce_ticket;
				yit_save_prop( $product, '_reduce_ticket', $reduce_ticket );
			}

            //*** Save option tickets already sold ***
            if ( isset( $_POST['_already_sold'] ) && ! empty( $_POST['_already_sold'] ) ) {
                $already_sold = $_POST['_already_sold'];
                //$changes['_already_sold'] = $already_sold;
                yit_save_prop( $product, '_already_sold', $already_sold );
            }
            else{
                $already_sold = array( '_enable' => 'off' );
                yit_save_prop( $product, '_already_sold', $already_sold );
            }

			//*** Save rules to increase price event by stock ***
			if ( isset( $_POST['_increase_by_stock'] ) && ! empty( $_POST['_increase_by_stock'] ) ) {
				$increase_by_stock_post = $_POST['_increase_by_stock'];
				$increase_by_stock      = array();

				foreach ( $increase_by_stock_post as $increase ) {

					if ( ! empty( $increase['_threshold'] ) ) {
						$increase_by_stock[] = $increase;
					}
				}
				//$changes['_increase_by_stock'] = $increase_by_stock;
				yit_save_prop( $product, '_increase_by_stock', $increase_by_stock );
			} else {
				//$changes['_increase_by_stock'] = '';
				yit_save_prop( $product, '_increase_by_stock', '' );
			}

			//*** Save rules to increase price event by time ***
			if ( isset( $_POST['_increase_by_time'] ) && ! empty( $_POST['_increase_by_time'] ) ) {
				$increase_by_time_post = $_POST['_increase_by_time'];
				$increase_by_time      = array();

				foreach ( $increase_by_time_post as $increase ) {

					if ( ! empty( $increase['_threshold'] ) ) {
						$increase_by_time[] = $increase;
					}
				}
				//$changes['_increase_by_time'] = $increase_by_time;
				yit_save_prop( $product, '_increase_by_time', $increase_by_time );

			} else {
				//$changes['_increase_by_time'] = '';
				yit_save_prop( $product, '_increase_by_time', '' );
			}

			//*** Save services ***
			if ( isset( $_POST['_services'] ) && ! empty( $_POST['_services'] ) ) {
				$services_post = $_POST['_services'];
				$services      = array();
				foreach ( $services_post as $service_item ) {
					$service_item['_item_overcharge'] = ! empty( $service_item['_item_overcharge'] ) ? $service_item['_item_overcharge'] : 0;
					if ( isset( $service_item['_label'] ) ) {
						switch ( $service_item['_type'] ) {
							case 'select':
								foreach ( $service_item['_select'] as &$select ) {
									if ( empty( $select['_overcharge'] ) ) {
										$select['_overcharge'] = 0;
										$select['_label']      = sanitize_text_field( $select['_label'] );
                                    }
									//$changes['_service_'.$select['_label'].'_stock'] = $select['_stock'];

                                    yit_save_prop( $product, '_service_' . $select['_label'] . '_stock', $select['_stock'] );

								}
								array_push( $services, $service_item );
								break;
							case 'checkbox':
							default:
								array_push( $services, $service_item );
								//$changes['_service_'. $service_item['_label'] .'_stock'] = $service_item['_stock'];

								yit_save_prop( $product, '_service_' . $service_item['_label'] . '_stock', $service_item['_stock'] );
								break;
						}
                    }
				}

				$current_service_stock = yith_wcevti_get_service_stocks( yit_get_prop( $product, 'id' ) );
				yith_wcevti_clean_service_stock( yit_get_prop( $product, 'id' ), $services, $current_service_stock );

				//$changes['_services'] = $services;
				yit_save_prop( $product, '_services', $services );

			} else {
				//$changes['_services'] = '';
				yit_save_prop( $product, '_services', '' );
			}

			//*** Save options for organizers fields ***//
			if ( isset( $_POST['_organization'] ) ) {
				$organization['tab_assistants']                = isset( $_POST['_organization']['_tab_assistants'] ) ? $_POST['_organization']['_tab_assistants'] : '';
				$organization['tab_assistants_for_organizers'] = isset( $_POST['_organization']['_tab_assistants_for_organizers'] ) ? $_POST['_organization']['_tab_assistants_for_organizers'] : '';
				$organization['display']                       = isset( $_POST['_organization']['_display'] ) ? $_POST['_organization']['_display'] : '';
				$organization['values']                        = isset( $_POST['_organization']['_values'] ) ? $_POST['_organization']['_values'] : '';
				//$changes['_organization'] = $organization;
				yit_save_prop( $product, '_organization', $organization );
			} else {
				$organization['tab_assistants']                = '';
				$organization['tab_assistants_for_organizers'] = '';
				$organization['display']                       = '';
				$organization['values']                        = '';
				yit_save_prop( $product, '_organization', $organization );
			}

			$export['disable_fields']   = '';
			$export['disable_services'] = '';
			if ( isset( $_POST['_export'] ) ) {
				$export['disable_fields']   = isset( $_POST['_export']['_disable_fields'] ) ? $_POST['_export']['_disable_fields'] : '';
				$export['disable_services'] = isset( $_POST['_export']['_disable_services'] ) ? $_POST['_export']['_disable_services'] : '';
				yit_save_prop( $product, '_export', $export );
			} else {
				yit_save_prop( $product, '_export', $export );
			}

			//*** Save Latitude, Longitude and address Event location ***
			if ( isset( $_POST['_direction_event_field'] ) ) {
				$direction_event = $_POST['_direction_event_field'];
				//$changes['_direction_event'] = esc_attr($direction_event);
				yit_save_prop( $product, '_direction_event', esc_attr( stripslashes( $direction_event ) ) );

				$map_tab_display = isset( $_POST['_map_tab_display'] ) ? $_POST['_map_tab_display'] : '';
				//$changes['_map_tab_display'] = esc_attr($map_tab_display);
				yit_save_prop( $product, '_map_tab_display', esc_attr( $map_tab_display ) );
			}
			$latitude_event  = '';
			$longitude_event = '';
			if ( isset( $_POST['_direction_event_field'] ) ) {
				if ( ! empty( $_POST['_direction_event_field'] ) ) {
					$latitude_event  = $_POST['_latitude_event_field'];
					$longitude_event = $_POST['_longitude_event_field'];
				}
			}
			//$changes['_latitude_event'] = esc_attr( $latitude_event );
			yit_save_prop( $product, '_latitude_event', esc_attr( $latitude_event ) );
			//$changes['_longitude_event'] = esc_attr( $longitude_event );
			yit_save_prop( $product, '_longitude_event', esc_attr( $longitude_event ) );

			//return $changes;
		}

		/**
		 * Before save order
		 *
		 * @author Francsico Mateo
		 * @since  1.1.6
		 * @return void
		 */
		public function before_save_order( $post_id, $post ) {

			$proceed_check = false;
			// Check from pending, pro
			if ( 'wc-pending' == $_POST['order_status'] | 'wc-processing' == $_POST['order_status'] | 'wc-on-hold' == $_POST['order_status'] | 'wc-completed' == $_POST['order_status'] ) {
				if ( $_POST['original_post_status'] == 'wc-cancelled' | $_POST['original_post_status'] == 'wc-refunded' | $_POST['original_post_status'] == 'wc-failed' ) {
					$proceed_check = true;
				}
			}
			if ( $proceed_check ) {
				$order       = wc_get_order( $post_id );
				$order_items = $order->get_items();

				$services_solds = array();
				foreach ( $order_items as $key => $order_item ) {
					$product_id          = wc_get_order_item_meta( $key, '_product_id' );
					$services_from_order = yith_wcevti_get_order_item_meta( $key, 'service' );

					foreach ( $services_from_order as $service_from_order ) {
						$service      = array(
							'_type'  => 'select',
							'_label' => $service_from_order['label'],
							'_value' => array(
								sanitize_title( $service_from_order['label'] ) => $service_from_order['value']
							)
						);
						$service_sold = yith_wcevti_check_service_sold( $product_id, $service, '' );
						if ( 'sold' == $service_sold ) {
							$services_solds[] = $service;
						}
					}
				}
				if ( ! empty( $services_solds ) ) {
					$_POST['order_status'] = $_POST['original_post_status'];
					add_action( 'admin_notices', "set_error_notice" );
				} else {
					$order       = wc_get_order( $post_id );
					$order_items = $order->get_items();

					foreach ( $order_items as $key => $order_item ) {
						$product_id = wc_get_order_item_meta( $key, '_product_id' );
						foreach ( $services_from_order as $service_from_order ) {
							$service = array(
								'_type'  => 'select',
								'_label' => $service_from_order['label'],
								'_value' => array(
									sanitize_title( $service_from_order['label'] ) => $service_from_order['value']
								)
							);
							yith_wcevti_add_service_sold( $product_id, $service );
						}
					}
				}
			}
		}

		public function set_error_notice() {
			?>
            <div class="error">
                <p><?php _e( 'You are tried change order status that have an item with service purchased', 'yith-event-tickets-for-woocommerce' );//@since 1.1.5 ?></p>
            </div>
			<?php
		}

		/**
		 * Set the main options for product type Ticket Event
		 *
		 * @author Francsico Mateo
		 * @since  1.0
		 * @return void
		 */
		public function event_ticket_type_options( $options ) {
			$options['virtual']['wrapper_class']      = $options['virtual']['wrapper_class'] . ' show_if_ticket-event';
			$options['downloadable']['wrapper_class'] = $options['downloadable']['wrapper_class'] . ' show_if_ticket-event';

			return $options;
		}

		/**
		 * Ajax call, send event data to json format
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function load_calendar_events_action() {

			$jsonData = yith_wcevti_get_dates();

			wp_send_json( $jsonData );
			die();
		}

		/**
		 * Ajax call, add Increase by stock row
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_increase_stock_row_action() {

			if ( isset( $_POST['index'] ) ) {
				$args = array(
					'index' => $_POST['index']
				);
				yith_wcevti_get_template( 'increase_stock_row', $args, 'admin' );
			}
			die();
		}

		/**
		 * Ajax call, add Increase by time row
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_increase_time_row_action() {

			if ( isset( $_POST['index'] ) ) {
				$args = array(
					'index' => $_POST['index']
				);
				yith_wcevti_get_template( 'increase_time_row', $args, 'admin' );
			}
			die();
		}

		/**
		 * Ajax call, add service row
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_service_row_action() {
			if ( isset( $_POST['index'] ) ) {
				$service = array(
					'_type' => ''
				);
				$args    = array(
					'index'   => $_POST['index'],
					'service' => $service
				);
				yith_wcevti_get_template( 'service_row', $args, 'admin' );
			}
			die();
		}

		/**
		 * Ajax call, add select service row
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function print_select_service_row_action() {
			if ( isset( $_POST['index'] ) ) {
				$args = array(
					'row_index'     => $_POST['row_index'],
					'index'         => $_POST['index'],
					'service_label' => $_POST['service_label']
				);
				yith_wcevti_get_template( 'select_service_row.php', $args, 'admin' );
			}
			die();
		}

		/**
		 * Add services on order metabox.
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function set_order_metabox_services_template( $post ) {

			$args = array(
				'services' => yith_wcevti_get_services( $post ),
                'post' => $post
			);
			yith_wcevti_get_template( 'ticket_order_meta_box_services', $args, 'admin' );
		}

		/**
		 * Add services on live preview template...
		 *
		 * @return void
		 * @since 1.0.0
		 */
		public function set_default_html_preview_services_template( $post ) {

			$args = array(
				'services' => yith_wcevti_get_services( $post )
			);
			yith_wcevti_get_template( 'default-html-preview-services', $args, 'tickets' );
		}

		public function set_default_html_before_date_template( $post ) {
			$args = yith_wcevti_set_args_mail_template( $post );
			$args = array(
				'location' => $args['location']
			);
			yith_wcevti_get_template( 'default-html-preview-before-date', $args, 'tickets' );
		}


		public function add_new_columns_tickets( $columns ) {

			$ticket_status['ticket-status'] = '<span class="fa fa-hand-paper-o" title="Ticket status"></span>';

			$place['place'] = __( 'Place', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.3

			array_splice_assoc( $columns, 1, 0, $ticket_status );
			array_splice_assoc( $columns, 4, 0, $place );

			$columns['actions'] = __( 'Actions', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.3

			return $columns;
		}

		public function render_ticket_column( $column, $post_id ) {
			switch ( $column ) {
				case 'actions':
					$ticket_status = get_post_status( $post_id );
					$ticket_status = empty( $ticket_status ) ? 'yith-wcevti-pending-check' : $ticket_status;
					if ( 'yi-checked' != $ticket_status ) {
						?>
                        <a class="button make_checkin_button fa fa-thumbs-o-up tips" title="<?php echo __( 'Make check in', 'yith-event-tickets-for-woocommerce' );//@since 1.1.3 ?>" aria-hidden="true" data-ticket_id="<?php echo $post_id; ?>" data-status="yi-checked" href=""></a>
						<?php
					}
					?>
                    <a class="button fa fa-eye tips" title="View ticket" aria-hidden="true" href="<?php echo get_edit_post_link( $post_id ); ?>"></a>
					<?php
					break;
				case 'ticket-status':
					$ticket_status = get_post_status( $post_id );
					$ticket_status = empty( $ticket_status ) ? 'yith-wcevti-pending-check' : $ticket_status;
					if ( 'yi-checked' == $ticket_status ) {
						?>
                        <span class="ticket_status_icon fa fa-thumbs-o-up status_checked" title="Checked"></span>
						<?php
					} elseif ( 'yi-cancelled' == $ticket_status ) {
						?>
                        <span class="ticket_status_icon fa fa-ban status_cancelled" title="Cancelled"></span>
						<?php
					} else {
						?>
                        <span class="ticket_status_icon fa fa-hand-paper-o status_pending_check" title="Pending check"></span>
						<?php
					}
					break;
				case 'place':
					$product_id      = get_post_meta( $post_id, 'wc_event_id', true );
					$product_ticket  = wc_get_product( $product_id );
					$direction_event = yit_get_prop( $product_ticket, '_direction_event', true );
					if ( empty( $direction_event ) ) {
						echo __( 'No location has been defined for this event', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.3
					} else {
						echo stripslashes_deep( $direction_event );
					}
					break;
			}
		}

		public function set_ticket_row_actions( $actions, $post ) {
			if ( 'product' == $post->post_type ) {
				$product = wc_get_product( $post->ID );

				$product_type = version_compare( WC()->version, '3.0.0', '>=' ) ? yit_get_prop( $product, 'type' ) : $product->product_type;

				if ( 'ticket-event' == $product_type ) {
					$actions['export_csv'] = '<a id="_export_csv_button" class="_export_csv_button" description="' . __( 'Export to CSV', 'yith-event-tickets-for-woocommerce' ) . '" href="' . esc_url( add_query_arg( array( 'action' => 'export_csv_action' ), admin_url( 'admin-ajax.php' ) ) ) . '&ticket_number=' . '&product_id=' . $post->ID . '" target="_blank">' . __( 'CSV', 'yith-event-tickets-for-woocommerce' ) . '</a>'; //@since 1.1.3
				}
			}

			return $actions;
		}


		/**
		 * Define the actions for all tickets items selected on tickets table...
		 *
		 * @return void
		 * @since 1.1.3
		 */
		public function ticket_bulk_actions( $actions ) {
			if ( isset( $actions['edit'] ) ) {
				unset( $actions['edit'] );
			}
			$actions['make_check_in']      = __( 'Make Check in', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.3
			$actions['mark_pending_check'] = __( 'Mark Pending check', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.3
			$actions['mark_cancelled']     = __( 'Mark Cancelled', 'yith-event-tickets-for-woocommerce' ); //@since 1.1.7

			return $actions;
		}

		/**
		 * Handle the actions for all tickets items selected on tickets table...
		 *
		 * @return void
		 * @since 1.1.3
		 */
		public function handle_ticket_bulk_actions( $redirect_to, $action, $ids ) {
			if ( 'make_check_in' == $action ) {
				foreach ( $ids as $id ) {
					yith_wecvti_update_ticket_status( $id, 'yi-checked' );
				}
			}
			if ( 'mark_pending_check' == $action ) {
				foreach ( $ids as $id ) {
					yith_wecvti_update_ticket_status( $id, 'yi-pending-check' );
				}
			}
			if ( 'mark_cancelled' == $action ) {
				foreach ( $ids as $id ) {
					yith_wecvti_update_ticket_status( $id, 'yi-cancelled' );
				}
			}

			return $redirect_to;
		}

		public function add_search_ticket_for( $query, $text ) {
			global $wpdb;

			$matching_ids = $wpdb->get_col( $wpdb->prepare(
				"SELECT DISTINCT ID FROM {$wpdb->posts} AS p
                       LEFT JOIN {$wpdb->postmeta} AS pm ON p.ID = pm.post_id
			           WHERE p.post_type = %s
			           AND ( ( pm.meta_key = %s AND pm.meta_value LIKE %s ) OR ( pm.meta_key = %s AND pm.meta_value LIKE %s ) OR ( pm.meta_key = %s AND pm.meta_value LIKE %s ) )",
				"ticket",
                "_barcode_display_value_ticket",
				"%{$text}%",
				"_barcode_display_value_order",
                "%{$text}%",
				"_barcode_display_value_product" ,
                "%{$text}%"
			) );

			$search_string = implode( ',', $matching_ids );

			if( ! empty( $matching_ids ) ) {
				$query .= "OR {$wpdb->posts}.ID IN ({$search_string})";
			}

			return $query;
		}


        public function plugin_row_meta( $new_row_meta_args, $plugin_meta, $plugin_file, $plugin_data, $status, $init_file = 'YITH_WCEVTI_INIT' ) {
            $new_row_meta_args = parent::plugin_row_meta( $new_row_meta_args, $plugin_meta, $plugin_file, $plugin_data, $status, $init_file );

            if ( defined( $init_file ) && constant( $init_file ) == $plugin_file ){
                $new_row_meta_args['is_premium'] = true;
            }

            return $new_row_meta_args;
        }

        public function action_links( $links ) {
            $links = yith_add_action_links( $links, $this->_panel_page, true );
            return $links;
        }



    }
}