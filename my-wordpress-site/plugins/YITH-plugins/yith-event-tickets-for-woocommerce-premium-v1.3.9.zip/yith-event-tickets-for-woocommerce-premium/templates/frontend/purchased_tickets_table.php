<!doctype html>
<html lang="en">
<?php
$avoid_print_tickets_table = current_user_can( 'manage_woocommerce' );
$avoid_print_tickets_table = ! empty( $avoid_print_tickets_table ) ? false : true;

$avoid_print_tickets_table = apply_filters( 'yith_wcevti_print_tickets_table', $avoid_print_tickets_table, $product_id );

if ( $avoid_print_tickets_table ) {
	return;
}

$mail_template   = get_post_meta( $product_id, '_mail_template', true );
$barcode_options = isset($mail_template['data']) && ! empty( $mail_template['data']['barcode'] ) & 'on' == $mail_template['data']['barcode']['display'] ? $mail_template['data']['barcode'] : false;
?>
<head>
    <meta charset="utf-8">
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,800" rel="stylesheet">
    <style type="text/css">
    </style>
</head>
<body>
<table style="border-collapse: collapse">
    <tr>
		<?php
		$columns_line = explode( ',', $list['columns'] );
		if ( 'on' == $barcode_options['display'] ) {
			?>
            <th style="border: 1px solid black">
				<?php echo __( 'Barcode', 'yith-event-tickets-for-woocommerce' ); ?>
            </th>
			<?php
		}

		foreach ( $columns_line as $column_line ) {
			?>
            <th style="border: 1px solid black">
				<?php echo $column_line; ?>
            </th>
		<?php } ?>
    </tr>

	<?php foreach ( $list['rows'] as $row ) {
		?>
        <tr>
			<?php
			$row_exploded = explode( ',', $row );
			if ( 'on' == $barcode_options['display'] ) {
				?>
                <td style="border: 1px solid black;text-align: center;">
					<?php echo yith_wcevti_get_barcode_rendered( $row_exploded[1], $barcode_options ); ?>
                </td>
				<?php
			}
			foreach ( $row_exploded as $cell ) {
				?>
                <td style="border: 1px solid black">
					<?php echo $cell; ?>
                </td>

				<?php
			}
			?>

        </tr>
		<?php
	} ?>
</table>
</body>
</html>