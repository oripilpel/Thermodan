<?php
if(isset($organization['display'])){
    if('on' == $organization['display']){
    	$attributes = apply_filters( 'yith_wctevi_atts_organizers_shortcode_tab', '');
      echo  do_shortcode('[organizers ' . $attributes . ']');
    }
}

$attributes = apply_filters( 'yith_wctevi_atts_users_purchased_shortcode_tab', '');
echo do_shortcode('[users_purchased ' . $attributes . ']');