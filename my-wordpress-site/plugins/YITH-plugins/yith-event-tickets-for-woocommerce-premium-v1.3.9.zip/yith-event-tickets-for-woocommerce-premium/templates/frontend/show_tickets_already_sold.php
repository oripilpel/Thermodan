<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCEVTI_PATH' ) ) {
    exit( 'Direct access forbidden.' );
}
/**
 *
 *
 * @template   show_tickets_already_sold
 * @package    Yithemes
 * @since      Version 1.1.9
 * @author     Danirel Sanchez
 *
 */

global $wpdb;

$orders_statuses = "'wc-completed', 'wc-processing', 'wc-on-hold'";
$order_status = apply_filters( 'yith_wc_event_tickets_show_already_sold_order_status', array( 'wc-completed', 'wc-processing', 'wc-on-hold', 'wc-pending' ) );

$results = apply_filters('yith_wc_event_tickets_show_already_sold_tickets', $wpdb->get_col("
        SELECT order_items.order_id
        FROM {$wpdb->prefix}woocommerce_order_items as order_items
        LEFT JOIN {$wpdb->prefix}woocommerce_order_itemmeta as order_item_meta ON order_items.order_item_id = order_item_meta.order_item_id
        LEFT JOIN {$wpdb->posts} AS posts ON order_items.order_id = posts.ID
        WHERE posts.post_type = 'shop_order'
        AND posts.post_status IN ( '" . implode( "','", $order_status ) . "' )
        AND order_items.order_item_type = 'line_item'
        AND order_item_meta.meta_key = '_product_id'
        AND order_item_meta.meta_value = '$product_id'
    "));
$content = "<p><strong>" . count( $results ) . "</strong> " . _x( 'tickets already sold', 'show tickets already sold', 'yith-event-tickets-for-woocommerce' ) . "</p>";

$content = apply_filters( 'yith_wc_event_tickets_show_already_sold_text', $content, count( $results ), $product_id, $results );

echo $content;