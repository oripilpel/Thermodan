<label> <?php echo $address ?> </label>
<div class="yith_wcevti_address_map_div">
    <div id="" class="yith_wcevti_address_map" data-latitude ="<?php echo $latitude ?>" data-longitude ="<?php echo $longitude ?>">

    </div>
</div>
