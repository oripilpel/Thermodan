<?php
echo do_shortcode('[event_map]');