<?php
/*
 * This file belongs to the YIT Framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

if ( ! defined( 'YITH_WCEVTI_PATH' ) ) {
    exit( 'Direct access forbidden.' );
}
/**
 *
 *
 * @template   show_tickets_already_sold
 * @package    Yithemes
 * @since      Version 1.1.9
 * @author     Danirel Sanchez
 *
 */

?>

<div class="show_if_ticket-event">
    <p class="form-field _enable_show_tickets_sold ">
        <label for="_show_tickets_sold"><?php echo __('Show number of tickets already sold', 'yith-event-tickets-for-woocommerce') ?></label>
        <input  id="_show_tickets_sold"
                type="checkbox"
                class="yith-wceti-already_sold"
                style="" name="_already_sold[_enable]"
            <?php if ( isset( $already_sold[ '_enable' ] ) ){ if ( 'on' == $already_sold[ '_enable' ] ) { echo 'checked'; } }?>
        >
    </p>
</div>