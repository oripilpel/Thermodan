<div class="yith_evti_mail_template_container">
    <div class="yith_evti_mail_template_panel">
        <div class="yith_evti_mail_template_content">

            <?php

            $post_meta = get_post_meta( $post->ID, '', true );
            $mail_template = get_post_meta( $post_meta['wc_event_id'][0], '_mail_template', true );
            $header_image = $mail_template['data']['header_image']['uri'];

            if( apply_filters( 'yith_wcevti_image_pdf_path', false ) ) { //use the path instead of url

                $uploads = wp_upload_dir();
                $array_header_logo_path = explode("uploads", $header_image);
                $header_image = $uploads[ 'basedir' ] . $array_header_logo_path[ 1 ];
            }



            ?>
            
            <?php if ( false != $barcode_rendered ){ ?>
                <?php if( !empty($header_image) ) {?>
                    <div class="yith_evti_mail_template_header">
                    <div class="header_image" style="width: 85%; height: auto; max-height: 25%; float:left">
                        <img src="<?php echo $header_image ?>" alt="">
                    </div>
                <?php } ?>

                <div id="header_barcode" style="width: auto; height: 25%; float:right; ">
                    <div class="barcode_container">
                        <?php echo $barcode_rendered;?>
                    </div>
                </div>
                </div>

            <?php }
            else{?>
                <?php if( !empty($header_image) ) {?>

                    <div class="yith_evti_mail_template_header">
                        <div class="header_image" style="align-content: center; width: 100%;">
                            <img src="<?php echo $header_image ?>" alt="">
                        </div>
                    </div>
                <?php } ?>
            <?php } ?>


            <div style="display: inline-block">
                <strong>&#9986; - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - - -</strong>
            </div>

            <div id="content_main">
                <div id="content_title">
                    <h2><?php
                        if('on' == $display_ticket_number){
                            echo '#' . $post->ID . ' ';
                        }
                        echo $post->post_title; ?></h2>
                    <?php do_action('yith_wcevti_default_html_after_title', $post) ?>
                </div>
                <div id="content_fields">
                    <?php
                    if(isset($fields)){
                        if(is_array($fields)){
                            foreach ($fields as $field){
                                if(isset($field) & !empty($field)){
                                    $label = key($field);
                                    $field = $field[$label];
                                    ?>
                                    <p class="form-field">
                                        <label for="_ticket_field_<?php echo esc_html($label)?>"><?php echo esc_html($label)?>: </label>
                                        <span id="_ticket_field_<?php echo esc_html($label)?>"><?php echo esc_html($field);?> </span>
                                    </p>
                                    <?php
                                }
                            }
                        }
                    }
                    ?>
                </div>
                <?php
                do_action('yith_wcevti_default_html_end_fields', $post);
                if(!empty($date['message_start']) & !empty($date['message_end'])){
                    ?>
                    <div id="content_date">
                        <p>
                            <?php echo $date['message_start'];?>
                        </p>
                        <p>
                            <?php echo $date['message_end'];?>
                        </p>
                    </div>
                    <?php
                }
                do_action('yith_wcevti_default_html_end_date', $post);
                $formated_price_service =  sprintf( get_woocommerce_price_format(),  get_woocommerce_currency_symbol() , $price );
                ?>
                <div id="content_price">
                    <p class="form-field">
                        <label for="_content_price"><?php echo __('Price', 'yith-event-tickets-for-woocommerce'); ?>: </label>
                        <span id="_content_price"><?php echo $price?></span>
                    </p>
                </div>
                <?php
                do_action('yith_wcevti_default_html_end_price', $post);
                ?>
                <div id="content_aditional">
                    <p>
                        <?php echo nl2br( esc_html($mail_template['data']['aditional_text'] ) );?>
                    </p>
                </div>
                <?php
                do_action('yith_wcevti_default_html_end_aditional', $post);

                ?>
            </div>
        </div>

        <div class="yith_evti_mail_template_footer">
            <table class="footer_table">
                <tr>
                    <td>
                        <div class="footer_logo">
                            <?php
                            if( $footer_image ){
                                if( apply_filters( 'yith_wcevti_image_pdf_path', false ) ) {
                                    $uploads = wp_upload_dir();
                                    $array_footer_logo_path = explode("uploads", $footer_image[0]);
                                    $footer_image[0] = $uploads[ 'basedir' ] . $array_footer_logo_path[ 1 ];
                                }
                                ?>
                                <img class="footer_image" src="<?php echo $footer_image[0]; ?>" width="<?php if(isset($footer_image[1])){ echo $footer_image[1];} ?>" height="<?php if (isset($footer_image[2])){ echo $footer_image[2];} ?>">
                            <?php }
                            ?>
                        </div>
                    </td>
                    <td>
                        <div class="footer_text">
                            <p>
                                <?php echo get_home_url();?>
                            </p>
                        </div>
                    </td>
                </tr>
            </table>
        </div>
    </div>
</div>
