<?php
$header_title_width       = '100';
$header_image_margin_left = '5';
$header_title_left        = '6';
$header_title_left_border = YITH_WCEVTI_ASSETS_URL . '/images/triangle-pattern.png';
$barcode_image_transform = 'transform: rotate(90deg);';
$barcode_image_padding = 'padding: 0em -15em -3em -15em;';
$barcode_image_margin_bottom = 'margin-bottom: 3em;';
$barcode_image_margin_left = 'margin-left: 6em;';
$barcode_display_container_padding = 'padding: 8em 0em 0em 0em;';


if('on' == $barcode['display'] & defined('YITH_YWBC_PREMIUM') & !empty($barcode_rendered)){
    $header_title_width = '80';
    $header_image_margin_left = '1.75';
    $header_title_left = '3';
    $header_title_left_border = YITH_WCEVTI_ASSETS_URL . '/images/circle-pattern.png' ;
    $barcode_protocol = get_post_meta($post->ID, '_ywbc_barcode_protocol', true);
    $barcode_image_transform = ('QRcode' == $barcode_protocol) ? '' : $barcode_image_transform ;
    $barcode_image_padding = ('QRcode' == $barcode_protocol) ? '' : $barcode_image_padding ;
    $barcode_image_margin_bottom = ('QRcode' == $barcode_protocol) ? '' : $barcode_image_margin_bottom ;
    $barcode_image_margin_left = ('QRcode' == $barcode_protocol) ? '' : $barcode_image_margin_left ;
    $barcode_display_container_padding = ('QRcode' == $barcode_protocol) ? '' : $barcode_display_container_padding ;
}
?>

    body{
    font-family: "dejavusans";
    background: white;
    }
    .yith_evti_mail_template_panel{
    margin: auto;
    width: 604px;
    }
    #content_main {
    background-image: url(<?php echo $content_image[0]; ?>);
    background-repeat: no-repeat;
    border-radius: 7px;
    padding: 1em 2em 1em 2em;
    }
    .yith_evti_mail_template_footer{
    background-color: #BEBEBE;
    border: 1px solid #BEBEBE;
    width: 100%;
    }
    .footer_table{
    padding: 1em;
    }
    .footer_logo{
    margin-right: 1em;
    }
    .footer_text{
    color: white;
    font-weight: bold;
    font-size: 0.7em;
    }
    .barcode_container{
    text-align: center;
    }
    .ywbc-barcode-image{
<?php echo $barcode_image_transform?>
<?php echo $barcode_image_padding?>
<?php echo $barcode_image_margin_bottom?>
<?php echo $barcode_image_margin_left?>
    }
    .ywbc-barcode-display-container{
<?php echo $barcode_display_container_padding?>
    }




<?php
do_action( 'yith_wcevti_end_default_css' );