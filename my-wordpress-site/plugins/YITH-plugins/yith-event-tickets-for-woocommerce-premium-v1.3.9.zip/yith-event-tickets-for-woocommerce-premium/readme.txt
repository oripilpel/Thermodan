=== YITH Event Tickets for WooCommerce ===

Contributors: yithemes
Tags: event, ticket, events, e-commerce, WooCommerce, calendar, yit, yith, yithemes
Requires at least: 4.0
Tested up to: 5.3
Stable tag: 1.3.9
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html/

Start selling tickets for all sorts of events on your own website with YITH Event Tickets for WooCommerce.

== Description ==

Your users will simply have to select the event they want to take part in, fill out the required fields, like first and last name, seat and any other piece of information you require and proceed to checkout.
This will make you manage tickets in a simple way from your own website and will make you save the money needed if you had to rely on external services.

= Features: =

* Events management (create/edit) + table list + single event data
* Search the event per city, date or per word search + possible filters
* Enable additional fields, to be filled by the customer when purchasing
* Insert the tickets as administrator (complete management of the tickets)
* Can set the number of tickets that can be sold (100 available tickets)
* The administrator can display a report with the sold tickets, completed payments and also make the check-in of the person who purchased
* Integration with barcode/qr code
* Handle tickets stock
* Insert start and end ticket date.
* Integration with Google Calendar
* Print out the ticket from the summary page after the purchase
* Download the ticket in PDF
* Receive the ticket in the email attachment

= Premium features: =

* Check in system is coming, now you can make check in on frontend with a shortcode or tickets table on admin side.
* Exports purchased tickets to CSV or printable table.
* Insert the map of the event location
* Insert a (widget/shortcode) with the agenda to be shown
* Display all the events in the form of a calendar (widget+shortcode)
* Can enable reduced ticket, and choose price
* Insert different ticket variations
* Assign a number or a letter or a code to each ticket
* Make automatically increase the ticket value per threshold time frame
* Increase the ticket by thresholds basing on the number of remaining tickets (the last 20 tickets cost 50% more)
* Decide to show all the people who purchased the ticket to the users
* Choose not to be shown on the summary page of the people who take part in the event
* Can also match the selection (adult-seat; child-chair)
* Choose several tickets by typology (2 seats 3 chairs 4 bleachers)
* Will see the price increasing depending on the applied selections in a dynamic way
* The user can choose the ticket number/code/letter during the purchase
* Can decide if the ticket will be virtual or physical

= Premium Live Demo =


Do you want to discover all plugin features? Would you like to try it?

Visit our **[test sandbox](https://plugins.yithemes.com/yith-event-tickets-for-woocommerce/)**
By accessing our testing platform, you will be able to discover all plugin features and test it as your prefer, both in back end and in front end.

What are you waiting for, visit the official "**[live demo](https://plugins.yithemes.com/yith-event-tickets-for-woocommerce/)**" of the plugin and click on "LAUNCH ADMIN DEMO" link that you find in the topbar to make test our plugin right now.

= Coming Soon =

- Add Option to make events expire after end date (no more purchasable/no more visible)

= Languages =

Also available in:

* English (default).

== Screenshots ==

1. Admin: Set start and end date event
2. Admin: Set the fields of event
3. Admin: Display purchased tickets table
4. Admin: Display tickets details from tickets table
5. User: Can buy ticket filling the fields.
6. User: Can see the fields filled on cart.
7. User: Can see the tickets purchased, view, print pdf export ticket to Goolge Calendar.
8. User: Can see the view ticket purchased.
9. User: Can print ticket purchased to PDF file
10. User: Can export ticket purchased to Google Calendar.

== Installation ==

**Important**: First of all, you have to download and activate [WooCommerce](https://wordpress.org/plugins/woocommerce) plugin, because without it YITH Event Ticket for WooCommerce cannot work.

1. Unzip the downloaded zip file.
2. Upload the plugin folder into the `wp-content/plugins/` directory of your WordPress site.
3. Activate `YITH Event Ticket for WooCommerce` from Plugins page.


== Changelog ==

= 1.3.9 - Released Nov, 08 - 2019 =

* New: support for WordPress 5.3
* New: support for WooCommerce 3.8
* New: added new order actions to send processing and completed order emails with event ticket PDF attached
* New: now select service options can be disabled
* New: now tickets can be filtered by Name and Status on backend
* New: now check-in shortcode allows to check-out tickets
* New: added automatic search option for check-in shortcode
* Update: Plugin framework
* Update: Italian language
* Update: Spanish language
* Fix: missing services in CSV export of the tickets
* Dev: added new parameter to yith_start_date_message and yith_end_date_message filters
* Dev: added new parameters to yith_wcevti_allowed_emails filter
* Dev: added ticket price to get_purchased_ticket method
* Dev: added new filter yith_wcevti_add_view_and_gcalendar_button_custom_status
* Dev: added new filter yith_wcevt_args_ticket_purchased_template
* Dev: added new filter yith_check_if_expired_event

= 1.3.8 - Released Aug, 12 - 2019 =

* New: WooCommerce 3.7 support
* Tweak: removed call that retrieves all tickets for checkin shortcode (ajax loading will be applied anyway)
* Tweak: add args for service metabox template
* Tweak: check if $item_meta exists
* Tweak: added stripslashes wherever it is required
* Update: internal plugin framework
* Fix: prevent fatal error when not isset $get[post_type]
* Fix: issue with services index, causing new items overwriting previous one
* Fix: fixed barcode value in the CSV export
* Dev: new filters yith_wcevti_load_tickets_purchased and yith_wcevti_search_ticket_output
* Dev: new filter yith_wc_event_tickets_show_already_sold_tickets
* Dev: new action yith_wcevti_order_metabox_end_services

= 1.3.7 - Released May, 30 - 2019 =

* Update: Added new fonts to mpdf library
* Tweak: Add year range as a parameter
* Dev: Filter yith_wcevt_get_tickets_purchased_by_order_items
* Dev: Filter yith_wcevti_year_range

= 1.3.6 - Released Apr, 16 - 2019 =

* New: WooCommerce 3.6 support
* Tweak: added jquery-blockui as a dependency
* Tweak: improved message when a ticket is already checked
* Tweak: disable the service if it doesn't have stock
* Update: internal plugin framework
* Update: Spanish language
* Fix: how to get the services type select name for the CSV
* Fix: problem with the delimiter on csv exporter when the field doesn't exists
* Fix: added yes or no field to the text domain
* Fix: removed appropriate class when ticket message is closed
* Fix: fixed message colors when searching if the ticket is checked
* Dev: added filter yith_wcevt_ticket_purchased_row
* Dev: added filter yith_wcevt_display_fields_panel
* Dev: added filter yith_wcevt_export_csv

= 1.3.5 - Released Feb, 19 - 2019 =

* Tweak: allow numbers leading with zero in the numbers input
* Update: updated plugin FW
* Fix: fixed a warning
* Fix: fixed problem to display shortcode in the right way
* Dev: added new filter yith_event_ticket_display_barcode_option and yith_event_ticket_display_ticket_number_option
* Dev: added new filter yith_wcevt_get_csv_list_column, yith_wcevt_get_csv_row and yith_wcevt_get_user_from_order
* Dev: added dynamic filter yith_wcevt_passed_item_field_'.$field['_type']


= 1.3.4 - Released Dec, 31 - 2018 =

* New: Support to WordPress 5.0.2
* Tweak: change input type to allow decimals on overcharge option
* Update: Updated Dutch Language
* Update: updated plugin FW
* Update: updated .pot
* Dev: added filter yith_wcevti_get_event_name
* Dev: added filter yith_wcevti_view_pdf_and_gcalendar_post_status
* Dev: added filter yith_wcevti_when_status_changed
* Dev: added filter yith_wcevt_display_barcode_and_qr_code_notice
* Dev: added new parameters on yith_wcevti_event_title_form filter


= 1.3.3 - Released Oct, 25 - 2018 =

* New: WooCommerce 3.5 support
* Tweak: updated plugin framework

= 1.3.2 - Released Oct, 16 - 2018 =

* New: WooCommerce 3.5-rc support
* New: WordPress 4.9.8 support
* Tweak: updated plugin framework

= 1.3.1 - Released Oct, 02 - 2018 =

* Update: Dutch language
* Update:Updating plugin Framework
* Fix: Adding a quantity 1 in the cart for even tickets products
* Fix: Fixed notice on tab_assistants_for_organizers index
* Dev: Filter yith_wcevti_image_pdf_path to allow use the direct path instead of url


= 1.3.0 - Released Sep, 04 - 2018 =

* New: New PDF template for the tickets
* Tweak: Improving the CSV export
* Tweak: Added order id among search parameters for tickets
* Tweak: Improve the date picker fields year selector
* Dev: Added new filter yith_wcevt_display_checking_event
* Dev: Added a new filter in the frontend script url
* Dev: Sanitize service label whenever required
* Dev: Added yith_wcevti_checkbox_cart_label filter
* Dev: Added new filter yith_wcevti_mpdf_args
* Dev: Added a new filter in the ID of the check_in_event shortcode
* Fix: Fixing minor issues
* Fix: Fixed a problem in the shortcode
* Fix: Fixed JS problem in label with apostrophe
* Fix: Fixing an issue with the print button


= 1.2 - Released Jun, 15 - 2018 =

* New: add even tickets capabilities to the administrator and shop_manager role
* Update: Spanish translation
* Update: Italian translation
* Update: Dutch translation
* Dev: added a new argument to a filter
* Dev: New filter yith_wcevti_date_format_frontend_js
* Dev: check if isset $already_sold[ '_enable' ]
* Fix: Fixed checkbox services stock not working properly
* Fix: check if order exists for prevent errors with paypal plus

= 1.1.9 - Released May, 28 - 2018 =

* New: WooCommerce 3.4 compatibility
* New: WordPress 4.9.6 compatibility
* New: GDPR compliance
* New: added additional information to tickets export
* Tweak: hide Ticket and PDF buttons if the order is a deposit
* Update: Italian language
* Fix: disabled the quantity in the cart when the product is a ticket.
* Dev: added new filter 'yith_ywet_barcode_rendered'
* Dev: added new filter 'yith_wcevti_calendar_script_path'
* Dev: added new filter 'yith_wcevti_date_format'
* Dev: added new filter 'yith_wcevti_date_format_frontend'
* Dev: added new filter 'yith_wcevti_hide_surcharge'

= 1.1.8 - Released Feb, 23, - 2018 =

* New: Updated MPDF library.
* New: Added conditions for organizers and assitant list, now you can choose if the lists can be only displayed for organizers. Using filters.
* New: Added delay days to define how much time has to pass before an expired event can be removed from sale.
* Tweak: Now CSV display Barcode value.
* Tweak: Widget Calendar display "On Stock" and "Out Stock" events.
* Tweak: You can customize the date message with filters.
* Tweak: You can define margins on PDF.
* Fix: Export CSV issue with charset.
* Fix: Little changes for services.
* Fix: Barcode issue, now generates a new barcode if the ticket barcode doesn't exist.
* Fix: Deleted tickets on form dialog window works fine now.
* Fix: Widget Calendar quick clicks loads ajax results on the last month fixed.
* Fix: Load location data instead location feature disabled fixed.

= 1.1.7 - Released: Jan, 30 - 2018 =

* New: Support to WooCommerce 3.3.x version.
* New: Support to YITH Plugin Framework 3.0.6
* New: Cancelled ticket status, for the moment is a visual element. Can`t release purchased services.
* New: Added new hooks for third parties.
* Tweak: Improve double check method.
* Tweak: Added check over booked services on load cart from session.
* Tweak: Improved queried requests.
* Tweak: Added overcharge info.
* Tweak: Check PDF creation before mail send.
* Tweak: Change "Add to Cart" text for expired events.
* Fix: Issue with double tickets with YITH Multi Vendor plugin.
* Fix: Issue with export services.
* Fix: Calendar shortcode position always on top content fixed.
* Fix: Issue with datepicker for multiples tickets.

= 1.1.6 - Released: Nov, 14 - 2017 =

* Tweak: Improve persistence with services purchased and orders. Added double check confirmation when services will be loaded on frontend (disabled by default). Now changing the status order we can release and lock services.
* Tweak: Now the date will be display resumed.
* Fix: Problem with QR.
* Fix: Issue that generates manual tickets.
* Fix: Avoid mail spam with the generation link tickets. Now link will be generated when be need it.
* Fix: CSS Styles.

= 1.1.5 - Released: Oct, 5 - 2017 =

* New: Added Expire Date feature, disable if date was expired.
* New: Added Expire Date feature, hide if date was expired.
* Tweak: Added news hooks for tickets templates and display options.
* Fix: Save assistant tab.
* Fix: Issue that generates unnecessary tickets.

= 1.1.4 - Released: Aug, 14 - 2017 =

* Tweak: Improve security system.
* Tweak: Date format defined by WordPress options.
* New: Added Spanish and Italian languages.
* Fix: Empty date time, now avoid display '00000' if admin let empty date time field.
* Fix: Compatibility issues.
* Fix: Fields save on custom post type.
* Fix: Display ticket number.
* Fix: Redundancy cart data.
* Fix: Compatibility problem on PHP 5.4.34.

= 1.1.3 - Released: Jul, 13 - 2017 =

* New: Check in system is coming, make check in event from a shortcode or admin tickets table side.
* New: Tickets table style renew and adapted to check in system.
* New: Tickets table sortable columns.
* New: Search your tickets by ticket number, ticket barcode number and order barcode number.
* New: Automatic check in on frontend with shortcode. Good for barcode scanner device.
* New: Bulk actions to make check in on tickets table, mark checked or pending check.
* New: Export purchased tickets to CSV or printable table. Print your results founded on frontend shortcode or from edit product page.
* New: Hooks for thirds developers.
* Tweak: Added stock quantity on widget calendar and clickable event on calendar widget.
* Tweak: Added option to hide label and put placeholder on fields.
* Tweak: Added hide surcharge service option.
* Tweak: Added option to load form ticket via ajax or js, only for developers.
* Tweak: Added option that allows print ticket number just before title on email template.
* Tweak: PDF ticket changed background color to white to optimize ink printer.
* Tweak: Option to enable or disable save cookie form.
* Tweak: Yes/No option field type added.
* Tweak: Regenerate pdf tickets if has been removed.
* Fix: Price taxes on ticket template.
* Fix: Google Calendar issue.
* Fix: Start and end date time lenght.
* Fix: Empty service option.
* Fix: Format price on frontend.
* Fix: Print users who purchased tickets when orders are on processing and complete status.
* Fix: WooCommerce deactive.

= 1.1.2 - Released: Apr, 26 - 2017 =

* Fix: Save stock services.

= 1.1.1 - Released: Apr, 25 - 2017 =

* New: Datepicker for date field on frontend.
* New: Added downloaded option.
* Tweak: Change 'overcharge' to 'surcharge' translation.
* Fix: Saving duplicated post meta.
* Fix: Update post meta problem for custom data.


= 1.1.0 - Released: Mar, 9 - 2017 =

* New: Support to WooCommerce 2.7 RC 1
* New: Calendar widget title. Now you can set title on widget.
* New: Added date field type on 'Fields'.
* Update: Yith Plugin Framework.
* Update: Third tools. Now your events from Calendar widget are clickable to product page.
* Update: Added javascript that enable or disable map tab check on admin product page, when map field its changed.
* Fix: Currency position fixed. Now the symbol will be display defined by WooCommerce settings.
* Fix: Url to enable map settings from product page.
* Fix: Break lines on pdf and preview template.
* Fix: Url documentation on plugins page.
* Fix: Some errors and style issues.


= 1.0.2 - Released: Feb, 9 - 2017 =

* Update: Added 'id' attribute for [users_purchased] and [organizers]. Now shortcodes can be loaded any place on frontend.
* Tweak: Now event date and location are display on ticket template, before price.
* Fix: Some style error with quantity field for some templates.
* Fix: Bug style with wrapper title on ticket template.
* Fix: Problem to load pdf file from some server.
* Fix: Auto fill form with cookies.
* Fix: Error map on frontend console.

= 1.0.1 - Released: Jan, 23 - 2017 =

* Tweak: Improve frontend form design. Customer can handle accordion panels, remove tickets.
* Tweak: Frontend form loads on client browser, removed ajax call for each ticket added.
* Tweak: Less intrusive validation on frontend forms. Messages display when customer click on 'Add to cart button'.

= 1.0.0 =

* Initial release

