<?php
/*
 * This file belongs to the YITH framework.
 *
 * This source file is subject to the GNU GENERAL PUBLIC LICENSE (GPL 3.0)
 * that is bundled with this package in the file LICENSE.txt.
 * It is also available through the world-wide-web at this URL:
 * http://www.gnu.org/licenses/gpl-3.0.txt
 */

return array(

	'settings' => apply_filters( 'yith_wcte_settings_options', array(

			'settings_options_start' => array(
				'type' => 'sectionstart',
				'id'   => 'yith_wcte_settings_options_start'
			),

			'settings_options_title' => array(
				'title' => _x( 'General settings', 'Panel: page title', 'yith-event-tickets-for-woocommerce' ),
				'type'  => 'title',
				'desc'  => '',
				'id'    => 'yith_wcte_settings_options_title'
			),

			'settings_enable_location' => array(
				'title'   => _x( 'Enable Location site:', 'Admin option: Enable location maps', 'yith-event-tickets-for-woocommerce' ),
				'type'    => 'checkbox',
				'desc'    => _x( 'Check this option to enable Google Maps event location', 'Admin option: Enable location maps',
					'yith-event-tickets-for-woocommerce' ),
				'id'      => 'yith_wcte_enable_location',
				'default' => 'yes'
			),

			'settings_api_key_gmaps' => array(
				'title' => _x( 'Google Maps API Key:', 'Admin option: Google Maps Api Key', 'yith-event-tickets-for-woocommerce' ),
				'type'  => 'text',
				'desc'  => _x( 'Your Api Key here, you need a Google Developer account to generate your Api Key for Google Maps', 'Admin option:
                Google Maps Api Key', 'yith-event-tickets-for-woocommerce' ),
				'id'    => 'yith_wcte_api_key_gmaps'
			),

			'settings_enable_purchasable_expired' => array(
				'title' => _x( 'Disable sale if expired:', 'Admin option to choose whether to remove events with past dates from sale or
	            not',
					'yith-event-tickets-for-woocommerce' ), //@since 1.1.5
				'type'  => 'checkbox',
				'desc'  => _x( 'Choose whether you want to remove events with past dates from sale or not', 'Admin option description',
					'yith-event-tickets-for-woocommerce' ), //@since 1.1.5
				'id'    => 'yith_wcte_purchasable_expired'
			),

			'settings_text_expired' => array(
				'title' => _x( 'Text for expired events:', 'Admin option that defines the text used by expired dates', 'yith-event-tickets-for-woocommerce' ),
				//@since 1.1.7
				'type'  => 'text',
				'id'    => 'yith_wcte_text_expired'
			),

			'settings_enable_visible_expired' => array(
				'title' => _x( 'Hide if expired:', 'Admin option to choose whether to hide events with past dates', 'yith-event-tickets-for-woocommerce' ),
				//@since 1.1.5
				'type'  => 'checkbox',
				'desc'  => _x( 'Choose whether you want to hide events with past dates', 'Admin option description',
					'yith-event-tickets-for-woocommerce' ),
				//@since 1.1.5
				'id'    => 'yith_wcte_visible_expired'
			),

			'settings_delay_for_expired_events' => array(
				'title' => _x( 'Delay time for expired events (days)', 'Admin options to define the time that has to pass before an expired event is hidden', 'yith-event-tickets-for-woocommerce' ),
				//@since 1.1.8
				'type'  => 'number',
				'desc'  => _x( 'Define how much time has to pass before an expired event can be removed from sale', 'yith-event-tickets-for-woocommerce' ),
				//@since 1.1.8
				'id'    => 'yith_wcte_delay_expired'
			),

			'settings_options_end' => array(
				'type' => 'sectionend',
				'id'   => 'yith_wcte_settings_options_end'
			),
		)
	)
);