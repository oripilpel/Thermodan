﻿=== YITH FAQ Plugin for WordPress Premium ===

Contributors: yithemes
Tags: faq, faqs, yit, yith, yithemes, e-commerce, shop, frequently asked questions
Requires at least: 4.0
Tested up to: 5.3
Stable tag: 1.1.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.1.2 =

* Update: plugin framework

= 1.1.1 =

* Update: plugin framework

= 1.1.0 =

* New: Support for WordPress 5.3 RC2
* Update: plugin framework
* Update: Spanish language

= 1.0.9 =

* Update: plugin framework
* Update: Italian language

= 1.0.8 =

* New: Support to WordPress 5.2
* Update: plugin framework

= 1.0.7 =

* Update: plugin framework

= 1.0.6 =

* Update: plugin framework
* Fix: fixed category filter CSS
* Dev: added filter yith_faq_enable_scroll

= 1.0.5 =

* New: Support to WordPress 5.0
* New: Gutenberg block for FAQ shortcode
* Update: plugin framework

= 1.0.4 =

* Update: plugin framework

= 1.0.3 =

* Fix: scripts conflicting with other plugins scripts

= 1.0.2 =

* New: Italian translation
* Update: plugin framework

= 1.0.1 =

* New: Dutch translation
* Update: plugin framework
* Fix: pagination links behavior

= 1.0.0 =

* Initial release
