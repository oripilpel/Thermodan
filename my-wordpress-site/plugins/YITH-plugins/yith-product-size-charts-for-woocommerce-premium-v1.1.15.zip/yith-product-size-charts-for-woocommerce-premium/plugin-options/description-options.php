<?php
// Exit if accessed directly
! defined( 'YITH_WCPSC' )  && exit();

return array(
    'description' => array(
        'description' => array(
            'type'         => 'custom_tab',
            'action'       => 'yith_wcpsc_description_tab',
        )
    )
);  