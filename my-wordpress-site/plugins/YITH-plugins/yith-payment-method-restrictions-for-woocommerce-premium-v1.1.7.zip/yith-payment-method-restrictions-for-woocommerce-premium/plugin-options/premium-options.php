<?php

return array(
    'premium' => array(
        'home' => array(
            'type'   => 'custom_tab',
            'action' => 'yith_wcpmr_premium_tab',
            'hide_sidebar' => true
        )
    )
);