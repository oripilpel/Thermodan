== YITH WooCommerce Pending Order Survey  ==

= 1.0.13 =
* New: Support to WooCommerce 3.8
* New: Support to WordPress 5.3
* Update: Plugin Framework

= 1.0.12 =
* New: Support to WooCommerce 3.7 RC1
* Update: Plugin Framework

= 1.0.11 =
* New: Support to WordPress 5.2
* Update: Plugin Framework
* Update: Italian language


= 1.0.10 =
* New: Support to WooCommerce 3.6.0 RC1
* New: Support to WordPress 5.1.1
* Update: Plugin Framework
* Update: Spanish language


= 1.0.9 =
* New: Support to WooCommerce 3.5.4
* Update: Plugin Framework
* Dev: Added filter ywcpos_send_email_manually

= 1.0.8 =
* New: Support to WordPress 5.0
* Update: Plugin Framework

= 1.0.7 =
* Update: Plugin Framework
* Update: Language Files

= 1.0.6 =
* New: Support to WooCommerce 3.5.0
* Update: Plugin Framework
* Update: Italian language

= 1.0.5 =

* New: Support to WooCommerce 3.4.0
* New: Support to WordPress 4.9.6
* New: Support to GDPR compliance
* Update: Italian language
* Update: Spanish language
* Update: Plugin Framework

= 1.0.4
* New: Spanish language
* New: Support to WooCommerce 3.3.5
* New: Support to WordPress 4.9.5
* Update: Plugin Framework

= 1.0.3 =
* New: Support to WooCommerce 3.3.0
* New: Support to WordPress 4.9.2
* Update: Plugin Framework 3.0
= 1.0.2 =
* New: Support to WooCommerce 3.2.0
* New: Italian language file
* Update Plugin Framework

= 1.0.1 =
* New: Support to WooCommerce 3.0-RC2
* Update: Plugin Framework


= 1.0.0 =

* Initial release
