<p>The plugin monitors orders with pending payment status and sends one or more emails to users to invite them to complete the order.</p>
<p>If required, the email can include a link to a survey to which the user can answer.</p>
<p>Users' answers will be stored anonymously, that is only the survey and the related order data will be stored.</p>
<p>Uses the email stored in the order. This field follows the WooCommerce policy.</p>
<p>The plugin can send an email to users to thank them for completing the survey.</p>
