<?php
$tab = array(
    'gift-cards-category' => array(
        'custom-post-type_list_table' => array(
            'type'         => 'taxonomy',
            'taxonomy'    => 'giftcard-category',
        ),
    )
);

return $tab;