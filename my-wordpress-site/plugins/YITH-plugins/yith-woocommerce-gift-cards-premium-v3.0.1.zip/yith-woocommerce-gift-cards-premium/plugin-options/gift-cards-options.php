<?php
$tab = array(
    'gift-cards' => array(
        'custom-post-type_list_table' => array(
            'type'         => 'post_type',
            'post_type'    => 'gift_card',
        ),
    )
);

return $tab;