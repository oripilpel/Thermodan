<?php
/**
 * Gift Card product add to cart
 *
 * @author  Yithemes
 * @package YITH WooCommerce Gift Cards
 *
 */
if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

//dont show the design presets in the physical gift cards
if ( is_product() && is_object($product) && ! $product->is_virtual() ) {
    return;
}

$allow_customer_images = get_option ( "ywgc_custom_design", 'no');

?>
<script type="text/template" id="tmpl-gift-card-presets">
    <div id="ywgc-choose-design" class="ywgc-template-design">
        <div class="ywgc-design-list-menu">
            <?php if ( count( $categories ) > 0 ): ?>
            <h2 class="ywgc-design-categories-title"><?php echo apply_filters( 'yith_ywgc_design_categories_title_text', __( "Categories", 'yith-woocommerce-gift-cards' ) ); ?></h2>
                <ul class="ywgc-template-categories">
                    <li class="ywgc-template-item ywgc-category-all">
                        <a href="#" class="ywgc-show-category ywgc-category-selected" data-category-id="all">
                            <?php echo apply_filters( 'yith_ywgc_show_all_design_text', _x( "All", 'choose design', 'yith-woocommerce-gift-cards' ) ); ?>
                        </a>
                    </li>
                    <?php foreach ( $categories as $item ): ?>
                        <li class="ywgc-template-item ywgc-category-<?php echo $item->term_id; ?>">
                            <a href="#" class="ywgc-show-category" data-category-id="ywgc-category-<?php echo $item->term_id; ?>"><?php echo $item->name; ?></a>
                        </li>

                    <?php endforeach; ?>

                    <!-- Let the user to upload a file to be used as gift card main image -->
                    <?php if ( $allow_customer_images == 'yes' ) : ?>
                        <li class="ywgc-upload-section-modal">
                            <hr style="color: dimgrey; width: 50%; margin-bottom: 5px;">
                            <p class="ywgc-custom-design-menu-title"> <?php echo  __( "Or ", 'yith-woocommerce-gift-cards' ); ?>
                                <a href="#" class="ywgc-custom-design-menu-title-link"><?php echo  __( "Upload your photo/image >", 'yith-woocommerce-gift-cards' ); ?></a>
                            </p>
                        </li>
                    <?php endif; ?>

                </ul>
            <?php endif; ?>
        </div>
        <div class="ywgc-design-list-modal">

            <?php foreach ( $item_categories as $item_id => $categories ): ?>

                <div class="ywgc-design-item <?php echo $categories; ?> template-<?php echo $item_id; ?>">

                    <div class="ywgc-preset-image" data-design-id="<?php echo $item_id; ?>"  data-design-url="<?php echo yith_get_attachment_image_url( intval( $item_id ), 'full' ); ?>" >
                        <?php echo wp_get_attachment_image( intval( $item_id ), apply_filters('yith_ywgc_preset_image_size','shop_catalog' ) ); ?>

                        <?php if ( ( "yes" == get_option ( 'ywgc_show_preset_title', 'no' ) ) ):
                            $post = get_post( $item_id );
                            if ( $post ): ?>
                                <span class="ywgc-preset-title"><?php echo $post->post_title; ?></span>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>

                </div>

            <?php endforeach; ?>

        </div>

        <?php if ( $allow_customer_images == 'yes' ) : ?>
            <div class="ywgc-custom-upload-container-modal ywgc-hidden" style="padding-top: 1em; text-align: center">

                <h2><?php echo __( "Upload your photo/image", 'yith-woocommerce-gift-cards' ); ?></h2>
                <br>
                <p><?php echo __( "Here you can upload a customized image or a photo to make your gift card even more special!", 'yith-woocommerce-gift-cards' ); ?></p>

                <div class="ywgc-custom-design-modal-wrapper">
                    <span class="dashicons dashicons-dismiss ywgc-custom-design-modal-preview-close ywgc-hidden"></span>
                    <div class="ywgc-custom-design-modal-preview-container">

                    </div>
                </div>


                <p class="ywgc-custom-design-link">
                    <a href="#" title="<?php echo __( "Suggested size (px): ", 'yith-woocommerce-gift-cards' ) . get_option( 'ywgc_custom_design_suggested_size' , '180x330' ); ?>"
                       class="ywgc-choose-image-modal ywgc-custom-picture-modal" style="margin-bottom: 25px;">
                        <img src="<?php echo YITH_YWGC_ASSETS_IMAGES_URL . 'addimage.svg'?>" alt="" style="width: 30%;">
                    </a>
                </p>
                <input type="file" class="ywgc-hidden" name="ywgc-upload-picture-modal" id="ywgc-upload-picture-modal" accept="image/*" />

                <a class="ywgc-custom-image-modal-submit-link ywgc-hidden" href="#"><?php echo  __( "OK, USE THIS IMAGE", 'yith-woocommerce-gift-cards' ); ?></a>

            </div>
        <?php endif; ?>

    </div>
</script>