<?php
/**
 * Main class
 *
 * @author YITH
 * @package YITH WooCommerce Color and Label Variations Premium
 * @version 1.0.0
 */


if ( ! defined( 'YITH_WCCL' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WCCL' ) ) {
	/**
	 * YITH WooCommerce Color and Label Variations Premium
	 *
	 * @since 1.0.0
	 */
	class YITH_WCCL {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WCCL
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Plugin version
		 *
		 * @var string
		 * @since 1.0.0
		 */
		public $version = YITH_WCCL_VERSION;


		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WCCL
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 *
		 * @return mixed YITH_WCCL_Admin | YITH_WCCL_Frontend
		 * @since 1.0.0
		 */
		public function __construct() {

			// Load Plugin Framework
			add_action( 'after_setup_theme', array( $this, 'plugin_fw_loader' ), 1 );

			// Class admin
			if ( $this->is_admin() ) {
				// require classes
				require_once( 'class.yith-wccl-admin.php' );
				// Admin Class
				YITH_WCCL_Admin();
			}
			else {
				// require classes
				require_once( 'class.yith-wccl-frontend.php' );
				// Frontend Class
				YITH_WCCL_Frontend();
			}


			// add new attribute types
			add_filter( 'product_attributes_type_selector', array( $this, 'attribute_types' ), 10, 1 );

			// delete transient on update stock
            add_action( 'woocommerce_variation_set_stock', array( $this, 'delete_transient' ), 10, 1 );
            add_action( 'woocommerce_product_set_stock', array( $this, 'delete_transient' ), 10, 1 );
            // delete transient on save product
            add_action( 'woocommerce_before_product_object_save', array ( $this, 'delete_transient' ), 10, 2 );
            add_action( 'woocommerce_before_product_variation_object_save', array ( $this, 'delete_transient' ), 10, 2 );

            /* Compatibility with WP ALL IMPORT (import gallery for variations) */
            add_action('pmxi_gallery_image', array( $this,'wpai_import_gallery_images_variation'), 10, 4);

            //
            add_filter( 'woocommerce_product_export_meta_value', array( $this, 'product_export_meta_value' ), 10, 4 );
            add_filter( 'woocommerce_product_import_process_item_data', array( $this, 'product_import_gallery' ), 10, 2 );
		}

		/**
		 * Check if context is admin
		 *
		 * @since 1.2.2
		 * @author Francesco Licandro
		 * @return boolean
		 */
		public function is_admin(){
			$actions = apply_filters( 'yith_wccl_is_admin_actions_array', array(
				'prdctfltr_respond_550',
				'flatsome_quickview'
			));
			$is_frontend = isset( $_REQUEST['context'] ) && $_REQUEST['context'] == 'frontend';
			$is_ajax =  defined( 'DOING_AJAX' ) && DOING_AJAX && ( $is_frontend || ( isset( $_REQUEST['action'] ) && in_array( $_REQUEST['action'], $actions ) ) );
			
			return apply_filters( 'yith_wccl_load_admin_class', ( is_admin() && ! $is_ajax ) );
		}

		/**
		 * Load Plugin Framework
		 *
		 * @since  1.0
		 * @access public
		 * @return void
		 * @author Andrea Grillo <andrea.grillo@yithemes.com>
		 */
		public function plugin_fw_loader() {

			if ( ! defined( 'YIT_CORE_PLUGIN' ) ) {
				global $plugin_fw_data;
				if( ! empty( $plugin_fw_data ) ){
					$plugin_fw_file = array_shift( $plugin_fw_data );
					require_once( $plugin_fw_file );
				}
			}
		}

		/**
		 * Delete plugin transient on product save
		 *
		 * @since 1.5.0
		 * @author Francesco Licandro
		 * @param \WC_Product $product
		 * @param array $data
		 */
		public function delete_transient( $product, $data = array() ) {
		    // get the ID
            $id = $product->is_type( 'variation' ) ? $product->get_parent_id() : $product->get_id();
            delete_transient( 'yith_wccl_available_variations_' . $id );
		}

		/**
		 * Add new attribute types to standard WooCommerce
		 *
		 * @since 1.5.0
		 * @author Francesco Licandro <francesco.licandro@yithemes.com>
		 * @param array $default_type
		 * @return array
		 */
		public function attribute_types( $default_type ){
			$custom = ywccl_get_custom_tax_types();
			return is_array( $custom ) ? array_merge( $default_type, $custom ) : $default_type;
		}


        /**
         * Import gallery images for single variation with WP ALL IMPORT
         * @param $post_id
         * @param $att_id
         * @param $filepath
         * @param string $is_keep_existing_images
         */
		public function wpai_import_gallery_images_variation( $post_id, $att_id, $filepath, $is_keep_existing_images = '' ){
            $key = '_yith_wccl_gallery';  // Edit this: Set meta key for gallery array here

            // Get the ID of the featured image
            $featured_image = get_post_meta($post_id, '_thumbnail_id', true);

            $gallery = get_post_meta($post_id, $key, TRUE);
            if (empty($gallery)) {
                $gallery = array();
            }

            if (!in_array($att_id, $gallery) && ( !empty($featured_image) && $featured_image != $att_id ) ) {
                $gallery[] = $att_id;
                update_post_meta($post_id, $key, $gallery);
            }
        }

        /**
         * Filter gallery value on product export
         *
         * @since 1.8.15
         * @author Francesco Licandro
         * @param mixed $value
         * @param string $meta
         * @param WC_Product $product
         * @param $row
         * @return mixed
         */
        public function product_export_meta_value( $value, $meta, $product, $row ) {
            if( $meta == '_yith_wccl_gallery' || empty( $value ) ) {
                return $value;
            }

            $gallery = $product->get_meta( '_yith_wccl_gallery', true ); // make sure gallery is correct
            if( $gallery ){
                $value = [];
                foreach( $gallery as $attachment_id ) {
                    $image = wp_get_attachment_url( $attachment_id );
                    $image && $value[] = $image;
                }
                $value = implode(',', $value);
            }

            return $value;
        }

        /**
         *
         */
        public function product_import_gallery( $data ){
            if( isset( $data['meta_data'] ) ) {
                foreach( $data['meta_data'] as $index => $meta ){
                    if( $meta['key'] == '_yith_wccl_gallery' && ! empty( $meta['value'] ) ) {
                        $gallery    = explode( ',', $meta['value'] );
                        $new_value  = [];

                        foreach( $gallery as $image ){
                            $id = $this->get_attachment_id_from_url( $image );
                            $id && $new_value[] = $id;
                        }

                        $data['meta_data'][$index]['value'] = $new_value;
                    }
                }
            }

            return $data;
        }

        public function get_attachment_id_from_url( $url ) {
            if ( empty( $url ) ) {
                return 0;
            }

            $id         = 0;
            $ids        = get_posts( array(
                'post_type'   => 'attachment',
                'post_status' => 'any',
                'fields'      => 'ids',
                'meta_query'  => array( // @codingStandardsIgnoreLine.
                    array(
                        'value' => $url,
                        'key'   => '_wc_attachment_source',
                    ),
                ),
            ) ); // @codingStandardsIgnoreLine.

            if ( $ids ) {
                $id = current( $ids );
            }

            // Upload if attachment does not exists.
            if ( ! $id && stristr( $url, '://' ) ) {
                $upload = wc_rest_upload_image_from_url( $url );

                if ( is_wp_error( $upload ) ) {
                    return 0;
                }

                $id = wc_rest_set_uploaded_image_as_attachment( $upload, 0 );
                if ( ! wp_attachment_is_image( $id ) ) {
                    return 0;
                }
                // Save attachment source for future reference.
                update_post_meta( $id, '_wc_attachment_source', $url );
            }

            return $id;
        }
	}
}

/**
 * Unique access to instance of YITH_WCCL class
 *
 * @return \YITH_WCCL
 * @since 1.0.0
 */
function YITH_WCCL(){
	return YITH_WCCL::get_instance();
}