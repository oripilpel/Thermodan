<p>The plugin allows adding products removed from the cart to a dedicated list. To do this, the plugin stores both the user ID and the product ID, quantity and the date in which the product is added to this list.
</p>
<p>If the site is visited with a guest user account, the plugin uses a cookie to store this information.
</p>