== Changelog ==


= 1.0.2 = Released on May 02, 2019

* New: Spanish language
* New: Shortcodes can now be used inside descriptions
* Update: Plugin Core

= 1.0.1 = Released on Apr 05, 2019

* New: Support to WooCommerce 3.6
* New: Dutch language files
* Update: Plugin Core
* Update: Language files

= 1.0.0 = Released on Mar 25, 2019

* Initial release