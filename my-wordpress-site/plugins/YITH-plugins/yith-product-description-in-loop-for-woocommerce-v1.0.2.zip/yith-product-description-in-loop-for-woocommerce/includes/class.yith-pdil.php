<?php
/**
 * Main class
 *
 * @author YITH
 * @package YITH WooCommerce Added to Cart Popup
 * @version 1.0.0
 */


if ( ! defined( 'YITH_PDIL' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_PDIL' ) ) {

	class YITH_PDIL {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_PDIL
		 * @since 1.0.0
		 */
		protected static $instance;

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_PDIL
		 * @since 1.0.0
		 */
		public static function get_instance() {
			return ! is_null( self::$instance ) ? self::$instance : self::$instance = new self();
		}

		/**
		 * Constructor
		 *
		 * @since   1.0.0
		 * @return  void
		 * @author  Francesco Grasso - francgrasso@yithemes.com
		 */
		public function __construct() {

			//Load plugin framework
			add_action( 'plugins_loaded', array( $this, 'plugin_fw_loader' ), 12 );

			$this->includes();
		}

		/**
		 * Files inclusion
		 *
		 * @since   1.0.0
		 * @return  void
		 */
		private function includes() {
			// both
			include_once( YITH_PDIL_DIR . 'includes/class.yith-pdil-settings.php' );
			// only in admin area
			if ( is_admin() ) {
				include_once( YITH_PDIL_DIR . 'includes/class.yith-pdil-admin.php' );
				YITH_PDIL_Admin();
			} // only in frontend area
			else {
				include_once( YITH_PDIL_DIR . 'includes/class.yith-pdil-frontend.php' );
				YITH_PDIL_Frontend();
			}

		}



		/**
		 * YITH FRAMEWORK
		 */

		/**
		 * Load plugin framework
		 *
		 * @since   1.0.0
		 * @return  void
		 */
		public function plugin_fw_loader() {

			if ( ! defined( 'YIT_CORE_PLUGIN' ) ) {

				global $plugin_fw_data;

				if ( ! empty( $plugin_fw_data ) ) {

					$plugin_fw_file = array_shift( $plugin_fw_data );
					require_once( $plugin_fw_file );

				}

			}

		}

	}

}

/**
 * Unique access to instance of YITH_PDIL class
 *
 * @return \YITH_PDIL
 * @since 1.0.0
 */
function YITH_PDIL() {
	return YITH_PDIL::get_instance();
}