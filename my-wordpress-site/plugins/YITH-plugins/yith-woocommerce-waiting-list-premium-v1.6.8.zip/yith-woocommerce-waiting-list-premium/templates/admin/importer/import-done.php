<?php
/**
 * YITH WCWTL Importer Step: Import Done columns
 *
 * @package YITH WooCommerce Waiting List
 * @since 1.6.0
 */

defined( 'ABSPATH' ) || exit;
?>
<div>
    <h2><?php _e( 'Import completed!', 'yith-woocommerce-waiting-list' ); ?></h2>
    <p><?php echo sprintf( __( 'You have successfully imported users to the waiting list of product %s', 'yith-woocommerce-waiting-list' ), $product->get_title() ); ?></p>
</div>
