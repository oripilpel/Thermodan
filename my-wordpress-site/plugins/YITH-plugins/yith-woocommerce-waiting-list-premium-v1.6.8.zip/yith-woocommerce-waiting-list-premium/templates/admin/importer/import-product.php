<?php
/**
 * YITH WCWTL Importer Step: Choose a Product
 *
 * @package YITH WooCommerce Waiting List
 * @since 1.6.0
 */

defined( 'ABSPATH' ) || exit;

?>
<form id="yith-wcwtl-choose-product" enctype="multipart/form-data" method="POST">
    <header>
        <h2><?php _e( 'Waiting List Import Tool', 'yith-woocommerce-waiting-list' ); ?></h2>
        <p><?php _e( 'This tool allows you to import (or merge) customer emails from a CSV file into an existing waiting list.', 'yith-woocommerce-waiting-list' ); ?></p>
    </header>
    <section>
        <label for="product_id" class="label_select"><?php _e( 'Choose a product', 'yith-woocommerce-waiting-list' ); ?></label><br>
        <?php yit_add_select2_fields( array(
            'class' 		    => 'wc-product-search',
            'data-placeholder'  => __( 'Select a product', 'yith-woocommerce-waiting-list' ),
            'data-multiple'     => false,
            'id'			    => 'product_id',
            'name'			    => 'product_id'
        ) ); ?>
    </section>
    <footer>
        <?php wp_nonce_field( 'yith-wcwtl-importer-action', '__wpnonce' ); ?>
        <input type="submit" value="<?php _e( 'Continue', 'yith-woocommerce-waiting-list' ); ?>" id="next_step" class="button button-primary button-hero" name="next_step">
    </footer>
</form>
