<?php
/**
 * Uninstall plugin
 *
 * @author YITHEMES
 * @package YITH WordPress Test Environment 
 * @version 1.0.0
 */

// If uninstall not called from WordPress exit
if( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}


// prevedere cancellazione sandbox create ?