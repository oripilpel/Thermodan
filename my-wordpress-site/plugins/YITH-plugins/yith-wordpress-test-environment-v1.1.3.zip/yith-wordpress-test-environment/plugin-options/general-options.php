<?php
/**
 * GENERAL ARRAY OPTIONS
 */
if ( ! defined( 'YWTENV' ) ) {
	exit;
} // Exit if accessed directly

global $wp_roles;
if ( ! isset( $wp_roles ) ) {
	$wp_roles = new WP_Roles();
}

$general = array(

	'general' => array(

		'header'    => array(

			array(
				'name' => __( 'General Settings', 'yith-wordpress-test-environment' ),
				'type' => 'title'
			),

			array( 'type' => 'close' )
		),


		'settings' => array(

			array( 'type' => 'open' ),

			array(
				'name' => __( 'Enable Plugin', 'yith-wordpress-test-environment' ),
				'type' => 'on-off',
				'desc' => __( 'By disabling this option, the plugin will be deactivated on this site.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-enable-plugin-site',
				'std'   => 'no'
			),
			
			array(
				'name' => __( 'Allow New Sandboxes', 'yith-wordpress-test-environment' ),
				'type' => 'on-off',
				'desc' => __( 'By disabling this option, new sandboxes cannot be created for this site.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-allow-sandboxes',
				'std'   => 'yes'
			),

			array(
				'name' => __( 'Demo User Role', 'yith-wordpress-test-environment' ),
				'type' => 'select',
				'options' => $wp_roles->get_names(),
				'desc' => __( 'This is the role new demo users will have.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-user-role',
				'std' => 'administrator',
				'deps'  => array(
					'ids'   => 'ywtenv-allow-sandboxes',
					'values' => 'yes'
				)
			),

			array(
				'name' => __( 'Clone Uploads Directory', 'yith-wordpress-test-environment' ),
				'type' => 'on-off',
				'desc' => __( 'Choose whether to clone the uploads folder too or not.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-clone-wpuploads',
				'std'   => 'no',
				'deps'  => array(
					'ids'   => 'ywtenv-allow-sandboxes',
					'values' => 'yes'
				)
			),

			array(
				'name' => __( 'Demo Button Label', 'yith-wordpress-test-environment' ),
				'type' => 'text',
				'desc' => __( 'This is the demo button label that you find in the preview bar.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-demo-button-label',
				'std'   => __( 'Launch Admin Demo', 'yith-wordpress-test-environment' ),
				'deps'  => array(
					'ids'   => 'ywtenv-allow-sandboxes',
					'values' => 'yes'
				)
			),

			array(
				'name' => __( 'Demo Popup Text', 'yith-wordpress-test-environment' ),
				'type' => 'text',
				'desc' => __( 'This is the popup content shown while creating the sandbox.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-demo-popup-content',
				'std'   => __( 'Waiting for the sandbox creation', 'yith-wordpress-test-environment' ),
				'deps'  => array(
					'ids'   => 'ywtenv-allow-sandboxes',
					'values' => 'yes'
				)
			),

			array(
				'name' => __( 'Number of Sandboxes', 'yith-wordpress-test-environment' ),
				'type' => 'number',
				'desc' => __( 'Choose how many sandboxes can be active on this site at the same time. ( 0 for unlimited )', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-sandbox-same-time',
				'std'   => '0',
				'custom_attributes' => array(
					'min' => '0',
					'step'  => '1'
				),
				'deps'  => array(
					'ids'   => 'ywtenv-allow-sandboxes',
					'values' => 'yes'
				)
			),

			array(
				'name' => __( 'Sandboxes Duration', 'yith-wordpress-test-environment' ),
				'type' => 'number',
				'desc' => __( 'Sandboxes time duration for this site. ( in minutes )', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-sandbox-expiration-time',
				'std'   => '30',
				'custom_attributes' => array(
					'min' => '10',
					'step'  => '5'
				),
				'deps'  => array(
					'ids'   => 'ywtenv-allow-sandboxes',
					'values' => 'yes'
				)
			),
		
			array(
				'name' => __( 'Purchase Button Label', 'yith-wordpress-test-environment' ),
				'type' => 'text',
				'desc' => __( 'This is the purchase button label that you find in the preview bar.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-purchase-button-label',
				'std'   => __( 'Purchase', 'yith-wordpress-test-environment' )
			),

			array(
				'name' => __( 'Purchase URL', 'yith-wordpress-test-environment' ),
				'type' => 'text',
				'desc' => __( 'This can be used to show a purchase button on the preview bar. This needs to be a valid URL. If not set, the purchase buttons will not be shown.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-purchase-button-url',
				'std'   => ''
			),

			array(
				'name' => '',
				'type' => 'ywtenv_delete_button',
				'desc' => __( 'Delete all sandboxes on current site.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-delete-sandbox-button',
				'std'   => ''
			),

			array( 'type' => 'close' ),
		)
	)
);

return apply_filters( 'ywtenv_general_array_options', $general );