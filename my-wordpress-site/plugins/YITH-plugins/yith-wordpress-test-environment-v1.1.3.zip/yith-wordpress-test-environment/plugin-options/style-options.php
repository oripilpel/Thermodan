<?php
/**
 * GENERAL ARRAY OPTIONS
 */
if ( ! defined( 'YWTENV' ) ) {
	exit;
} // Exit if accessed directly

$style = array(

	'style' => array(

		'header'    => array(

			array(
				'name' => __( 'Style Settings', 'yith-wordpress-test-environment' ),
				'type' => 'title'
			),

			array( 'type' => 'close' )
		),


		'settings' => array(

			array( 'type' => 'open' ),

			array(
				'name' => __( 'Preview Bar Logo', 'yith-wordpress-test-environment' ),
				'type' => 'upload',
				'desc' => __( 'Upload an image logo for the preview bar. ( Maximum recommended height is 60px )', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-bar-logo',
				'std' => ''
			),

			array(
				'name' => __( 'Preview Bar Logo Link', 'yith-wordpress-test-environment' ),
				'type' => 'text',
				'desc' => __( 'A link for the bar logo.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-bar-logo-link',
				'std' => ''
			),

			array(
				'name' => __( 'Preview Bar Background Color', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'Choose the background color for the preview bar.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-bar-bakcground-color',
				'std' => '#2e2e2e'
			),

			array(
				'name' => __( 'Purchase button background color', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The background color of purchase button', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-purchase-btn-background-color',
				'std' => '#a94442'
			),

			array(
				'name' => __( 'Purchase button background color on hover', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The background color of purchase button on hover', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-purchase-btn-background-color-hover',
				'std' => '#ff5f5d'
			),

			array(
				'name' => __( 'Purchase button text color', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The text color of purchase button', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-purchase-btn-text-color',
				'std' => '#ffffff'
			),

			array(
				'name' => __( 'Purchase button text color on hover', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The text color of purchase button on hover', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-purchase-btn-text-color-hover',
				'std' => '#ffffff'
			),

			array(
				'name' => __( 'Launch demo button background color', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The background color of launch demo button', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-launch-btn-background-color',
				'std' => '#a0cc00'
			),

			array(
				'name' => __( 'Launch demo button background color on hover', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The background color of launch demo button on hover', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-launch-btn-background-color-hover',
				'std' => '#b8e21d'
			),

			array(
				'name' => __( 'Launch demo button text color', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The text color of launch demo button', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-launch-btn-text-color',
				'std' => '#ffffff'
			),

			array(
				'name' => __( 'Launch demo button text color on hover', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The text color of launch demo button on hover', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-launch-btn-text-color-hover',
				'std' => '#ffffff'
			),

			array(
				'name' => __( 'Close button text color', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The text color of close button', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-close-btn-text-color',
				'std' => '#5f6060'
			),

			array(
				'name' => __( 'Close button text color on hover', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The text color of close button on hover', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-close-btn-text-color-hover',
				'std' => '#ffffff'
			),

			array(
				'name' => __( 'Countdown color', 'yith-wordpress-test-environment' ),
				'type' => 'colorpicker',
				'desc' => __( 'The text color of the sandbox countdown.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-countdown-text-color',
				'std' => '#ffffff'
			),

			array(
				'name' => __( 'Custom CSS', 'yith-wordpress-test-environment' ),
				'type' => 'textarea',
				'desc' => '',
				'id' => 'ywtenv-custom-css-rules',
				'std' => ''
			),

			array( 'type' => 'close' ),
		)
	)
);

return apply_filters( 'ywtenv_style_array_options', $style );