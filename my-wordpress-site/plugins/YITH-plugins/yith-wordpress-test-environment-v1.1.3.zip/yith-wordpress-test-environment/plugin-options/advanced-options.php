<?php
/**
 * ADVANCED ARRAY OPTIONS
 */
if ( ! defined( 'YWTENV' ) ) {
	exit;
} // Exit if accessed directly


$advanced = array(

	'advanced' => array(

		'header'    => array(

			array(
				'name' => __( 'Advanced Settings', 'yith-wordpress-test-environment' ),
				'type' => 'title'
			),

			array( 'type' => 'close' )
		),


		'settings' => array(

			array( 'type' => 'open' ),

			array(
				'name' => __( 'Enable Order', 'yith-wordpress-test-environment' ),
				'type' => 'on-off',
				'desc' => __( 'By disabling this option users cannot place shop orders.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-enable-shop-order',
				'std'   => 'no'
			),

			array(
				'name' => __( 'Enable Post Comments', 'yith-wordpress-test-environment' ),
				'type' => 'on-off',
				'desc' => __( 'By disabling this option users cannot leave post comments.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-enable-post-comments',
				'std'   => 'no'
			),

			array(
				'name' => __( 'Enable Product Review', 'yith-wordpress-test-environment' ),
				'type' => 'on-off',
				'desc' => __( 'By disabling this option users cannot leave product reviews.', 'yith-wordpress-test-environment' ),
				'id' => 'ywtenv-enable-product-reviews',
				'std'   => 'no'
			),

			array( 'type' => 'close' ),
		)
	)
);

return apply_filters( 'ywtenv_advanced_array_options', $advanced );