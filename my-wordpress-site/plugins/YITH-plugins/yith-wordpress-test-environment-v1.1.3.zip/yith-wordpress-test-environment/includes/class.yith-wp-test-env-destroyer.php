<?php
/**
 * Destroyer sandbox sites class
 *
 * @author YITHEMES
 * @package YITH WordPress Test Environment
 * @version 1.0.0
 */

if ( ! defined( 'YWTENV' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WP_Test_Env_Destroyer' ) ) {
	/**
	 * Destroyer sandbox sites class.
	 * The class manage all the frontend behaviors.
	 *
	 * @since 1.0.0
	 */
	class YITH_WP_Test_Env_Destroyer {

		/**
		 * YITH_Live_Demo_Destroyer constructor.
		 */
		public function __construct() {}

		/**
		 * Destroy sandbox site
		 *
		 * @since 1.0.0
		 * @param int $sandbox_id The sandbox ID
		 * @param boolean $delete_users If delete users or not
		 * @param boolean $delete_attachments If delete attachments or not
		 * @return boolean
		 * @author Francesco Licandro
		 */
		public function sandbox_destroy( $sandbox_id, $delete_users, $delete_attachments ) {
			
			if( ! $sandbox_id ) {
				return false;
			}
			
			// first delete attachments
			if( $delete_attachments ) {
				// make sure you are in sandbox
                class_exists( 'WooCommerce' ) && remove_action( 'switch_blog', array( WooCommerce::instance(), 'wpdb_table_fix' ), 0 );
				switch_to_blog( $sandbox_id );
				// get sandbox attachment
				$attachments = get_option( 'ywtenv_attachment_ids', false );

				if( $attachments ) {
					foreach( (array) $attachments as $attachment ) {
						wp_delete_attachment( $attachment, true );
					}
				}

                // make sure there is no filter for upload path
                remove_filter( 'upload_dir', array( YITH_WP_Test_Env(), 'filter_sandbox_upload_dir' ), 10 );

				// then remove directory if any
                $src_upload_dir = wp_get_upload_dir();
                ! empty( $src_upload_dir['basedir'] ) && ywtenv_delete_directory_recursive( $src_upload_dir['basedir'] );

				// restore current blog
				restore_current_blog();
			}

            // make sure there is no filter for upload path. Double check.
            remove_filter( 'upload_dir', array( YITH_WP_Test_Env(), 'filter_sandbox_upload_dir' ), 10 );

			// first get users
			$users = get_users( array( 'blog_id' => $sandbox_id ) );

			// delete the blog
			if( ! function_exists( 'wpmu_delete_blog' ) ) {
				require_once( ABSPATH . 'wp-admin/includes/ms.php' );
			}

			wpmu_delete_blog( $sandbox_id, true );

			// and delete also the user
			if( $delete_users ) {
				self::delete_users( $users );
			}
			
			// check and return true if site is really deleted
			return ywtenv_sandbox_deleted( $sandbox_id );
		}

		/**
		 * Delete all users of the blog only if they haven't other sites
		 *
		 * @since 1.0.0
		 * @param array $users An array of blog users
		 * @author Francesco Licandro
		 */
		protected function delete_users( $users ) {

			// check for wpmu_delete_user function
			if( ! function_exists( 'wpmu_delete_user' ) ) {
				require_once( ABSPATH . 'wp-admin/includes/ms.php' );
			}

			// hook before users delete
			do_action( 'yvtenv_before_delete_user_action', $users );

			// prevent WP DB error
			remove_action( 'deleted_user', 'wc_reset_order_customer_id_on_deleted_user', 10 );

			foreach ( $users as $user ) {

				if( is_super_admin( $user->ID ) ) {
					continue;
				}

				// let's third part prevent or modify delete process for user
				if( apply_filters( 'ywtenv_delete_user_process', false, $user ) ) {
					continue;
				}

				$sites = get_blogs_of_user( $user->ID );
				// if haven't associated sites delete it!
				if ( count( $sites ) == 0 ) {
					wpmu_delete_user( $user->ID );
				}
			}
		}
	}
}