<?php

if( ! function_exists( 'ywtenv_get_option' ) ) {
	/**
	 * Get single option from main options array
	 *
	 * @since 1.0.0
	 * @param string $option The option to retrieve
	 * @param int $blogID Optionally the site id for main array options
	 * @return mixed|boolean The value or false if not exists
	 * @author Francesco Licandro
	 */
	function ywtenv_get_option( $option, $blogID = 0 ) {

		if( ! $option ) {
			return false;
		}

		// check if passed blog is a sandbox else get itself
		$blogID = ywtenv_is_sandbox( $blogID, true );

		// get main options array
		$options = get_blog_option( $blogID, 'yit_ywtenv_options', array() );

		if( ! isset( $options[$option] ) ) {
			// return default
			return ywtenv_get_option_default( $option );
		}

		return $options[$option];
	}
}

if( ! function_exists( 'ywtenv_get_option_default' ) ) {
	/**
	 * Get default value of an option
	 *
	 * @since 1.0.0
	 * @param string $option The option to retrieve
	 * @return mixed
	 * @author Francesco Licandro
	 */
	function ywtenv_get_option_default( $option ) {

		$options = array();

		// check for main array options
		$file = YWTENV_DIR . 'plugin-options/general-options.php';
		if( file_exists( $file ) ){
			$options = include( $file );
		}

		// check for advanced array options
		$file = YWTENV_DIR . 'plugin-options/advanced-options.php';
		if( file_exists( $file ) ){
			$options_advanced = include( $file );
			$options = array_merge( $options, $options_advanced );
		}

		// check for style options
		$file = YWTENV_DIR . 'plugin-options/style-options.php';
		if( file_exists( $file ) ){
			$options_style = include( $file );
			$options = array_merge( $options, $options_style );
		}

		$return = false;

		foreach( $options as $sections ) {
			foreach( $sections as $section ) {
				foreach( $section as $single_options ) {
					if( isset( $single_options['id'] ) && $single_options['id'] == $option ) {
						$return = isset( $single_options['std'] ) ? $single_options['std'] : false;
						break;
					}
				}
			}
		}
		
		return $return;
	}
}

if( ! function_exists( 'ywtenv_get_current_user_ip' ) ) {
	/**
	 * Get the IP of current user
	 *
	 * @since 1.0.0
	 * @return string
	 * @author Francesco Licandro
	 */
	function ywtenv_get_current_user_ip(){

		if( ! empty( $_SERVER['HTTP_CLIENT_IP'] ) ) {
			$ip = $_SERVER['HTTP_CLIENT_IP'];
		}
		elseif( ! empty( $_SERVER['HTTP_X_FORWARDED_FOR'] ) ) {
			$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		}
		else {
			$ip = $_SERVER['REMOTE_ADDR'];
		}

		return apply_filters( 'ywtenv_current_user_ip', $ip );
	}
}

if( ! function_exists( 'ywtenv_generate_sandbox_hash' ) ) {
	/**
	 * Creates a randomized hash string
	 *
	 * @param int|string $blogID the original blogID
	 * @return string Hash
	 */
	function ywtenv_generate_sandbox_hash( $blogID ) {
		// get ip
		$ip = ywtenv_get_current_user_ip();

		// return a md5 with IP and blog ID
		return md5( $ip . $blogID );
	}
}

if( ! function_exists( 'ywtenv_create_sandbox') ) {
	/**
	 * This function create new sandbox
	 * 
	 * @since 1.0.0
	 * @param int|string $blogID The original blog ID
	 * @return array
	 * @author Francesco Licandro
	 */
	function ywtenv_create_sandbox( $blogID = 0 ){

		global $host, $db, $usr, $pwd;
		
		if( ! $blogID ) {
			$blogID = get_current_blog_id();
		}
		
		$sandboxName                = ywtenv_generate_sandbox_hash( $blogID );
		$blogDetails                = get_blog_details( $blogID );
		// Set YITH Cloner variables
		$host                       = DB_HOST;
		$db                         = DB_NAME;
		$usr                        = DB_USER;
		$pwd                        = DB_PASSWORD;
		$options['source_id']       = $blogID;
		$options['new_site_title']  = sprintf( __( 'Sandbox for %s', 'yith-wordpress-test-environment' ), $blogDetails->blogname );
		$options['new_site_name']   = $sandboxName;
		$response                   = false;

		/*
		 * Make sure that site doesn't exists
		 */
		$site_id = get_id_from_blogname( $sandboxName );
		// return if exists
		if( ! is_null( $site_id ) ) {
			$response['newBlogID'] = $site_id;
			// get user from this blog
			$users = get_users( array( 'blog_id' => $site_id ) );
			foreach( $users as $user ) {
				$response['userID'] = $user->ID;
				break;
			}			
		}
		// create new
		else {

			if( ! ywtenv_can_site_have_sandbox( $blogID ) ) {
				// if max number of sandbox are active exit
				return false;
			}

			if( ! class_exists( 'YITH_WP_Test_Env_Cloner' ) ) {
				require_once( 'class.yith-wp-test-env-cloner.php' );
			}
			$clone = new YITH_WP_Test_Env_Cloner();
			// create sandbox
			$response = $clone->sandbox_create($options);

			// if response is positive save sandbox ID
			$sandboxes_active[$response['newBlogID']] = true;
			update_blog_option( $blogID, 'ywtenv-sandboxes-active', $sandboxes_active );
		}
		
		return $response;
	}
}

if( ! function_exists( 'ywtenv_is_sandbox' ) ) {
	/**
	 * Check if current blog or passed blog id is a sandbox and return parent id or itself if false
	 *
	 * @since 1.0.0
	 * @param int|string $blog_id
	 * @param boolean $return_itself
	 * @return int
	 * @author Francesco Licandro
	 */
	function ywtenv_is_sandbox( $blog_id = 0, $return_itself = false ) {

		if( ! $blog_id ) {
			$blog_id = get_current_blog_id();
		}

		$sandboxes = ywtenv_get_sanboxes_global_list();

		$parent_id = isset( $sandboxes[ $blog_id ] ) ? $sandboxes[ $blog_id ]['parent'] : 0;
		// if need an id to be returned and sandbox is false, get current
		( $return_itself && ! $parent_id ) && $parent_id = $blog_id;

		return $parent_id;
	}
}

if( ! function_exists( 'ywtenv_get_sanboxes_global_list') ) {
	/**
	 * The the global list of active sandboxes
	 * 
	 * @since 1.0.0
	 * @author Francesco Licandro
	 * @return array
	 */
	function ywtenv_get_sanboxes_global_list(){
		return get_site_option( 'ywtenv_sandboxes_list', array() );
	}
}

if( ! function_exists( 'ywtenv_add_sandbox_to_global_list' ) ) {
	/**
	 * Add a new sandbox to the global sandboxes list
	 *
	 * @since 1.0.0
	 * @param int $sandbox_id The sandbox id
	 * @param int $parent_id The parent id of sandbox
	 * @author Francesco Licandro
	 */
	function ywtenv_add_sandbox_to_global_list( $sandbox_id, $parent_id ) {

		if( ! $sandbox_id ) {
			return;
		}

		$duration = ywtenv_get_option('ywtenv-sandbox-expiration-time');
		if( intval( $duration ) < 10 ) {
			$duration = 10;
		} 

		$list = ywtenv_get_sanboxes_global_list();
		$list[ $sandbox_id ] = array(
			'parent'  => $parent_id,
			'expired' => time() + ($duration * MINUTE_IN_SECONDS)
		);

		update_site_option( 'ywtenv_sandboxes_list', $list );

	}
}

if( ! function_exists( 'ywtenv_remove_sandboxes_from_global_list' ) ) {
	/**
	 * Remove a sandbox or multiple sandboxes from global option
	 *
	 * @since 1.0.0
	 * @author Francesco Licandro
	 * @param string|array $to_remove
	 */
	function ywtenv_remove_sandboxes_from_global_list( $to_remove ) {
		// remove from global sandboxes list
		$active_sandboxes = ywtenv_get_sanboxes_global_list();

		if( ! is_array( $to_remove ) ) {
			unset( $active_sandboxes[$to_remove] );
		}
		else {
			$active_sandboxes = array_diff_key( $active_sandboxes, $to_remove );
		}

		// then update
		update_site_option( 'ywtenv_sandboxes_list', $active_sandboxes );
	}
}

if( ! function_exists( 'ywtenv_destroy_sandbox') ) {
	/**
	 * This function destroy a sandbox
	 *
	 * @since 1.0.0
	 * @param int|string $sandboxID The sandbox ID
	 * @param boolean $delete_users If delete users of sandbox or not
	 * @param boolean $delete_attachments If delete attachments of sandbox or not
	 * @return boolean true on success, false otherwise
	 * @author Francesco Licandro
	 */
	function ywtenv_destroy_sandbox( $sandboxID, $delete_users = true, $delete_attachments = true ){

		/*
		 * Make sure that site is a sandbox and get parent id
		 */
		if( ! $parentID = ywtenv_is_sandbox( $sandboxID ) ) {
			return false;
		}

		do_action( 'ywtenv_before_destroy_sandbox', $sandboxID );

		if( ! class_exists( 'YITH_WP_Test_Env_Destroyer' ) ) {
			require_once( 'class.yith-wp-test-env-destroyer.php' );
		}

		// check first if sandbox currently exists and was not deleted manually
		if( ! ( $response = ywtenv_sandbox_deleted( $sandboxID ) ) ) {
			// if exists delete it!
			$destroyer = new YITH_WP_Test_Env_Destroyer();
			$response = $destroyer->sandbox_destroy( $sandboxID, $delete_users, $delete_attachments );
		}

		// if response is positive
		if( $response ) {
			
			// remove from global
			ywtenv_remove_sandboxes_from_global_list( $sandboxID );
			
			// remove sandbox ID from sandboxes list for parent blog
			$sandboxes_active_for_site = get_blog_option( $parentID, 'ywtenv-sandboxes-active', array() );
			unset( $sandboxes_active_for_site[ $sandboxID ] );
			update_blog_option( $parentID, 'ywtenv-sandboxes-active', $sandboxes_active_for_site );
		}

		return $response;
	}
}

if( ! function_exists( 'ywtenv_can_site_have_sandbox' ) ) {
	/**
	 * Check if a site can have a sandbox active
	 * 
	 * @since 1.0.0
	 * @param string|int $siteID
	 * @author Francesco Licandro
	 * @return boolean
	 */
	function ywtenv_can_site_have_sandbox( $siteID = 0 ){
		if( ! $siteID ){
			$siteID = get_current_blog_id();
		}

		// first check if there is a limit for sandbox active at the same time
		$sandbox_same_time = ywtenv_get_option( 'ywtenv-sandbox-same-time', $siteID );
		$sandboxes_active = get_blog_option( $siteID, 'ywtenv-sandboxes-active', array() );

		if( $sandbox_same_time && count( $sandboxes_active ) >= ( $sandbox_same_time - 1 ) ) {
			// if max number of sandbox are active return false
			return false;
		}
		
		return true;
	}
}

if( ! function_exists( 'ywtenv_get_all_custom_style' ) ) {
	/**
	 * Get all custom style for frontend
	 * 
	 * @since 1.0.0
	 * @author Francesco Licandro
	 * @return string
	 */
	function ywtenv_get_all_custom_style(){
		
		// get all options
		$bkg_bar            = ywtenv_get_option( 'ywtenv-bar-bakcground-color' );
		$bkg_purchase       = ywtenv_get_option( 'ywtenv-purchase-btn-background-color' );
		$bkg_purchase_h     = ywtenv_get_option( 'ywtenv-purchase-btn-background-color-hover' );
		$clr_purchase       = ywtenv_get_option( 'ywtenv-purchase-btn-text-color' );
		$clr_purchase_h     = ywtenv_get_option( 'ywtenv-purchase-btn-text-color-hover' );
		$bkg_launch         = ywtenv_get_option( 'ywtenv-launch-btn-background-color' );
		$bkg_launch_h       = ywtenv_get_option( 'ywtenv-launch-btn-background-color-hover' );
		$clr_launch         = ywtenv_get_option( 'ywtenv-launch-btn-text-color' );
		$clr_launch_h       = ywtenv_get_option( 'ywtenv-launch-btn-text-color-hover' );
		$close_color        = ywtenv_get_option( 'ywtenv-close-btn-text-color' );
		$close_color_h      = ywtenv_get_option( 'ywtenv-close-btn-text-color-hover' );
		$countdown_clr      = ywtenv_get_option( 'ywtenv-countdown-text-color' );

		// get custom css
		$custom_css = ywtenv_get_option( 'ywtenv-custom-css-rules' );

		$return = "#ywtenv-banner{background-color:{$bkg_bar}}#purchase-box a{background-color:{$bkg_purchase};color:{$clr_purchase}}
				#purchase-box a:hover{background-color:{$bkg_purchase_h};color:{$clr_purchase_h}}#login-sandbox a,#new-sandbox a{background-color:{$bkg_launch};color:{$clr_launch}}
				#login-sandbox a:hover,#new-sandbox a:hover{background-color:{$bkg_launch_h};color:{$clr_launch_h}}a.close-link{color:{$close_color}}a.close-link:hover{color:{$close_color_h}}
				#sandbox-countdown{color:{$countdown_clr}}";

		return $return . $custom_css;
		
	}
}

if( ! function_exists( 'ywtenv_get_sandbox_expiration_time' ) ) {
	/**
	 * Get the expiration time for a sandbox
	 * 
	 * @since 1.0.0
	 * @param int|string $blogID The blog id to retrieve the expiration
	 * @return int
	 * @author Francesco Licandro
	 */
	function ywtenv_get_sandbox_expiration_time( $blogID = 0 ) {

		$sandboxes  = ywtenv_get_sanboxes_global_list();
		! $blogID && $blogID = get_current_blog_id();
		
		if( ! isset( $sandboxes[$blogID] ) ) {
			return 0; 
		}
		
		return intval( $sandboxes[$blogID]['expired'] );
	}
}

if( ! function_exists( 'ywtenv_is_sandbox_expired' ) ) {
    /**
     * Check if given sandbox is expired
     *
     * @since 1.2.0
     * @author Francesco Licandro
     * @param integer $blogID
     * @return boolean
     */
    function ywtenv_is_sandbox_expired( $blogID ) {
        $expiration_time = ywtenv_get_sandbox_expiration_time( $blogID );
        return $expiration_time && $expiration_time < time();
    }
}

if( ! function_exists( 'ywtenv_return_false' ) ) {
	/**
	 * Return false function
	 *
	 * @since 1.0.0
	 * @author Francesco Licandro
	 */
	function ywtenv_return_false(){
		return false;
	}
}

if( ! function_exists( 'ywtenv_is_a_sandbox_user' ) ) {
	/**
	 * Check if logged in user is a sandbox user
	 * 
	 * @since 1.0.0
	 * @author Francesco Licandro
	 * @param string $user_id The user id to check
	 * @return bool
	 */
	function ywtenv_is_a_sandbox_user( $user_id = '' ){
		// get global if not passed 
		! $user_id && $user_id = get_current_user_id();
		
		return get_user_meta( $user_id, '_ywtenv_is_sandbox_user', true );
	}
}

if( ! function_exists( 'ywtenv_sandbox_deleted' ) ) {
	/**
	 * Check if a sandbox currently exists or was deleted manually
	 *
	 * @author Francesco Licandro
	 * @param int $sandboxID
	 * @return boolean
	 * @since 1.0.0
	 */
	function ywtenv_sandbox_deleted( $sandboxID ){
		$resp = get_site( $sandboxID );
		
		return is_null( $resp );
	}
}

if( ! function_exists( 'ywtenv_get_login_sandbox_url' ) ) {
	/**
	 * Get login sandbox url with correct query string for frontend
	 * 
	 * @since 1.0.0
	 * @author Francesco Licandro
	 * @return string
	 */
	function ywtenv_get_login_sandbox_url(){
		return add_query_arg( 'ywtenv', 'login_sandbox', home_url() );
	}
}

if( ! function_exists( 'ywtenv_delete_directory_recursive' ) ){
    /**
     * Delete a directory recursive
     *
     * @since 1.1.0
     * @author Francesco Licandro
     * @param string $dir
     * @return boolean
     */
    function ywtenv_delete_directory_recursive( $dir ) {
        if( ! file_exists( $dir ) ) {
            return true;
        }

        if( ! is_dir( $dir ) ) {
            return unlink( $dir );
        }

        foreach( scandir( $dir ) as $item ) {
            if( $item == '.' || $item == '..' ) {
                continue;
            }

            if( ! ywtenv_delete_directory_recursive( $dir . DIRECTORY_SEPARATOR . $item ) ) {
                return false;
            }
        }

        return rmdir( $dir );
    }
}

if( ! function_exists( 'ywtenv_include_template' ) ) {
    /**
     * Include a plugin template
     *
     * @since 1.2.0
     * @author Francesco Licandro
     * @param string $template
     * @param array $arguments
     * @return void
     */
    function ywtenv_include_template( $template, $arguments = array() ){
        // define pats
        $plugin_path   = YWTENV_TEMPLATE_PATH . '/' . $template;
        $template_path = get_template_directory() . '/' . $template;
        $child_path    = get_stylesheet_directory() . '/' . $template;

        // then include template!
        foreach ( array( 'child_path', 'template_path', 'plugin_path' ) as $var ) {
            if ( file_exists( ${$var} ) ) {
                // extract arguments
                extract( $arguments );
                include( ${$var} );
                break;
            }
        }
    }
}