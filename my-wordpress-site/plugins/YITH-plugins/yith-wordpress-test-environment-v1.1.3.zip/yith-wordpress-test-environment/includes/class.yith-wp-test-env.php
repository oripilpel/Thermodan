<?php
/**
 * Main class
 *
 * @author YITHEMES
 * @package YITH WordPress Test Environment
 * @version 1.0.0
 */

if ( ! defined( 'YWTENV' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WP_Test_Env' ) ) {
	/**
	 * YITH WordPress Test Environment
	 *
	 * @since 1.0.0
	 */
	class YITH_WP_Test_Env {

		/**
		 * Single instance of the class
		 *
		 * @var \YITH_WP_Test_Env
		 * @since 1.0.0
		 */
		protected static $instance;
		
		/**
		 * Instanced Class
		 * @var object
		 * @since 1.0.0
		 */
		public $obj = null;

		/**
		 * Returns single instance of the class
		 *
		 * @return \YITH_WP_Test_Env
		 * @since 1.0.0
		 */
		public static function get_instance(){
			if( is_null( self::$instance ) ){
				self::$instance = new self();
			}

			return self::$instance;
		}

		/**
		 * Constructor
		 *
		 * @since 1.0.0
		 */
		public function __construct() {

		    global $wp_version;

			// Class admin
			if ( $this->is_admin() ) {
				// require file
				require_once('class.yith-wp-test-env-admin.php');
				// START ADMIN
				$this->obj = new YITH_WP_Test_Env_Admin();
			}
			else {
				// require file
				require_once('class.yith-wp-test-env-front.php');
				// START FRONTEND
				$this->obj = new YITH_WP_Test_Env_Front();
			}

			if( ywtenv_get_option( 'ywtenv-clone-wpuploads' ) !== 'yes' ) {
				// filter upload dir for sandbox
				add_filter( 'upload_dir', array( $this, 'filter_sandbox_upload_dir' ), 10, 1 );
				// save attachment id for sandbox site
				add_action( 'add_attachment', array( $this, 'save_attachment_id_for_sandbox' ), 10, 1 );
				// don't allow to sandbox to delete parent media
				add_action( 'delete_attachment', array( $this, 'delete_attachement_for_sandbox' ), 10, 1 );
			}

			// init advanced options handler
			add_action( 'init', array( $this, 'advanced_options_handler' ), 0 );

			// remove upload dir filter in delete process
			if( version_compare( $wp_version, '5.1.0' ) === -1 ) {
			    add_action( 'delete_blog', array( $this, 'remove_filter_sandbox_upload_dir' ), 10, 2 );
            } else {
                add_action( 'wp_delete_site', array( $this, 'remove_filter_sandbox_upload_dir' ), 10, 1 );
            }

			// display message for expired sandbox
            add_action( 'init', array( $this, 'expired_sandbox_action_handler' ), 1 );
            add_action( 'init', array( $this, 'expired_sandbox_message' ), 1 );
            // delete sandbox if is expired without wait the cron job
			// create sandbox from query string
			add_action( 'init', array( $this, 'create_sandbox' ), 2 );
            // cron for delete expired sandbox
            add_action( 'init', array( $this, 'schedule_cron_destroyer' ), 5 );
			// login sandbox from query string
			add_action( 'init', array( $this, 'login_sandbox' ) );
			// logout sandbox users
			add_action( 'init', array( $this, 'logout_sandbox_user' ) );

			// destroy expired sandbox
            add_action( 'ywtenv_delete_sandbox', array( $this, 'destroy_expired_sandbox' ) );
			// includes custom tables on wpmu_delete_blog function
			add_filter( 'wpmu_drop_tables', array( $this, 'add_tables_to_drop' ), 10, 2 );

		}

		/**
		 * Filter upload directory's path and url for sandbox sites
		 *
		 * @since 1.0.0
		 * @param string $dir
		 * @return string
		 * @author Francesco Licandro
		 */
		public function filter_sandbox_upload_dir( $dir ) {
			
			// first check if current site is a sandbox
			$currentID = get_current_blog_id();
			$mainSiteID = ywtenv_is_sandbox( $currentID );

			if( ! $mainSiteID ) {
				return $dir;
			}

			// get main site upload
			switch_to_blog( $mainSiteID );
			$src_upload_dir =  _wp_upload_dir();
			restore_current_blog();

			return $src_upload_dir;
		}

		/**
		 * Remove filter for upload dir during delete site process to prevent wrong deletion
		 * Also remove from sandboxes list the site ID
		 * 
		 * @since 1.0.0
		 * @param integer|\WP_Site $blog The site ID for WP version older then 5.1. The deleted site object for newest versions.
		 * @param bool $drop True if site's table should be dropped. Default is false.
		 * @author Francesco Licandro
		 */
		public function remove_filter_sandbox_upload_dir( $blog, $drop = false ){
			remove_filter( 'upload_dir', array( $this, 'filter_sandbox_upload_dir' ), 10 );
		}

		/**
		 * Save attachment post id for sandbox site. Is used for deleting attachment files after sandbox was cancelled
		 *
		 * @since 1.0.0
		 * @param int     $post_ID Post ID.
		 * @author Francesco Licandro
		 */
		public function save_attachment_id_for_sandbox( $post_ID ){

			// check if current blog is a sandbox or post is an attachment
			if( ! ywtenv_is_sandbox() ){
				return;
			}

			$ids = get_option( 'ywtenv_attachment_ids', array() );
			$ids[] = $post_ID;

			// save post id
			update_option( 'ywtenv_attachment_ids', $ids );
		}

		/**
		 * Delete only attachment for sandbox
		 * 
		 * @since 1.0.0
		 * @author Francesco Licandro
		 * @param $post_ID
		 */
		function delete_attachement_for_sandbox( $post_ID ){
			// check if current blog is a sandbox or post is an attachment
			if( ! ywtenv_is_sandbox() ){
				return;
			}

			$ids = get_option( 'ywtenv_attachment_ids', array() );
			if( ! in_array( $post_ID, $ids ) ) {
				if( ! has_filter( 'wp_delete_file', 'ywtenv_return_false' ) ) {
					add_filter( 'wp_delete_file', 'ywtenv_return_false', 99 );
				}
			}
			else {
				// ensure the filter is not added
				remove_filter( 'wp_delete_file', 'ywtenv_return_false', 99 );
			}
		}
		

		/**
		 * Destroy overdue sandbox
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function destroy_expired_sandbox(){
			$sandboxes = ywtenv_get_sanboxes_global_list();

			if( empty( $sandboxes ) ) {
				return;
			}

			foreach( (array) $sandboxes as $sandbox => $option ) {
			    // give on more hour for resume sandbox
				if( ( $option['expired'] + HOUR_IN_SECONDS ) < time() ) {
					ywtenv_destroy_sandbox( $sandbox, true, true );
				}
			}
		}
		
		/**
		 * Action for create sandbox from query strings
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function create_sandbox(){

			if( ! isset( $_GET['ywtenv'] ) || $_GET['ywtenv'] != 'create_sandbox' ){
				return;
			}

            do_action( 'ywtenv_before_sandbox_creation' );

			$response = ywtenv_create_sandbox();

			if( ! $response || ! isset( $response['userID'] ) || ! isset( $response['newBlogID'] ) ) {
				return;
			}

			do_action( 'ywtenv_new_sandbox_cretaed', $response );

			// first login user
			wp_set_auth_cookie( $response['userID'], true );

			$redirect = get_site_url( $response['newBlogID'] ) . '/wp-admin';

			wp_redirect( $redirect );
			exit;
		}

		/**
		 * Login sandbox user from query string
		 * 
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function login_sandbox(){
			
			if( ! isset( $_GET['ywtenv'] ) || $_GET['ywtenv'] != 'login_sandbox' || is_user_logged_in() ){
				return;
			}
			
			$currentBlog    = get_current_blog_id();
			$allSandbox     = ywtenv_get_sanboxes_global_list();
			$redirect       = home_url();

			if( array_key_exists( $currentBlog, $allSandbox ) ) {
				// if is sandbox and user is logged out, login!
				$user_id = get_blog_option( $currentBlog, 'ywten_admin_id' );
				$user_id && wp_set_auth_cookie( $user_id, true );

				$redirect = apply_filters( 'ywtenv_login_sandbox_redirect_url', admin_url() );
			}
			// else redirect to home
			
			wp_redirect( $redirect );
			exit;
		}

		/**
		 * Schedule cron for delete overdue sandbox
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 * @return void
		 */
		public function schedule_cron_destroyer(){
			if ( ! wp_next_scheduled( 'ywtenv_delete_sandbox' ) ) {
				wp_schedule_event( time(), 'hourly', 'ywtenv_delete_sandbox' );
			}
		}
		
		/**
		 * Destroy current site if is a sandbox and it is expired
		 * 
		 * @since 1.0.0
		 * @author Francesco Licandro
         * @deprecated
		 */
		public function destroy_current_sandbox(){

			$blog_id    = get_current_blog_id();
			// delete it if expired
			if( ywtenv_is_sandbox_expired( $blog_id ) ) {

                $sandboxes      = ywtenv_get_sanboxes_global_list();
				$redirect_url   = get_site_url( $sandboxes[$blog_id]['parent'] );

				ywtenv_destroy_sandbox( $blog_id, true, true );

				// redirect to parent
				wp_redirect( $redirect_url );
				exit();
			}
		}
		
		/**
		 * Logout sandbox users from other sites
		 * 
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function logout_sandbox_user(){

			$currentBlog    = get_current_blog_id();
			$allSandbox     = ywtenv_get_sanboxes_global_list();
			$redirect       = false;

			if( ! array_key_exists( $currentBlog, $allSandbox ) ) {
				// if blog is not a sandbox and current user is a sandbox user logged out
				$user_id = get_current_user_id();

				if( $user_id && get_user_meta( $user_id, '_ywtenv_is_sandbox_user', true ) ) {
					wp_logout();
					$redirect = true;
				}
			}

			if( $redirect ) {
				wp_safe_redirect( add_query_arg( array() ) );
				exit;
			} 
		}

		/**
		 * Require if necessary the advanced options handler
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function advanced_options_handler(){
			if( apply_filters( 'ywtenv_show_adavanced_options', false ) ) {
				require_once('advanced-handler.yith-wp-test-env.php');
			}
		}

		/**
		 * Add tables to drop
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 * @param $default_tables array
		 * @param $blog_id int
		 * @return array
		 */
		public function add_tables_to_drop( $default_tables, $blog_id ){
			global $wpdb;

			// build query
			$query = "SHOW TABLES LIKE '{$wpdb->prefix}%'";
			$tables_to_merge = $wpdb->get_col( $query );
			// build tables array
			foreach( $tables_to_merge as $table ) {
				if( in_array( $table, $default_tables ) ) {
					continue;
				}
				$default_tables[] = $table;
			}

			return $default_tables;
		}

		/**
		 * Check if context is admin
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 * @return boolean
		 */
		public function is_admin() {
			$is_ajax = defined( 'DOING_AJAX' ) && DOING_AJAX && isset( $_REQUEST['context'] ) && $_REQUEST['context'] == 'frontend';
			return is_admin() && ! $is_ajax;
		}

        /**
         * Expired sandbox action handler
         *
         * @since 1.2.0
         * @author Francesco Licandro
         * @return void
         */
        public function expired_sandbox_action_handler(){
            if( empty( $_POST['_expiredNonce'] ) || ! wp_verify_nonce( $_POST['_expiredNonce'], 'expired-sandbox-action' )
                || empty( $_POST['expired-action'] ) || empty( $_POST['sandboxID'] ) ) {
                return;
            }

            $sandbox_id     = intval( $_POST['sandboxID'] );
            $sandboxes      = ywtenv_get_sanboxes_global_list();
            // double check if sandbox is in list
            if( ! isset( $sandboxes[$sandbox_id] ) ) {
                return;
            }

            $parent_id      = $sandboxes[$sandbox_id]['parent'];

            if( $_POST['expired-action'] == 'continue' ) {
                $redirect_url   = ! empty( $_POST['wp_http_referer'] ) ? $_POST['wp_http_referer'] : get_site_url( $sandbox_id );
                ywtenv_add_sandbox_to_global_list( $sandbox_id, $parent_id );
            }
            else {
                $redirect_url   = get_site_url( $parent_id );
                ywtenv_destroy_sandbox( $sandbox_id, true, true );
            }

            // redirect
            wp_safe_redirect( $redirect_url );
            exit();
        }

        /**
         * Print expired message for a sandbox
         *
         * @since 1.2.0
         * @author Francesco Licandro
         * @return void
         */
        public function expired_sandbox_message(){

            $blog_id    = get_current_blog_id();
            if( ! ywtenv_is_sandbox_expired( $blog_id ) ) {
                return;
            }

            if ( ! headers_sent() ) { // send header
                status_header( 200 );
                nocache_headers();
                header( 'Content-Type: text/html; charset=utf-8' );
            }

            // set bar name
            $expired_modal  = apply_filters( 'ywtenv_expired_modal_template_name', 'expired-page.php' );
            $args           = apply_filters( 'ywtenv_expired_modal_template_args', array(
                'sandboxID'    => $blog_id
            ) );

            ywtenv_include_template( $expired_modal, $args );
            die();
        }
	}
}

/**
 * Unique access to instance of YITH_WP_Test_Env class
 *
 * @return \YITH_WP_Test_Env
 * @since 1.0.0
 */
function YITH_WP_Test_Env(){
	return YITH_WP_Test_Env::get_instance();
}