<?php

// exit directly if the current site is a sandbox
if( ywtenv_is_sandbox() ) {
	return;
}

// disable post comments
if( ywtenv_get_option('ywtenv-enable-post-comments') == 'no' ) {
	add_filter( 'comments_open', 'ywtenv_disable_post_comments', 10, 2 );
	function ywtenv_disable_post_comments( $open, $post_id ){
		$post_type = get_post_type( $post_id );

		if( in_array( $post_type, array( 'product', 'product_variation' ) ) ) {
			return $open;
		}

		return false;
	}
}

// disable product review
if( ywtenv_get_option('ywtenv-enable-product-reviews') == 'no' ) {
	add_filter( 'pre_option_woocommerce_review_rating_verification_required', 'ywtenv_disable_product_reviews', 10, 2 );
	function ywtenv_disable_product_reviews( $pre_value, $option ){
		return 'yes';
	}
}

// disable shop order
if( ywtenv_get_option('ywtenv-enable-shop-order') == 'no' && function_exists( 'WC' ) ) {
	add_action( 'woocommerce_after_checkout_validation', 'ywtenv_disable_shop_orders', 10, 1 );
	function ywtenv_disable_shop_orders( $posted ){
		wc_add_notice( __( ' Sorry but you cannot create order on this demo site. Create a sandbox by clicking on "Launch admin demo" for complete shop orders.', 'yith-wordpress-test-environment' ), 'error' );
	}
}