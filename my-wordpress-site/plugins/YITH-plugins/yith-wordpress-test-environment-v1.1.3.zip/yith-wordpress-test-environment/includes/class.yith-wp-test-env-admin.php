<?php
/**
 * Admin class
 *
 * @author YITHEMES
 * @package YITH WordPress Test Environment
 * @version 1.0.0
 */

if ( ! defined( 'YWTENV' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WP_Test_Env_Admin' ) ) {
	/**
	 * Admin class.
	 * The class manage all the admin behaviors.
	 *
	 * @since 1.0.0
	 */
	class YITH_WP_Test_Env_Admin {

		/**
		 * @var $_panel Panel Object
		 */
		protected $_panel;

		/**
		 * @var string Customize my account panel page
		 */
		protected $_panel_page = 'ywtenv_panel';

		/**
		 * @var string Action for delete all sandboxes
		 */
		public $action_delete = 'ywtenv_delete_button';

		/**
		 * Various links
		 *
		 * @var string
		 * @access public
		 * @since 1.0.0
		 */
		public $doc_url = '#';

		/**
		 * Constructor
		 *
		 * @access public
		 * @since 1.0.0
		 */
		public function __construct() {

			// Load Plugin Framework
			add_action( 'after_setup_theme', array( $this, 'plugin_fw_loader' ), 1 );

			add_action( 'admin_menu', array( $this, 'register_panel' ), 5) ;
			add_action( 'admin_enqueue_scripts', array( $this, 'enqueue_scripts' ) );

			// Add action links
			add_filter( 'plugin_action_links_' . plugin_basename( YWTENV_DIR . '/' . basename( YWTENV_FILE ) ), array( $this, 'action_links' ) );
			add_filter( 'plugin_row_meta', array( $this, 'plugin_row_meta' ), 10, 4 );

			// Register plugin to licence/update system
			add_action( 'wp_loaded', array( $this, 'register_plugin_for_activation' ), 99 );
			add_action( 'admin_init', array( $this, 'register_plugin_for_updates' ) );

			// add banner with time if sandbox
			add_action( 'admin_footer', array( $this, 'countdown_banner' ), 10 );
			
			// add button for delete all sandbox from panel
			add_action( 'yit_panel_ywtenv_delete_button', array( $this, 'render_delete_button' ), 10, 3 );
			
			// ajax action for delete sandbox from admin panel
			add_action( 'wp_ajax_' . $this->action_delete, array( $this, 'delete_sandboxes' ) );
		}

		/**
		 * Enqueue scripts
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function enqueue_scripts() {

			// register style
			wp_register_style( 'ywtenv-admin-style', YWTENV_ASSETS_URL . 'css/admin.css', array(), YWTENV_VERSION, 'all' );
			// register scripts
			wp_register_script( 'jquery-plugin', YWTENV_ASSETS_URL . 'js/jquery.plugin.min.js', array( 'jquery' ), false, true );
			wp_register_script( 'jquery-countdown', YWTENV_ASSETS_URL . 'js/jquery.countdown.min.js', array( 'jquery', 'jquery-plugin' ), false, true );
			wp_register_script( 'ywtenv-admin', YWTENV_ASSETS_URL . 'js/ywtenv-admin.js', array( 'jquery' ), YWTENV_VERSION, true );

			// check if current is a sandbox
			wp_enqueue_style( 'ywtenv-admin-style' );
			wp_enqueue_script( 'jquery-plugin' );
			wp_enqueue_script( 'jquery-countdown' );
			wp_enqueue_script( 'ywtenv-admin' );

			wp_localize_script( 'ywtenv-admin', 'ywtenv', array(
				'ajaxurl'           => admin_url( 'admin-ajax.php' ),
				'actiondel'         => $this->action_delete,
				'nonce_actiondel'   => wp_create_nonce( $this->action_delete ),
				'alert_msg'         => __( 'Do you really want to delete all the sandboxes activated on this site?', 'yith-wordpress-test-environment' )
			));
		}

		/**
		 * Load Plugin Framework
		 *
		 * @since  1.0
		 * @access public
		 * @return void
		 * @author Andrea Grillo <andrea.grillo@yithemes.com>
		 */
		public function plugin_fw_loader() {

			if ( ! defined( 'YIT_CORE_PLUGIN' ) ) {
				global $plugin_fw_data;
				if( ! empty( $plugin_fw_data ) ){
					$plugin_fw_file = array_shift( $plugin_fw_data );
					require_once( $plugin_fw_file );
				}
			}
		}

		/**
		 * Add a panel under YITH Plugins tab
		 *
		 * @return   void
		 * @since    1.0
		 * @author   Andrea Grillo <andrea.grillo@yithemes.com>
		 * @use     /Yit_Plugin_Panel class
		 * @see      plugin-fw/lib/yit-plugin-panel.php
		 */
		public function register_panel() {

			if ( ! empty( $this->_panel ) || ! current_user_can( 'manage_network_options' ) ) {
				return;
			}

			$admin_tabs = array(
				'general' 	=> __( 'Settings', 'yith-wordpress-test-environment' ),
				'style'     => __( 'Style', 'yith-wordpress-test-environment' )
			);

			if( apply_filters( 'ywtenv_show_adavanced_options', false ) ) {
				$admin_tabs['advanced'] = __( 'Advanced', 'yith-wordpress-test-environment' );
			}

			$args = array(
				'create_menu_page' => true,
				'parent_slug'      => '',
				'page_title'       => __( 'WordPress Test Environment', 'yith-wordpress-test-environment' ),
				'menu_title'       => __( 'WordPress Test Environment', 'yith-wordpress-test-environment' ),
				'capability'       => 'manage_network_options',
				'parent'           => 'ywtenv',
				'parent_page'      => 'yit_plugin_panel',
				'page'             => $this->_panel_page,
				'admin-tabs'       => $admin_tabs,
				'options-path'     => YWTENV_DIR . 'plugin-options'
			);

			$this->_panel = new YIT_Plugin_Panel( $args );
		}

		/**
		 * Action Links
		 *
		 * add the action links to plugin admin page
		 *
		 * @param $links | links plugin array
		 *
		 * @return   mixed Array
		 * @since    1.0
		 * @author   Andrea Grillo <andrea.grillo@yithemes.com>
		 * @return mixed
		 * @use plugin_action_links_{$plugin_file_name}
		 */
		public function action_links( $links ) {
			$links[] = '<a href="' . admin_url( "admin.php?page={$this->_panel_page}" ) . '">' . __( 'Settings', 'yith-wordpress-test-environment' ) . '</a>';

			return $links;
		}

		/**
		 * plugin_row_meta
		 *
		 * add the action links to plugin admin page
		 *
		 * @param $plugin_meta
		 * @param $plugin_file
		 * @param $plugin_data
		 * @param $status
		 *
		 * @return   Array
		 * @since    1.0
		 * @author   Andrea Grillo <andrea.grillo@yithemes.com>
		 * @use plugin_row_meta
		 */
		public function plugin_row_meta( $plugin_meta, $plugin_file, $plugin_data, $status ) {

			if ( defined( 'YWTENV_INIT') && YWTENV_INIT == $plugin_file ) {
				$plugin_meta[] = '<a href="' . $this->doc_url . '" target="_blank">' . __( 'Plugin Documentation', 'yith-wordpress-test-environment' ) . '</a>';
			}

			return $plugin_meta;
		}

		/**
		 * Register plugins for activation tab
		 *
		 * @return void
		 * @since 2.0.0
		 */
		public function register_plugin_for_activation() {
			if ( ! class_exists( 'YIT_Plugin_Licence' ) ) {
				require_once( YWTENV_DIR . '/plugin-fw/licence/lib/yit-licence.php' );
				require_once( YWTENV_DIR . '/plugin-fw/licence/lib/yit-plugin-licence.php' );
			}

			YIT_Plugin_Licence()->register( YWTENV_INIT, YWTENV_SECRET_KEY, YWTENV_SLUG );
		}

		/**
		 * Register plugins for update tab
		 *
		 * @return void
		 * @since 2.0.0
		 */
		public function register_plugin_for_updates() {
			if( ! class_exists( 'YIT_Plugin_Licence' ) ){
				require_once( YWTENV_DIR . '/plugin-fw/lib/yit-upgrade.php' );
			}

			YIT_Upgrade()->register( YWTENV_SLUG, YWTENV_INIT );
		}

		/**
		 * Add countdown banner for sandbox admin
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function countdown_banner(){

			// exit if not sandboxes exist or if current is not a sandbox
			if( ! ywtenv_is_sandbox() ) {
				return;
			}

			// check if template exist
			$countdown_bar = YWTENV_TEMPLATE_PATH . '/admin/countdown-bar.php';
			if( ! file_exists( $countdown_bar ) ) {
				return;
			}
			
			// set countdown to
			$countdown = ywtenv_get_sandbox_expiration_time() * 1000;

			// then include template
			include( $countdown_bar );
		}
		
		/**
		 * Render delete button on admin plugin panel
		 * 
		 * @since 1.0.0
		 * @param array $option
		 * @param mixed $db_value
		 * @param array $custom_attributes
		 * @author Francesco Licandro
		 */
		public function render_delete_button( $option, $db_value, $custom_attributes ) {

			// check if template exist
			$delete_button = YWTENV_TEMPLATE_PATH . '/admin/delete-button.php';
			if( ! file_exists( $delete_button ) ) {
				return;
			}

			// then include template
			include( $delete_button );
		}
		
		/**
		 * Delete all sandboxes for current site
		 * 
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function delete_sandboxes(){

			if( ! isset( $_REQUEST['action'] ) || ! isset( $_REQUEST['nonce'] ) || ! wp_verify_nonce( $_REQUEST['nonce'], $this->action_delete ) ) {
				die();
			}

			$currentID = get_current_blog_id();
			// get all active sandboxes
			$sandboxes_active = get_blog_option( $currentID, 'ywtenv-sandboxes-active', array() );
			
			if( ! empty( $sandboxes_active ) ) {
				
				if( ! class_exists( 'YITH_WP_Test_Env_Destroyer' ) ) {
					require_once( 'class.yith-wp-test-env-destroyer.php' );
				}
				$destroyer = new YITH_WP_Test_Env_Destroyer();

				foreach ( $sandboxes_active as $sandboxID => $value ) {
					// check first if sandbox currently exists and was not deleted manually
					if( ! ( $response = ywtenv_sandbox_deleted( $sandboxID ) ) ) {
						// if exists delete it!
						$response = $destroyer->sandbox_destroy( $sandboxID, true, true );
					}
					
					if( $response ) {
						// remove from global
						ywtenv_remove_sandboxes_from_global_list( $sandboxID );
					}
				}
				
				// empty parent option for active sandboxes
				update_blog_option( $currentID, 'ywtenv-sandboxes-active', array() );
			}

			echo 'success';
			die();
		}
	}
}