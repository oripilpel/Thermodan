<?php
/**
 * Frontend class
 *
 * @author YITHEMES
 * @package YITH WordPress Test Environment
 * @version 1.0.0
 */

if ( ! defined( 'YWTENV' ) ) {
	exit;
} // Exit if accessed directly

if ( ! class_exists( 'YITH_WP_Test_Env_Front' ) ) {
	/**
	 * Frontend class.
	 * The class manage all the frontend behaviors.
	 *
	 * @since 1.0.0
	 */
	class YITH_WP_Test_Env_Front {

		/**
		 * Ajax action for creating sandbox
		 *
		 * @since 1.0.0
		 * @access public
		 */
		public $action_create = 'ywtenv_create_sandbox';

		/**
		 * Constructor
		 *
		 * @access public
		 * @since 1.0.0
		 */
		public function __construct() {

			if( ywtenv_get_option('ywtenv-enable-plugin-site') != 'yes' ) {
				return;
			}

			// scripts and styles
			add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_scripts_styles' ), 10 );

			// add ajax call for create demo
			add_action( 'wp_ajax_' . $this->action_create, array( $this, 'create_sandbox_ajax' ) );
			add_action( 'wp_ajax_nopriv_' . $this->action_create, array( $this, 'create_sandbox_ajax' ) );
			
			// apply preview bar
			add_action( 'wp_footer', array( $this, 'add_preview_bar' ), 10 );
		}

		/**
		 * Enqueue scripts and styles for plugin
		 * 
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function enqueue_scripts_styles(){

			$min = ( defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ) ? '' : '.min';

			// get stylesheet 
			$stylesheet = self::stylesheet_url();
			
			// register script
			wp_register_script( 'ywtenv.js', YWTENV_ASSETS_URL . 'js/ywtenv-front' . $min . '.js', array( 'jquery' ), YWTENV_VERSION, true );

			if( apply_filters('ywtenv_enqueue_fontawesome', true ) ) {
				wp_register_style( 'font-awesome', YWTENV_ASSETS_URL . 'fonts/font-awesome/css/font-awesome.min.css', array(), '4.6.3' );
				wp_enqueue_style( 'font-awesome' );
			}

			// register style
			if( $stylesheet ){
				wp_register_style( 'ywtenv.css', $stylesheet, array(), YWTENV_VERSION );
				wp_enqueue_style( 'ywtenv.css' );
			}

			// get custom style
			$custom = ywtenv_get_all_custom_style();
			// add inline
			wp_add_inline_style( 'ywtenv.css', $custom );
			
			// if sandbox include also countdown
			if( ywtenv_is_sandbox() ) {
				wp_register_script( 'jquery-plugin', YWTENV_ASSETS_URL . 'js/jquery.plugin.min.js', array( 'jquery' ), false, true );
				wp_register_script( 'jquery-countdown', YWTENV_ASSETS_URL . 'js/jquery.countdown.min.js', array( 'jquery', 'jquery-plugin' ), false, true );
				
				wp_enqueue_script( 'jquery-plugin' );
				wp_enqueue_script( 'jquery-countdown' );
			} 

			wp_enqueue_script( 'ywtenv.js' );
			wp_localize_script( 'ywtenv.js', 'ywtenv_args', array(
				'ajaxurl'       => admin_url( 'admin-ajax.php' ),
				'actionCreate'  => $this->action_create,
				'errorMsg'      => apply_filters( 'ywtenv_error_creation_msg', __( 'An error occured while creating the sandbox. Please try again.', 'yith-wordpress-test-environment' ) )
			) );
		}

		/**
		 * Ajax action for create sandbox
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function create_sandbox_ajax(){

			if( ! isset( $_REQUEST['action'] ) || $_REQUEST['action'] != $this->action_create ){
				die();
			}

			do_action( 'ywtenv_before_sandbox_creation' );

			$response = ywtenv_create_sandbox();

			if( ! $response || ! isset( $response['userID'] ) || ! isset( $response['newBlogID'] ) ) {
				die();
			}

			do_action( 'ywtenv_new_sandbox_cretaed', $response );

			// first login user
			wp_set_auth_cookie( $response['userID'], true );
			// response url,
			$url = apply_filters( 'ywtenv_new_sandbox_redirect_url', get_site_url( $response['newBlogID'] ) . '/wp-admin', $response );

			echo $url;

			die();
		}

		/**
		 * Apply preview bar on frontend
		 *
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		public function add_preview_bar() {

			// if bar was closed exit
			if( isset( $_COOKIE['ywtenv_bar_closed'] ) && $_COOKIE['ywtenv_bar_closed'] && ! ywtenv_is_sandbox() ) {
				return;
			}

			// set bar name
			$preview_bar    = apply_filters( 'ywtenv_preview_bar_template_name', 'preview-bar.php' );
			$args           = apply_filters( 'ywtenv_preview_bar_template_args', array(
                'sandbox_enabled'    => ywtenv_get_option( 'ywtenv-allow-sandboxes' ),
                'demo_label'         => ywtenv_get_option( 'ywtenv-demo-button-label' ),
                'purchase_label'     => ywtenv_get_option( 'ywtenv-purchase-button-label' ),
                'purchase_url'       => ywtenv_get_option( 'ywtenv-purchase-button-url' ),
                'logo'               => ywtenv_get_option( 'ywtenv-bar-logo' ),
                'logo_link'          => ywtenv_get_option( 'ywtenv-bar-logo-link' ),
                'popup_content'      => ywtenv_get_option( 'ywtenv-demo-popup-content' ),
                'popup_submessage'   => apply_filters( 'ywtenv_popup_sandbox_submessage', '' ),
                'is_sandbox'         => ywtenv_is_sandbox()
            ) );

			ywtenv_include_template( $preview_bar, $args );
		}

		/**
		 * Return the url of stylesheet position
		 * 
		 * @since 1.0.0
		 * @author Francesco Licandro
		 */
		protected function stylesheet_url() {

			$filename = 'ywtenv-front.css';
			$stylesheet = '';
			$plugin_path   = array( 'path' => YWTENV_DIR . 'assets/css/' . $filename, 'url' => YWTENV_ASSETS_URL . 'css/' . $filename );
			$template_path = array( 'path' => get_template_directory() . '/' . $filename, 'url' => get_template_directory_uri() . '/' . $filename );
			$child_path    = array( 'path' => get_stylesheet_directory() . '/' . $filename, 'url' => get_stylesheet_directory_uri() . '/' . $filename );

			foreach ( array( 'child_path', 'template_path', 'plugin_path' ) as $var ) {
				if ( file_exists( ${$var}['path'] ) ) {
					$stylesheet = ${$var}['url'];
					break;
				}
			}
			
			return $stylesheet;
		}
	}
}