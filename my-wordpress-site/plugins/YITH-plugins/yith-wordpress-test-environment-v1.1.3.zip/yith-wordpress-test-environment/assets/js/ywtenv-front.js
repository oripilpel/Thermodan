/**
 * YITH Live Demo
 *
 * Frontend script
 * ver 1.0.0
 */
jQuery(document).ready(function($){
	"use strict";

    // get elements
    var $banner = $( '#ywtenv-banner' ),
        popup = $('#create-sandbox'),
        popupContent = popup.find('.popup-content'),
        popupContentHtml = popupContent.html(),
        countdown = $('#countdownSandbox');

    if( ! $banner.length || typeof ywtenv_args == 'undefined' ) {
        return;
    }

	// Add padding to body height
    function bodyPadding () {
        $('body').css( 'padding-top', $banner.height() + 'px');
    }

    $( window ).resize( bodyPadding );
    bodyPadding();

	$( '#new-sandbox a' ).on( 'click', function(ev) {
		ev.preventDefault();

        if( popup.length ){
            popupContent.html( popupContentHtml );
            popup.fadeIn();
        }

        // start ajax
        $.ajax({
            url: ywtenv_args.ajaxurl,
            data: {
                action : ywtenv_args.actionCreate,
                context: 'frontend'
            },
            success: function( resp ){
                // on success redirect to admin sandbox
                if( resp ){
                    window.top.location.href = resp;
                    return;
                }

                if( popup.length ) {
                    popupContent.html('<p>' + ywtenv_args.errorMsg + '</p>');
                    setTimeout(function () {
                        popup.fadeOut();
                    }, 3000);
                }
            },
            error: function(){
                if( popup.length ) {
                    popupContent.html('<p>' + ywtenv_args.errorMsg + '</p>');
                    setTimeout(function () {
                        popup.fadeOut();
                    }, 3000);
                }
            }
        })
	});

    if( typeof $.fn.countdown != 'undefined' && countdown.length ) {

        var until = new Date( countdown.data('to') );

        countdown.countdown({
            until: until,
            format: 'HMS',
            compact: true,
            description: ''
        });
    }

    $banner.find( '.close-link' ).on( 'click', function(ev){
        ev.preventDefault();
        document.cookie = "ywtenv_bar_closed=1";

        $banner.remove();
        $('body').css( 'padding-top', '0' );
    });
});
