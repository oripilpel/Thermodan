/**
 * YITH WordPress Test Environment
 *
 * Admin script
 * ver 1.0.0
 */
jQuery(document).ready(function($){
	"use strict";

    if( typeof ywtenv == 'undefined' ) {
        return;
    }

    $('.ywtenv-delete-from-admin').on('click', function(){
        var button = $(this),
            r = confirm( ywtenv.alert_msg );
        if ( r == true ) {

            button.attr( 'disabled', 'disable' );
            button.next().fadeIn();

            $.ajax({
                url: ywtenv.ajaxurl,
                data: {
                   action: ywtenv.actiondel,
                   nonce:  ywtenv.nonce_actiondel
                },
                success: function ( resp ) {
                    button.removeAttr( 'disabled' );
                    button.next().fadeOut();
                }
                
            });
        }
    });

    // countdown for sandbox
    var countdown = $('#countdownSandbox');

    if( typeof $.fn.countdown != 'undefined' && countdown.length ) {

        var until = new Date( countdown.data('to') );

        countdown.countdown({
            until: until,
            format: 'HMS',
            compact: true,
            description: ''
        });
    }

});
