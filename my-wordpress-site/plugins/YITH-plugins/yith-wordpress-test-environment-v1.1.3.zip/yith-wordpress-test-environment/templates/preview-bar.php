<?php
/**
 * YITH WordPress Test Environment
 * 
 * PREVIEW BAR TEMPLATE
 * @ver 1.0.0
 */

?>
<div id="ywtenv-banner">
    <div class="ywtenv-banner-container">
        
        <?php if( $logo ) : ?>
            <div id="logo-section">
            <?php if( $logo_link ) : ?>
                <a href="<?php echo esc_url( $logo_link ) ?>" class="logo-link">
            <?php endif; ?>
                    <img src="<?php echo esc_url( $logo ) ?>">
            <?php if( $logo_link ) : ?>
                </a>
            <?php endif; ?>
            </div>
        <?php endif; ?>

        <div id="demo-action" <?php echo ! $logo ? 'class="fullWidth"' : '' ?>>
            <?php if( $purchase_url ) : ?>
                <div id="purchase-box">
                    <a href="<?php echo esc_url( $purchase_url ); ?>">
                        <i class="fa fa-shopping-cart" aria-hidden="true"></i>
                        <span><?php echo esc_html( $purchase_label ); ?></span>
                    </a>
                </div>
            <?php endif; ?>

            <?php if( $is_sandbox && is_user_logged_in() ) : ?>
                <div id="sandbox-countdown">
                    <p><?php _e( 'Your demo ends in: ', 'yith-wordpress-test-environment' ) ?><span id="countdownSandbox" data-to="<?php echo ywtenv_get_sandbox_expiration_time() * 1000; ?>"></span></p>
                </div>
            <?php elseif( $is_sandbox ) : ?>
                <div id="login-sandbox">
                    <a href="<?php echo ywtenv_get_login_sandbox_url() ?>">
                        <i class="fa fa-power-off" aria-hidden="true"></i>
                        <span><?php _e( 'Log In Sandbox', 'yith-wordpress-test-environment' ) ?></span>
                    </a>
                </div>
            <?php elseif( $sandbox_enabled === 'yes' && ywtenv_can_site_have_sandbox() ) : ?>
                <div id="new-sandbox">
                    <a href="#" data-action="ywtenv_create_sandbox">
                        <i class="fa fa-power-off" aria-hidden="true"></i>
                        <span><?php echo esc_html( $demo_label ); ?></span>
                    </a>
                </div>
            <?php endif; ?>
        </div>
        
        <?php if( ! $is_sandbox ) : ?>
            <a class="close-link" href="#"><span class="fa fa-times"></span><?php _ex( 'Close', 'Close preview bar', 'yith-wordpress-test-environment' ); ?></a>
        <?php endif; ?>
    </div>
</div>

<?php if( $popup_content ) : ?>
    <div id="create-sandbox">
        <div class="popup-content">
            <p class="popup-message"><?php echo esc_html( $popup_content ) ?></p>
            <?php if( $popup_submessage ) : ?>
                <?php echo $popup_submessage ?>
            <?php endif; ?>
            <div class="image-loader"><img src="<?php echo YWTENV_ASSETS_URL . 'images/loader1.gif' ?>"></div>
        </div>
    </div>
<?php endif; ?>