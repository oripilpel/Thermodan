<?php
/**
 * YITH WordPress Test Environment
 * 
 * Expired template
 * @ver 1.2.0
 */

?>
<!DOCTYPE html>
<html xmlns="http://www.w3.org/1999/xhtml" <?php language_attributes() ?>>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width">
    <?php
    if ( function_exists( 'wp_no_robots' ) ) {
        wp_no_robots();
    }
    ?>
    <style type="text/css">
        html, body {
            height: 100%;
            margin: 0;
            padding: 0;
        }
        body {
            background: #f1f1f1;
            min-width: 0;
            color: #444;
            font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif;
            font-size: 13px;
            line-height: 1.4em;
        }
        #content {
            width: 500px;
            padding: 12% 0 0;
            margin: auto;
        }
        #content .modal {
            overflow: hidden;
            background: #fff;
            box-shadow: 0 1px 3px rgba(0,0,0,0.13);
            padding: 35px 15px;
            text-align: center;
            border-radius: 5px;
        }
        .button {
            background: #f7f7f7;
            border: 1px solid #ccc;
            color: #555;
            display: inline-block;
            text-decoration: none;
            font-size: 13px;
            line-height: 26px;
            height: 28px;
            margin: 0;
            padding: 0 10px 1px;
            cursor: pointer;
            -webkit-border-radius: 3px;
            -webkit-appearance: none;
            border-radius: 3px;
            white-space: nowrap;
            -webkit-box-sizing: border-box;
            -moz-box-sizing:    border-box;
            box-sizing:         border-box;

            -webkit-box-shadow: 0 1px 0 #ccc;
            box-shadow: 0 1px 0 #ccc;
            vertical-align: middle;
        }

        .button.button-large {
            height: 30px;
            line-height: 28px;
            padding: 0 12px 2px;
        }

        .button:hover,
        .button:focus {
            background: #fafafa;
            border-color: #999;
            color: #23282d;
        }

        .button:focus  {
            border-color: #5b9dd9;
            -webkit-box-shadow: 0 0 3px rgba( 0, 115, 170, .8 );
            box-shadow: 0 0 3px rgba( 0, 115, 170, .8 );
            outline: none;
        }

        .button:active {
            background: #eee;
            border-color: #999;
            -webkit-box-shadow: inset 0 2px 5px -3px rgba( 0, 0, 0, 0.5 );
            box-shadow: inset 0 2px 5px -3px rgba( 0, 0, 0, 0.5 );
            -webkit-transform: translateY(1px);
            -ms-transform: translateY(1px);
            transform: translateY(1px);
        }
        #content h1 {
            font-size: 24px;
            text-transform: uppercase;
            margin: 20px 0;
        }
        #content p {
            font-size: 15px;
            font-weight: 600;
            margin: 10px 0;
        }
        #content .sep {
            margin: 0 5px;
            text-transform: uppercase;
            font-weight: bold;
        }
        #content form {
            margin: 35px 0 20px;
        }
        @media( max-width: 480px ) {
            #content {
                width: 380px;
            }
        }
    </style>
</head>
<body id="expired-sandbox-page">
<div id="content">
    <div class="modal">
        <h1><?php _e( 'Ops! Your sandbox is expired', 'yith-wordpress-test-environment' ) ?></h1>
        <form method="POST">
            <?php wp_nonce_field( 'expired-sandbox-action', '_expiredNonce' ); ?>
            <input type="hidden" name="sandboxID" value="<?php echo esc_attr( $sandboxID ) ?>">
            <input type="hidden" name="wp_http_referer" value="<?php echo esc_attr( wp_unslash( $_SERVER['REQUEST_URI'] ) ) ?>">
            <button class="button" name="expired-action" value="continue"><?php _e( 'Get more time', 'yith-wordpress-test-environment' ) ?></button>
            <span class="sep"><?php _e( 'or', 'yith-wordpress-test-environment' ); ?></span>
            <button class="button alt" name="expired-action" value="return"><?php _e( 'Go to live demo', 'yith-wordpress-test-environment' ); ?></button>
        </form>
    </div>
</div>
<div class="clear"></div>
</body>
</html>