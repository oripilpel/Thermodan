<?php

if ( ! defined( 'ABSPATH' ) ) {
    exit;
} // Exit if accessed directly

$id                 = $this->_panel->get_id_field( $option['id'] );
$name               = $this->_panel->get_name_field( $option['id'] );

?>
<div id="<?php echo $id ?>-container" <?php if ( isset( $option['deps'] ) ): ?>data-field="<?php echo $id ?>" data-dep="<?php echo $this->_panel->get_id_field( $option['deps']['ids'] ) ?>" data-value="<?php echo $option['deps']['values'] ?>" <?php endif ?> class="yit_options rm_option rm_input rm_text">
    <div class="option">
        <input type="button" class="button-secondary ywtenv-delete-from-admin" value="<?php _e( 'Delete Sandboxes', 'yith-wordpress-test-environment' ); ?>">
        <img src="<?php echo YWTENV_ASSETS_URL . 'images/wpspin_light.gif' ?>" style="display:none"/>
    </div>
    <span class="description"><?php echo $option['desc'] ?></span>

    <div class="clear"></div>
</div>