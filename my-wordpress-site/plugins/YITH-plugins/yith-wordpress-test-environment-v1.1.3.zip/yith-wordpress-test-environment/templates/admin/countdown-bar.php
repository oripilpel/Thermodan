<div id="countdownSandbox-container">
    <p><?php _e( 'Your demo ends in: ', 'yith-wordpress-test-environment' ) ?><span id="countdownSandbox" data-to="<?php echo $countdown ?>"></span></p>
</div>
<script>
    jQuery(document).ready( function($){
        var countdown = $('#countdownSandbox'),
            until = new Date( countdown.data('to') );

        if( typeof $.fn.countdown != 'undefined' ) {
            countdown.countdown({
                until: until,
                format: 'HMS',
                compact: true,
                description: ''
            });
        }
    });
</script>