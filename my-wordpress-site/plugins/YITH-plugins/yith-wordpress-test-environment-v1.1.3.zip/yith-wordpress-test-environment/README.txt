=== CHANGELOG ===

=== 1.1.3 === Released on Nov 05, 2019

* Update: plugin core

=== 1.1.2 === Released on Oct 30, 2019

* Tweak: new modal box when a sandbox is expired
* Update: plugin core

=== 1.1.1 === Released on May 29, 2019

* New: support to WordPress 5.2.1
* Tweak: new modal box when a sandbox is expired
* Update: plugin core
* Dev: new hook 'ywtenv_before_sandbox_creation'
* Dev: removed WC action on sandbox_destroy method


=== 1.1.0 === Released on Oct 02, 2018

* New: Spanish translation.
* New: Italian translation.
* New: Dutch translation.
* Update : Plugin Core.
* Fix: Delete sandbox attachments and upload directory.
* Dev: New filter "ywtenv_run_replace_tables_list".
* Dev: New filter "ywtenv_new_sandbox_redirect_url".
* Dev: New action "ywtenv_before_destroy_sandbox".

=== 1.0.0 === Released on Aug 30, 2016
* Initial Release