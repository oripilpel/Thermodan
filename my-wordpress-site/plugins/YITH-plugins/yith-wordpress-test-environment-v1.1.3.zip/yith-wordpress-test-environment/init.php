<?php
/**
 * Plugin Name: YITH WordPress Test Environment
 * Plugin URI: https://yithemes.com/themes/plugins/yith-wordpress-test-environment/
 * Description: The best way to set up a testing environment for WordPress!
 * Version: 1.1.3
 * Author: YITH
 * Author URI: https://yithemes.com/
 * Text Domain: yith-wordpress-test-environment
 * Domain Path: /languages/
 *
 * @author YITH
 * @package YITH WordPress Test Environment
 * @version 1.1.3
 */
/*  Copyright 2016  Your Inspiration Themes  (email : plugins@yithemes.com)

This program is a free software; you can redistribute it and/or modify
it under the terms of the GNU General Public License, version 2, as
published by the Free Software Foundation.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program; if not, write to the Free Software
Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/


if ( !defined( 'ABSPATH' ) ) { exit; } // Exit if accessed directly

if ( ! function_exists( 'is_plugin_active' ) ) {
    require_once( ABSPATH . 'wp-admin/includes/plugin.php' );
}

if ( ! function_exists( 'yith_plugin_registration_hook' ) ) {
    require_once 'plugin-fw/yit-plugin-registration-hook.php';
}
register_activation_hook( __FILE__, 'yith_plugin_registration_hook' );


if ( ! defined( 'YWTENV_VERSION' ) ){
    define( 'YWTENV_VERSION', '1.1.3' );
}
if ( ! defined( 'YWTENV_INIT' ) ) {
    define( 'YWTENV_INIT', plugin_basename( __FILE__ ) );
}
if ( ! defined( 'YWTENV' ) ) {
    define( 'YWTENV', true );
}
if ( ! defined( 'YWTENV_FILE' ) ) {
    define( 'YWTENV_FILE', __FILE__ );
}
if ( ! defined( 'YWTENV_URL' ) ) {
    define( 'YWTENV_URL', plugin_dir_url( __FILE__ ) );
}
if ( ! defined( 'YWTENV_DIR' ) ) {
    define( 'YWTENV_DIR', plugin_dir_path( __FILE__ )  );
}
if ( ! defined( 'YWTENV_TEMPLATE_PATH' ) ) {
    define( 'YWTENV_TEMPLATE_PATH', YWTENV_DIR . 'templates' );
}
if ( ! defined( 'YWTENV_ASSETS_URL' ) ) {
    define( 'YWTENV_ASSETS_URL', YWTENV_URL . 'assets/' );
}
if ( ! defined( 'YWTENV_SLUG' ) ) {
    define( 'YWTENV_SLUG', 'yith-wordpress-test-environment' );
}
if ( ! defined( 'YWTENV_SECRET_KEY' ) ) {
    define( 'YWTENV_SECRET_KEY', '9YxhXFDKIU8ad9HKNRsY' );
}

/* Plugin Framework Version Check */
if( ! function_exists( 'yit_maybe_plugin_fw_loader' ) && file_exists( YWTENV_DIR . 'plugin-fw/init.php' ) ) {
    require_once( YWTENV_DIR . 'plugin-fw/init.php' );
}
yit_maybe_plugin_fw_loader( YWTENV_DIR  );

function ywtenv_multisite_admin_error() {
    ?>
    <div class="error">
        <p><?php _e( 'YITH WordPress Test Environment works only on multisite installations', 'yith-wordpress-test-environment' ); ?></p>
    </div>
    <?php
}

function ywtenv_init() {

    if ( ! is_multisite() ) {
        add_action( 'admin_notices', 'ywtenv_multisite_admin_error' );
        return;
    }

    load_plugin_textdomain( 'yith-wordpress-test-environment', false, dirname( plugin_basename( __FILE__ ) ). '/languages/' );

    // Load required classes and functions
    require_once('includes/functions.yith-wp-test-env.php');
    require_once('includes/class.yith-wp-test-env.php');

    // Let's start the game!
    YITH_WP_Test_Env();
}
add_action( 'plugins_loaded', 'ywtenv_init', 50 );