<div class="yith-wcbk-printer-field__desc-box">
    <?php echo $value ?>
</div>
