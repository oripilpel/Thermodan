<?php echo $value ?>
