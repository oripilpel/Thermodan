<?php
/**
 * @var YITH_WCBK_Booking $booking
 * @var string            $footer
 * @var bool              $is_admin
 */
?>

<div class="footer">
    <?php if ( $footer != '' ): ?>
        <div class="footer-content"><?php echo $footer ?></div>
    <?php endif; ?>
</div>