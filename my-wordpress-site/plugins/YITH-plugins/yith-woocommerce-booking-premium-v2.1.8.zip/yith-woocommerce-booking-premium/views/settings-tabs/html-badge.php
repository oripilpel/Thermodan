<?php
/**
 * @var string $type
 * @var string $text
 */
?>

<div class="yith-wcbk-integration-badge <?php echo $type; ?>">
    <div class="yith-wcbk-integration-badge-s1"></div>
    <div class="yith-wcbk-integration-badge-s2"></div>
    <div class="yith-wcbk-integration-badge-text"><?php echo $text ?></div>
</div>