<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
} // Exit if accessed directly

// !important; is a gmail hack to prevent styles being stripped if it doesn't like something.

?>

	h2{
	margin: 16px 0 0 0;
	}

	i{
	font-size: small;
	margin: 0 0 16px 0;
	display: block;
	}

	span{
	font-size: small;
	font-style: italic;
	}

<?php
