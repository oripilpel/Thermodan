<?php
/* Compatibility with Aelia Currency Switcher */

if( !empty($GLOBALS['woocommerce-aelia-currencyswitcher']) ){

    add_filter('yith_wcbpg_suggested_price', 'yith_wcbpg_filter_amount',10,3);
    add_filter('yith_wcbpg_coupon_display_price', 'yith_wcbpg_filter_amount',10,3);
    add_filter('yith_wcbpg_coupon_product_price', 'yith_wcbpg_filter_amount',10,3);
    add_filter('yith_wcbpg_product_price', 'yith_wcbpg_filter_amount',10,3);
    add_filter('yith_wcbpg_suggested_price_email_user_notification','yith_wcbpg_filter_amount',10,4);


    function yith_wcbpg_filter_amount( $amount,$customer_currency, $view, $woocommerce_currency = NULL  ){

        $aelia = $GLOBALS['woocommerce-aelia-currencyswitcher'];

        $woocommerce_currency = get_option ( 'woocommerce_currency' );

//        error_log(current_action() . '  - Customer currency - ' . $customer_currency);
//        error_log(current_action() . '  - WooCommerce currency - ' . $customer_currency);

        if( $customer_currency != $woocommerce_currency ){

            if( current_action() == 'yith_wcbpg_suggested_price_email_user_notification' ){

                $amount = str_replace( ',','.',$amount );

            }

            if( $view == 'admin' ){
                $amount = $aelia->convert($amount, $customer_currency, $woocommerce_currency,true);
            }elseif( $view == 'customer' ){
                $amount = $aelia->convert($amount, $woocommerce_currency, $customer_currency,true );
            }

            if (get_option('woocommerce_price_decimal_sep') == ','){
                $amount = str_replace( '.',',',$amount );
            }else{
                $amount = str_replace( ',','.',$amount );
            }

        }

        return $amount;

    }
}

//$woocommerce_currency = get_option ( 'woocommerce_currency' );
//$aelia = $GLOBALS['woocommerce-aelia-currencyswitcher'];
//var_dump($aelia->convert('6,26', 'EUR', 'AUD' ));die();