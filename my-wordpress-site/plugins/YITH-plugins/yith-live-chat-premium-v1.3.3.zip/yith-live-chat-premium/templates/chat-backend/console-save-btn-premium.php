<button id="YLC_save" data-cnv-id="0" class="button">
    <i class="fa fa-floppy-o"></i>
    <?php _e( 'Save chat', 'yith-live-chat' ); ?>
</button>
