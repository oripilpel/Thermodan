
<div class="wcbm-css-badge">
	<div class="wcbm-css-s1"></div>
	<div class="wcbm-css-s2"></div>
	<div class="wcbm-css-text"></div>
</div>