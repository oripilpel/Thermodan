<?php
echo 'Premium version tab';