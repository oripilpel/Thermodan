<?php
/*
YITH FRONTEND DASHBOARD SKIN DEFAULT HEADER
*/
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

?>
<div class="clear clearfix"></div>
<div id="yith_wcfm-footer" class="skin-1">
    <div class="yith_wcfm-container">
        <div class="yith_wcfm-widget-area">
			<?php dynamic_sidebar( 'yith_wcfm_footer_sidebar' ); ?>
        </div>
    </div>
</div>
</body>
</html>