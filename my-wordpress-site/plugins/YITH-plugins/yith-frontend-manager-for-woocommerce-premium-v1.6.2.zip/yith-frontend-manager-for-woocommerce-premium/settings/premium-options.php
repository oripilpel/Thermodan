<?php

return array(
	'premium' => array(
		'home' => array(
			'type'   => 'custom_tab',
			'action' => 'yith_wcfm_premium_tab',
		)
	)
);