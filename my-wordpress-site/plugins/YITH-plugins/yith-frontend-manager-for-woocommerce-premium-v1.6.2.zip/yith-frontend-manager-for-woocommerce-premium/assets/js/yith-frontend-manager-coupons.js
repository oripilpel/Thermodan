(function($) {
    $(".product_ids-select2").selectYITH();
    $(".exclude_product_ids-select2").selectYITH();
    $(".product_categories-select2").selectYITH();
    $(".exclude_product_categories-select2").selectYITH();
})(jQuery);