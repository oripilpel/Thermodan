<p>Members of our team have access to the information you provide us. For example,  Administrators can access:</p>
<ul>
    <li>View and edit available funds</li>
    <li>View the deposit list</li>
</ul>
