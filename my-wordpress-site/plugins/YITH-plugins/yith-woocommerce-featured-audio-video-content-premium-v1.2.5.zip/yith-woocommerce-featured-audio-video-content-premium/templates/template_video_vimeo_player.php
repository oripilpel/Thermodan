<div id="<?php echo $id;?>" data-video="<?php echo $video_data;?>" data-vimeo="<?php echo $data;?>" class="iframe">
</div>
<?php

include ( YWCFAV_DIR.'assets/php/vimeo_manager.php');
?>