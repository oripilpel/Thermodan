<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}
?>
<div class="ywcfav_video_embedded_iframe" id="<?php echo $id;?>">
	<?php echo urldecode( $video_id ); ?>
</div>
