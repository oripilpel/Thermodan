<?php
if( !class_exists( 'YITH_Delivery_Date_WC_Advanced_Shipping' ) ){

	class YITH_Delivery_Date_WC_Advanced_Shipping{

		public function __construct()
		{
			add_filter( 'ywcdd_get_shipping_method_option', array( $this, 'get_table_rate_option_name' ), 10 ,2 );

		}

		public function get_table_rate_option_name( $shipping_option, $option_name ) {


			if( empty( $shipping_option ) ) {
				$shipping_option = get_option( 'woocommerce_advanced_shipping_settings', array() );


			}
			return $shipping_option;
		}



	}
}

new YITH_Delivery_Date_WC_Advanced_Shipping();