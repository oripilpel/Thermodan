<?php
/**
 * Class SampleTest
 *
 * @package Yith_Woocommerce_Points_And_Rewards.premium
 */

/**
 * Sample test case.
 */
class SampleTest extends WP_UnitTestCase {

	/**
	 * A single example test.
	 */
	public function test_sample() {
		// Replace this with some actual testing code.
		$this->assertTrue( true );
	}
}
