<?php
/**
 * Class SampleTest
 *
 * @package YITH_Woocommerce_Subscription_Premium
 */

/**
 * Sample test case.
 */
class SampleTest extends WP_UnitTestCase {

	/**
	 * A single example test.
	 */
	public function test_sample() {
		// Replace this with some actual testing code.
		$this->assertTrue( true );
	}
}
