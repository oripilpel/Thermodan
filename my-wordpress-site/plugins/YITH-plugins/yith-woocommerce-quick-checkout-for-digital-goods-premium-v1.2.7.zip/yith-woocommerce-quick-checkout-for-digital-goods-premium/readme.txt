=== YITH WooCommerce Quick Checkout For Digital Goods ===

Contributors: yithemes
Tags: woocommerce, products, themes, yit, yith, yithemes, e-commerce, shop, checkout, digital, virtual, quick checkout, digital goods
Requires at least: 4.0
Tested up to: 5.3
Stable tag: 1.2.7
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

== Changelog ==

= 1.2.7 =

* Update: plugin framework

= 1.2.6 =

* Update: plugin framework

= 1.2.5 =

* New: Support for WordPress 5.3
* New: Support for WooCommerce 3.8
* Update: plugin framework

= 1.2.4 =

* New: Support to WooCommerce 3.7.0 RC1
* Update: Italian language

= 1.2.3 =

* New: Support to WordPress 5.2
* Update: plugin framework
* Update: Spanish language

= 1.2.2 =

* New: Support to WooCommerce 3.6.0 RC1
* Update: plugin framework

= 1.2.1 =

* Update: plugin framework

= 1.2.0 =

* New: Support to Wordpress 5.0
* Update: plugin framework

= 1.1.9 =

* Update: plugin framework

= 1.1.8 =

* New: Support to WooCommerce 3.5.0 RC2
* Update: plugin framework

= 1.1.7 =

* Update: plugin framework

= 1.1.6 =

* Update: plugin framework

= 1.1.5 =

* New: Support to Wordpress 4.9.6
* New: Support to WooCommerce 3.4.0
* New: "Enable all users" option
* Update: plugin framework
* Update: Spanish language
* Update: Italian language

= 1.1.4

* Tweak: added "ywqcdg_post_content" filter

= 1.1.3

* New: Spanish translation
* Fix: checkout script loading

= 1.1.2 =

* New: Support to WooCommerce 3.3.0

= 1.1.1 =

* New: Italian translation
* New: Dutch translation
* Update: plugin framework
* Tweak: added "ywqcdg_double_shortcode_loading" filter
* Fix: shortcode lightbox not working

= 1.1.0 =

* New: Support to WooCommerce 3.2.0 RC2
* Update: plugin framework

= 1.0.9 =

* Fix: compatibility issue when using YITH WooCommerce Multi-Step Checkout

= 1.0.8 =

* Fix: total checkout on product page

= 1.0.7 =

* Fix: total on shortcode
* Update: plugin framework

= 1.0.6 =

* Tweak: Support for WooCommerce 3.0.0-RC 1

= 1.0.5 =

* Fix: automatic add to cart of every product

= 1.0.4 =

* Fix: double shortcode button
* Fix: product page option not working

= 1.0.3 =

* Added: option to add a product to the cart automatically when quick checkout has been set in product page

= 1.0.2 =

* Fix: double page loading with shortcode

= 1.0.1 =

* New: support to WooCommerce 2.6.0 beta 4

= 1.0.0 =

* Initial release
