<?php
/**
 * Admin View: Fields Table Edit Form
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit; // Exit if accessed directly
}

$field_types = ywccp_get_field_type();

$billing_fields = ywccp_get_checkout_fields('billing');
$shipping_fields = ywccp_get_checkout_fields('shipping');
$checkout_fields = array_merge($billing_fields,$shipping_fields);

?>

<div id="ywccp_field_add_edit_form" style="display: none;">
	<form>
		<table>
			<tr class="remove_default">
				<td class="label"><?php _e( 'Name', 'yith-woocommerce-checkout-manager' ) ?></td>
				<td><input type="text" name="field_name[]"/></td>
			</tr>
			<tr class="remove_default">
				<td class="label"><?php _e( 'Type', 'yith-woocommerce-checkout-manager' ) ?></td>
				<td>
					<select name="field_type[]">
						<?php foreach( $field_types as $value => $label ): ?>
							<option value="<?php echo $value; ?>"><?php echo $label; ?></option>
						<?php endforeach; ?>
					</select>
				</td>
			</tr>
			<tr>
				<td class="label"><?php _e( 'Label', 'yith-woocommerce-checkout-manager' ) ?></td>
				<td><input type="text" name="field_label[]"/></td>
			</tr>
			<tr data-hide="checkbox,radio,heading,number">
				<td class="label"><?php _e( 'Placeholder', 'yith-woocommerce-checkout-manager' ) ?></td>
				<td><input type="text" name="field_placeholder[]"/></td>
			</tr>
			<?php if( get_option('ywccp-enable-tooltip-check') == 'yes' ) : ?>
				<tr>
					<td class="label"><?php _e( 'Tooltip', 'yith-woocommerce-checkout-manager' ) ?></td>
					<td><input type="text" name="field_tooltip[]"/></td>
				</tr>
			<?php endif; ?>
			<tr class="remove_default" data-hide="text,number,password,tel,textarea,datepicker,checkbox,heading,timepicker">
				<td class="label"><?php _e( 'Options', 'yith-woocommerce-checkout-manager' ) ?></td>
				<td><input type="text" name="field_options[]" placeholder="<?php _e( 'Separate options with pipes (|) and key from value using (::). Es. key::value|', 'yith-woocommerce-checkout-manager' ); ?>" /></td>
			</tr>
			<?php if( isset( $positions ) && is_array( $positions ) ) : ?>
				<tr>
					<td class="label"><?php _e( 'Position', 'yith-woocommerce-checkout-manager' ) ?></td>
					<td>
						<select name="field_position[]"/>
							<?php foreach( $positions as $pos => $pos_label ): ?>
									<option value="<?php echo $pos ?>"><?php echo $pos_label ?></option>
							<?php endforeach; ?>
						</select>
					</td>
				</tr>
			<?php endif; ?>
			<tr>
				<td class="label"><?php _e( 'Class', 'yith-woocommerce-checkout-manager' ) ?></td>
				<td><input type="text" name="field_class[]" placeholder="<?php _e( 'Separate classes with commas', 'yith-woocommerce-checkout-manager' ); ?>"/></td>
			</tr>
			<tr data-hide="heading">
				<td class="label"><?php _e( 'Label class', 'yith-woocommerce-checkout-manager' ) ?></td>
				<td><input type="text" name="field_label_class[]" placeholder="<?php _e( 'Separate classes with commas', 'yith-woocommerce-checkout-manager' ); ?>"/></td>
			</tr>
			<?php if( isset( $validation ) && is_array( $validation ) ) : ?>
				<tr data-hide="heading">
					<td class="label"><?php _e( 'Validation', 'yith-woocommerce-checkout-manager' ) ?></td>
					<td>
						<select name="field_validate[]"/>
						<?php foreach( $validation as $valid_rule => $valid_label ): ?>
							<option value="<?php echo $valid_rule ?>"><?php echo $valid_label ?></option>
						<?php endforeach; ?>
						</select>
					</td>
				</tr>
			<?php endif; ?>

            <tr data-hide="heading">
                <td></td>
                <td>
                    <input type="checkbox" name="field_required[]" value="1" checked/>
                    <label for="field_required">
                        <?php _e( 'Required', 'yith-woocommerce-checkout-manager' ) ?>
                        <small>
                            <?php echo sprintf( __('Please keep it disabled if you need to set at least one condition. %sThe field will be set as required according to the conditions configured','yith-woocommerce-checkout-manager'),'<br>'); ?>
                        </small>
                    </label>
                </td>
            </tr>

			<tr class="remove_default" data-hide="heading">
				<td>&nbsp;</td>
				<td>
					<input type="checkbox" name="field_show_in_email[]" value="1" checked/>
					<label for="field_show_in_email"><?php _e( 'Display in emails', 'yith-woocommerce-checkout-manager' ) ?></label><br/>

					<input type="checkbox" name="field_show_in_order[]" value="1" checked/>
					<label for="field_show_in_order"><?php _e( 'Display in Order Detail Pages', 'yith-woocommerce-checkout-manager' ) ?></label>
				</td>
			</tr>

            <tr data-hide="heading" class="conditions">
                <table class="wrap-conditions">
                    <tr>
                        <th><?php _e( 'Field','yith-woocommerce-checkout-manager' ); ?></th>
                        <th><?php _e( 'Condition','yith-woocommerce-checkout-manager' ); ?></th>
                        <th class="value">
                            <?php _e( 'Value *','yith-woocommerce-checkout-manager' ); ?>
                            <small><?php echo sprintf( __( 'If the condition is %1$s%3$sselected products in cart%4$s%3$sat least one product in cart%4$s %3$sall selected categories in cart%4$s%3$sat least one selected category in cart%4$s%2$s please insert product/category IDs separated by comma','yith-woocommerce-checkout-manager' ),'<ul>','</ul>','<li>','</li>','<p>','</p>' ); ?></small>
                        </th>
                        <th><?php _e( 'Action','yith-woocommerce-checkout-manager' ); ?></th>
                        <th><?php _e( 'Required','yith-woocommerce-checkout-manager' ); ?></th>
                        <th></th>
                    </tr>
                    <tr class="single-condition">
                        <td class="field-name">
                            <select name="field_condition_input_name[]" class="condition-field first field_condition_input_name">
                                <option disabled selected></option>
                                <option value="products"><?php _e( 'Products in cart','yith-woocommerce-checkout-manager' ); ?></option>
                                <?php foreach ( $checkout_fields as $key => $property ): ?>
                                    <?php
                                    $label = '';
                                    if( !isset($property['label']) || $property['label'] == '' ){
                                        $label = str_replace( '_',' ', $key );
                                    }elseif( strpos($key, 'billing') !== false ){
                                        $label = '(billing) - ' . $property['label'];
                                    }elseif( strpos($key, 'shipping') !== false ){
                                        $label = '(shipping) - ' . $property['label'];
                                    }
                                    elseif( strpos($key, 'additional') !== false ){
                                        $label = '(additional) - ' . $property['label'];
                                    }
                                    ?>
                                    <option value="<?php echo $key ?>"><?php echo $label; ?></option>
                                <?php endforeach; ?>
                            </select>
                        </td>
                        <td class="condition-type">
                            <select name="field_condition_type[]" class="condition-field condition-type">
                                <option disabled selected></option>
                                <option value="is-set"><?php _e( 'Is set','yith-woocommerce-checkout-manager' ); ?></option>
                                <option value="is-empty"><?php _e( 'Is empty','yith-woocommerce-checkout-manager' ); ?></option>
                                <option value="has-value"><?php _e( 'Value is','yith-woocommerce-checkout-manager' ); ?></option>
                                <option value="has-not-value"><?php _e( 'Value is not','yith-woocommerce-checkout-manager' ); ?></option>
                                <option value="all-in-cart"><?php _e( 'All selected products in cart','yith-woocommerce-checkout-manager' ); ?></option>
                                <option value="at-least-one-product-in-cart"><?php _e( 'At least one selected product in cart','yith-woocommerce-checkout-manager' ); ?></option>
                                <option value="all-categories-in-cart"><?php _e( 'All selected categories in cart','yith-woocommerce-checkout-manager' ); ?></option>
                                <option value="at-least-one-category-in-cart"><?php _e( 'At least one selected category in cart','yith-woocommerce-checkout-manager' ); ?></option>
                            </select>
                        </td>
                        <td class="condition-value">
                            <input class="condition-field field_condition_value" type="text" name="field_condition_value[]" value="">
                        </td>
                        <td class="condition-action">
                            <select class="condition-field" name="field_condition_action[]">
                                <option disabled selected></option>
                                <option value="show"><?php _e( 'Show','yith-woocommerce-checkout-manager' ); ?></option>
                                <option value="hide"><?php _e( 'Hide','yith-woocommerce-checkout-manager' ); ?></option>
                            </select>
                        </td>
                        <td class="condition-required">
                            <input class="condition-field" type="checkbox" name="field_condition_required[]" value=""/>
                        </td>
                        <td class="wrap-plus-remove">
                            <button class="add-new"></button>
                            <button class="remove"></button>
                        </td>
                    </tr>
                </table>
            </tr>
		</table>
	</form>
</div>
