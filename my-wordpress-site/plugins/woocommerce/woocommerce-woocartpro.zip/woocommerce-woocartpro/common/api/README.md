
```php
FestiTeamApiClient::addInstallStatistics(PLUGIN_ID);
```