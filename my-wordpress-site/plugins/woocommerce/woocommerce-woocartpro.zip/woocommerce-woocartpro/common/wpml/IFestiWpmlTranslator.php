<?php

interface IFestiWpmlTranslator
{
    public function getWpmlPrefix();
    public function getTranslateList();
}
