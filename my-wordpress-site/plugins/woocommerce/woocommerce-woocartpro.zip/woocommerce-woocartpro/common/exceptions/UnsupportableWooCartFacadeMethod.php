<?php

class UnsupportableWooCartFacadeMethod extends Exception
{
}