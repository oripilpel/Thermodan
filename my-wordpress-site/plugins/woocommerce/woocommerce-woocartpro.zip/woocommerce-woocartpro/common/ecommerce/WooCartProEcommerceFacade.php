<?php

abstract class WooCartProEcommerceFacade implements IWooCartProEcommerceFacade
{
}
