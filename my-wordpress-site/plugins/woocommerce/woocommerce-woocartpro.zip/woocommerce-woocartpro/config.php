<?php
/* widget */
define('WOOCARTPRO_CART_WIDGET_ID', 'WooCartFestiWidget');
define('WOOCARTPRO_CROSS_SELL_ITEMS_PER_PAGE', 3);
define('WOOCARTPRO_CROSS_SELL_COLUMNS', 3);
define('WOOCARTPRO_PLUGIN_ID', 2);

define(
    'WOOCARTPRO_FILTER_POPUP_COUNT_ITEM_PRODUCT',
    'woocartpro_popup_count_item_product'
);
define(
    'WOOCARTPRO_FILTER_POPUP_REMOVE_ITEM_PRODUCT',
    'woocartpro_popup_remove_item_product'
);
define(
    'WOOCARTPRO_FILTER_POPUP_HIDE_ITEM_PRODUCT',
    'woocartpro_popup_hide_item_product'
);
