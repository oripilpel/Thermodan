<?php
/*
Plugin Name: WooCommerce Deposits
Plugin URI: https://www.webtomizer.com/
Description: Adds deposits support to WooCommerce.
Version: 2.1.5
Author: Webtomizer
Author URI: https://www.webtomizer.com/
Text Domain: woocommerce-deposits
Domain Path: /locale

Copyright: © 2017, Webtomizer.
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if( ! defined( 'ABSPATH' ) ){
	exit;
}

require_once( 'includes/wc-deposits-functions.php' );

if( wc_deposits_woocommerce_is_active() ) :
	
	/**
	 * @brief Main WC_Deposits class
	 *
	 */
	class WC_Deposits{
		
		// Components
		public $cart;
		public $add_to_cart;
		public $orders;
		public $emails;
		public $checkout;
		public $gateways;
		public $admin_product;
		public $admin_order;
		public $admin_settings;
		public $admin_reports;
		public $admin_notices;
		public $checkout_mode;
		
		/**
		 * @brief Returns the global instance
		 *
		 * @param array $GLOBALS ...
		 * @return mixed
		 */
		public static function &get_singleton(){
			if( ! isset( $GLOBALS[ 'wc_deposits' ] ) )
				$GLOBALS[ 'wc_deposits' ] = new WC_Deposits();
			
			
			return $GLOBALS[ 'wc_deposits' ];
		}
		
		/**
		 * @brief Constructor
		 *
		 * @return void
		 */
		private function __construct(){
			$this->checkout_mode = get_option( 'wc_deposits_checkout_mode_enabled' ) === 'yes';
			define( 'WC_DEPOSITS_VERSION' , '2.1.5' );
			define( 'WC_DEPOSITS_TEMPLATE_PATH' , untrailingslashit( plugin_dir_path( __FILE__ ) ) . '/templates/' );
			define( 'WC_DEPOSITS_PLUGIN_PATH' , plugin_dir_path( basename( plugin_dir_path( __FILE__ ) ) , basename( __FILE__ ) ) );
			define( 'WC_DEPOSITS_PLUGIN_URL' , untrailingslashit( plugins_url( basename( plugin_dir_path( __FILE__ ) ) , basename( __FILE__ ) ) ) );
			define( 'WC_DEPOSITS_MAIN_FILE' , __FILE__ );
			
			add_action( 'init' , array( $this , 'load_plugin_textdomain' ) );
			add_action( 'init' , array( $this , 'register_order_status' ) );
			add_action( 'woocommerce_init' , array( $this , 'early_includes' ) );
			add_action( 'woocommerce_loaded' , array( $this , 'includes' ) );
			add_action( 'admin_enqueue_scripts' , array( $this , 'enqueue_admin_scripts_and_styles' ) );
			add_action( 'wp_enqueue_scripts' , array( $this , 'enqueue_styles' ) );
			add_action( 'wp_ajax_wc_deposits_update_outdated_orders' , array( $this , 'update_outdated_orders' ) );
			
			//bookings related
			//      add_filter('woocommerce_bookings_for_user_statuses',array($this,'booking_partially_paid_status'));
			
			
			if( is_admin() ){
				add_action( 'admin_notices' , array( $this , 'show_admin_notices' ) );
				$this->admin_includes();
			}
			
		}
		
		
		/**
		 * @brief Localisation
		 *
		 * @return void
		 */
		public function load_plugin_textdomain(){
			load_plugin_textdomain( 'woocommerce-deposits' , false , dirname( plugin_basename( __FILE__ ) ) . '/locale/' );
		}
		
		/**
		 * @brief Enqueues front-end styles
		 *
		 * @return void
		 */
		public function enqueue_styles(){
			if( ! $this->is_disabled() ){
				wp_enqueue_style( 'toggle-switch' , plugins_url( 'assets/css/toggle-switch.css' , __FILE__ ) , array() , '3.0' , 'screen' );
				wp_enqueue_style( 'wc-deposits-frontend-styles' , plugins_url( 'assets/css/style.css' , __FILE__ ) );
				
				if(is_cart() || is_checkout()){
					$suffix       = defined( 'SCRIPT_DEBUG' ) && SCRIPT_DEBUG ? '' : '.min';
					wp_register_script( 'jquery-tiptip', WC()->plugin_url() . '/assets/js/jquery-tiptip/jquery.tipTip' . $suffix . '.js', array( 'jquery' ), WC_VERSION, true );
					wp_enqueue_script( 'wc-deposits-cart' , WC_DEPOSITS_PLUGIN_URL . '/assets/js/wc-deposits-cart.js' , array( 'jquery' ) , '' , true );
					wp_enqueue_script('jquery-tiptip');
				}
				
			}
		}
		
		/**
		 * @brief Early includes
		 *
		 * @since 1.3
		 *
		 * @return void
		 */
		public function early_includes(){
			
			
			$wc_3 = version_compare( get_option( 'woocommerce_version' , null ) , '3.0.0' , '>=' );
			
			if( $wc_3 ){
				
				include( 'includes/class-wc-deposits-emails.php' );
				$this->emails = new WC_Deposits_Emails( $this );
				
			} else{
				include( 'includes/class-wc-deposits-legacy-emails.php' );
				$this->emails = new WC_Deposits_Legacy_Emails( $this );
				
			}
			
		}
		
		/**
		 * @brief Load classes
		 *
		 * @return void
		 */
		public function includes(){
			
			$wc_3 = version_compare( get_option( 'woocommerce_version' , null ) , '3.0.0' , '>=' );
			
			if( ! $this->is_disabled() ){
				
				if( $wc_3 ){
					include( 'includes/class-wc-deposits-cart.php' );
					include( 'includes/class-wc-deposits-checkout.php' );
					
					$this->cart = new WC_Deposits_Cart( $this );
					$this->checkout = new WC_Deposits_Checkout( $this );
					
					if( ! $this->checkout_mode ){
						include( 'includes/class-wc-deposits-add-to-cart.php' );
						$this->add_to_cart = new WC_Deposits_Add_To_Cart( $this );
						
					}
				} else{
					
					include( 'includes/class-wc-deposits-legacy-cart.php' );
					include( 'includes/class-wc-deposits-legacy-checkout.php' );
					include( 'includes/class-wc-deposits-legacy-add-to-cart.php' );
					
					$this->cart = new WC_Deposits_Legacy_Cart( $this );
					$this->checkout = new WC_Deposits_Legacy_Checkout( $this );
					$this->add_to_cart = new WC_Deposits_Legacy_Add_To_Cart( $this );
				}
				
			}
   
			if( $wc_3 ){
				include( 'includes/class-wc-deposits-orders.php' );
				$this->orders = new WC_Deposits_Orders( $this );
				include( 'includes/class-wc-deposits-gateways.php' );
				$this->gateways = new WC_Deposits_Gateways( $this );
				
			} else{
				include( 'includes/class-wc-deposits-legacy-orders.php' );
				$this->orders = new WC_Deposits_Legacy_Orders( $this );
				include( 'includes/class-wc-deposits-legacy-gateways.php' );
				$this->gateways = new WC_Deposits_Legacy_Gateways( $this );
				
			}
			
		}
		

		/**
		 * @brief Load admin includes
		 *
		 * @return void
		 */
		public function admin_includes(){
			
			
			$this->admin_notices = array();
			$wc_3 = version_compare( get_option( 'woocommerce_version' , null ) , '3.0.0' , '>=' );
			
			if( $wc_3){
				include( 'includes/admin/class-wc-deposits-admin-settings.php' );
				include( 'includes/admin/class-wc-deposits-admin-order.php' );
				
				$this->admin_settings = new WC_Deposits_Admin_Settings( $this );
				$this->admin_order = new WC_Deposits_Admin_Order( $this );
				
				if( ! $this->checkout_mode ){
					
					include( 'includes/admin/class-wc-deposits-admin-product.php' );
					$this->admin_product = new WC_Deposits_Admin_Product( $this );
				}
				
				
			} else{
				include( 'includes/admin/class-wc-deposits-legacy-admin-settings.php' );
				include( 'includes/admin/class-wc-deposits-legacy-admin-product.php' );
				include( 'includes/admin/class-wc-deposits-legacy-admin-order.php' );
				
				$this->admin_settings = new WC_Deposits_Legacy_Admin_Settings( $this );
				$this->admin_product = new WC_Deposits_Legacy_Admin_Product( $this );
				$this->admin_order = new WC_Deposits_Legacy_Admin_Order( $this );
				
			}
			
			
			add_filter( 'woocommerce_admin_reports' , array( $this , 'admin_reports' ) );
		}
		
		/**
		 * @param $reports
		 * @return mixed
		 */
		public function admin_reports( $reports ){
			if( ! $this->admin_reports ){
				$admin_reports = include( 'includes/admin/class-wc-deposits-admin-reports.php' );
				$this->admin_reports = $admin_reports;
			}
			return $this->admin_reports->admin_reports( $reports );
		}
		
		/**
		 * @brief Load admin scripts and styles
		 * @return void
		 */
		public function enqueue_admin_scripts_and_styles(){
			wp_enqueue_script( 'jquery' );
			wp_enqueue_style( 'wc-deposits-frontend-style' , plugins_url( 'assets/css/admin-style.css' , __FILE__ ) );
		}
		
		/**
		 * @brief Display all buffered admin notices
		 *
		 * @return void
		 */
		public function show_admin_notices(){
			foreach( $this->admin_notices as $notice ){
				?>
                <div class='<?php echo esc_attr( $notice[ 'type' ] ); ?>'>
                    <p><?php _e( $notice[ 'content' ] , 'woocommerce-deposits' ); ?></p></div>
				<?php
			}
		}
		
		/**
		 * @brief Add a new notice
		 *
		 * @param $content Notice contents
		 * @param $type Notice class
		 *
		 * @return void
		 */
		public function enqueue_admin_notice( $content , $type ){
			array_push( $this->admin_notices , array( 'content' => $content , 'type' => $type ) );
		}
		
		/**
		 * @return bool
		 */
		public function is_disabled(){
			return get_option( 'wc_deposits_site_wide_disable' ) === 'yes';
		}
		
		
		/**
		 * @brief Register a custom order status
		 *
		 * @since 1.3
		 *
		 * @return void
		 */
		public function register_order_status(){
			
			register_post_status( 'wc-partially-paid' , array(
				'label' => _x( 'Partially Paid' , 'Order status' , 'woocommerce-deposits' ) ,
				'public' => true ,
				'exclude_from_search' => false ,
				'show_in_admin_all_list' => true ,
				'show_in_admin_status_list' => true ,
				'label_count' => _n_noop( 'Partially Paid <span class="count">(%s)</span>' ,
					'Partially Paid <span class="count">(%s)</span>' , 'woocommerce-deposits' )
			) );
			
		}
		
		
		/**
		 * @since : 2.0
		 * @desc : allows users to update orders created with previous versions of Woocommerce Deposit
		 */
		public function update_outdated_orders(){
			
			
			//do query
			$posts = get_posts( array(
				'post_type' => 'shop_order' ,
				'posts_per_page' => 10000 ,
				'post_status' => array( 'wc-pending' , 'wc-on-hold' , 'wc-partially-paid' , 'wc-processing' , 'wc-completed' )
			
			) );
			$nonce = $_POST[ 'nonce' ];
			if( ! wp_verify_nonce( $nonce , 'woocommerce-settings' ) ){
				
				wp_send_json_error( 'authentication failed' );
				wp_die();
			}
			$wc_3 = version_compare( get_option( 'woocommerce_version' , null ) , '3.0.0' , '>=' );
			
			if( ! empty( $posts ) ){
				
				foreach( $posts as $post ){
					$order_id = $post->ID;
					$order = new WC_Order( $order_id );
					$status = $order->get_status();
					
					if( ! empty( $order->wc_deposits_remaining ) ){
						
						$deposit = $order->get_total();
						$second_payment = floatval( $order->wc_deposits_remaining );
						$total = $deposit + $second_payment;
						
						
						switch( $status ){
							case 'pending':
								
								if( $wc_3 ){
									
									$order->update_meta_data( '_wc_deposits_order_has_deposit' , 'yes' );
									$order->update_meta_data( '_wc_deposits_deposit_paid' , 'no' );
									$order->update_meta_data( '_wc_deposits_second_payment_paid' , 'no' );
									$order->update_meta_data( '_wc_deposits_deposit_amount' , $deposit );
									$order->update_meta_data( '_wc_deposits_second_payment' , $second_payment );
									$order->update_meta_data( '_wc_deposits_original_total' , $total );
									$order->set_total( $deposit );
									$order->save();
									
								} else{
									
									update_post_meta( $order_id , '_wc_deposits_order_has_deposit' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'no' );
									update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'no' );
									update_post_meta( $order_id , '_wc_deposits_deposit_amount' , $deposit );
									update_post_meta( $order_id , '_wc_deposits_second_payment' , $second_payment );
									update_post_meta( $order_id , '_wc_deposits_original_total' , $total );
									$order->set_total( $deposit );
									
								}
								
								delete_post_meta( $order_id , '_wc_deposits_remaining' );
								delete_post_meta( $order_id , '_wc_deposits_remaining_paid' );
								
								break;
							case 'partially-paid':
								
								
								if( $wc_3 ){
									
									$order->update_meta_data( '_wc_deposits_order_has_deposit' , 'yes' );
									$order->update_meta_data( '_wc_deposits_deposit_paid' , 'yes' );
									$order->update_meta_data( '_wc_deposits_second_payment_paid' , 'no' );
									$order->update_meta_data( '_wc_deposits_deposit_amount' , $deposit );
									$order->update_meta_data( '_wc_deposits_second_payment' , $second_payment );
									$order->update_meta_data( '_wc_deposits_original_total' , $total );
									$order->set_total( $second_payment );
									$order->save();
									
								} else{
									
									update_post_meta( $order_id , '_wc_deposits_order_has_deposit' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'no' );
									update_post_meta( $order_id , '_wc_deposits_deposit_amount' , $deposit );
									update_post_meta( $order_id , '_wc_deposits_second_payment' , $second_payment );
									update_post_meta( $order_id , '_wc_deposits_original_total' , $total );
									$order->set_total( $second_payment );
									
								}
								
								delete_post_meta( $order_id , '_wc_deposits_remaining' );
								delete_post_meta( $order_id , '_wc_deposits_remaining_paid' );
								
								break;
							case 'on-hold':
								
								if( $wc_3 ){
									
									$order->update_meta_data( '_wc_deposits_order_has_deposit' , 'yes' );
									$order->update_meta_data( '_wc_deposits_deposit_paid' , 'yes' );
									$order->update_meta_data( '_wc_deposits_second_payment_paid' , 'no' );
									$order->update_meta_data( '_wc_deposits_deposit_amount' , $deposit );
									$order->update_meta_data( '_wc_deposits_second_payment' , $second_payment );
									$order->update_meta_data( '_wc_deposits_original_total' , $total );
									$order->save_meta_data();
									$order->set_total( $second_payment );
									$order->save();
									
								} else{
									
									
									update_post_meta( $order_id , '_wc_deposits_order_has_deposit' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'no' );
									update_post_meta( $order_id , '_wc_deposits_deposit_amount' , $deposit );
									update_post_meta( $order_id , '_wc_deposits_second_payment' , $second_payment );
									update_post_meta( $order_id , '_wc_deposits_original_total' , $total );
									$order->set_total( $second_payment );
									
								}
								
								delete_post_meta( $order_id , '_wc_deposits_remaining' );
								delete_post_meta( $order_id , '_wc_deposits_remaining_paid' );
								
								break;
							case 'processing':
								
								if( $wc_3 ){
									
									$order->update_meta_data( '_wc_deposits_order_has_deposit' , 'yes' );
									$order->update_meta_data( '_wc_deposits_deposit_paid' , 'yes' );
									$order->update_meta_data( '_wc_deposits_second_payment_paid' , 'yes' );
									$order->update_meta_data( '_wc_deposits_deposit_amount' , $deposit );
									$order->update_meta_data( '_wc_deposits_second_payment' , $second_payment );
									$order->update_meta_data( '_wc_deposits_original_total' , $total );
									$order->set_total( $total );
									$order->save();
									
								} else{
									
									
									update_post_meta( $order_id , '_wc_deposits_order_has_deposit' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_deposit_amount' , $deposit );
									update_post_meta( $order_id , '_wc_deposits_second_payment' , $second_payment );
									update_post_meta( $order_id , '_wc_deposits_original_total' , $total );
									$order->set_total( $total );
									
								}
								
								delete_post_meta( $order_id , '_wc_deposits_remaining' );
								delete_post_meta( $order_id , '_wc_deposits_remaining_paid' );
								
								break;
							case 'completed':
								
								
								if( $wc_3 ){
									
									$order->update_meta_data( '_wc_deposits_order_has_deposit' , 'yes' );
									$order->update_meta_data( '_wc_deposits_deposit_paid' , 'yes' );
									$order->update_meta_data( '_wc_deposits_second_payment_paid' , 'yes' );
									$order->update_meta_data( '_wc_deposits_deposit_amount' , $deposit );
									$order->update_meta_data( '_wc_deposits_second_payment' , $second_payment );
									$order->update_meta_data( '_wc_deposits_original_total' , $total );
									$order->set_total( $total );
									$order->save();
									
								} else{
									
									
									update_post_meta( $order_id , '_wc_deposits_order_has_deposit' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'yes' );
									update_post_meta( $order_id , '_wc_deposits_deposit_amount' , $deposit );
									update_post_meta( $order_id , '_wc_deposits_second_payment' , $second_payment );
									update_post_meta( $order_id , '_wc_deposits_original_total' , $total );
									$order->set_total( $total );
									
								}
								
								delete_post_meta( $order_id , '_wc_deposits_remaining' );
								delete_post_meta( $order_id , '_wc_deposits_remaining_paid' );
								
								
								break;
							
							default :
								break;
						}
					}
				}
				
			}
			wp_send_json_success( array( 'success' => 'yes' ) );
			wp_die();
		}
		
		public static function plugin_activated(){
			
			if( ! wp_next_scheduled( 'woocommerce_deposits_second_payment_reminder' ) ){
				wp_schedule_event( time() , 'twicedaily' , 'woocommerce_deposits_second_payment_reminder' );
			}
		}
		
		public static function plugin_deactivated(){
			wp_clear_scheduled_hook( 'woocommerce_deposits_second_payment_reminder' );
			
		}
		
	}
	
	// Install the singleton instance
	WC_Deposits::get_singleton();
	register_activation_hook( __FILE__ , array( 'WC_Deposits' , 'plugin_activated' ) );
	register_deactivation_hook( __FILE__ , array( 'WC_Deposits' , 'plugin_deactivated' ) );


endif;
