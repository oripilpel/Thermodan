<?php

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly
}

echo $email_heading . "\n\n";

echo __("Kindly be reminded that your order's second payment is still pending payment", 'woocommerce-deposits') . "\n\n";

if ($order->has_status('partially-paid') && get_option('wc_deposits_remaining_payable', 'yes') === 'yes') {
    echo sprintf(__('To pay the remaining balance, please visit this link: %s', 'woocommerce-deposits'), $order->get_checkout_payment_url()) . "\n\n";
}

echo "****************************************************\n\n";

do_action('woocommerce_email_before_order_table', $order, $sent_to_admin, $plain_text);

echo sprintf(__('Order number: %s', 'woocommerce-deposits'), $order->get_order_number()) . "\n";
echo sprintf(__('Order date: %s', 'woocommerce-deposits'), date_i18n(wc_date_format(), strtotime($order->get_date_created()))) . "\n";

do_action('woocommerce_email_order_meta', $order, $sent_to_admin, $plain_text);

echo wc_get_email_order_items($order);


echo "----------\n\n";

if ($totals = $order->get_order_item_totals()) {
    foreach ($totals as $total) {
        echo $total['label'] . "\t " . $total['value'] . "\n";
    }
}

echo "\n****************************************************\n\n";

do_action('woocommerce_email_after_order_table', $order, $sent_to_admin, $plain_text);

do_action('woocommerce_email_customer_details', $order, $sent_to_admin, $plain_text);

echo "\n****************************************************\n\n";

echo apply_filters('woocommerce_email_footer_text', get_option('woocommerce_email_footer_text'));
