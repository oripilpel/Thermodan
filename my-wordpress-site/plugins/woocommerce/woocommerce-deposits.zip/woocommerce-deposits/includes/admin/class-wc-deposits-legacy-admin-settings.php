<?php

if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}

/**
 * @brief Adds a new panel to the WooCommerce Settings
 *
 */
class WC_Deposits_Legacy_Admin_Settings{
	public $wc_deposits;
	
	public function __construct( &$wc_deposits ){
		$this->wc_deposits = $wc_deposits;
		// Hook the settings page
		add_filter( 'woocommerce_settings_tabs_array' , array( $this , 'settings_tabs_array' ) , 21 );
		add_action( 'woocommerce_settings_wc-deposits' , array( $this , 'settings_tabs_wc_deposits' ) );
		add_action( 'woocommerce_update_options_wc-deposits' , array( $this , 'update_options_wc_deposits' ) );
		add_action( 'woocommerce_admin_field_update_deposit_orders' , array( $this , 'update_outdated_orders' ) );
		add_action( 'woocommerce_admin_field_deposit_buttons_color' , array( $this , 'deposit_buttons_color' ) );
		add_action( 'admin_enqueue_scripts' , array( $this , 'enqueue_settings_script' ) );
	}
	
	
	public function enqueue_settings_script( $hook ){
		
		if( $hook === 'woocommerce_page_wc-settings' && isset( $_GET[ 'tab' ] ) && $_GET[ 'tab' ] === 'wc-deposits' )
			
			wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wc-deposits-admin-settings' , WC_DEPOSITS_PLUGIN_URL . '/assets/js/admin/admin-settings.js' , array( 'jquery' , 'wp-color-picker' ) );
		wp_localize_script( 'wc-deposits-admin-settings' , 'wc_deposits' , array(
			'ajax_url' => admin_url( 'admin-ajax.php' ) ,
			'strings' => array(
				'success' => __( 'Upadated successfully' , 'woocommerce-deposits' )
			)
		
		) );
	}
	
	public function update_outdated_orders(){
		
		?>
        <table class="form-table" xmlns="http://www.w3.org/1999/html">

            <tr valign="top" class="">
                <th scope="row" class="titledesc"><?php _e( 'Update Outdated Orders' , 'woocommerce-deposits' ); ?></th>
                <td class="forminp ">
                    <fieldset id="wc_deposits_update_outdated_orders_container">
                        <label for="wc_deposits_update_outdated_orders">
                            <button name="wc_deposits_update_outdated_orders" id="wc_deposits_update_outdated_orders"
                                    class="button button-primary"><?php _e( 'Update Outdated Orders' , 'woocommerce-deposits' ); ?></button>
                            <p><?php _e( 'if there are orders created using a previous version of Woocommerce Deposits(1.0 ~ 1.6), an update for these orders is required to display correctly' ); ?></p>

                        </label></fieldset>
                </td>
            </tr>


        </table>
        <div>

        </div>
		
		<?php
		
	}
	
	
	public function deposit_buttons_color(){
		
		$colors = get_option( 'wc_deposits_deposit_buttons_colors' );
		$primary_color = $colors[ 'primary' ];
		$secondary_color = $colors[ 'secondary' ];
		$highlight_color = $colors[ 'highlight' ];;
		
		?>
        <tr valign="top" class="">
            <th scope="row"
                class="titledesc"><?php _e( 'Deposit Buttons Primary Colour' , 'woocommerce-deposits' ); ?></th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <input type="text" name="wc_deposits_deposit_buttons_colors_primary" class="deposits-color-field"
                           value="<?php echo $primary_color; ?>">
                </fieldset>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row"
                class="titledesc"><?php _e( 'Deposit Buttons Secondary Colour' , 'woocommerce-deposits' ); ?></th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <input type="text" name="wc_deposits_deposit_buttons_colors_secondary" class="deposits-color-field"
                           value="<?php echo $secondary_color; ?>">
                </fieldset>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row"
                class="titledesc"><?php _e( 'Deposit Buttons Highlight Colour' , 'woocommerce-deposits' ); ?></th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <input type="text" name="wc_deposits_deposit_buttons_colors_highlight" class="deposits-color-field"
                           value="<?php echo $highlight_color; ?>">
                </fieldset>
            </td>
        </tr>
		<?php
	}
	
	public function settings_tabs_array( $tabs ){
		$tabs[ 'wc-deposits' ] = __( 'Deposits' , 'woocommerce-deposits' );
		return $tabs;
	}
	
	/**
	 * @brief Write out settings html
	 *
	 * @param array $settings ...
	 * @return void
	 */
	public function settings_tabs_wc_deposits(){
		$settings = array(
			
			/*
			 * Site-wide settings
			 */
			
			'sitewide_title' => array(
				'name' => __( 'Site-wide Settings' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => '' ,
				'id' => 'wc_deposits_site_wide_title'
			) ,
			'deposits_disable' => array(
				'name' => __( 'Disable Deposits' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Check this to disable all deposit functionality with one click.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_site_wide_disable' ,
			) ,
			
			'deposits_default' => array(
				'name' => __( 'Default Selection' , 'woocommerce-deposits' ) ,
				'type' => 'radio' ,
				'desc' => __( 'Select the default deposit option.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_default_option' ,
				'options' => array(
					'deposit' => __( 'Pay Deposit' , 'woocommerce-deposits' ) ,
					'full' => __( 'Full Amount' , 'woocommerce-deposits' )
				) ,
				'default' => 'deposit'
			) ,
			'deposits_tax' => array(
				'name' => __( 'Display Taxes' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Check this to count taxes as part of deposits for purposes of display to the customer. (Taxes are always collected upfront)' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_tax_display' ,
			) ,
			'taxes_handling' => array(
				'name' => __( 'Taxes Collection Method' , 'woocommerce-deposits' ) ,
				'type' => 'select' ,
				'desc' => __( 'Choose how to handle taxes.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_taxes_handling' ,
				'options' => array(
					'deposit' => __( 'Collect Taxes with deposit' , 'woocommerce-deposits' ) ,
					'full' => __( 'Collect Taxes with second payment' , 'woocommerce-deposits' )
				)
			) ,
			'shipping_handling' => array(
				'name' => __( 'Shipping Handling Method' , 'woocommerce-deposits' ) ,
				'type' => 'select' ,
				'desc' => __( 'Choose how to handle shipping.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_shipping_handling' ,
				'options' => array(
					'deposit' => __( 'Collect Shipping fees with deposit' , 'woocommerce-deposits' ) ,
					'full' => __( 'Collect Shipping fees with second payment' , 'woocommerce-deposits' )
				)
			) ,
			'deposits_stock' => array(
				'name' => __( 'Reduce Stocks On' , 'woocommerce-deposits' ) ,
				'type' => 'radio' ,
				'desc' => __( 'Choose when to reduce stocks.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_reduce_stock' ,
				'options' => array(
					'deposit' => __( 'Deposit Payment' , 'woocommerce-deposits' ) ,
					'full' => __( 'Full Payment' , 'woocommerce-deposits' )
				) ,
				'default' => 'full'
			) ,
			'deposits_payaple' => array(
				'name' => __( 'Enable Second Payment' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Uncheck this to prevent the customer from making the second payment. (You\'ll have to manually mark the order as completed)' ,
					'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_remaining_payable' ,
				'default' => 'yes' ,
			) ,
			'sitewide_end' => array(
				'type' => 'sectionend' ,
				'id' => 'wc_deposits_site_wide_end'
			) ,
			
			/*
			 * Section for buttons
			 */
			
			'buttons_title' => array(
				'name' => __( 'Buttons' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => __( 'No HTML allowed. Text will be translated to the user if a translation is available.<br/>Please note that any overflow will be hidden, since button width is theme-dependent.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_buttons_title'
			) ,
			'basic_radio_buttons' => array(
				'name' => __( 'Use Basic Deposit Buttons' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Use basic radio buttons for deposits, Check this if you are facing issues with deposits slider buttons in product page, ' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_use_basic_radio_buttons' ,
				'default' => 'no' ,
			) ,
			'buttons_color' => array(
				'type' => 'deposit_buttons_color' ,
				'class' => 'deposit_buttons_color_html' ,
			) ,
			'deposits_button_deposit' => array(
				'name' => __( 'Deposit Button Text' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text displayed in the \'Pay Deposit\' button.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_button_deposit' ,
				'default' => 'Pay Deposit'
			) ,
			'deposits_button_full' => array(
				'name' => __( 'Full Amount Button Text' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text displayed in the \'Full Amount\' button.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_button_full_amount' ,
				'default' => 'Full Amount'
			) ,
			'buttons_end' => array(
				'type' => 'sectionend' ,
				'id' => 'wc_deposits_buttons_end'
			) ,
			
			/*
			 * Section for messages
			 */
			
			'messages_title' => array(
				'name' => __( 'Messages' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => __( 'Please check the documentation for allowed HTML tags.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_messages_title'
			) ,
			'deposits_message_deposit' => array(
				'name' => __( 'Deposit Message' , 'woocommerce-deposits' ) ,
				'type' => 'textarea' ,
				'desc' => __( 'Message to show when \'Pay Deposit\' is selected on the product\'s page.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_message_deposit' ,
			) ,
			'deposits_message_full' => array(
				'name' => __( 'Full Amount Message' , 'woocommerce-deposits' ) ,
				'type' => 'textarea' ,
				'desc' => __( 'Message to show when \'Full Amount\' is selected on the product\'s page.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_message_full_amount' ,
			) ,
			'messages_end' => array(
				'type' => 'sectionend' ,
				'id' => 'wc_deposits_messages_end'
			) ,
			'update_orders' => array(
				'type' => 'update_deposit_orders' ,
				'class' => 'update_deposit_orders_html' ,
			) ,
			'enhanced_gateway_compatibility' => array(
				'name' => __( 'Enhanced Gateway Compatiblity' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => __( 'Settings that can enhance compatibility for specific gateways that are incompatible' , 'woocommerce-deposits' ) ,
				'id' => 'enhanced_gateway_compatibility_title'
			) ,
			'enable_product_calculation_filter' => array(
				'name' => __( 'Enable product calculation filter (experimental)' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'enable product-based calculation filter function for better compatibility with gateways which calculate total amount by accessing order products directly' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_enable_product_calculation_filter' ,
				'default' => 'no' ,
			) ,
			'enhanced_gateway_compatibility_sectionend' => array(
				'type' => 'sectionend' ,
			) ,
		);
		
		woocommerce_admin_fields( $settings );
		
		/*
		 * Allowed gateways
		 */
		
		$gateways_settings = array();
		
		$gateways_settings[ 'gateways_title' ] = array(
			'name' => __( 'Disallowed Gateways' , 'woocommerce-deposits' ) ,
			'type' => 'title' ,
			'desc' => __( 'Disallow the following gateways when there is a deposit in the cart.' , 'woocommerce-deposits' ) ,
			'id' => 'wc_deposits_gateways_title'
		);
		
		$gateways = WC()->payment_gateways()->payment_gateways();
		
		$group = 'start';
		
		foreach( $gateways as $key => $gateway ){
			if( $key === 'wc-booking-gateway' ) // Protect the wc-booking-gateway
				continue;
			$title = $gateway->get_title();
			$gateways_settings[ 'gateway_' . $key ] = array(
				'name' => __( 'Disallowed For Deposits' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => $title ,
				'id' => 'wc_deposits_disabled_gateways[' . $key . ']' ,
				'checkboxgroup' => $group ,
			);
			$group = 'wc_deposits_disabled_gateways';
		}
		
		$gateways_settings[ 'gateways_end' ] = array(
			'type' => 'sectionend' ,
			'id' => 'wc_deposits_gateways_end'
		);
		
		woocommerce_admin_fields( $gateways_settings );
	}
	
	/**
	 * @brief Save all settings on POST
	 *
	 * @return void
	 */
	public function update_options_wc_deposits(){
		$allowed_html = array(
			'a' => array( 'href' => true , 'title' => true ) ,
			'br' => array() , 'em' => array() ,
			'strong' => array() , 'p' => array() ,
			's' => array() , 'strike' => array() ,
			'del' => array() , 'u' => array()
		);
		
		
		$sitewide_disable = isset( $_POST[ 'wc_deposits_site_wide_disable' ] ) ? 'yes' : 'no';
		$default_option = isset( $_POST[ 'wc_deposits_default_option' ] ) ?
			( $_POST[ 'wc_deposits_default_option' ] === 'deposit' ? 'deposit' : 'full' ) : 'deposit';
		$reduce_stock = isset( $_POST[ 'wc_deposits_reduce_stock' ] ) ?
			( $_POST[ 'wc_deposits_reduce_stock' ] === 'deposit' ? 'deposit' : 'full' ) : 'full';
		$display_tax = isset( $_POST[ 'wc_deposits_tax_display' ] ) ? 'yes' : 'no';
		$basic_radio_buttons = isset( $_POST[ 'wc_deposits_use_basic_radio_buttons' ] ) ? 'yes' : 'no';
		
		$colors = array(
			
			'primary' => $_POST[ 'wc_deposits_deposit_buttons_colors_primary' ] ? $_POST[ 'wc_deposits_deposit_buttons_colors_primary' ] : false ,
			'secondary' => $_POST[ 'wc_deposits_deposit_buttons_colors_secondary' ] ? $_POST[ 'wc_deposits_deposit_buttons_colors_secondary' ] : false ,
			'highlight' => $_POST[ 'wc_deposits_deposit_buttons_colors_highlight' ] ? $_POST[ 'wc_deposits_deposit_buttons_colors_highlight' ] : false
        );
		
		$tax_handling = isset( $_POST[ 'wc_deposits_taxes_handling' ] ) && $_POST[ 'wc_deposits_taxes_handling' ] === 'deposit' ? 'deposit' : 'full';
		$shipping_handling = isset( $_POST[ 'wc_deposits_shipping_handling' ] ) && $_POST[ 'wc_deposits_shipping_handling' ] === 'deposit' ? 'deposit' : 'full';
		$deposit_payble = isset( $_POST[ 'wc_deposits_remaining_payable' ] ) ? 'yes' : 'no';
		$button_deposit = isset( $_POST[ 'wc_deposits_button_deposit' ] ) ? esc_html( $_POST[ 'wc_deposits_button_deposit' ] ) : 'Pay Deposit';
		$button_full = isset( $_POST[ 'wc_deposits_button_full_amount' ] ) ? esc_html( $_POST[ 'wc_deposits_button_full_amount' ] ) : 'Full Amount';
		$message_deposit = isset( $_POST[ 'wc_deposits_message_deposit' ] ) ? wp_kses( $_POST[ 'wc_deposits_message_deposit' ] , $allowed_html ) : '';
		$message_full = isset( $_POST[ 'wc_deposits_message_full_amount' ] ) ? wp_kses( $_POST[ 'wc_deposits_message_full_amount' ] , $allowed_html ) : '';
		
		//gateway compatiblity options
		$product_calculation_filter = isset( $_POST[ 'wc_deposits_enable_product_calculation_filter' ] ) ? 'yes' : 'no';
		
		
		update_option( 'wc_deposits_site_wide_disable' , $sitewide_disable );
		update_option( 'wc_deposits_default_option' , $default_option );
		update_option( 'wc_deposits_tax_display' , $display_tax );
		update_option( 'wc_deposits_taxes_handling' , $tax_handling );
		update_option( 'wc_deposits_shipping_handling' , $shipping_handling );
		update_option( 'wc_deposits_remaining_payable' , $deposit_payble );
		update_option( 'wc_deposits_use_basic_radio_buttons' , $basic_radio_buttons );
		update_option( 'wc_deposits_deposit_buttons_colors' , $colors );
		update_option( 'wc_deposits_button_deposit' , $button_deposit ); // No need for addslashes(), esc_html() takes care of it.
		update_option( 'wc_deposits_button_full_amount' , $button_full ); // Likewise.
		update_option( 'wc_deposits_message_deposit' , $message_deposit ); // No need for addslashes(), wp_kses() takes care of it.
		update_option( 'wc_deposits_message_full_amount' , $message_full ); // Likewise.
		update_option( 'wc_deposits_reduce_stock' , $reduce_stock );
		update_option( 'wc_deposits_enable_product_calculation_filter' , $product_calculation_filter );
		
		$gateways_disabled = array();
		
		$gateways = WC()->payment_gateways()->payment_gateways();
		
		if( isset( $_POST[ 'wc_deposits_disabled_gateways' ] ) ){
			foreach( $gateways as $key => $gateway ){
				if( isset( $_POST[ 'wc_deposits_disabled_gateways' ][ $key ] ) &&
					( $_POST[ 'wc_deposits_disabled_gateways' ][ $key ] === 'yes' ||
						$_POST[ 'wc_deposits_disabled_gateways' ][ $key ] === '1' ||
						$_POST[ 'wc_deposits_disabled_gateways' ][ $key ] === 'on' ||
						$_POST[ 'wc_deposits_disabled_gateways' ][ $key ] === 'checked' )
				){
					$gateways_disabled[ $key ] = 'yes';
				} else{
					$gateways_disabled[ $key ] = 'no';
				}
			}
		}
		
		update_option( 'wc_deposits_disabled_gateways' , $gateways_disabled );
	}
	
}
