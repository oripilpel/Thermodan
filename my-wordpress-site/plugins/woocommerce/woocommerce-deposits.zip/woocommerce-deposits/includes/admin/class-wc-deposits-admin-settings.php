<?php

if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}

/**
 * @brief Adds a new panel to the WooCommerce Settings
 *
 */
class WC_Deposits_Admin_Settings{
	public $wc_deposits;
	
	public function __construct( &$wc_deposits ){
		$this->wc_deposits = $wc_deposits;
		// Hook the settings page
		add_filter( 'woocommerce_settings_tabs_array' , array( $this , 'settings_tabs_array' ) , 21 );
		add_action( 'woocommerce_settings_wc-deposits' , array( $this , 'settings_tabs_wc_deposits' ) );
		add_action( 'woocommerce_update_options_wc-deposits' , array( $this , 'update_options_wc_deposits' ) );
		add_action( 'woocommerce_admin_field_update_deposit_orders' , array( $this , 'update_outdated_orders' ) );
		add_action( 'woocommerce_admin_field_deposit_buttons_color' , array( $this , 'deposit_buttons_color' ) );
		add_action( 'admin_enqueue_scripts' , array( $this , 'enqueue_settings_script' ) );
	}
	
	
	public function enqueue_settings_script( $hook ){
		
		if( $hook === 'woocommerce_page_wc-settings' && isset( $_GET[ 'tab' ] ) && $_GET[ 'tab' ] === 'wc-deposits' )
			
			wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wc-deposits-admin-settings' , WC_DEPOSITS_PLUGIN_URL . '/assets/js/admin/admin-settings.js' , array( 'jquery' , 'wp-color-picker' ) );
		wp_localize_script( 'wc-deposits-admin-settings' , 'wc_deposits' , array(
			'ajax_url' => admin_url( 'admin-ajax.php' ) ,
			'strings' => array(
				'success' => __( 'Upadated successfully' , 'woocommerce-deposits' )
			)
		
		) );
	}
	
	public function update_outdated_orders(){
		
		?>
        <table class="form-table" xmlns="http://www.w3.org/1999/html">

            <tr valign="top" class="">
                <th scope="row" class="titledesc"><?php _e( 'Update Outdated Orders' , 'woocommerce-deposits' ); ?></th>
                <td class="forminp ">
                    <fieldset id="wc_deposits_update_outdated_orders_container">
                        <label for="wc_deposits_update_outdated_orders">
                            <button name="wc_deposits_update_outdated_orders" id="wc_deposits_update_outdated_orders"
                                    class="button button-primary"><?php _e( 'Update Outdated Orders' , 'woocommerce-deposits' ); ?></button>
                            <p><?php _e( 'if there are orders created using a previous version of Woocommerce Deposits(1.0 ~ 1.6), an update for these orders is required to display correctly' ); ?></p>

                        </label></fieldset>
                </td>
            </tr>


        </table>
        <div>

        </div>
		
		<?php
		
	}
	
	
	public function deposit_buttons_color(){
		
		$colors = get_option( 'wc_deposits_deposit_buttons_colors' );
		$primary_color = $colors[ 'primary' ];
		$secondary_color = $colors[ 'secondary' ];
		$highlight_color = $colors[ 'highlight' ];;
		
		?>
        <tr valign="top" class="">
            <th scope="row"
                class="titledesc"><?php _e( 'Deposit Buttons Primary Colour' , 'woocommerce-deposits' ); ?></th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <input type="text" name="wc_deposits_deposit_buttons_colors_primary" class="deposits-color-field"
                           value="<?php echo $primary_color; ?>">
                </fieldset>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row"
                class="titledesc"><?php _e( 'Deposit Buttons Secondary Colour' , 'woocommerce-deposits' ); ?></th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <input type="text" name="wc_deposits_deposit_buttons_colors_secondary" class="deposits-color-field"
                           value="<?php echo $secondary_color; ?>">
                </fieldset>
            </td>
        </tr>
        <tr valign="top" class="">
            <th scope="row"
                class="titledesc"><?php _e( 'Deposit Buttons Highlight Colour' , 'woocommerce-deposits' ); ?></th>
            <td class="forminp forminp-checkbox">
                <fieldset>
                    <input type="text" name="wc_deposits_deposit_buttons_colors_highlight" class="deposits-color-field"
                           value="<?php echo $highlight_color; ?>">
                </fieldset>
            </td>
        </tr>
		<?php
	}
	
	public function settings_tabs_array( $tabs ){
		$tabs[ 'wc-deposits' ] = __( 'Deposits' , 'woocommerce-deposits' );
		return $tabs;
	}
	
	/**
	 * @brief Write out settings html
	 *
	 * @param array $settings ...
	 * @return void
	 */
	public function settings_tabs_wc_deposits(){
		$settings = array(
			
			/*
			 * Site-wide settings
			 */
			
			'sitewide_title' => array(
				'name' => __( 'Site-wide Settings' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => '' ,
				'id' => 'wc_deposits_site_wide_title'
			) ,
			'deposits_disable' => array(
				'name' => __( 'Disable Deposits' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Check this to disable all deposit functionality with one click.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_site_wide_disable' ,
			) ,
			
			'deposits_default' => array(
				'name' => __( 'Default Selection' , 'woocommerce-deposits' ) ,
				'type' => 'radio' ,
				'desc' => __( 'Select the default deposit option.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_default_option' ,
				'options' => array(
					'deposit' => __( 'Pay Deposit' , 'woocommerce-deposits' ) ,
					'full' => __( 'Full Amount' , 'woocommerce-deposits' )
				) ,
				'default' => 'deposit'
			) ,
			'deposits_tax' => array(
				'name' => __( 'Display Taxes' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Check this to count taxes as part of deposits for purposes of display to the customer. (in product page & cart)' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_tax_display' ,
			) ,
			'deposits_breakdown_cart_tooltip' => array(
				'name' => __( 'Display Deposit-breakdown Tooltip in cart' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Check this to display a tooltip next to deposit in cart totals, this tooltip explains deposit cost breakdown)' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_breakdown_cart_tooltip' ,
			) ,
			'fees_handling' => array(
				'name' => __( 'Fees Collection Method' , 'woocommerce-deposits' ) ,
				'type' => 'select' ,
				'desc' => __( 'Choose how to handle fees.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_fees_handling' ,
				'options' => array(
					'deposit' => __( 'Collect Fees with deposit' , 'woocommerce-deposits' ) ,
					'full' => __( 'Collect Fees with second payment' , 'woocommerce-deposits' )
				)
			) , 'taxes_handling' => array(
				'name' => __( 'Taxes Collection Method' , 'woocommerce-deposits' ) ,
				'type' => 'select' ,
				'desc' => __( 'Choose how to handle taxes.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_taxes_handling' ,
				'options' => array(
					'deposit' => __( 'Collect Taxes with deposit' , 'woocommerce-deposits' ) ,
					'split' => __( 'Split taxes according to deposit amount' , 'woocommerce-deposits' ) ,
					'full' => __( 'Collect Taxes with second payment' , 'woocommerce-deposits' )
				)
			) ,
			'shipping_handling' => array(
				'name' => __( 'Shipping Handling Method' , 'woocommerce-deposits' ) ,
				'type' => 'select' ,
				'desc' => __( 'Choose how to handle shipping.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_shipping_handling' ,
				'options' => array(
					'deposit' => __( 'Collect Shipping fees with deposit' , 'woocommerce-deposits' ) ,
					'full' => __( 'Collect Shipping fees with second payment' , 'woocommerce-deposits' )
				)
			) ,
			'shipping_taxes_handling' => array(
				'name' => __( 'Shipping Taxes Handling Method' , 'woocommerce-deposits' ) ,
				'type' => 'select' ,
				'desc' => __( 'Choose how to handle shipping taxes.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_shipping_taxes_handling' ,
				'options' => array(
					'deposit' => __( 'Collect Shipping taxes with deposit' , 'woocommerce-deposits' ) ,
					'full' => __( 'Collect Shipping taxes with second payment' , 'woocommerce-deposits' )
				)
			) ,
			'deposits_stock' => array(
				'name' => __( 'Reduce Stocks On' , 'woocommerce-deposits' ) ,
				'type' => 'radio' ,
				'desc' => __( 'Choose when to reduce stocks.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_reduce_stock' ,
				'options' => array(
					'deposit' => __( 'Deposit Payment' , 'woocommerce-deposits' ) ,
					'full' => __( 'Full Payment' , 'woocommerce-deposits' )
				) ,
				'default' => 'full'
			) ,
			'deposits_payaple' => array(
				'name' => __( 'Enable Second Payment' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Uncheck this to prevent the customer from making the second payment. (You\'ll have to manually mark the order as completed)' ,
					'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_remaining_payable' ,
				'default' => 'yes' ,
			) ,
			'enable_second_payment_reminder' => array(
				'name' => __( 'Enable Second Payment Reminder' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Uncheck this to prevent sending second payment reminder email. (You can always send a reminder manually from order actions )' ,
					'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_enable_second_payment_reminder' ,
				'default' => 'no' ,
			) ,
			'second_payment_reminder_duration' => array(
				'name' => __( 'Days before Second Payment reminder ' , 'woocommerce-deposits' ) ,
				'type' => 'number' ,
				'desc' => __( 'Duration between partial payment and second payment reminder (in days)' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_second_payment_reminder_duration' ,
				'default' => '14'
			) ,
			'sitewide_end' => array(
				'type' => 'sectionend' ,
				'id' => 'wc_deposits_site_wide_end'
			) ,
			/*
			 *
			 * Section for Strings
			  */
			
			'strings_title' => array(
				'name' => __( 'Strings' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => __( 'No HTML allowed. Text will be translated to the user if a translation is available.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_strings_title'
			) ,
			'deposits_to_pay_text' => array(
				'name' => __( 'To Pay ' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "To Pay"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_to_pay_text' ,
				'default' => 'To Pay'
			) ,
            'deposits_second_payment_text' => array(
				'name' => __( 'Second Payment' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Second Payment"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_second_payment_text' ,
				'default' => 'Second Payment'
			) ,
			'deposits_deposit_amount_text' => array(
				'name' => __( 'Deposit Amount' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Deposit Amount"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_deposit_amount_text' ,
				'default' => 'Deposit Amount'
			) ,
			'deposits_second_payment_amount_text' => array(
				'name' => __( 'Second Payment Amount' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Second Payment Amount"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_second_payment_amount_text' ,
				'default' => 'Second Payment Amount'
			) ,
            'deposits_deposit_option_text' => array(
				'name' => __( 'Deposit Option' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Deposit Option"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_deposit_option_text' ,
				'default' => 'Deposit Option'
			) ,
            'deposits_payment_status_text' => array(
				'name' => __( 'Payment Status' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Payment Status"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_payment_status_text' ,
				'default' => 'Payment Status'
			) ,
            'deposits_deposit_pending_payment_text' => array(
				'name' => __( 'Deposit Pending Payment' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Deposit Pending Payment"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_deposit_pending_payment_text' ,
				'default' => 'Deposit Pending Payment'
			) ,
            'deposits_deposit_paid_text' => array(
				'name' => __( 'Deposit Paid' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Deposit Paid"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_deposit_paid_text' ,
				'default' => 'Deposit Deposit Paid'
			) ,
            'deposits_order_fully_paid_text' => array(
				'name' => __( 'Order Fully Paid' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Order Fully Paid"' , 'woocommerce-deposits' ) ,
	            'id' => 'wc_deposits_order_fully_paid_text' ,
				'default' => 'Order Fully Paid'
			) ,
			 'deposits_deposit_previously_paid_text' => array(
				'name' => __( 'Deposit Previously Paid' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text to replace "Deposit Previously Paid"' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_deposit_previously_paid_text' ,
				'default' => 'Deposit Previously Paid'
			) ,
			
			'strings_end' => array(
				'type' => 'sectionend' ,
				'id' => 'wc_deposits_strings_end'
			) ,
			
			/*
			 * Section for buttons
			 */
			
			'buttons_title' => array(
				'name' => __( 'Buttons' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => __( 'No HTML allowed. Text will be translated to the user if a translation is available.<br/>Please note that any overflow will be hidden, since button width is theme-dependent.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_buttons_title'
			) ,

			'basic_radio_buttons' => array(
				'name' => __( 'Use Basic Deposit Buttons' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Use basic radio buttons for deposits, Check this if you are facing issues with deposits slider buttons in product page, ' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_use_basic_radio_buttons' ,
				'default' => 'no' ,
			) ,
			'buttons_color' => array(
				'type' => 'deposit_buttons_color' ,
				'class' => 'deposit_buttons_color_html' ,
			) ,
			'deposits_button_deposit' => array(
				'name' => __( 'Deposit Button Text' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text displayed in the \'Pay Deposit\' button.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_button_deposit' ,
				'default' => 'Pay Deposit'
			) ,
			'deposits_button_full' => array(
				'name' => __( 'Full Amount Button Text' , 'woocommerce-deposits' ) ,
				'type' => 'text' ,
				'desc' => __( 'Text displayed in the \'Full Amount\' button.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_button_full_amount' ,
				'default' => 'Full Amount'
			) ,
			'buttons_end' => array(
				'type' => 'sectionend' ,
				'id' => 'wc_deposits_buttons_end'
			) ,
			
			/*
			 * Section for messages
			 */
			
			'messages_title' => array(
				'name' => __( 'Messages' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => __( 'Please check the documentation for allowed HTML tags.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_messages_title'
			) ,
			'deposits_message_deposit' => array(
				'name' => __( 'Deposit Message' , 'woocommerce-deposits' ) ,
				'type' => 'textarea' ,
				'desc' => __( 'Message to show when \'Pay Deposit\' is selected on the product\'s page.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_message_deposit' ,
			) ,
			'deposits_message_full' => array(
				'name' => __( 'Full Amount Message' , 'woocommerce-deposits' ) ,
				'type' => 'textarea' ,
				'desc' => __( 'Message to show when \'Full Amount\' is selected on the product\'s page.' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_message_full_amount' ,
			) ,
			'messages_end' => array(
				'type' => 'sectionend' ,
				'id' => 'wc_deposits_messages_end'
			) ,
			
			
			/*
             * Section for checkout mode
             */
                    	
			'checkout_mode_title' => array(
				'name' => __( 'Deposit on Checkout Mode' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => __( 'changes the way deposits work to be based on total amount at checkout button' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_messages_title'
			),
			'enable_checkout_mode' => array(
				'name' => __( 'Enable checkout mode' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'Check this to enable checkout mode, which makes deposits calculate based on total amount during checkout instead of per product' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_checkout_mode_enabled' ,
			),
			'checkout_mode_amount_deposit_amount' => array(
				'name' => __( 'Deposit amount ' , 'woocommerce-deposits' ) ,
				'type' => 'number' ,
				'desc' => __( 'Amount of deposit ( should not be more than 99 for percentage or more than order total for fixed' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_checkout_mode_deposit_amount' ,
				'default' => '14'
			) ,
			'checkout_mode_amount_type' => array(
				'name' => __( 'Amount Type' , 'woocommerce-deposits' ) ,
				'type' => 'radio' ,
				'desc' => __( 'Choose amount type' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_checkout_mode_deposit_amount_type' ,
				'options' => array(
					'fixed' => __( 'Fixed' , 'woocommerce-deposits' ) ,
					'percentage' => __( 'Percentage' , 'woocommerce-deposits' )
				) ,
				'default' => 'percentage'
			),
			'checkout_mode_end' => array(
				'type' => 'sectionend' ,
				'id' => 'wc_deposits_checkout_mode_end'
			) ,
			'update_orders' => array(
				'type' => 'update_deposit_orders' ,
				'class' => 'update_deposit_orders_html' ,
			) ,
			'enhanced_gateway_compatibility' => array(
				'name' => __( 'Enhanced Gateway Compatiblity' , 'woocommerce-deposits' ) ,
				'type' => 'title' ,
				'desc' => __( 'Settings that can enhance compatibility for specific gateways that are incompatible' , 'woocommerce-deposits' ) ,
				'id' => 'enhanced_gateway_compatibility_title'
			) ,
			'enable_product_calculation_filter' => array(
				'name' => __( 'Enable product calculation filter (experimental)' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => __( 'enable product-based calculation filter function for better compatibility with gateways which calculate total amount by accessing order products directly' , 'woocommerce-deposits' ) ,
				'id' => 'wc_deposits_enable_product_calculation_filter' ,
				'default' => 'no' ,
			) ,
			'enhanced_gateway_compatibility_sectionend' => array(
				'type' => 'sectionend' ,
			) ,
		);
		
		woocommerce_admin_fields( $settings );
		
		/*
		 * Allowed gateways
		 */
		
		$gateways_settings = array();
		
		$gateways_settings[ 'gateways_title' ] = array(
			'name' => __( 'Disallowed Gateways' , 'woocommerce-deposits' ) ,
			'type' => 'title' ,
			'desc' => __( 'Disallow the following gateways when there is a deposit in the cart.' , 'woocommerce-deposits' ) ,
			'id' => 'wc_deposits_gateways_title'
		);
		
		$gateways = WC()->payment_gateways()->payment_gateways();
		
		$group = 'start';
		
		foreach( $gateways as $key => $gateway ){
			if( $key === 'wc-booking-gateway' ) // Protect the wc-booking-gateway
				continue;
			$title = $gateway->get_title();
			$gateways_settings[ 'gateway_' . $key ] = array(
				'name' => __( 'Disallowed For Deposits' , 'woocommerce-deposits' ) ,
				'type' => 'checkbox' ,
				'desc' => $title ,
				'id' => 'wc_deposits_disabled_gateways[' . $key . ']' ,
				'checkboxgroup' => $group ,
			);
			$group = 'wc_deposits_disabled_gateways';
		}
		
		$gateways_settings[ 'gateways_end' ] = array(
			'type' => 'sectionend' ,
			'id' => 'wc_deposits_gateways_end'
		);
		
		woocommerce_admin_fields( $gateways_settings );
	}
	
	/**
	 * @brief Save all settings on POST
	 *
	 * @return void
	 */
	public function update_options_wc_deposits(){
		$allowed_html = array(
			'a' => array( 'href' => true , 'title' => true ) ,
			'br' => array() , 'em' => array() ,
			'strong' => array() , 'p' => array() ,
			's' => array() , 'strike' => array() ,
			'del' => array() , 'u' => array()
		);
		
		$settings = array();
		
				
						
        $settings ['wc_deposits_site_wide_disable'] = isset( $_POST[ 'wc_deposits_site_wide_disable' ] ) ? 'yes' : 'no';
		
		$settings['wc_deposits_default_option'] =  isset( $_POST[ 'wc_deposits_default_option' ] ) ?
			( $_POST[ 'wc_deposits_default_option' ] === 'deposit' ? 'deposit' : 'full' ) : 'deposit';
   
		$settings['wc_deposits_reduce_stock']  = isset( $_POST[ 'wc_deposits_reduce_stock' ] ) ?
			( $_POST[ 'wc_deposits_reduce_stock' ] === 'deposit' ? 'deposit' : 'full' ) : 'full';
		$settings['wc_deposits_tax_display']  = isset( $_POST[ 'wc_deposits_tax_display' ] ) ? 'yes' : 'no';
		$settings['wc_deposits_breakdown_cart_tooltip']  = isset( $_POST[ 'wc_deposits_breakdown_cart_tooltip' ] ) ? 'yes' : 'no';
		$settings['wc_deposits_use_basic_radio_buttons'] = isset( $_POST[ 'wc_deposits_use_basic_radio_buttons' ] ) ? 'yes' : 'no';
		
		//STRINGS
		$settings[ 'wc_deposits_to_pay_text' ] = isset( $_POST[ 'wc_deposits_to_pay_text' ] ) ? esc_html( $_POST[ 'wc_deposits_to_pay_text' ] ) : 'To Pay';
		$settings[ 'wc_deposits_second_payment_text' ] = isset( $_POST[ 'wc_deposits_second_payment_text' ] ) ? esc_html( $_POST[ 'wc_deposits_second_payment_text' ] ) : 'Second Payment';
		$settings[ 'wc_deposits_deposit_amount_text' ] = isset( $_POST[ 'wc_deposits_deposit_amount_text' ] ) ? esc_html( $_POST[ 'wc_deposits_deposit_amount_text' ] ) : 'Deposit Amount';
		$settings[ 'wc_deposits_second_payment_amount_text' ] = isset( $_POST[ 'wc_deposits_second_payment_amount_text' ] ) ? esc_html( $_POST[ 'wc_deposits_second_payment_amount_text' ] ) : 'Second Payment Amount';
		$settings[ 'wc_deposits_deposit_option_text' ] = isset( $_POST[ 'wc_deposits_deposit_option_text' ] ) ? esc_html( $_POST[ 'wc_deposits_deposit_option_text' ] ) : 'Deposit Option';
		$settings[ 'wc_deposits_payment_status_text' ] = isset( $_POST[ 'wc_deposits_payment_status_text' ] ) ? esc_html( $_POST[ 'wc_deposits_payment_status_text' ] ) : 'Payment Status';
		$settings[ 'wc_deposits_deposit_pending_payment_text' ] = isset( $_POST[ 'wc_deposits_deposit_pending_payment_text' ] ) ? esc_html( $_POST[ 'wc_deposits_deposit_pending_payment_text' ] ) : 'Deposit Pending Payment';
		$settings[ 'wc_deposits_deposit_paid_text' ] = isset( $_POST[ 'wc_deposits_deposit_paid_text' ] ) ? esc_html( $_POST[ 'wc_deposits_deposit_paid_text' ] ) : 'Deposit Paid';
		$settings[ 'wc_deposits_order_fully_paid_text' ] = isset( $_POST[ 'wc_deposits_order_fully_paid_text' ] ) ? esc_html( $_POST[ 'wc_deposits_order_fully_paid_text' ] ) : 'Order Fully Paid';
		$settings[ 'wc_deposits_deposit_previously_paid_text' ] = isset( $_POST[ 'wc_deposits_deposit_previously_paid_text' ] ) ? esc_html( $_POST[ 'wc_deposits_deposit_previously_paid_text' ] ) : 'Deposit Previously Paid';
  
		
		$settings['wc_deposits_deposit_buttons_colors'] = array(
			
			'primary' => isset($_POST[ 'wc_deposits_deposit_buttons_colors_primary' ]) ? $_POST[ 'wc_deposits_deposit_buttons_colors_primary' ] : false ,
			'secondary' => isset($_POST[ 'wc_deposits_deposit_buttons_colors_secondary' ]) ? $_POST[ 'wc_deposits_deposit_buttons_colors_secondary' ] : false ,
			'highlight' => isset($_POST[ 'wc_deposits_deposit_buttons_colors_highlight' ]) ? $_POST[ 'wc_deposits_deposit_buttons_colors_highlight' ] : false
        );
		
		$settings['wc_deposits_checkout_mode_enabled'] = isset( $_POST[ 'wc_deposits_checkout_mode_enabled' ] ) ? 'yes' : 'no';
		$settings['wc_deposits_checkout_mode_deposit_amount'] = isset( $_POST[ 'wc_deposits_checkout_mode_deposit_amount' ] ) ? $_POST[ 'wc_deposits_checkout_mode_deposit_amount' ]  : '0';
		$settings['wc_deposits_checkout_mode_deposit_amount_type'] = isset( $_POST[ 'wc_deposits_checkout_mode_deposit_amount_type' ] ) && $_POST[ 'wc_deposits_checkout_mode_deposit_amount_type' ] === 'fixed' ? 'fixed' : 'percentage';
		
		
		$settings['wc_deposits_fees_handling'] = isset( $_POST[ 'wc_deposits_fees_handling' ] ) && $_POST[ 'wc_deposits_fees_handling' ] === 'deposit' ? 'deposit' : 'full';
		$settings['wc_deposits_taxes_handling'] = isset( $_POST[ 'wc_deposits_taxes_handling' ] ) ? $_POST[ 'wc_deposits_taxes_handling' ] : 'full';
		$settings['wc_deposits_shipping_handling'] = isset( $_POST[ 'wc_deposits_shipping_handling' ] ) && $_POST[ 'wc_deposits_shipping_handling' ] === 'deposit' ? 'deposit' : 'full';
		$settings['wc_deposits_shipping_taxes_handling'] = isset( $_POST[ 'wc_deposits_shipping_taxes_handling' ] ) && $_POST[ 'wc_deposits_shipping_taxes_handling' ] === 'deposit' ? 'deposit' : 'full';
		$settings['wc_deposits_remaining_payable'] = isset( $_POST[ 'wc_deposits_remaining_payable' ] ) ? 'yes' : 'no';
		$settings[ 'wc_deposits_enable_second_payment_reminder' ] = isset( $_POST[ 'wc_deposits_enable_second_payment_reminder' ] ) ? 'yes' : 'no';
		$settings[ 'wc_deposits_second_payment_reminder_duration' ] = isset( $_POST[ 'wc_deposits_second_payment_reminder_duration' ] ) ? $_POST[ 'wc_deposits_second_payment_reminder_duration' ]  : '0';
		$settings[ 'wc_deposits_button_deposit' ] = isset( $_POST[ 'wc_deposits_button_deposit' ] ) ? esc_html( $_POST[ 'wc_deposits_button_deposit' ] ) : 'Pay Deposit';
		$settings[ 'wc_deposits_button_full_amount' ] = isset( $_POST[ 'wc_deposits_button_full_amount' ] ) ? esc_html( $_POST[ 'wc_deposits_button_full_amount' ] ) : 'Full Amount';
		$settings[ 'wc_deposits_message_deposit' ] = isset( $_POST[ 'wc_deposits_message_deposit' ] ) ? wp_kses( $_POST[ 'wc_deposits_message_deposit' ] , $allowed_html ) : '';
		$settings[ 'wc_deposits_message_full_amount' ] = isset( $_POST[ 'wc_deposits_message_full_amount' ] ) ? wp_kses( $_POST[ 'wc_deposits_message_full_amount' ] , $allowed_html ) : '';
		
		//gateway compatiblity options
		$settings[ 'wc_deposits_enable_product_calculation_filter' ] = isset( $_POST[ 'wc_deposits_enable_product_calculation_filter' ] ) ? 'yes' : 'no';
		
		foreach ($settings as $key => $setting){
			update_option( $key , $setting );
			
		}
		

		$gateways_disabled = array();
		
		$gateways = WC()->payment_gateways()->payment_gateways();
		
		if( isset( $_POST[ 'wc_deposits_disabled_gateways' ] ) ){
			foreach( $gateways as $key => $gateway ){
				if( isset( $_POST[ 'wc_deposits_disabled_gateways' ][ $key ] ) &&
					( $_POST[ 'wc_deposits_disabled_gateways' ][ $key ] === 'yes' ||
						$_POST[ 'wc_deposits_disabled_gateways' ][ $key ] === '1' ||
						$_POST[ 'wc_deposits_disabled_gateways' ][ $key ] === 'on' ||
						$_POST[ 'wc_deposits_disabled_gateways' ][ $key ] === 'checked' )
				){
					$gateways_disabled[ $key ] = 'yes';
				} else{
					$gateways_disabled[ $key ] = 'no';
				}
			}
		}
		
		update_option( 'wc_deposits_disabled_gateways' , $gateways_disabled );
	}
	
}
