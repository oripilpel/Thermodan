<?php
/*Copyright: © 2017 Webtomizer.
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}

/**
 * @brief Adds UI elements to the order editor in the admin area
 *
 */
class WC_Deposits_Legacy_Admin_Order{
	public function __construct( &$wc_deposits ){
		// Hook the order admin page
		add_action( 'woocommerce_admin_order_item_headers' , array( $this , 'admin_order_item_headers' ) );
		add_action( 'woocommerce_admin_order_totals_after_total' , array( $this , 'admin_order_totals_after_total' ) );
		add_action( 'woocommerce_admin_order_item_values' , array( $this , 'admin_order_item_values' ) , 10 , 3 );
		add_action( 'woocommerce_saved_order_items' , array( $this , 'saved_order_items' ) , 10 , 2 );
		add_action( 'admin_enqueue_scripts' , array( $this , 'enqueue_scripts' ) );
		add_action( 'wp_ajax_wc_deposits_get_original_total' , array( $this , 'get_original_total' ) );
		add_action( 'woocommerce_admin_order_totals_after_total' , array( $this , 'update_original_total' ) );
	}
	
	function update_original_total(){
		$order_id = isset( $_POST[ 'order_id' ] ) ? $_POST[ 'order_id' ] : false;
		$order = wc_get_order( $order_id );
		
		$original_total = wc_format_localized_price( $order->wc_deposits_original_total );
		
		echo '<script> 
        jQuery(document).ready(function($){
            var original_total = ' . $original_total . '
            
            $(".wc-order-totals .edit input#_order_total").attr("value", original_total);

        });
        </script>';
		
	}
	
	function enqueue_scripts(){
		
		
		$is_order_editor = false;
		
		if( function_exists( 'get_current_screen' ) ){
			$screen = get_current_screen();
			if( $screen )
				$is_order_editor = $screen->id === 'shop_order';
		}
		
		if( $is_order_editor ){
			
			$order_id = isset( $_GET[ 'post' ] ) && ! empty( $_GET[ 'post' ] ) ? $_GET[ 'post' ] : false;
			$order = $order_id ? wc_get_order( $order_id ) : false;
			$original_total = $order ? wc_format_localized_price( $order->wc_deposits_original_total ) : null;
			
			
			wp_enqueue_script( 'jquery.bind-first' , WC_DEPOSITS_PLUGIN_URL . '/assets/js/jquery.bind-first-0.2.3.min.js' );
			wp_enqueue_script( 'wc-deposits-admin-orders' , WC_DEPOSITS_PLUGIN_URL . '/assets/js/admin/admin-orders.js' );
			wp_localize_script( 'wc-deposits-admin-orders' , 'wc_deposits_data' ,
				array( 'decimal_separator' => wc_get_price_decimal_separator() ,
					'thousand_separator' => wc_get_price_thousand_separator() ,
					'number_of_decimals' => wc_get_price_decimals() ,
					'currency_symbol' => get_woocommerce_currency_symbol() ,
					'original_total' => $original_total ,
					'order_id' => $order_id
				) );
		}
	}
	
	public function admin_order_item_headers(){
		?>
        <th class="deposit-paid"><?php _e( 'Deposit' , 'woocommerce-deposits' ); ?></th>
        <th class="deposit-remaining"><?php _e( 'Second Payment' , 'woocommerce-deposits' ); ?></th>
		<?php
	}
	
	public function admin_order_item_values( $product , $item , $item_id ){
		global $post;
		$order = $post ? wc_get_order( $post->ID ) : null;
		$item_meta = array();
		$paid = '';
		$remaining = '';
		$price_args = array();
		if( $order ){
			$price_args = array( 'currency' , $order->get_order_currency() );
		}
		if( $product && isset( $item[ 'wc_deposit_meta' ] ) ){
			$item_meta = maybe_unserialize( $item[ 'wc_deposit_meta' ] );
			if( is_array( $item_meta ) && isset( $item_meta[ 'deposit' ] ) )
				$paid = $item_meta[ 'deposit' ];
			if( is_array( $item_meta ) && isset( $item_meta[ 'remaining' ] ) )
				$remaining = $item_meta[ 'remaining' ];
		}
		?>
        <td class="deposit-paid" width="1%">
            <div class="view">
				<?php
				if( $paid )
					echo wc_price( $paid , $price_args );
				?>
            </div>
			<?php if( $product ){ ?>
                <div class="edit" style="display: none;">
                    <input type="text" name="deposit_paid[<?php echo absint( $item_id ); ?>]"
                           placeholder="<?php echo wc_format_localized_price( 0 ); ?>" value="<?php echo $paid; ?>"
                           class="deposit_paid wc_input_price" data-total="<?php echo $paid; ?>"/>
                </div>
			<?php } ?>
        </td>
        <td class="deposit-remaining" width="1%">
            <div class="view">
				<?php
				if( $remaining )
					echo wc_price( $remaining , $price_args );
				?>
            </div>
			<?php if( $product ){ ?>
                <div class="edit" style="display: none;">
                    <input type="text" name="deposit_remaining[<?php echo absint( $item_id ); ?>]"
                           placeholder="<?php echo wc_format_localized_price( 0 ); ?>" value="<?php echo $remaining; ?>"
                           class="deposit_remaining wc_input_price" data-total="<?php echo $remaining; ?>"/>
                </div>
			<?php } ?>
        </td>
		<?php
	}
	
	public function admin_order_totals_after_total( $order_id ){
		$order = wc_get_order( $order_id );
		$deposit = get_post_meta( $order_id , '_wc_deposits_deposit_amount' , true );
		$second_payment = get_post_meta( $order_id , '_wc_deposits_second_payment' , true );
		
		?>
        <tr>
            <td class="label"><?php _e( 'Deposit' , 'woocommerce-deposits' ); ?>:</td>
            <td>
				<?php if( $order->is_editable() ) : ?>
                    <div class="wc-order-edit-line-item-actions"><a class="edit-order-item" href="#"></a>
                    </div><?php endif; ?>
            </td>
            <td class="paid">
                <div
                        class="view"><?php echo wc_price( $deposit , array( 'currency' => $order->get_order_currency() ) ); ?></div>
                <div class="edit" style="display: none;">
                    <input type="text" class="wc_input_price" id="_order_paid" name="_order_paid"
                           placeholder="<?php echo wc_format_localized_price( 0 ); ?>"
                           value="<?php echo ( isset( $deposit ) ) ? esc_attr( wc_format_localized_price( $deposit ) ) : ''; ?>"/>
                    <div class="clear"></div>
                </div>
            </td>

        </tr>
        <tr>
            <td class="label"><?php _e( 'Second Payment' , 'woocommerce-deposits' ); ?>:</td>
            <td>
            </td>
            <td class="remaining">
                <div
                        class="view"><?php echo wc_price( $second_payment , array( 'currency' => $order->get_order_currency() ) ); ?></div>
                <div class="edit" style="display: none;">
                    <input type="text" class="wc_input_price" id="_order_remaining" name="_order_remaining"
                           placeholder="<?php echo wc_format_localized_price( 0 ); ?>"
                           value="<?php echo ( isset( $second_payment ) ) ? esc_attr( wc_format_localized_price( $second_payment ) ) : ''; ?>"/>
                    <div class="clear"></div>
                </div>
            </td>
        </tr>
		<?php
	}
	
	public function saved_order_items( $order_id , $items ){
		if( isset( $items[ 'order_item_id' ] ) ){
			$deposit_paid = isset( $items[ 'deposit_paid' ] ) ? $items[ 'deposit_paid' ] : array();
			$deposit_remaining = isset( $items[ 'deposit_remaining' ] ) ? $items[ 'deposit_remaining' ] : array();
			foreach( $items[ 'order_item_id' ] as $item_id ){
				$meta = array();
				$paid = isset( $deposit_paid[ $item_id ] ) ? floatval( $deposit_paid[ $item_id ] ) : null;
				$total = wc_get_order_item_meta( $item_id , '_line_total' );
				if( $paid !== null && floatval( $paid ) >= 0 && floatval( $paid ) <= floatval( $total ) ){
					$meta[ 'deposit' ] = floatval( $paid );
					$meta[ 'remaining' ] = floatval( $total ) - floatval( $paid );
				}
				if( $paid !== null && $paid > 0 ){
					$meta[ 'enable' ] = 'yes';
				} else{
					$meta[ 'enable' ] = 'no';
				}
				wc_update_order_item_meta( $item_id , 'wc_deposit_meta' , $meta );
			}
		}
		
		
		$order = wc_get_order( $order_id );
		$deposit_amount = floatval( wc_format_decimal( $order->wc_deposits_deposit_amount ) );
		$new_original_total = floatval( wc_format_decimal( $items[ '_order_total' ] ) );
		
		update_post_meta( $order_id , '_wc_deposits_original_total' , $new_original_total );
		
		
		if( isset( $items[ '_order_paid' ] ) ){
			$deposit_amount = floatval( $items[ '_order_paid' ] );
			if( $deposit_amount > 0 ){
				
				update_post_meta( $order_id , '_wc_deposits_order_has_deposit' , 'yes' );
				
				
			} else{
				update_post_meta( $order_id , '_wc_deposits_order_has_deposit' , 'no' );
			}
			
			$second_payment = $new_original_total - $deposit_amount;
			
			
			if( $deposit_amount > $new_original_total ){
				
				$deposit_amount = $new_original_total;
				$second_payment = 0;
			}
			
		}
		
		
		if( $order->wc_deposits_order_has_deposit === 'yes' ){
			
			$to_pay = 0;
			
			if( $order->wc_deposits_deposit_paid !== 'yes' ){
				$to_pay = $deposit_amount;
			}
			
			if( $order->wc_deposits_deposit_paid === 'yes' && $order->wc_deposits_second_payment_paid !== 'yes' ){
				$to_pay = $second_payment;
			}
			
			$order->set_total( wc_format_decimal( $to_pay ) );
		}
		
		update_post_meta( $order_id , '_wc_deposits_deposit_amount' , wc_format_decimal( $deposit_amount ) );
		update_post_meta( $order_id , '_wc_deposits_second_payment' , wc_format_decimal( $second_payment ) );
		
	}
}