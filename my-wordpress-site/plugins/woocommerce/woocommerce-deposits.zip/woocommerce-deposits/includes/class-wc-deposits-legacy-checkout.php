<?php
/*Copyright: Â© 2014 Abdullah Ali.
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}

class WC_Deposits_Legacy_Checkout{
	public $wc_deposits;
	public $checkout;
	
	public function __construct( &$wc_deposits ){
		$this->wc_deposits = $wc_deposits;
		
		add_action( 'woocommerce_review_order_after_order_total' , array( $this , 'review_order_after_order_total' ) );
		add_action( 'woocommerce_checkout_order_processed' , array( $this , 'checkout_order_processed' ) , 10 , 2 );
		
		// Hook the payments gateways filter to remove the ones we don't want
		add_filter( 'woocommerce_available_payment_gateways' , array( $this , 'available_payment_gateways' ) );
		//    add_filter('woocommerce_get_return_url',array($this,'return_url'),10,2);
		//    add_filter('woocommerce_get_checkout_order_received_url',array($this,'return_url'),10,2);
	}
	
	
	public function return_url( $return_url , $order ){
		//TODO : use return url query vars to enhance gateway compatiblity
		
		$query_strings = array();
		$status = $order->get_status();
		if( $order->id === $order->get_order_number() ){
			
			$query_strings[ 'second-payment-status' ] = 'success';
			$query_strings[ 'second-payment-id' ] = $order->get_order_number();
			
			$url_extension = http_build_query( $query_strings );
			$url = $return_url . '&' . $url_extension;
			
		} else{
			$url = $return_url;
		}
		
		
		return $url;
		
	}
	
	public function review_order_after_order_total( $order ){
		if( WC()->cart->deposit_enabled === true ) :
			
			?>

            <tr class="order-paid">
                <th><?php _e( 'To Pay' , 'woocommerce-deposits' ); ?></th>
                <td data-title="<?php _e( 'To Pay' , 'woocommerce-deposits' ); ?>">
					<?php $this->wc_deposits->cart->deposit_paid_html(); ?>
                </td>
            </tr>
            <tr class="order-remaining">
                <th><?php _e( 'Second Payment' , 'woocommerce-deposits' ); ?></th>
                <td data-title="<?php _e( 'Remaining Amount' , 'woocommerce-deposits' ); ?>">
					<?php $this->wc_deposits->cart->second_payment_html(); ?>
                </td>
            </tr>
			<?php
		endif;
	}
	
	/**
	 * @brief Updates the order metadata with deposit information
	 *
	 * @return void
	 */
	public function checkout_order_processed( $order_id ){
		$second_payment = WC()->cart->second_payment;
		$deposit_enabled = WC()->cart->deposit_enabled;
		
		if( $deposit_enabled === true && $second_payment > 0 ){
			
			$order = wc_get_order( $order_id );
			$order->set_total( WC()->cart->deposit_amount );
			
			
			update_post_meta( $order_id , '_wc_deposits_order_has_deposit' , 'yes' );
			update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'no' );
			update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'no' );
			update_post_meta( $order_id , '_wc_deposits_deposit_amount' , WC()->cart->deposit_amount );
			update_post_meta( $order_id , '_wc_deposits_second_payment' , $second_payment );
			update_post_meta( $order_id , '_wc_deposits_original_total' , WC()->cart->original_total );
		}
	}
	
	/**
	 * @brief Removes the unwanted gateways from the settings page when there's a deposit
	 *
	 * @return mixed
	 */
	public function available_payment_gateways( $gateways ){
		$has_deposit = false;
		
		$pay_slug = get_option( 'woocommerce_checkout_pay_endpoint' , 'order-pay' );
		$order_id = absint( get_query_var( $pay_slug ) );
		
		if( $order_id > 0 ){
			$order = wc_get_order( $order_id );
			if( $order ){
				$has_deposit = $order->has_status( 'partially-paid' );
			}
			if( ! $has_deposit ){
				$items = $order->get_items();
				foreach( $items as $item_key => $item ){
					if( isset( $item[ 'wc_deposit_meta' ] ) ){
						$meta = maybe_unserialize( $item[ 'wc_deposit_meta' ] );
						if( $meta && isset( $meta[ 'enable' ] ) && $meta[ 'enable' ] === 'yes' ){
							$has_deposit = true;
							break;
						}
					}
				}
			}
		} else{
			foreach( WC()->cart->cart_contents as $cart_item_key => $cart_item ){
				if( isset( $cart_item[ 'deposit' ] ) &&
					isset( $cart_item[ 'deposit' ][ 'enable' ] ) &&
					$cart_item[ 'deposit' ][ 'enable' ] === 'yes'
				){
					$has_deposit = true;
					break;
				}
			}
		}
		
		if( $has_deposit ){
			$disallowed_gateways = get_option( 'wc_deposits_disabled_gateways' );
			if( is_array( $disallowed_gateways ) ){
				foreach( $disallowed_gateways as $key => $value ){
					if( $value === 'yes' ){
						unset( $gateways[ $key ] );
					}
				}
			}
		}
		return $gateways;
	}
}