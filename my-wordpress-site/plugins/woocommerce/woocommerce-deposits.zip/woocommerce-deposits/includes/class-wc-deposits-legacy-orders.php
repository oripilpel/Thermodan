<?php
/*Copyright: Â© 2014 Abdullah Ali.
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}


class WC_Deposits_Legacy_Orders{
	public function __construct( &$wc_deposits ){
		// Payment complete events
		add_action( 'woocommerce_order_status_completed' , array( $this , 'order_status_completed' ) );
		add_action( 'woocommerce_pre_payment_complete' , array( $this , 'pre_payment_complete' ) );
		add_filter( 'woocommerce_payment_complete_reduce_order_stock' , array( $this , 'payment_complete_reduce_order_stock' ) , 10 , 2 );
		
		// Order statuses
		add_filter( 'wc_order_statuses' , array( $this , 'order_statuses' ) );
		add_filter( 'wc_order_is_editable' , array( $this , 'order_is_editable' ) , 10 , 2 );
		add_filter( 'woocommerce_payment_complete_order_status' , array( $this , 'payment_complete_order_status' ) , 10 , 2 );
		add_filter( 'woocommerce_valid_order_statuses_for_payment_complete' , array( $this , 'valid_order_statuses_for_payment_complete' ) , 10 , 2 );
		add_filter( 'woocommerce_order_has_status' , array( $this , 'order_has_status' ) , 10 , 3 );
		add_action( 'woocommerce_order_status_changed' , array( $this , 'order_status_changed' ) , 10 , 3 );
		add_filter( 'woocommerce_order_needs_payment' , array( $this , 'needs_payment' ) , 10 , 3 );
		
		
		//remove woocommerce order cancellation process and
		// replace it to prevent partially-paid orders from being cancelled if payment fails
		remove_action( 'wp_loaded' , array( 'WC_Form_Handler' , 'cancel_order' ) , 20 );
		add_action( 'wp_loaded' , array( $this , 'cancelled_order' ) , 10 );
		//  add_action('wp_loaded',array($this,'second_payment_query_var'));
		
		
		// Order handling
		add_action( 'woocommerce_add_order_item_meta' , array( $this , 'add_order_item_meta' ) , 10 , 3 );
		add_filter( 'woocommerce_get_order_item_totals' , array( $this , 'get_order_item_totals' ) , 10 , 2 );
		add_filter( 'woocommerce_order_formatted_line_subtotal' , array( $this , 'order_formatted_line_subtotal' ) , 10 , 3 );
		add_filter( 'woocommerce_get_formatted_order_total' , array( $this , 'get_formatted_order_total' ) , 10 , 2 );
		add_filter( 'woocommerce_order_amount_total_shipping' , array( $this , 'order_amount_total_shipping' ) , 10 , 2 );
		add_filter( 'woocommerce_order_get_shipping_tax' , array( $this , 'order_amount_shipping_tax' ) , 10 , 2 );
		add_filter( 'woocommerce_order_amount_order_discount' , array( $this , 'order_amount_order_discount' ) , 10 , 2 );
		add_filter( 'woocommerce_order_amount_cart_discount' , array( $this , 'order_amount_cart_discount' ) , 10 , 2 );
		add_filter( 'woocommerce_order_amount_item_subtotal' , array( $this , 'order_amount_item_subtotal' ) , 10 , 3 );
		add_filter( 'woocommerce_order_get_items' , array( $this , 'order_get_items' ) , 10 , 2 );
		add_filter( 'woocommerce_order_number' , array( $this , 'order_number' ) , 10 , 2 );
	}
	
	public function needs_payment( $needs_payment , $order , $valid_statuses ){
		
		$status = $order->get_status();
		if( $status === 'partially-paid' && get_option( 'wc_deposits_remaining_payable' , 'yes' ) === 'yes' ){
			$needs_payment = true;
		}
		return $needs_payment;
	}
	
	public function order_status_changed( $order_id , $old_status , $new_status ){
		$order = wc_get_order( $order_id );
		
		if( $order->wc_deposits_order_has_deposit === 'yes' ){
			
			
			$deposit_paid = $order->wc_deposits_deposit_paid;
			$second_payment = floatval( $order->wc_deposits_second_payment );
			
			//for cases of bank-transfer and some other gateways
			if( ( $new_status === 'partially-paid' ) && $deposit_paid !== 'yes' ){
				
				update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'yes' );
				$order->set_total( $second_payment );
				
				
			}
			
			//order marked processing /completed manually
			if( $old_status === 'partially-paid' && ( $new_status === 'processing' || $new_status === 'completed' ) && $deposit_paid === 'yes' ){
				
				
				update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'yes' );
				$order->set_total( $order->wc_deposits_original_total );
			}
		}
		
		
	}
	
	public function second_payment_query_var(){
		//TODO : use query vars to enhance gateway compatiblity
		if( isset( $_GET[ 'second-payment-id' ] ) && isset( $_GET[ 'second-payment-status' ] ) ){
			
			if( $_GET[ 'second-payment-status' ] === 'success' ){
				
				$order_id = $_GET[ 'second-payment-id' ];
				$wcdp = '-WCDP';
				if( strpos( $order_id , $wcdp ) === false ){
					
					$deposit_id = strstr( $order_id , $wcdp , true );
					$order = wc_get_order( $deposit_id );
					$order->payment_complete();
					
				}
				
				$order_number_check = $order->get_order_number();
				if( $order_id !== $order_number_check ){
					$correct_order_number = $order->get_order_number();
				}
				$correct_order = wc_get_order( $correct_order_number );
				$correct_order->payment_complete();
				
			}
		}
		
	}
	
	public function cancelled_order(){
		
		if( isset( $_GET[ 'cancel_order' ] ) && isset( $_GET[ 'order' ] ) && isset( $_GET[ 'order_id' ] ) ){
			$order_key = $_GET[ 'order' ];
			$order_id = absint( $_GET[ 'order_id' ] );
			$order = wc_get_order( $order_id );
			$user_can_cancel = current_user_can( 'cancel_order' , $order_id );
			$order_can_cancel = $order->has_status( apply_filters( 'woocommerce_valid_order_statuses_for_cancel' , array( 'pending' , 'failed' ) ) );
			$redirect = $_GET[ 'redirect' ];
			
			if( $order->has_status( 'cancelled' ) ){
				// Already cancelled - take no action
			} elseif( $user_can_cancel && $order_can_cancel && $order->id === $order_id && $order->order_key === $order_key ){
				
				if( $order->has_status( 'partially-paid' ) ){
					wp_safe_redirect( $order->get_checkout_payment_url() );
					return;
				}
				
				
				// Cancel the order + restore stock
				$order->cancel_order( __( 'Order cancelled by customer.' , 'woocommerce' ) );
				
				// Message
				wc_add_notice( apply_filters( 'woocommerce_order_cancelled_notice' , __( 'Your order was cancelled.' , 'woocommerce' ) ) , apply_filters( 'woocommerce_order_cancelled_notice_type' , 'notice' ) );
				
				do_action( 'woocommerce_cancelled_order' , $order->id );
				
			} elseif( $user_can_cancel && ! $order_can_cancel ){
				wc_add_notice( __( 'Your order can no longer be cancelled. Please contact us if you need assistance.' , 'woocommerce' ) , 'error' );
			} else{
				wc_add_notice( __( 'Invalid order.' , 'woocommerce' ) , 'error' );
			}
			
			if( $redirect ){
				wp_safe_redirect( $redirect );
				exit;
			}
		}
	}
	
	public function order_status_completed( $order_id ){
		$order = wc_get_order( $order_id );
		
		if( isset( $order->wc_deposits_second_payment ) && $order->wc_deposits_second_payment > 0 ){
			update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'yes' );
			$order->set_total( $order->wc_deposits_original_total );
			
			
		}
	}
	
	public function pre_payment_complete( $order_id ){
		
		$order = wc_get_order( $order_id );
		$status = $order->get_status();
		
		
		if( ( $order->wc_deposits_order_has_deposit === 'yes' && $order->wc_deposits_deposit_paid !== 'yes' ) ){
			
			$second_payment = $order->wc_deposits_second_payment;
			$order->set_total( $second_payment );
			update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'yes' );
		}
		
		if( $status === 'partially-paid' && $order->wc_deposits_second_payment_paid !== 'yes' ){
			
			update_post_meta( $order_id , '_wc_deposits_deposit_paid' , 'yes' );
			update_post_meta( $order_id , '_wc_deposits_second_payment_paid' , 'yes' );
			$order->set_total( $order->wc_deposits_original_total );
		}
		
	}
	
	public function payment_complete_reduce_order_stock( $reduce , $order_id ){
		$order = wc_get_order( $order_id );
		$order_has_deposit = $order->get_meta( '_wc_deposits_order_has_deposit' , true ) === 'yes';
		
		if($order_has_deposit){
			
			
			$status = $order->get_status();
			$reduce_on = get_option( 'wc_deposits_reduce_stock' , 'full' );
			
			if( $status === 'partially-paid' && $reduce_on === 'full' ){
				$reduce = false;
			} elseif( $status === 'processing' && $reduce_on === 'deposit' ){
				$reduce = false;
			}
			
		}
	}
	
	public function payment_complete_order_status( $new_status , $order_id ){
		$order = wc_get_order( $order_id );
		$status = $order->get_status();
		
		
		if( $status !== 'partially-paid' ){
			$second_payment = $order->wc_deposits_second_payment;
			$second_payment_paid = $order->wc_deposits_second_payment_paid;
			
			
			if( $second_payment > 0 && $second_payment_paid !== 'yes' ){
				$new_status = 'partially-paid';
			}
		}
		
		return $new_status;
	}
	
	public function order_is_editable( $editable , $order ){
		if( $order->has_status( 'partially-paid' ) ){
			$editable = false;
		}
		return $editable;
	}
	
	
	public function valid_order_statuses_for_payment_complete( $statuses , $order ){
		if( get_option( 'wc_deposits_remaining_payable' , 'yes' ) === 'yes' ){
			$statuses[] = 'partially-paid';
		}
		return $statuses;
	}
	
	/**
	 * @brief Add the new 'Deposit paid' status to orders
	 *
	 * @return array
	 */
	public function order_statuses( $order_statuses ){
		$new_statuses = array();
		// Place the new status after 'Pending payment'
		foreach( $order_statuses as $key => $value ){
			$new_statuses[ $key ] = $value;
			if( $key === 'wc-pending' ){
				$new_statuses[ 'wc-partially-paid' ] = _x( 'Partially Paid' , 'Order status' , 'woocommerce-deposits' );
			}
		}
		return $new_statuses;
	}
	
	public function order_has_status( $has_status , $order , $status ){
		if( $order->get_status() === 'partially-paid' ){
			if( is_array( $status ) ){
				if( in_array( 'pending' , $status ) ){
					$has_status = true;
				}
			} else{
				if( $status === 'pending' ){
					$has_status = true;
				}
			}
		}
		return $has_status;
	}
	
	public function add_order_item_meta( $item_id , $values , $cart_item_key ){
		$cart_item = WC()->cart->cart_contents[ $cart_item_key ];
		if( is_array( $cart_item ) && isset( $cart_item[ 'deposit' ] ) ){
			wc_add_order_item_meta( $item_id , '_wc_deposit_meta' , $cart_item[ 'deposit' ] );
		}
	}
	
	public function get_order_item_totals( $total_rows , $order ){
		
		if( $order->wc_deposits_order_has_deposit === 'yes' ) :
			
			$order_total = $order->wc_deposits_original_total;
			$status = $order->get_status();
			$deposit_amount = floatval( $order->wc_deposits_deposit_amount );
			$deposit_paid = $order->wc_deposits_deposit_paid;
			$second_payment = floatval( $order->wc_deposits_second_payment );
			$second_payment_paid = $order->wc_deposits_second_payment_paid;
			
			$is_checkout = false;
			$received_slug = get_option( 'woocommerce_checkout_order_received_endpoint' , 'order-received' );
			$pay_slug = get_option( 'woocommerce_checkout_order_pay_endpoint' , 'order-pay' );
			
			$is_checkout = ( get_query_var( $received_slug ) === '' && is_checkout() );
			$is_paying_remaining = ! ! get_query_var( $pay_slug ) && $status === 'partially-paid';
			
			
			$total_rows[ 'order_total' ] = array(
				'label' => __( 'Order Total:' , 'woocommerce-deposits' ) ,
				'value' => wc_price( $order_total , array( 'currency' => $order->get_order_currency() ) )
			);
			
			if( ! $is_checkout ){
				
				$total_rows[ 'deposit_amount' ] = array(
					'label' => __( 'Deposit Amount:' , 'woocommerce-deposits' ) ,
					'value' => wc_price( $deposit_amount , array( 'currency' => $order->get_order_currency() ) )
				);
				
				$total_rows[ 'second_payment' ] = array(
					'label' => __( 'Second Payment Amount:' , 'woocommerce-deposits' ) ,
					'value' => wc_price( $second_payment , array( 'currency' => $order->get_order_currency() ) )
				);
				
				
			}
			
			if( $is_checkout && ! $is_paying_remaining ){
				
				$total_rows[ 'paid_today' ] = array(
					'label' => __( 'To Pay:' , 'woocommerce-deposits' ) ,
					'value' => wc_price( $order->get_total() , array( 'currency' => $order->get_order_currency() ) )
				);
				
				
			}
			
			if( $is_checkout && $is_paying_remaining ){
				
				$total_rows[ 'deposit_amount' ] = array(
					'label' => __( 'Deposit Previously Paid:' , 'woocommerce-deposits' ) ,
					'value' => wc_price( $deposit_amount , array( 'currency' => $order->get_order_currency() ) )
				);
				
				$total_rows[ 'paid_today' ] = array(
					'label' => __( 'To Pay:' , 'woocommerce-deposits' ) ,
					'value' => wc_price( $order->get_total() , array( 'currency' => $order->get_order_currency() ) )
				);
			}
			
			
			if( is_account_page() ){
				$payment_status = '';
				if( $deposit_paid !== 'yes' )
					$payment_status = __( 'Deposit Pending Payment' , 'woocommerce-deposits' );
				if( $deposit_paid === 'yes' )
					$payment_status = __( 'Deposit Paid' , 'woocommerce-deposits' );
				if( $deposit_paid === 'yes' && $second_payment_paid === 'yes' )
					$payment_status = __( 'Order Fully Paid' , 'woocommerce-deposits' );
				$total_rows[ 'payment_status' ] = array(
					'label' => __( 'Payment status:' , 'woocommerce-deposits' ) ,
					'value' => __( $payment_status , 'woocommerce-deposits' )
				);
			}
		
		
		endif;
		return $total_rows;
	}
	
	
	public function order_formatted_line_subtotal( $subtotal , $item , $order ){
		if( $order->wc_deposits_order_has_deposit === 'yes' ) :
			
			if( isset( $item[ 'wc_deposit_meta' ] ) ){
				$deposit_meta = maybe_unserialize( $item[ 'wc_deposit_meta' ] );
			} else{
				return $subtotal;
			}
			
			if( is_array( $deposit_meta ) && isset( $deposit_meta[ 'enable' ] ) && $deposit_meta[ 'enable' ] === 'yes' ){
				$tax = get_option( 'wc_deposits_tax_display' , 'no' ) === 'yes' ? floatval( $item[ 'line_tax' ] ) : 0;
				$deposit = $deposit_meta[ 'deposit' ] + $tax;
				
				return $subtotal . '<br/>(' .
					wc_price( $deposit , array( 'currency' => $order->get_order_currency() ) ) . ' ' . __( 'Deposit' , 'woocommerce-deposits' ) . ')';
			} else{
				return $subtotal;
			}
		endif;
	}
	
	public function get_formatted_order_total( $total , $order ){
		if( $order->wc_deposits_order_has_deposit === 'yes' ) :
			
			$deposit_amount = $order->wc_deposits_deposit_amount;
			
			{
				$total = wc_price( floatval( $order->wc_deposits_original_total ) , array( 'currency' => $order->get_order_currency() ) );
				
				if( $order->get_status() == 'partially-paid' ){
					$total = sprintf( __( '%s' , 'woocommerce-deposits' ) , $total );
				}
				
			}
		endif;
		return $total;
	}
	
	public function order_amount_total_shipping( $total , $order ){
		$status = $order->get_status();
		$is_order_editor = false;
		
		if( function_exists( 'get_current_screen' ) ){
			$screen = get_current_screen();
			if( $screen )
				$is_order_editor = $screen->id === 'shop_order';
		}
		
		if( $status === 'partially-paid' && ! $is_order_editor )
			return 0;
		
		return $total;
	}
	
	public function order_amount_shipping_tax( $tax , $order ){
		$status = $order->get_status();
		$is_order_editor = false;
		
		if( function_exists( 'get_current_screen' ) ){
			$screen = get_current_screen();
			if( $screen )
				$is_order_editor = $screen->id === 'shop_order';
		}
		
		if( $status === 'partially-paid' && ! $is_order_editor )
			return 0;
		
		return $tax;
	}
	
	public function order_amount_order_discount( $discount , $order ){
		$status = $order->get_status();
		$is_order_editor = false;
		
		if( function_exists( 'get_current_screen' ) ){
			$screen = get_current_screen();
			if( $screen )
				$is_order_editor = $screen->id === 'shop_order';
		}
		
		if( $status === 'partially-paid' && ! $is_order_editor )
			return 0;
		
		return $discount;
	}
	
	public function order_amount_cart_discount( $discount , $order ){
		$status = $order->get_status();
		$is_order_editor = false;
		
		if( function_exists( 'get_current_screen' ) ){
			$screen = get_current_screen();
			if( $screen )
				$is_order_editor = $screen->id === 'shop_order';
		}
		
		if( $status === 'partially-paid' && ! $is_order_editor )
			return 0;
		
		return $discount;
	}
	
	public function order_amount_item_subtotal( $price , $order , $item ){
		
		$status = $order->get_status();
		
		if( isset( $item[ 'wc_deposit_meta' ] ) ){
			$deposit_meta = maybe_unserialize( $item[ 'wc_deposit_meta' ] );
		} else{
			return $price;
		}
		
		if( isset( $deposit_meta ) && isset( $deposit_meta[ 'enable' ] ) && $deposit_meta[ 'enable' ] === 'yes' ){
			if( $status === 'partially-paid' ){
				$price = floatval( $deposit_meta[ 'remaining' ] ) / $item[ 'qty' ];
			} else{
				$price = floatval( $deposit_meta[ 'deposit' ] ) / $item[ 'qty' ];
			}
			$price = round( $price , absint( get_option( 'woocommerce_price_num_decimals' ) ) );
		} elseif( $status === 'partially-paid' ){
			$price = 0; // ensure that fully paid items are not paid for yet again.
		}
		
		return $price;
	}
	
	
	public function order_get_items( $items , $order ){
		
		$filter_enabled = get_option( 'wc_deposits_enable_product_calculation_filter' );
		if( $filter_enabled === 'yes' ) :
			$status = $order->get_status();
			$is_order_editor = false;
			if( function_exists( 'get_current_screen' ) ){
				$screen = get_current_screen();
				if( $screen )
					$is_order_editor = $screen->id === 'shop_order';
				if( $screen && ! $is_order_editor )
					$is_order_editor = $screen->id === 'post' && $screen->parent_base === 'edit';
			}
			
			if( $status === 'partially-paid' && ! $is_order_editor ){
				// remove everything that's not a line item with a remaining deposit, including fees
				$temp = array();
				foreach( $items as $item ){
					if( isset( $item ) && isset( $item[ 'type' ] ) && $item[ 'type' ] === 'line_item' && isset( $item[ 'wc_deposit_meta' ] ) ){
						$deposit_meta = maybe_unserialize( $item[ 'wc_deposit_meta' ] );
						if( isset( $deposit_meta ) && isset( $deposit_meta[ 'enable' ] ) && $deposit_meta[ 'enable' ] === 'yes' ){
							$item[ 'line_tax' ] = 0;
							$item[ 'line_total' ] = round( $deposit_meta[ 'remaining' ] , absint( get_option( 'woocommerce_price_num_decimals' ) ) );
							$temp[] = $item;
						}
					}
				}
				$items = $temp;
			}
		endif;
		return $items;
	}
	
	/**
	 * @brief Adjust order number based on order state
	 *
	 * @return string
	 * @since 1.5.1
	 */
	public function order_number( $number , $order_or_id ){
		$order = is_object( $order_or_id ) ? $order_or_id : wc_get_order( $order_or_id );
		if( $order !== false ){
			$status = $order->get_status();
			return $status === 'partially-paid' ? $number . '-WCDP' : $number;
		}
		
	}
}