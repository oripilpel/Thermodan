<?php
/*Copyright: © 2017 Webtomizer.
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}

class WC_Deposits_Cart{
	
	public $wc_deposits;
	public $checkout_mode;
	
	public function __construct( &$wc_deposits ){
		// Hook cart functionality
		
		$this->wc_deposits = $wc_deposits;
		$this->checkout_mode = $this->wc_deposits->checkout_mode;
		
		if( ! $this->checkout_mode ){
			
			//			add_action( 'woocommerce_cart_item_subtotal' , array( $this , 'cart_item_subtotal' ) , 10 , 3 );
			add_filter( 'woocommerce_get_cart_item_from_session' , array( $this , 'get_cart_item_from_session' ) , 10 , 2 );
			add_action( 'woocommerce_cart_updated' , array( $this , 'cart_updated' ) );
			add_action( 'woocommerce_after_cart_item_quantity_update' , array( $this , 'after_cart_item_quantity_update' ) , 10 , 2 );
			add_action( 'woocommerce_cart_totals_after_order_total' , array( $this , 'cart_totals_after_order_total' ) );
			add_filter( 'woocommerce_cart_tax_totals' , array( $this , 'cart_tax_total' ) , 30 , 2 );
			add_filter( 'woocommerce_get_item_data' , array( $this , 'get_item_data' ) , 10 , 2 );
			
		}
		
		//have to set very low priority to make sure all other plugins make calculations first
		add_filter( 'woocommerce_calculated_total' , array( $this , 'calculated_total' ) , 1001 , 2 );
	}
	
	
	public function get_item_data( $item_data , $cart_item ){
		
		
		if( isset( $cart_item[ 'deposit' ] ) && $cart_item[ 'deposit' ][ 'enable' ] === 'yes' ){
			
			$product = $cart_item[ 'data' ];
			
			if( $product->get_type() === 'variation' ){
				
				$parent = wc_get_product( $product->get_parent_id() );
				
				$amount_type = $parent->get_meta( '_wc_deposits_amount_type' , true );
				$deposit_amount = $parent->get_meta( '_wc_deposits_deposit_amount' , true );
				
			} else{
				$amount_type = $product->get_meta( '_wc_deposits_amount_type' , true );
				$deposit_amount = $product->get_meta( '_wc_deposits_deposit_amount' , true );
			}
			
			
			$tax_display = get_option( 'wc_deposits_tax_display' ) === 'yes';
			$tax_handling = get_option( 'wc_deposits_taxes_handling' );
			$tax = 0;
			
			if( $tax_display ){
				
				if( $amount_type === 'fixed' ){
					
					if( $tax_handling === 'deposit' ){
						$tax = wc_get_price_including_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) ) - wc_get_price_excluding_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) );
						
					} elseif( $tax_handling === 'split' ){
						$tax_total = $tax = wc_get_price_including_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) ) - wc_get_price_excluding_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) );
						
						$deposit_percentage = $deposit_amount * 100 / ( $product->get_price() );
						$tax = $tax_total * $deposit_percentage / 100;
					}
					
				} else{
					
					if( $tax_handling === 'deposit' ){
						$tax = wc_get_price_including_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) ) - wc_get_price_excluding_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) );
					} elseif( $tax_handling === 'split' ){
						$tax_total = $tax = wc_get_price_including_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) ) - wc_get_price_excluding_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) );
						$tax = $tax_total * $deposit_amount / 100;
					}
				}
			}
			
			$deposit = $cart_item[ 'deposit' ][ 'deposit' ];
			
			
			$woocommerce_prices_include_tax = get_option( 'woocommerce_prices_include_tax' );
			
			if( $woocommerce_prices_include_tax === 'yes' ){
				$display_deposit = $deposit;
				$display_remaining = $cart_item[ 'deposit' ][ 'remaining' ];
			} else{
				$display_deposit = $deposit + $tax;
				$display_remaining = $cart_item[ 'deposit' ][ 'remaining' ] + ( $tax_total - $tax );
			}
			
			
			$item_data[] = array(
				'name' => __( 'Deposit Amount' , 'woocommerce-deposits' ) ,
				'display' => wc_price( $display_deposit ) ,
				'value' => 'wc_deposit_amount' ,
			);
			$item_data[] = array(
				'name' => __( 'Remaining Amount' , 'woocommerce-deposits' ) ,
				'display' => wc_price( $display_remaining ) ,
				'value' => 'wc_deposit_amount' ,
			);
			
			
		}
		
		return $item_data;
		
		
	}
	
	
	/**
	 * @brief Hook the subtotal display and show the deposit and remaining amount
	 *
	 * @param string $subtotal ...
	 * @param array $cart_item ...
	 * @param mixed $cart_item_key ...
	 * @return string
	 */
	public function cart_item_subtotal( $subtotal , $cart_item , $cart_item_key ){
		
		$product = $cart_item[ 'data' ];
		
		if( $product->get_type() === 'variation' ){
			
			$parent = wc_get_product( $product->get_parent_id() );
			
			$deposit_enabled = $parent->get_meta( '_wc_deposits_enable_deposit' , true );
			$amount_type = $parent->get_meta( '_wc_deposits_amount_type' , true );
			$deposit_amount = $parent->get_meta( '_wc_deposits_deposit_amount' , true );
			
		} else{
			$deposit_enabled = $product->get_meta( '_wc_deposits_enable_deposit' , true );
			$amount_type = $product->get_meta( '_wc_deposits_amount_type' , true );
			$deposit_amount = $product->get_meta( '_wc_deposits_deposit_amount' , true );
		}
		
		
		if( $deposit_enabled === 'yes' && ! empty( $cart_item[ 'deposit' ] ) && $cart_item[ 'deposit' ][ 'enable' ] === 'yes' ){
			
			$tax_display = get_option( 'wc_deposits_tax_display' ) === 'yes';
			$tax_handling = get_option( 'wc_deposits_taxes_handling' );
			$tax = 0;
			
			if( $tax_display ){
				
				if( $amount_type === 'fixed' ){
					
					if( $tax_handling === 'deposit' ){
						$tax = wc_get_price_including_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) ) - wc_get_price_excluding_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) );
						
					} elseif( $tax_handling === 'split' ){
						$tax_total = $tax = wc_get_price_including_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) ) - wc_get_price_excluding_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) );
						
						$deposit_percentage = $deposit_amount * 100 / ( $product->get_price() );
						$tax = $tax_total * $deposit_percentage / 100;
					}
					
				} else{
					
					if( $tax_handling === 'deposit' ){
						$tax = wc_get_price_including_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) ) - wc_get_price_excluding_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) );
					} elseif( $tax_handling === 'split' ){
						$tax_total = $tax = wc_get_price_including_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) ) - wc_get_price_excluding_tax( $product , array( 'qty' => $cart_item[ 'quantity' ] ) );
						$tax = $tax_total * $deposit_amount / 100;
					}
				}
			}
			
			$deposit = $cart_item[ 'deposit' ][ 'deposit' ];
			
			
			$woocommerce_prices_include_tax = get_option( 'woocommerce_prices_include_tax' );
			
			if( $woocommerce_prices_include_tax === 'yes' ){
				$display_deposit = $deposit;
				
			} else{
				$display_deposit = $deposit + $tax;
				
			}
			$remaining = $cart_item[ 'deposit' ][ 'remaining' ];
			return wc_price( $display_deposit ) . ' ' . __( 'Deposit' , 'woocommerce-deposits' ) . '<br/>(' .
				wc_price( $remaining ) . ' ' . __( 'Remaining' , 'woocommerce-deposits' ) . ')';
		} else{
			return $subtotal;
		}
	}
	
	public function get_cart_item_from_session( $cart_item , $values ){
		
		if( ! empty( $values[ 'deposit' ] ) ){
			$cart_item[ 'deposit' ] = $values[ 'deposit' ];
		}
		return $cart_item;
	}
	
	
	private function update_deposit_meta( $product , $quantity , &$cart_item_data ){
		
		if( $product ){
			
			$product_type = $product->get_type();
			if( $product_type === 'variation' ){
				
				$parent = wc_get_product( $product->get_parent_id() );
				
				$deposit_enabled = $parent->get_meta( '_wc_deposits_enable_deposit' , true );
			} else{
				$deposit_enabled = $product->get_meta( '_wc_deposits_enable_deposit' , true );
				
			}
			
			if( $deposit_enabled === 'yes' && isset( $cart_item_data[ 'deposit' ] ) &&
				$cart_item_data[ 'deposit' ][ 'enable' ] === 'yes'
			){
				
				if( $product_type === 'variation' ){
					
					$parent = wc_get_product( $product->get_parent_id() );
					$deposit = $parent->get_meta( '_wc_deposits_deposit_amount' , true );
					$amount_type = $parent->get_meta( '_wc_deposits_amount_type' , true );
					
				} else{
					
					$deposit = $product->get_meta( '_wc_deposits_deposit_amount' , true );
					$amount_type = $product->get_meta( '_wc_deposits_amount_type' , true );
					
				}
				
				$amount = 0;
				$woocommerce_prices_include_tax = get_option( 'woocommerce_prices_include_tax' );
				
				switch( $product_type ){
					
					case 'booking':
						$amount = $cart_item_data[ 'booking' ][ '_cost' ];
						if( $product->has_persons() && $product->wc_deposits_enable_per_person == 'yes' ){
							$persons = array_sum( $cart_item_data[ 'booking' ][ '_persons' ] );
							if( $amount_type === 'fixed' ){
								$deposit = $deposit * $persons;
							} else{ // percent
								$deposit = $deposit / 100.0 * $amount;
							}
						} else{
							if( $amount_type === 'percent' ){
								$deposit = $deposit / 100.0 * $amount;
							}
						}
						break;
					case 'subscription' :
						if( class_exists( 'WC_Subscriptions_Product' ) ){
							
							$amount = WC_Subscriptions_Product::get_sign_up_fee( $product );
							if( $amount_type === 'fixed' ){
								$deposit = $deposit * $quantity;
							} else{
								$deposit = $amount * ( $deposit / 100.0 );
							}
							
						}
						break;
					case 'yith_bundle' :
						$amount = $product->price_per_item_tot;
						if( $amount_type === 'fixed' ){
							$deposit = $deposit * $quantity;
						} else{
							$deposit = $amount * ( $deposit / 100.0 );
						}
						break;
					case 'variable' :
						
						$amount = $cart_item_data[ 'line_subtotal' ];
						if( $amount_type === 'fixed' ){
							$deposit = $deposit * $quantity;
						} else{
							$deposit = $amount * ( $deposit / 100.0 );
						}
						break;
					
					default:
						
						
						if( $woocommerce_prices_include_tax === 'yes' ){
							
							$amount = wc_get_price_including_tax( $product , array( 'qty' => $quantity ) );
							
						} else{
							$amount = wc_get_price_excluding_tax( $product , array( 'qty' => $quantity ) );
							
						}
						if( $amount_type === 'fixed' ){
							$deposit = $deposit * $quantity;
							
						} else{
							$deposit = $amount * ( $deposit / 100.0 );
						}
						
						break;
				}
				
				if( $deposit < $amount && $deposit > 0 ){
					
					
					$cart_item_data[ 'deposit' ][ 'deposit' ] = $deposit;
					$cart_item_data[ 'deposit' ][ 'remaining' ] = $amount - $deposit;
					$cart_item_data[ 'deposit' ][ 'total' ] = $amount;
				} else{
					$cart_item_data[ 'deposit' ][ 'enable' ] = 'no';
				}
				
				$cart_item_data[ 'deposit' ] = apply_filters( 'wc_deposits_cart_item_deposit_data' , $cart_item_data[ 'deposit' ] , $cart_item_data );
			}
		}
		
	}
	
	public function cart_updated(){
		
		foreach( WC()->cart->cart_contents as &$cart_item ){
			
			$this->update_deposit_meta( $cart_item[ 'data' ] , $cart_item[ 'quantity' ] , $cart_item );
		}
		
	}
	
	public function after_cart_item_quantity_update( $cart_item_key , $quantity ){
		$product = WC()->cart->cart_contents[ $cart_item_key ][ 'data' ];
		$this->update_deposit_meta( $product , $quantity , WC()->cart->cart_contents[ $cart_item_key ] );
	}
	
	
	/**
	 * @brief Calculate cart total
	 *
	 * @param mixed $cart_total ...
	 * @param mixed $cart ...
	 *
	 * @return float
	 */
	public function calculated_total( $cart_total , $cart ){
		
		$cart_original = $cart_total;
		$deposit_amount = 0;
		$deposit_total = 0;
		$full_amount_products = 0;
		$woocommerce_prices_include_tax = get_option( 'woocommerce_prices_include_tax' );
		
		if( $this->checkout_mode ){
			
			$deposit_amount = get_option( 'wc_deposits_checkout_mode_deposit_amount' );
			$amount_type = get_option( 'wc_deposits_checkout_mode_deposit_amount_type' );
			
			foreach( WC()->cart->get_cart() as $cart_item ){
				
				if( $woocommerce_prices_include_tax === 'yes' ){
					
					$deposit_total += wc_get_price_including_tax( $cart_item[ 'data' ] , array( 'qty' => $cart_item[ 'quantity' ] ) );
					
				} else{
					$deposit_total += wc_get_price_excluding_tax( $cart_item[ 'data' ] , array( 'qty' => $cart_item[ 'quantity' ] ) );
				}
				
			}
			
			if( $amount_type === 'percentage' ){
				
				
				$deposit_amount = ( WC()->cart->subtotal_ex_tax * $deposit_amount ) / 100;
				
			}
		} else{
			
			foreach( $cart->cart_contents as $cart_item_key => &$cart_item ){
				
				if( isset( $cart_item[ 'deposit' ] ) && $cart_item[ 'deposit' ][ 'enable' ] === 'yes' ){
					$product = wc_get_product( $cart_item[ 'product_id' ] );
					$this->update_deposit_meta( $cart_item[ 'data' ] , $cart_item[ 'quantity' ] , $cart_item );
					$deposit_amount += $cart_item[ 'deposit' ][ 'deposit' ];
					$deposit_total += $cart_item[ 'deposit' ][ 'total' ];
					
					if( $product->get_type() === 'subscription' && class_exists( 'WC_Subscriptions_Product' ) ){
						$deposit_amount += WC_Subscriptions_Product::get_price( $product );
					}
					
				} else{
					
					//YITH bundle compatiblity
					if( isset( $cart_item[ 'bundled_by' ] ) ){
						
						$bundled_by = $cart->cart_contents[ $cart_item[ 'bundled_by' ] ];
						if( isset( $bundled_by[ 'deposit' ] ) && $bundled_by[ 'deposit' ][ 'enable' ] === 'yes' ){
							
							if( ! ( isset( $bundled_by[ 'data' ]->per_items_pricing ) && $bundled_by[ 'data' ]->per_items_pricing ) ){
								$full_amount_products += $cart_item[ 'line_total' ];
							}
						} else{
							
							$full_amount_products += $cart_item[ 'line_total' ];
						}
						
					} else{
						
						if( $woocommerce_prices_include_tax !== 'yes' ){
							$full_amount_products += $cart_item[ 'line_total' ];
							
						} else{
							$full_amount_products += $cart_item[ 'line_total' ] + $cart_item[ 'line_tax' ];
							
						}
					}
				}
				
				
			}
		}
		
		$do_calculations = false;
		
		if( $deposit_amount > 0 && $deposit_amount < ( $deposit_total + $cart->fee_total + $cart->tax_total + $cart->shipping_total ) ){
			
			if( ! $this->checkout_mode ){
				$deposit_amount += $full_amount_products;
				
				WC()->cart->cart_session_data[ 'deposit_enabled' ] = true;
				$do_calculations = true;
			} else{
				
				if( is_ajax() && isset( $_POST[ 'deposit-radio' ] ) && $_POST[ 'deposit-radio' ] === 'deposit' ){
					WC()->cart->cart_session_data[ 'deposit_enabled' ] = true;
					
					$do_calculations = true;
				} elseif( is_ajax() && isset( $_POST[ 'deposit-radio' ] ) && $_POST[ 'deposit-radio' ] === 'full' ){
					WC()->cart->cart_session_data[ 'deposit_enabled' ] = false;
				} else{
					
					$default_checked = get_option( 'wc_deposits_default_option' , 'deposit' );
					if( $default_checked === 'deposit' ){
						$do_calculations = true;
						WC()->cart->cart_session_data[ 'deposit_enabled' ] = true;
						
					}
				}
			}
		}
		
		
		$deposit_breakdown = null;
		
		if( $do_calculations ){
			$fees_handling = get_option( 'wc_deposits_fees_handling' );
			$taxes_handling = get_option( 'wc_deposits_taxes_handling' );
			$shipping_handling = get_option( 'wc_deposits_shipping_handling' );
			$shipping_taxes_handling = get_option( 'wc_deposits_shipping_taxes_handling' );
			
			
			$deposit_breakdown = array(
				'cart_items' => $deposit_amount ,
				'fees' => 0 ,
				'taxes' => 0 ,
				'shipping' => 0 ,
				'shipping_taxes' => 0
			);
			
			
			if( $fees_handling === 'deposit' ){
				$deposit_amount += $cart->fee_total;
				
				$deposit_breakdown[ 'fees' ] = $cart->fee_total;
				
				
			}
			if( $taxes_handling === 'deposit' ){
				
				
				$deposit_amount += $cart->tax_total;
				$deposit_breakdown[ 'taxes' ] = $cart->tax_total;
				
			} elseif( $taxes_handling === 'split' ){
				
				if( ! $woocommerce_prices_include_tax !== 'yes' ){
					$deposit_percentage = $deposit_amount * 100 / $cart->subtotal_ex_tax;
					$tax = $cart->tax_total * $deposit_percentage / 100;
					$deposit_amount += $tax;
					
					
					$deposit_breakdown[ 'taxes' ] = $tax;
				}
				
				
			}
			
			if( $shipping_handling === 'deposit' ){
				$deposit_amount += $cart->shipping_total;
				
				if( $cart->shipping_total > 0 ){
					$deposit_breakdown[ 'shipping' ] = $cart->shipping_total;
				}
				
				
			}
			
			if( $shipping_taxes_handling === 'deposit' ){
				$deposit_amount += $cart->shipping_tax_total;
				
				
				$deposit_breakdown[ 'shipping_taxes' ] = $cart->shipping_tax_total;
				
				
			}
			
			
		}
		
		
		$second_payment = $cart_total - $deposit_amount;
		
		WC()->cart->cart_session_data[ 'deposit_breakdown' ] = $deposit_breakdown;
		WC()->cart->cart_session_data[ 'deposit_amount' ] = apply_filters( 'woocommerce_deposits_cart_deposit_amount' , $deposit_amount , $second_payment , $cart_total );
		WC()->cart->cart_session_data[ 'second_payment' ] = apply_filters( 'woocommerce_deposits_cart_second_payment_amount' , $second_payment , $deposit_amount , $cart_total );
		
		return $cart_original;
		
	}
	
	public function cart_totals_after_order_total(){
		
		if( isset( WC()->cart->cart_session_data[ 'deposit_enabled' ] ) && WC()->cart->cart_session_data[ 'deposit_enabled' ] === true ) :
			
			
			$to_pay_text = get_option( 'wc_deposits_to_pay_text' );
			$second_payment_text = get_option( 'wc_deposits_second_payment_text' );
			
			
			if( $to_pay_text === false ){
				$to_pay_text = __( 'To Pay' , 'woocommerce-deposits' );
			}
			
			
			if( $second_payment_text === false ){
				$second_payment_text = __( 'Second Payment' , 'woocommerce-deposits' );
			}
			$to_pay_text = stripslashes( $to_pay_text );
			$second_payment_text = stripslashes( $second_payment_text );
			
			
			$deposit_breakdown_tooltip = wc_deposits_deposit_breakdown_tooltip();
			
			?>
            <tr class="order-paid">
                <th><?php echo $to_pay_text ?>&nbsp;&nbsp;<?php echo $deposit_breakdown_tooltip; ?>
                </th>
                <td data-title="<?php echo $to_pay_text; ?>">
                    <strong><?php echo wc_price( WC()->cart->cart_session_data[ 'deposit_amount' ] ); ?></strong></td>
            </tr>
            <tr class="order-remaining">
                <th><?php echo $second_payment_text; ?></th>
                <td data-title="<?php echo $second_payment_text; ?>">
                    <strong><?php echo wc_price( WC()->cart->cart_session_data[ 'second_payment' ] ); ?></strong></td>
            </tr>
			<?php
		endif;
	}
	
	
	public function cart_tax_total( $tax_totals ){
		
		if( isset( WC()->cart->cart_session_data[ 'deposit_enabled' ] ) && WC()->cart->cart_session_data[ 'deposit_enabled' ] === true ) :
			$tax_option = get_option( 'wc_deposits_tax_collecting_method' );
			
			
			foreach( $tax_totals as $tax ){
				
				
				if( $tax_option === 'deposit' ){
					
					$tax->label .= __( '(collected with deposit)' , 'woocommerce-deposits' );
					
				} elseif( $tax_option === 'full' ){
					
					$tax->label .= __( ' ( collected With second payment )' , 'woocommerce-deposits' );
				}
			}
		endif;
		return $tax_totals;
		
	}
	
	
}
