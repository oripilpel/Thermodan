<?php
/*Copyright: Â© 2014 Abdullah Ali.
License: GNU General Public License v3.0
License URI: http://www.gnu.org/licenses/gpl-3.0.html
*/

if( ! defined( 'ABSPATH' ) ){
	exit; // Exit if accessed directly
}

class WC_Deposits_Legacy_Add_To_Cart{
	
	private $booking_cost = null;
	private $appointment_cost = null;
	
	
	public function __construct( &$wc_deposits ){
		// Add the required styles
		add_action( 'wp_enqueue_scripts' , array( $this , 'enqueue_scripts' ) );
		add_action( 'wp_enqueue_scripts' , array( $this , 'enqueue_inline_styles' ) );
		add_filter( 'woocommerce_bookings_booking_cost_string' , array( $this , 'calculate_bookings_cost' ) );
		add_filter( 'booking_form_calculated_booking_cost' , array( $this , 'get_booking_cost' ) );
		
		//appointments plugin
		add_filter( 'woocommerce_appointments_appointment_cost_html' , array( $this , 'calculate_appointment_cost_html' ) );
		add_filter( 'appointment_form_calculated_appointment_cost' , array( $this , 'get_appointment_cost' ) , 100 );
		// Hook the add to cart form
		add_action( 'woocommerce_before_add_to_cart_button' , array( $this , 'before_add_to_cart_button' ) );
		add_filter( 'woocommerce_add_cart_item_data' , array( $this , 'add_cart_item_data' ) , 10 , 2 );
	}
	
	/**
	 * @brief Load the deposit-switch logic
	 *
	 * @return void
	 */
	public function enqueue_scripts(){
		if( is_product() ){
			global $post;
			$product = wc_get_product( $post->ID );
			
			if( $product && isset( $product->wc_deposits_enable_deposit ) && $product->wc_deposits_enable_deposit === 'yes' ){
				wp_enqueue_script( 'wc-deposits-add-to-cart' , WC_DEPOSITS_PLUGIN_URL . '/assets/js/add-to-cart.js' );
				
				$message_deposit = get_option( 'wc_deposits_message_deposit' );
				$message_full_amount = get_option( 'wc_deposits_message_full_amount' );
				
				$message_deposit = stripslashes( $message_deposit );
				$message_full_amount = stripslashes( $message_full_amount );
				
				$script_args = array(
					'message' => array(
						'deposit' => __( $message_deposit , 'woocommerce-deposits' ) ,
						'full' => __( $message_full_amount , 'woocommerce-deposits' )
					)
				);
				
				if( $product->is_type( 'variable' ) && $product->wc_deposits_amount_type !== 'fixed' ){
					foreach( $product->get_children() as $variation_id ){
						$variation = $product->get_child( $variation_id );
						if( ! is_object( $variation ) )
							continue;
						$tax = get_option( 'wc_deposits_tax_display' , 'no' ) === 'yes' ?
							$variation->get_price_including_tax() - $variation->get_price_excluding_tax() : 0;
						$amount = wc_price( $variation->get_price_excluding_tax() *
							( $product->wc_deposits_deposit_amount / 100.0 ) + $tax );
						$script_args[ 'variations' ][ $variation_id ] = array( $amount );
					}
				}
				
				wp_localize_script( 'wc-deposits-add-to-cart' , 'wc_deposits_add_to_cart_options' , $script_args );
			}
		}
	}
	
	/**
	 * @brief Enqueues front-end styles
	 *
	 * @return void
	 */
	public function enqueue_inline_styles(){
		if( is_product() ){
			global $post;
			$product = wc_get_product( $post->ID );
			
			if( $product && isset( $product->wc_deposits_enable_deposit ) && $product->wc_deposits_enable_deposit === 'yes' ){
				// prepare inline styles
				$colors = get_option( 'wc_deposits_deposit_buttons_colors' );
				$fallback_colors = wc_deposits_woocommerce_frontend_colours();
				$gstart = $colors[ 'primary' ] ? $colors[ 'primary' ] : $fallback_colors[ 'primary' ];
				$secondary = $colors[ 'secondary' ] ? $colors[ 'secondary' ] : $fallback_colors[ 'secondary' ];
				$highlight = $colors[ 'highlight' ] ? $colors[ 'highlight' ] : $fallback_colors[ 'highlight' ];
				$gend = wc_deposits_adjust_colour( $gstart , 15 );
				
				
				$style = "@media only screen {
            #wc-deposits-options-form input.input-radio:enabled ~ label { color: {$secondary}; }
            #wc-deposits-options-form div a.wc-deposits-switcher {
              background-color: {$gstart};
              background: -moz-gradient(center top, {$gstart} 0%, {$gend} 100%);
              background: -moz-linear-gradient(center top, {$gstart} 0%, {$gend} 100%);
              background: -webkit-gradient(linear, left top, left bottom, from({$gstart}), to({$gend}));
              background: -webkit-linear-gradient({$gstart}, {$gend});
              background: -o-linear-gradient({$gstart}, {$gend});
              background: linear-gradient({$gstart}, {$gend});
            }
            #wc-deposits-options-form .amount { color: {$highlight}; }
            #wc-deposits-options-form .deposit-option { display: inline; }
          }";
				
				wp_add_inline_style( 'wc-deposits-frontend-styles' , $style );
			}
		}
	}
	
	
	/**
	 * get the updated booking cost and saves it to be used for html generation
	 * @param $cost
	 * @return mixed
	 */
	public function get_appointment_cost( $cost ){
		
		$this->appointment_cost = $cost;
		
		return $cost;
		
	}
	
	/**
	 * get the updated booking cost and saves it to be used for html generation
	 * @param $cost
	 * @return mixed
	 */
	public function get_booking_cost( $cost ){
		
		$this->booking_cost = $cost;
		
		return $cost;
		
	}
	
	
	/**
	 * @brief calculates new booking deposit on booking total change
	 * @param $html
	 * @return string
	 */
	public function calculate_bookings_cost( $html ){
		
		$posted = array();
		
		parse_str( $_POST[ 'form' ] , $posted );
		
		$product_id = $posted[ 'add-to-cart' ];
		$product = wc_get_product( $product_id );
		$deposit_amount = $product->wc_deposits_deposit_amount;
		$booking_cost = $this->booking_cost;
		if( $product->is_type( 'booking' ) ){
			$amount = $booking_cost;
			if( $product->has_persons() && $product->wc_deposits_enable_per_person == 'yes' ){
				$persons = $posted[ 'wc_bookings_field_persons' ];
				if( $product->wc_deposits_amount_type === 'fixed' ){
					$deposit = $deposit_amount * $persons;
				} else{ // percent
					$deposit = $deposit_amount / 100.0 * $amount;
				}
			} else{
				if( $product->wc_deposits_amount_type === 'percent' ){
					$deposit = $deposit_amount / 100.0 * $amount;
				}
			}
		}
		
		$deposit_html = wc_price( $deposit );
		$script = '<script type="text/javascript">
            jQuery(document).ready(function($){
                var deposit_html = \'' . $deposit_html . '\'
            $("#deposit-amount .amount").html(deposit_html);
                });
                
                </script>';
		
		return $html . $script;
		
	}
	
	public function calculate_appointment_cost_html( $html ){
		
		
		$posted = array();
		
		parse_str( $_POST[ 'form' ] , $posted );
		
		$product_id = $posted[ 'add-to-cart' ];
		$product = wc_get_product( $product_id );
		
		$deposit_amount = $product->wc_deposits_deposit_amount;
		$appointment_cost = $this->appointment_cost;
		if( $product->is_type( 'appointment' ) ){
			$amount = $appointment_cost;
			if( $product->wc_deposits_amount_type === 'percent' ){
				$deposit = $deposit_amount / 100.0 * $amount;
			}
			
		}
		
		$deposit_html = wc_price( floatval( $deposit ) );
		$script = '<script type="text/javascript">
            jQuery(document).ready(function($){
                var deposit_html = \'' . $deposit_html . '\'
            $("#deposit-amount .amount").html(deposit_html);
                });
                
                </script>';
		
		return $html . $script;
		
	}
	
	
	public function before_add_to_cart_button(){
		global $product;
		if( $product && isset( $product->wc_deposits_enable_deposit ) && $product->wc_deposits_enable_deposit === 'yes' ){
			$tax = get_option( 'wc_deposits_tax_display' , 'no' ) === 'yes' ?
				$product->get_price_including_tax() - $product->get_price_excluding_tax() : 0;
			if( $product->wc_deposits_amount_type === 'fixed' ){
				$amount = wc_price( $product->wc_deposits_deposit_amount + $tax );
				if( $product->is_type( 'booking' ) && $product->has_persons() && $product->wc_deposits_enable_per_person === 'yes' ){
					$suffix = __( 'per person' , 'woocommerce-deposits' );
				} elseif( $product->is_type( 'booking' ) ){
					$suffix = __( 'per booking' , 'woocommerce-deposits' );
				} elseif( ! $product->is_sold_individually() ){
					$suffix = __( 'per item' , 'woocommerce-deposits' );
				} else{
					$suffix = '';
				}
			} else{
				if( $product->is_type( 'booking' ) ){
					$amount = '<span class=\'amount\'>' . round( $product->wc_deposits_deposit_amount , 2 ) . '%' . '</span>';
				} elseif( $product->is_type( 'variable' ) ){
					$min_variation = $product->get_child( $product->min_price_variation_id );
					$max_variation = $product->get_child( $product->max_price_variation_id );
					if( $min_variation && $max_variation ){
						$tax_min = get_option( 'wc_deposits_tax_display' , 'no' ) === 'yes' ? $min_variation->get_price_including_tax() - $min_variation->get_price_excluding_tax() : 0;
						$tax_max = get_option( 'wc_deposits_tax_display' , 'no' ) === 'yes' ? $max_variation->get_price_including_tax() - $max_variation->get_price_excluding_tax() : 0;
						$amount_min = wc_price( $min_variation->get_price_excluding_tax() * ( $product->wc_deposits_deposit_amount / 100.0 ) + $tax_min );
						$amount_max = wc_price( $max_variation->get_price_excluding_tax() * ( $product->wc_deposits_deposit_amount / 100.0 ) + $tax_max );
						$amount = $amount_min . '&nbsp;&ndash;&nbsp;' . $amount_max;
					} else{
						$amount = wc_price( $product->get_price_excluding_tax() * ( $product->wc_deposits_deposit_amount / 100.0 ) + $tax );
					}
				} elseif( $product->is_type( 'composite' ) && $product->wc_deposits_amount_type === 'percent' ){
					$amount = '<span class=\'amount\'>' . round( $product->wc_deposits_deposit_amount , 2 ) . '%' . '</span>';
				} else{
					$amount = wc_price( $product->get_price_excluding_tax() * ( $product->wc_deposits_deposit_amount / 100.0 ) + $tax );
				}
				if( ! $product->is_sold_individually() ){
					$suffix = __( 'per item' , 'woocommerce-deposits' );
				} else{
					$suffix = '';
				}
			}
			$default = get_option( 'wc_deposits_default_option' , 'deposit' );
			$deposit_checked = ( $default === 'deposit' ? 'checked=\'checked\'' : '' );
			$full_checked = ( $default === 'full' ? 'checked=\'checked\'' : '' );
			$basic_button = get_option( 'wc_deposits_use_basic_radio_buttons' , true ) === 'yes' ? true : false;
			$div_id = $basic_button === true ? 'basic-wc-deposits-options-form' : 'wc-deposits-options-form';
			$classes = $basic_button === true ? 'basic-switch-woocommerce-deposits' : 'deposit-options switch-toggle switch-candy switch-woocommerce-deposits';
			$deposit_text = get_option( 'wc_deposits_button_deposit' );
			$full_text = get_option( 'wc_deposits_button_full_amount' );
			if( $deposit_text === false )
				$deposit_text = __( 'Pay Deposit' , 'woocommerce-deposits' );
			if( $full_text === false )
				$full_text = __( 'Full Amount' , 'woocommerce-deposits' );
			$deposit_text = stripslashes( $deposit_text );
			$full_text = stripslashes( $full_text );
			
			?>
            <div id='<?php echo $div_id ?>'>
                <hr class='separator'/>
                <label class='deposit-option'>
					<?php echo __( 'Deposit Option:' , 'woocommerce-deposits' ); ?>
                    <span id='deposit-amount'><?php echo $amount; ?></span>
                    <span id='deposit-suffix'><?php echo $suffix; ?></span>
                </label>
                <div class="<?php echo $classes ?>">
                    <input id='pay-deposit' name='<?php echo $product->id ?>-deposit-radio'
                           type='radio' <?php echo $deposit_checked; ?> class='input-radio' value='deposit'>
                    <label id="pay-deposit-label" for='pay-deposit'
                           onclick=''><?php _e( $deposit_text , 'woocommerce-deposits' ); ?></label>
					<?php if( isset( $product->wc_deposits_force_deposit ) && $product->wc_deposits_force_deposit === 'yes' ){ ?>
                        <input id='pay-full-amount' name='<?php echo $product->id ?>-deposit-radio' type='radio'
                               class='input-radio'
                               disabled>
                        <label id="pay-full-amount-label" for='pay-full-amount'
                               onclick=''><?php _e( $full_text , 'woocommerce-deposits' ); ?></label>
					<?php } else{ ?>
                        <input id='pay-full-amount' name='<?php echo $product->id ?>-deposit-radio'
                               type='radio' <?php echo $full_checked; ?> class='input-radio' value='full'>
                        <label id="pay-full-amount-label" for='pay-full-amount'
                               onclick=''><?php _e( $full_text , 'woocommerce-deposits' ); ?></label>
					<?php } ?>
                    <a class='wc-deposits-switcher'></a>
                </div>
                <span class='deposit-message' id='wc-deposits-notice'></span>
            </div>
			<?php
		}
	}
	
	public function add_cart_item_data( $cart_item_meta , $product_id ){
		$product = wc_get_product( $product_id );
		if( $product->wc_deposits_enable_deposit === 'yes' ){
			if( ! isset( $_POST[ $product_id . '-deposit-radio' ] ) ){
				$default = get_option( 'wc_deposits_default_option' );
				$_POST[ $product_id . '-deposit-radio' ] = $default ? $default : 'deposit';
			}
			$cart_item_meta[ 'deposit' ] = array(
				'enable' => $product->wc_deposits_force_deposit === 'yes' ? 'yes' : ( $_POST[ $product_id . '-deposit-radio' ] === 'full' ? 'no' : 'yes' )
			);
		}
		return $cart_item_meta;
	}
}

