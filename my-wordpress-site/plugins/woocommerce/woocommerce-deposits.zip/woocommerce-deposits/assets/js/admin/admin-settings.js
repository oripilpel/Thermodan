jQuery(document).ready(function($){


    $('.deposits-color-field').wpColorPicker();


    $('#wc_deposits_update_outdated_orders').on('click',function(e){

        if(!window.confirm(' Are you sure you want to update? Please make orders backup before proceeding.')) return;
        e.preventDefault();
        $(this).attr('disabled','disabled');
        $(this).after('<img src="images/loading.gif" />');

        //make ajax call
        var nonce = $('.wrap.woocommerce #mainform .submit #_wpnonce').get(0).value;
        var data = {
            action : 'wc_deposits_update_outdated_orders',
            nonce : nonce
        };
        $.post(wc_deposits.ajax_url,data).done(function(res){

            if(res.success) {

                $('#wc_deposits_update_outdated_orders').removeAttr('disabled');
                $('#wc_deposits_update_outdated_orders').after('&nbsp;<span>'+wc_deposits.strings.success+' &#10004; </span>');
                $('#wc_deposits_update_outdated_orders_container').find('img').remove();
            }


        }).fail(function(){

            $(this).removeAttr('disabled');
            alert('Error occured')

        });



    })
});