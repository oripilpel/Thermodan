= WooCommerce Lottery =
Author: wpgenie - https://codecanyon.net/user/wpgenie/portfolio

Documentation: https://wpgenie.org/woocommerce-lottery/documentation/
Tags: wordpress lotteries, woocommerce lotteries, simple wordpress lotteries, lotteries, lottery plugin, wordpress lottery plugin, woocommerce lottery plugin, simple lottery, wpgenie lottery, wpgenie


Requires at least:	4.0

== Description ==
WooCommerce Simple lotteries is an extension for Woocommerce. Since WooCommerce is popular we decided that it would be neat to extend it with lottery features. 
We wanted to make it easy to use but also to include all lottery features so you get a powerful lottery solution which is easily setup and customized.
With our lottery plugin you can setup WordPress lottery website and start lotteries in less than 30 minutes (assuming you have payment processor account ready).


= License =

Unless otherwise specified, all the theme files, scripts and images are licensed under GNU General Public Licemse.