WooCommerce One Page Shopping
=============================

Plugin displays cart and checkout pages on product page which makes it possible 
to do the shopping on one common page.
Since version 2.0.0 it's also possible to use the plugin on shop page and category
pages as well.
Since version 2.4.0 plugin allows to add shortcodes [ops_section] [ops_to_cart] to post page.
[ops_to_cart] shortcode is fully compatible with WooCommerce shortcode [add_to_cart]. Example [ops_to_cart id="11" style="border:4px solid #000"].
You need to include [ops_section] to indicate plugin where to put cart and checkout. Standard use [ops_section] will include both cart and checkout. 
You can also use [ops_section cart] or [ops_section checkout] to show only cart or checkout.