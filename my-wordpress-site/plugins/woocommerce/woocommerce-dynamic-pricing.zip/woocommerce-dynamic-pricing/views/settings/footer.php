<?php

/**
 * View for Settings page footer
 */

// Exit if accessed directly
if (!defined('ABSPATH')) {
    exit;
}

?>
