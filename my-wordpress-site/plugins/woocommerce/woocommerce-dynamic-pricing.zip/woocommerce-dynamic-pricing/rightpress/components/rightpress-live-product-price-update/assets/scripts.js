/**
 * RightPress Live Product Price Update Scripts
 */

jQuery(document).ready(function() {

    /**
     * Initialize live product update
     */
    jQuery('.rightpress_live_product_price').rightpress_live_product_update({

        // Params
        ajax_url:   rightpress_live_product_price_update_vars.ajaxurl,
        action:     'rightpress_live_product_price_update',

        // Callback
        response_handler: function(response) {

            // Display live price
            if (typeof response === 'object' && typeof response.result !== 'undefined' && response.result === 'success' && response.display) {
                var price_html = response.price_html + '<style style="display: none;">div.single_variation_wrap div.single_variation span.price { display: none; }</style>';
                jQuery(this).find('.price').html(price_html);
                jQuery(this).slideDown();
            }
            // Hide live price
            else {
                jQuery(this).slideUp();
                jQuery(this).find('.price').html('');
            }
        }
    });


});
