Improved Sale Badges for WooCommerce!
by Mihajlovicnenad.com - https://mihajlovicnenad.com

Read documentation for more information! https://mihajlovicnenad.com/improved-sale-badges/documentation-and-guide/