jQuery(document).ready(function ($) {

    $('.product-option').find('select, input[type="checkbox"], input[type="radio"]').on('update_option', function () {
        if ($(this).closest('.product-option').find('.suboptions-hide-options, .suboptions-show-options').length == 0) {
            return;
        }
        var productOptionsPostId = $(this).closest('.product-options').find('.product-option-post-id').val();
        $('.product-options-'+productOptionsPostId+' .product-option').show();
        $('.product-options-'+productOptionsPostId+' .product-option').each(function () {
            var productOption = $(this).closest('.product-option');
            if (productOption.find('.suboptions-hide-options, .suboptions-show-options').length == 0) {
                return;
            }
            //var productOptions = $(this).closest('.product-options');
            productOption.find('option:selected, input[type="radio"]:checked').each(function () {
                if(!$(this).is(':checked') && !$(this).is(':selected')) {
                    return;
                }
                var value = $(this).val();
                productOption.find('.hide-when-suboption-selected-' + value).each(function () {
                    var showProductOptionId = $(this).val();
                    $('.product-option-post-id[value="' + productOptionsPostId + '"]').each(function () {
                        $(this).closest('.product-options').find('.product-option-' + showProductOptionId).hide();
                    });
                });
                productOption.find('.show-when-suboption-selected-' + value).each(function () {
                    var showProductOptionId = $(this).val();
                    $('.product-option-post-id[value="' + productOptionsPostId + '"]').each(function () {
                        $(this).closest('.product-options').find('.product-option-' + showProductOptionId).show();
                    });
                });
            });
            productOption.find('input[type="checkbox"]:checked').each(function () {
                if(!$(this).prop('checked')) {
                    return;
                }
                var checked = $(this).attr('checked');
                var name = $(this).attr('name');
                var lastIndexOfOpeningBracket = name.lastIndexOf('[');
                var lastIndexOfClosingBracket = name.lastIndexOf(']');
                var value = name.substring(lastIndexOfOpeningBracket + 1, lastIndexOfClosingBracket);
                productOption.find('.hide-when-suboption-selected-' + value).each(function () {
                    var showProductOptionId = $(this).val();
                    $('.product-option-post-id[value="' + productOptionsPostId + '"]').each(function () {
                        $(this).closest('.product-options').find('.product-option-' + showProductOptionId).hide();
                    });
                });
                productOption.find('.show-when-suboption-selected-' + value).each(function () {
                    var showProductOptionId = $(this).val();
                    $('.product-option-post-id[value="' + productOptionsPostId + '"]').each(function () {
                        $(this).closest('.product-options').find('.product-option-' + showProductOptionId).show();
                    });
                });
            });
        });
    });

    $('.suboptions-hide-options').first().find('select, input[type="checkbox"], input[type="radio"]').first().trigger('update_option');

});