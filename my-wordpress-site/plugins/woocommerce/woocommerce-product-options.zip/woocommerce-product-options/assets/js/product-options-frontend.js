jQuery(document).ready(function ($) {

    if ($('.product-option').length > 0) {

        var addToCartButton = null;

        var addingToCart = false;
        var numberOfResponses = 0;
        var variation = null;
        var productPrice = parseFloat($('.product-options-product-price').val());
        var salePrice = parseFloat($('.product-options-product-price').val());
        //var thisExpanded = false;

        function showHideOptions() {
            $('.hide-product-options').each(function () {
                var productOptions = $(this).closest('.product-options');
                var productOption = $(this).closest('.product-option');
                var isChecked = productOption.find('input[type=checkbox]:checked').length;
                if (isChecked > 0) {
                    $(this).find('.hide-product-option').each(function () {
                        var productOptionId = $(this).val();
                        productOptions.find('.product-option-' + productOptionId).hide();
                    });
                } else {
                    $(this).find('.hide-product-option').each(function () {
                        var productOptionId = $(this).val();
                        productOptions.find('.product-option-' + productOptionId).show();
                    });
                }
            });
            $('.show-product-options').each(function () {
                var productOptions = $(this).closest('.product-options');
                var productOption = $(this).closest('.product-option');
                var isChecked = productOption.find('input[type=checkbox]:checked').length;
                if (isChecked > 0) {
                    $(this).find('.show-product-option').each(function () {
                        var productOptionId = $(this).val();
                        productOptions.find('.product-option-' + productOptionId).show();
                    });
                } else {
                    $(this).find('.show-product-option').each(function () {
                        var productOptionId = $(this).val();
                        productOptions.find('.product-option-' + productOptionId).hide();
                    });
                }
            });
        }

        showHideOptions();
        $(document).on('change', 'input[type=checkbox]', function () {
            showHideOptions();
        });
        function updateMessage(productOption) {
            productOption.find('.product-option-appended-message').hide();
            // setTimeout(function() {
            productOption.find('.product-option-appended-message').remove();
            var message = '';
            productOption.find('input:checked').each(function () {
                var messageElement = $(this).closest('label').find('.product-option-message');
                if (messageElement.length > 0) {
                    message = message + '<div class="product-option-appended-message">' + messageElement.html() + '</div>';
                }
            });
            productOption.find('option:selected').each(function () {
                var messageElement = productOption.find('.product-option-message-' + $(this).val());
                if (messageElement.length > 0) {
                    message = message + '<div class="product-option-appended-message">' + messageElement.html() + '</div>';
                }
            });
            if (message.length > 0) {
                productOption.append(message);
            }
            productOption.find('.product-option-appended-message').show();
            //}, 500);
        }


        function wc_price(price, showFree, addSign) {
            price = parseFloat(price);
            price = price * woocommerce_product_options_settings.currency_multiplier;
            var negative = false;
            if (price == 0 && showFree === 'yes') {
                return woocommerce_product_options_settings.free;
            } else {
                if (price < 0) {
                    negative = true;
                }
                price = price.toFixed(woocommerce_product_options_settings.number_of_decimals);
                if (negative) {
                    price = price.replace('-', '');
                }
            }
            if (price.indexOf('.') >= 0) {
                var formatted_price_before_decimal = price.split('.')[0];
                if (formatted_price_before_decimal.length > 3) {
                    var i = formatted_price_before_decimal.length - 1;
                    var new_string = '';
                    var j = 0;
                    while (i >= 0) {
                        if (j % 3 == 0 && j > 0) {
                            new_string = woocommerce_product_options_settings.thousands_separator + new_string;
                        }
                        new_string = formatted_price_before_decimal[i] + new_string;
                        j++;
                        i--;
                    }
                    formatted_price_before_decimal = new_string;
                }
                var formatted_price_after_decimal = '';
                if (price.split('.').length > 0) {
                    formatted_price_after_decimal = price.split('.')[1];
                    price = formatted_price_before_decimal + woocommerce_product_options_settings.decimal_separator + formatted_price_after_decimal;
                } else {
                    price = formatted_price_before_decimal;
                }
            }
            var price_format = woocommerce_product_options_settings.price_format;
            if (addSign && negative) {
                price_format = '<span class="price-sign">-</span>' + price_format;
            } else if (addSign) {
                price_format = '<span class="price-sign">+</span>' + price_format;
            }
            var formatted_price = price_format.replace('%1$s', woocommerce_product_options_settings.currency_symbol).replace('%2$s', price);
            var returnValue = formatted_price;
            return returnValue;
        }

        function wpshowcaseParseFloat(stringToParse) {
            if (typeof stringToParse == 'undefined') {
                return 0;
            }
            return parseFloat(stringToParse);
        }

        function getOptionPrice(productOption, productPrice) {
            var taxProportion = parseFloat(productOption.closest('.product-options').find('.product-options-tax-proportion').val());
            productOption.find('.required-error').remove();
            if ($('.required-error').length == 1) {
                $('.required-error').remove();
            }
            var price = 0;
            var type = productOption.find('.product-option-type').val();
            if (type == 'radio' || type == 'select' || type == 'radio_image' || type == 'checkboxes' || type == 'multi_select') {
                productOption.find('input:checked').each(function () {
                    var label = $(this).closest('label');
                    price += parseFloat(label.find('.product-option-option-price').val());
                    price += parseFloat(label.find('.product-option-option-percentage-price').val()) * productPrice / 100;
                });
                productOption.find('option:selected').each(function () {
                    var optionId = $(this).attr('value');
                    var span = productOption.find('.product-option-option-' + optionId + '-data');
                    price += parseFloat(span.find('.product-option-option-price').val());
                    price += parseFloat(span.find('.product-option-option-percentage-price').val()) * productPrice / 100;
                });
            } else if (type == 'text' || type == 'textarea') {
                var priceIfNotEmpty = wpshowcaseParseFloat(productOption.find('.product-option-price-if-not-empty').val());
                var pricePerCharacter = wpshowcaseParseFloat(productOption.find('.product-option-price-per-character').val());
                var pricePerWord = wpshowcaseParseFloat(productOption.find('.product-option-price-per-word').val());
                var pricePerLowerCaseCharacter = wpshowcaseParseFloat(productOption.find('.product-option-price-per-lower-case-character').val());
                var pricePerUpperCaseCharacter = wpshowcaseParseFloat(productOption.find('.product-option-price-per-upper-case-character').val());
                var value = productOption.find('input[type=text],textarea').val();
                value = $.trim(value);
                if (value != '' && $.isNumeric(priceIfNotEmpty)) {
                    price += priceIfNotEmpty;
                }
                var len = value.length;
                var words = value.match(/\S+/g);
                var numberOfWords = 0;
                if (words != null) {
                    numberOfWords = words.length;
                }
                var numberOfCharacters = value.length;
                var numberOfLowerCaseCharacters = 0;
                for (var i = 0; i < len; i++) {
                    if (/[a-z]/.test(value.charAt(i)))
                        numberOfLowerCaseCharacters++;
                }
                var numberOfUpperCaseCharacters = 0;
                for (var i = 0; i < len; i++) {
                    if (/[A-Z]/.test(value.charAt(i)))
                        numberOfUpperCaseCharacters++;
                }
                price += numberOfWords * pricePerWord + numberOfCharacters * pricePerCharacter + pricePerLowerCaseCharacter * numberOfLowerCaseCharacters + pricePerUpperCaseCharacter * numberOfUpperCaseCharacters;
            } else if (type == 'number' || type == 'number_as_text' || type == 'range') {
                var value = productOption.find('.product-option-value').val();
                if (value === '') {
                    value = 0;
                }
                var startingFrom = parseFloat(productOption.find('.product-option-starting-from').val());
                var percentagePrice = parseFloat(productOption.find('.product-option-percentage-price').val());
                price = (parseFloat(value) - startingFrom) * percentagePrice / 100;
            } else if (type == 'checkbox') {
                if (productOption.find('input[type="checkbox"]:checked').length > 0) {
                    price = parseFloat(productOption.find('.product-option-checked-price').val());
                } else {
                    price = parseFloat(productOption.find('.product-option-unchecked-price').val());
                }
            } else if (type == 'image_upload') {
                var src = productOption.find('.product-options-image-upload').val();
                var defaultFileName = productOption.find('.product-option-default-file-name').val();
                if (src.indexOf(defaultFileName) < 0) {
                    price = parseFloat(productOption.find('.product-option-price-for-image').val());
                }
            }
            return price * taxProportion;
        }

        function getFloat(stringValue) {
            if (stringValue == '') {
                return 0;
            }
            return parseFloat(stringValue);
        }

        function updateShippingInfo(product) {
            if (product.closest('.products').length > 0) {
                return;
            }
            var weight = parseFloat(product.find('.product-weight').val());
            var length = parseFloat(product.find('.product-length').val());
            var width = parseFloat(product.find('.product-width').val());
            var height = parseFloat(product.find('.product-height').val());
            var volume = length * width * height;
            product.find('.product-option-radio input[type=radio],.product-option-checkboxes input[type=checkbox],' +
                    '.product-option-radio_image input[type=radio],.product-option-radio_image input[type=checkbox],' +
                    '.product-option-select option, .product-option-multi_select option').each(function () {
                if (!$(this).is(':checked') && !$(this).is(':selected')) {
                    return;
                }
                var suboptionId = $(this).val();
                if (suboptionId == '') {
                    return;
                }
                var productOption = $(this).closest('.product-option');
                weight += getFloat(productOption.find('.product-option-weight-' + suboptionId).val());
                var suboptionLength = getFloat(productOption.find('.product-option-length-' + suboptionId).val());
                var suboptionWidth = getFloat(productOption.find('.product-option-width-' + suboptionId).val());
                var suboptionHeight = getFloat(productOption.find('.product-option-height-' + suboptionId).val());
                var suboptionVolume = suboptionLength * suboptionWidth * suboptionHeight;
                if (suboptionVolume > volume) {
                    length = suboptionLength;
                    width = suboptionWidth;
                    height = suboptionHeight;
                    volume = suboptionVolume;
                }
            });
            $('.shop_attributes .product_weight').text(woocommerce_product_options_settings.weight_format.replace('[weight]', weight));
            $('.shop_attributes .product_dimensions').text(woocommerce_product_options_settings.dimensions_format.replace('[length]', length).replace('[width]', width).replace('[height]', height));
        }

        function getPrice(saleOrNonSalePrice, optionChanged, summary) {
            var taxProportion = parseFloat(optionChanged.closest('.product-options').find('.product-options-tax-proportion').val());
            var totalPrice = saleOrNonSalePrice;
            summary.find('.product-option:visible').each(function () {
                var productOptionPrice = getOptionPrice($(this), productPrice);
                if ($(this).find('.show-price').val() != 'no_display_price') {
                    totalPrice += productOptionPrice;
                }
            });
            totalPrice *= taxProportion;
            return totalPrice;
        }

        function updateOptionChanged(optionChanged) {
            if ($('table.variations').length == 0) {
                productPrice = parseFloat(optionChanged.closest('.product-options').find('.product-options-product-price').val());
            }
            var showPrice = optionChanged.closest('.product-option').find().val();
            if (showPrice == 'no_display_price') {
                return;
            }
            optionChanged = optionChanged.closest('.product-option');
            var summary = optionChanged.closest('.summary, .product-top,  .product-option-summary-wrapper, .main-data, .product-info, li.product, .product');

            var optionPrice = getOptionPrice(optionChanged, productPrice);

            var amountToUpdate = summary.find('.price');
            var totalPrice = getPrice(salePrice, optionChanged, summary);
            var nonsaleAmountToUpdate = '';
            amountToUpdate.each(function () {
                if ($(this).find('ins').length > 0) {
                    nonsaleAmountToUpdate = amountToUpdate.find('del').find('.amount');
                    $(this).find('ins').find('.amount').html(wc_price(totalPrice, 'yes', false));
                } else {
                    var updateElement = $(this);
                    if ($(this).find('.amount').length > 0) {
                        updateElement = $(this).find('.amount');
                    }
                    updateElement.html(wc_price(totalPrice, 'yes', false));
                }
            });
            var optionPriceToUpdate = optionChanged.closest('.product-option').find('.current-price');
            if (showPrice == 'total') {
                optionPriceToUpdate.html(wc_price(totalPrice, showFree, true));
            } else if (showPrice == 'yes') {
                var optionPriceToUpdate = optionChanged.closest('.product-option').find('.current-price');
                optionPriceToUpdate.html(wc_price(optionPrice, showFree, true));
            }
            if (nonsaleAmountToUpdate != '' && $('table.variations').length == 0) {
                productPrice = parseFloat(optionChanged.closest('.product-options').find('.product-options-product-nonsale-price').val());
            }
            if (nonsaleAmountToUpdate != '') {
                nonsaleAmountToUpdate.html(wc_price(getPrice(productPrice, optionChanged, summary), 'yes', false));
            }
            if (nonsaleAmountToUpdate != '' && $('table.variations').length == 0) {
                productPrice = parseFloat(optionChanged.closest('.product-options').find('.product-options-product-price').val());
            }
    }

    function updateSubOptionPrices(productPrice, totalPrice) {
        $('.product-option').each(function () {
            var needsUpdating = $(this).find('.show-price').val();
            if (needsUpdating !== 'yes') {
                return;
            }
            if ($(this).find('.product-option-option-price').length > 0) {
                var currentOptionPrice = getOptionPrice($(this), productPrice);
                var basePrice = totalPrice;
                if ($(this).find('input[type="checkbox"]').length === 0 && !$(this).hasClass('product-option-multi_select')) {
                    basePrice = totalPrice - currentOptionPrice;
                }
                var showFree = 'yes';
                if ($(this).find('.hide-free').length > 0 && $(this).find('.hide-free').val() === 'yes') {
                    showFree = 'no';
                }
                $(this).find('.product-option-option-data').each(function () {
                    var label = $(this).find('.product-option-option-label').val();
                    var id = $(this).find('.product-option-option-id').val();
                    var option = $(this).closest('.product-option').find('option[value="' + id + '"]');
                    var suboptionPrice = parseFloat($(this).find('.product-option-option-price').val()) + productPrice * parseFloat($(this).find('.product-option-option-percentage-price').val()) / 100;
                    if (option.is(':selected')) {
                        suboptionPrice = 0;
                    }
                    option.text(label + ' (' + wc_price(basePrice + suboptionPrice, showFree, false) + ')');
                });
                $(this).find('label .product-option-option-price').each(function () {
                    var label = $(this).closest('label');
                    var originalLabel = label.find('.product-option-option-label').val();
                    var suboptionPrice = parseFloat(label.find('.product-option-option-price').val()) + productPrice * parseFloat(label.find('.product-option-option-percentage-price').val()) / 100;
                    if (label.find('input[type="checkbox"]').length > 0 && label.find('input[type="checkbox"]').is(':checked')) {
                        suboptionPrice = 0;
                    }
                    label.find('.product-option-suboption-label').html(originalLabel + ' (' + wc_price(basePrice + suboptionPrice, showFree, false) + ')');
                });
            }
        });
    }

    function ajax_update_option(optionChanged, currentVariation) {
        optionChanged.trigger('update_option');
        if (optionChanged.length == 0) {
            return;
        }
        updateSelectedBoxEffect();
        var postType = optionChanged.closest('.product-options').find('.product-options-post-type').val();
        if (postType != 'order_option_group' && optionChanged.find('.upload-image').length == 0) {
            updateOptionChanged(optionChanged);
            return;
        }
        update_option_with_ajax(optionChanged);
    }

    function getProductOptionValue(optionChanged) {
        var productOption = optionChanged.val();
        if (optionChanged.closest('.product-option').find('input[type=checkbox].radio-image-radio').length > 0) {
            productOption = [];
            optionChanged.closest('.product-option').find('input[type=checkbox]:checked.radio-image-radio').each(function () {
                productOption.push($(this).val());
            });
        }
        if (optionChanged.closest('.product-option').find('input[type=checkbox].product-option-checkbox').length > 0) {
            productOption = '';
            if (optionChanged.closest('.product-option').find('input[type=checkbox].product-option-checkbox:checked').length > 0) {
                productOption = 'yes';
            }
        }
        var checkboxes = optionChanged.closest('.product-option').find('.checkboxes-checkbox');
        if (checkboxes.length > 0) {
            productOption = [];
            var optionId = optionChanged.closest('.product-option').find('.product-option-id').val();
            var optionPostId = optionChanged.closest('.product-options').find('.product-option-post-id').val();
            optionChanged.closest('.product-option').find('.checkboxes-checkbox:checked').each(function () {
                productOption.push($(this).attr('name').replace('product-options[' + optionPostId + '][' + optionId + '][', '').replace(']', ''));
            });
        }
        /*var radioImageCheckboxes = optionChanged.closest('.product-option').find('.radio-image-radio[type=checkbox]');
         if (radioImageCheckboxes.length > 0) {
         productOption = [];
         var optionId = optionChanged.closest('.product-option').find('.product-option-id').val();
         optionChanged.closest('.product-option').find('.radio-image-radio:checked').each(function () {
         productOption.push($(this).attr('name').replace('product-options[' + optionId + '][', '').replace(']', ''));
         });
         }*/
        return productOption;
    }

    function update_option_with_ajax(optionChanged) {
        return;
        //Disable cart button and options
        $('form.cart button').prop("disabled", true);
        $('form.cart button').css('opacity', '0.5');
        $('.product-option, .variations').find('input, select, textarea').prop("disabled", true);
        $('.product-option').find('input, select, textarea').css('opacity', '0.5');
        $('.product-option').find('input, select, textarea').css('opacity', '0.5');
        $('.variations').find('.value, .product_value, .product-value').css('opacity', '0.5');
        //Accordion
        var productOptions = optionChanged.closest('.product-options');
        if (productOptions.length > 0 && productOptions.find('.accordion-keep-open-on-select').val() == '' && productOptions.find('.accordion-expand').length > 0) {
            optionChanged.closest('.product-option').find('.product-option-accordion-content').hide(500);
            optionChanged.closest('.product-option').find('.accordion-expand').html('+');
        }
//Price
        var summary = optionChanged.closest('.summary, .product-top,  .product-option-summary-wrapper, .main-data, .product-info, li.product, .product');
        var amountToUpdate = $('.woocommerce-product-options-length-zero');
        if (summary.find('.variations').length > 0) {
            amountToUpdate = summary.find('.single-variation, .single_variation');
        }
        if (amountToUpdate.length == 0) {
            if ($('.price').length == 1 && $('.price .amount').length < 2) {
                amountToUpdate = $('.price');
            }
        }
        var optionPriceToUpdate = optionChanged.closest('.product-option').find('.current-price');
        var productOption = getProductOptionValue(optionChanged);
        var fpd_product_price = '';
        if ($('input[name=fpd_product_price]').length > 0) {
            fpd_product_price = $('input[name=fpd_product_price]').val();
        }

        var attributes = {};
        summary.find('.variations').find('input, select').each(function () {
            attributes[$(this).attr('name')] = $(this).val();
        });
        var post_id = optionChanged.closest('.product-options').find('.product-post-id').val();
        var product_option_post_id = optionChanged.closest('.product-option').find('.product-option-post-id').val();
        var product_option_id = optionChanged.closest('.product-option').find('.product-option-id').val();
        var variation_id = 0;
        if (summary.find('input[name="variation_id"]').length > 0) {
            variation_id = summary.find('input[name="variation_id"]').val();
        }
        optionChanged.find('.product-option-error').remove();
        $.post(woocommerce_product_options_settings.ajaxurl,
                {
                    'action': 'update_product_option',
                    'post_id': post_id,
                    'variation_id': variation_id,
                    'product_option_post_id': product_option_post_id,
                    'product_option': productOption,
                    'product_option_id': product_option_id,
                    'attributes': attributes,
                    fpd_product_price: fpd_product_price
                },
        function (response) {
            response = $.parseJSON(response);
            amountToUpdate.html(response.price);
            optionPriceToUpdate.html(response.option_price);
            if (response.src != '') {
                optionChanged.find('.upload-image').attr('src', response.src);
            }
            $('form.cart button').prop("disabled", false);
            $('form.cart button').css('opacity', '1');
            $('.product-option, .variations').find('input, select, textarea').prop("disabled", false);
            $('.product-option').find('input, select, textarea').css('opacity', '1');
            $('.variations').find('.value, .product_value, .product-value').css('opacity', '0.5');
            numberOfResponses--;
            if (numberOfResponses == 0) {
                $('.single_add_to_cart_button').click();
            }
            $('body').trigger('update_checkout');
        });
    }

    $(document).on('change', '.product-option:not(.product-option-tooltip)', function () {
        updateMessage($(this).closest('.product-option'));
    });
    $('.product-option:not(.product-option-tooltip)').each(function () {
        var productOption = $(this);
        updateMessage(productOption);
    });
    $(document).on('change', '.product-option input[type=checkbox], .product-option select', function () {
        var parent = $(this).closest('.product-option');
        if (parent.find('.max-selected').length == 0) {
            return;
        }
        var maxSelected = parseInt(parent.find('.max-selected').val());
        $('.max-checkboxes-error').remove();
        var numberSelected = parent.find('input[type=checkbox]:checked, option:selected').length;
        if (numberSelected > maxSelected) {
            $(this).removeAttr('checked');
            $(this).find('option:selected').removeAttr('selected');
            $(this).closest('.product-option').append('<span class="max-checkboxes-error product-option-error"> ' + woocommerce_product_options_settings.checkboxes_max_error + '</span>');
            updateMessage(parent);
            event.preventDefault();
        }
    });
    $('.product-option-datepicker').on('change', '.product-option-datepicker-div', function () {
        var productOption = $(this).closest('.product-option');
        var date = $.datepicker.formatDate($(this).datepicker('option', 'dateFormat'), $(this).datepicker('getDate'));
        productOption.find('.product-option-value').val(date);
    });
    function addDatepicker(element, options) {
        var productOption = element.closest('.product-option');
        options.defaultDate = productOption.find('.date-chosen').val();
        if (productOption.find('.disallow-past').val() != '') {
            options.minDate = -1;
        }
        if (productOption.find('.disallow-today').val() != '') {
            options.minDate = 0;
        }
        if (productOption.find('.disallow-weekends').val() != '') {
            options.beforeShowDay = function (date) {
                var day = date.getDay();
                if (day == 0 || day == 6) {
                    return new Array(false, '', date.toLocaleDateString());
                }
                return new Array(true, '', date.toLocaleDateString());
            }
        }
        var locale = productOption.find('.locale').val();
        if (locale != '') {
            element.datepicker($.datepicker.regional[ locale ]);
        } else {
            element.datepicker(options);
        }
    }
    $('.product-option-input-datepicker').each(function () {
        addDatepicker($(this), {});
    });
    $('.product-option-datepicker-div').each(function () {
        var nameOfInput = $(this).find('.name-of-input').val();
        addDatepicker($(this), {altField: 'input[name="' + nameOfInput + '"]',
            onSelect: function () {
                var productOption = $(this).closest('.product-option');
                var nameOfInput = productOption.find('.name-of-input').val();
                $('input[name="' + nameOfInput + '"]').change();
            }});
    });
    $('.datepicker-icon').each(function () {
        $(this).closest('.product-option').find('.product-option-datepicker-div').hide();
    });
    $(document).on('click', '.datepicker-icon', function (event) {
        $(this).closest('.product-option').find('.product-option-datepicker-div').show(1000);
        $(this).hide(1000);
        event.preventDefault();
    });
    $('.datepicker-icon-value').change(function () {
        /*var productOption = $(this).closest('.product-option');
         productOption.find('.datepicker-icon').show(1000);
         productOption.find('.product-option-datepicker-div').hide(1000);*/
    });
    $(document).on('click', '.accordion-group', function () {
        var productOptions = $(this).closest('.product-option-groups');
        productOptions.find('.product-option-accordion-group-content').hide(500);
        var thisAccordionExpand = $(this).find('.accordion-group-expand');
        var thisExpanded = false;
        if (thisAccordionExpand.text().indexOf('-') == -1) {
            $(this).closest('.product-option-group').find('.product-option-accordion-group-content').show(500);
            $(this).find('.accordion-group-expand').html('-');
            thisExpanded = true;
        } else {
            $(this).find('.accordion-group-expand').html('+');
            thisExpanded = false;
        }
    });
    $('.product-option-accordion-group-content').hide(500);
    $(document).on('click', '.accordion', function () {
        var productOptions = $(this).closest('.product-options');
        if (productOptions.find('.accordion-keep-open').val() == '') {
            productOptions.find('.product-option-accordion-content').hide(500);
        }
        var thisAccordionExpand = $(this).find('.accordion-expand');
        var thisExpanded = false;
        if (thisAccordionExpand.text().indexOf('+') != -1) {
            $(this).closest('.product-option').find('.product-option-accordion-content').show(500);
            thisExpanded = true;
        }
        if (productOptions.find('.accordion-keep-open').val() == '') {
            productOptions.find('.accordion-expand').html('+');
        } else {
            if (!thisExpanded) {
                $(this).closest('.product-option').find('.product-option-accordion-content').hide(500);
                $(this).find('.accordion-expand').html('+');
            }
        }
        if (thisExpanded) {
            $(this).find('.accordion-expand').html('-');
        }
    });
    $('.product-options').each(function () {
        if ($(this).find('.accordion').length > 0) {
            $('.product-option-accordion-content').hide();
        }
    });
    $(document).on('change', '.number-as-text', function () {
        $('.number-as-text-error').remove();
        $('.number-as-text').each(function () {
            if (!$.isNumeric($(this).val())) {
                $(this).after(woocommerce_product_options_settings.numeric_error);
            }
        });
    });
    $('.product-options').each(function () {
        $(this).find('input[type=text], textarea').keyup(function () {
            var productOption = $(this).closest('.product-option');
            var value = $(this).val();
            var numberOfLineBreaks = (value.match(/\n/g) || []).length;
            if (productOption.find('.maximum-number-of-characters').length > 0) {
                var maximumNumberOfCharacters = parseInt(productOption.find('.maximum-number-of-characters').val());
                var numberOfCharacters = parseInt($(this).val().length);
                if (numberOfCharacters - numberOfLineBreaks > maximumNumberOfCharacters) {
                    $(this).val(value.substring(0, maximumNumberOfCharacters + numberOfLineBreaks));
                }
            }
        })
    });
    $(document).on('change', '.product-option input, .product-options-image-upload, .product-option select, .product-option textarea', function () {
        var type = $(this).attr('type');
        if (typeof type != 'undefined' && type == 'hidden') {
            return;
        }
        ajax_update_option($(this), null);
    });
    $('.product-option-number .product-option-value').on('spinstop', function () {
        ajax_update_option($(this), null);
    });
    $(document.body).on('adding_to_cart', function (data1, data2, data) {
        var product = addToCartButton.closest('.product');
        var serializedOptions = product.find('.product-option-groups, .product-options, input[name=fpd_product_price]').not('form.cart .product-option-groups, form.cart .product-options, form.cart input[name=fpd_product_price]').find(':input[name]').serialize();
        $('.remove-me').remove();
        data['product-options-serialized-data'] = serializedOptions;
        /*var product = $(this).closest('.summary, .product-top, .product-option-
         product.find('.product-options-loop-wrapper').addClass('summary-wrapper, .main-data, .product-info, li.product, .product');
         var productPostId = product.find('.product-post-id').val();
         var productOptionss = {};
         $('.product-options').each(function () {
         var productOptions = {};
         var productOptionPostId = $(this).find('.product-option-post-id').val();
         $(this).find('.product-option').each(function () {
         var productOptionId = $(this).find('.product-option-id').val();
         var productOption = $(this).find('.product-option-value').val();
         var optionChanged = $(this);
         if (optionChanged.closest('.product-option').find('input[type=checkbox].radio-image-radio').length > 0) {
         productOption = [];
         optionChanged.closest('.product-option').find('input[type=checkbox]:checked.radio-image-radio').each(function () {
         productOption.push($(this).val());
         });
         }
         if (optionChanged.closest('.product-option').find('input[type=checkbox].product-option-checkbox').length > 0) {
         productOption = '';
         if (optionChanged.closest('.product-option').find('input[type=checkbox].product-option-checkbox:checked').length > 0) {
         productOption = 'yes';
         }
         }
         var checkboxes = optionChanged.closest('.product-option').find('.checkboxes-checkbox');
         if (checkboxes.length > 0) {
         productOption = [];
         var optionId = optionChanged.closest('.product-option').find('.product-option-id').val();
         var optionPostId = optionChanged.closest('.product-options').find('.product-option-post-id').val();
         optionChanged.closest('.product-option').find('.checkboxes-checkbox:checked').each(function () {
         productOption.push($(this).attr('name').replace('product-options[' + optionPostId + '][' + optionId + '][', '').replace(']', ''));
         });
         }
         productOptions[productOptionId] = productOption;
         });
         productOptionss[productOptionPostId] = productOptions;
         });
         data['variation_id'] = '';
         data['product_post_id'] = data.product_id;
         data['product-options'] = productOptionss;*/
        return true;
    });
    $(document).on('found_variation', 'form', function (event, currentVariation) {
        variation = currentVariation;
        var summary = $('.variations_form').closest('.summary, .product-top,  .product-option-summary-wrapper, .main-data, .product-info, li.product, .product');
        var taxProportion = parseFloat(summary.find('.product-options').find('.product-options-tax-proportion').val());
        if (variation != null) {
            productPrice = variation.display_regular_price / taxProportion;
            salePrice = variation.display_price / taxProportion;
        }
        return;
        if (salePrice != productPrice) {
            var taxProportion = parseFloat(summary.find('.product-options').find('.product-options-tax-proportion').val());
            var totalPrice = salePrice / taxProportion;
            summary.find('.product-option:visible').each(function () {
                var productOptionPrice = getOptionPrice($(this), productPrice);
                if ($(this).find('.show-price').val() != 'no_display_price') {
                    totalPrice += productOptionPrice;
                }
            });
            amountToUpdate = summary.find('del .amount');
            amountToUpdate.html(wc_price(totalPrice, 'yes', false));
        }
    });
    $('form').on('woocommerce_variation_has_changed', function () {
        var summary = $(this).closest('.summary, .product-top,  .product-option-summary-wrapper, .main-data, li.product, .product-info, .product');
        var productOptions = summary.find('.product-options');
        if (productOptions.length > 0) {
            ajax_update_option(productOptions.find('.product-option').find('input[type=color], input[type=text], input[type=number], input[type=checkbox], input[type=radio], input[type=checkbox], .product-options-image-upload, select, textarea').first(), variation);
        }
    });
    var updateTimer = null;
    $('.product-option').find('input[type=color], input[type=text], input[type=number], input[type=checkbox], input[type=radio], input[type=checkbox], .product-options-image-upload, select, textarea').keyup(function () {
        clearTimeout(updateTimer);
        var productOptionToUpdate = $(this);
        updateTimer = setTimeout(function () {
            ajax_update_option(productOptionToUpdate, null);
        }, 5000);
    });

    $(document).on('change', 'input[name=variation_id]', function () {
        if ($(this).closest('.summary, .product-top,  .product-option-summary-wrapper, .main-data, li.product, .product-info, .product').length == 0) {
            return;
        }
        if ($(this).val() != '' && $('.product-option .product-option-content').find('input, select, textarea').length > 0) {
            ajax_update_option($('.product-option .product-option-content').find('input, select, textarea').first(), null);
        }
    });
    $(document).on('change', 'input[name=fpd_product_price]', function () {
        ajax_update_option($('.product-option .product-option-content').find('input, select, textarea').first(), null);
    });
    $(document).on('change', '.product-option input[type=radio]', function () {
        $(this).closest('.product-option').find('.product-option-value').removeClass('product-option-value');
        $(this).addClass('product-option-value');
    });
    $('.product-option input[type=radio]:checked').addClass('product-option-value');
    $(document).on('change', '.radio-image-radio', function () {
        var img = $(this).closest('.radio-image-label').find('.radio-image-image');
        if (img.hasClass('change-thumb-on-select')) {
            if ($('.woocommerce-product-gallery .woocommerce-product-gallery__image').length < 1) {
                var imageToChange;
                if (img.closest('.product').find('.woocommerce-product-gallery img, img.woocommerce-main-image, .woocommerce-main-image img, .wp-post-image, #product-img-slider .product-slider-image, .thb-product-slideshow rsImg').length > 0) {
                    imageToChange = img.closest('.product').find('.woocommerce-product-gallery img, img.woocommerce-main-image, .woocommerce-main-image img, .wp-post-image, #product-img-slider .product-slider-image, .thb-product-slideshow rsImg');
                } else {
                    imageToChange = img.closest('.product').find('.images').find('img').first().attr('src', img.attr('src'));
                }
                imageToChange.attr('src', img.attr('src'));
                var srcset = img.attr('srcset');
                if (typeof srcset != 'undefined' && srcset != '') {
                    imageToChange.attr('srcset', img.attr('srcset'));
                } else {
                    imageToChange.removeAttr('srcset');
                }
                $('a.zoom, a[data-rel^=\'prettyPhoto\']').attr('href', img.attr('src'));
            } else if ($('.woocommerce-product-gallery .woocommerce-product-gallery__image').length == 1) {
                var srcset = img.attr('srcset');
                $('.woocommerce-product-gallery__image').attr('data-thumb', img.attr('src'));
                $('.woocommerce-product-gallery__image a').attr('href', img.attr('src'));
                var html = $('.woocommerce-product-gallery__image').find('img').each(function () {
                    $(this).attr('src', img.attr('src'));
                    $(this).attr('data-large_image', img.attr('src'));
                    $(this).attr('data-src', img.attr('src'));
                    if (typeof srcset != 'undefined' && srcset != '') {
                        $(this).attr('srcset', img.attr('srcset'));
                    } else {
                        $(this).removeAttr('srcset');
                    }
                });
                $('.woocommerce-product-gallery').data('product_gallery').$images = $('.woocommerce-product-gallery__image');
            } else {
                if ($('.product-options-temporary-flex-active-slide').length > 0) {
                    $('.flex-control-nav img').first().click();
                    var htmlOfSecondLastNav = $('.flex-control-nav li:nth-last-child(2)')[0].outerHTML;
                    $('.woocommerce-product-gallery').data('flexslider').removeSlide('.product-options-temporary-flex-active-slide');
                    $('.flex-control-nav').append(htmlOfSecondLastNav);
                    $('.product-options-temporary-flex-active-slide, .product-options-temporary-flex-active-thumb').remove();
                }
                var srcToReplace = $('.woocommerce-product-gallery__wrapper').first().find('img').attr('src');
                var clonedElement = $('.woocommerce-product-gallery__image').first().clone(true);
                var html = clonedElement.html().replace(new RegExp(srcToReplace, 'g'), img.attr('src'));
                $('.woocommerce-product-gallery__wrapper').append(clonedElement);
                $('.woocommerce-product-gallery__image').last().addClass('product-options-temporary-flex-active-slide').attr('data-thumb', img.attr('src')).html(html);
                $('.flex-control-nav').append('<li><img class="product-options-temporary-flex-active-thumb" src="' + img.attr('src') + '" /></li>');
                $('.woocommerce-product-gallery').data('flexslider').addSlide('.product-options-temporary-flex-active-slide');
                $('.flex-control-nav li').each(function () {
                    if ($(this).find('img').length == 0) {
                        $(this).remove();
                    }
                });
                $('.woocommerce-product-gallery').data('product_gallery').$images = $('.woocommerce-product-gallery__image');
                $('.flex-control-nav li img').last().click();
                if ($.browser.mozilla) {
                    setTimeout(function () {
                        $(window).resize();
                    }, 200);
                    setTimeout(function () {
                        $(window).resize();
                    }, 500);
                    setTimeout(function () {
                        $(window).resize();
                    }, 1100);
                }
            }
        }
    });
    $(document).on('click', '.flex-control-nav li img', function () {
        $('.change-thumb-on-select').each(function () {
            $(this).closest('.product-option').block({
                message: null,
                overlayCSS: {
                    background: '#fff',
                    opacity: 0.6
                }
            });
            var productOptionnToUnblock = $(this).closest('.product-option');
            setTimeout(function () {
                productOptionnToUnblock.unblock();
            }, 1000);
        });
    });
    $('.product-option-spinner').each(function () {
        $(this).spinner({
            min: 0, //$(this).attr('min'),
            max: 100, /// $(this).attr('max'),
            start: 3, //$(this).closest('.product-option').find('.product-option-value').val(),
            numberFormat: 'n',
            slide: function (event, ui) {
                $(this).closest('.product-option').find('.product-option-value').val(ui.value);
            }
        });
    });
    $('.product-option-slider').each(function () {
        $(this).slider({range: false,
            min: parseFloat($(this).attr('min')),
            max: parseFloat($(this).attr('max')),
            value: $(this).closest('.product-option').find('.product-option-value').val(),
            slide: function (event, ui) {
                $(this).closest('.product-option').find('.product-option-value').val(ui.value);
            }
        });
    });
    function updateRange(element) {
        var productOption = element.closest('.product-option');
        var unit = productOption.find('.range-unit').val();
        productOption.find('.range-value').remove();
        var productOptionValue = productOption.find('.product-option-value');
        productOption.find('.product-option-content').append('<span class="range-value"> ' + productOptionValue.val() + ' ' + unit + '</span>');
    }
    $('.product-option').find('.product-option-slider').mouseup(function () {
        ajax_update_option($(this).closest('.product-option').find('.product-option-value'), null);
        updateRange($(this));
    });
    $('.product-option').find('.product-option-slider').keyup(function () {
        ajax_update_option($(this).closest('.product-option').find('.product-option-value'), null);
        updateRange($(this));
    });
    $('.product-option .product-option-slider').each(function () {
        updateRange($(this));
    });

    function addError(productOption) {
        productOption.closest('.product-option-accordion-group-content, .product-option-accordion-content').show();
    }

    function checkForErrorsBeforeCartSubmit(form, event) {
        $('.required-error, .min-checkboxes-error').remove();
        var requiredErrorExists = false;
        form.find('.product-option:visible').not('.product .products .product-option').each(function () {
            var requiredProductOption = $(this).find('.required-product-option').first();
            if (requiredProductOption.length > 0) {
                if (requiredProductOption.attr('type') == 'checkbox' || requiredProductOption.attr('type') == 'radio') {
                    var productOption = requiredProductOption.closest('div.product-option');
                    var requiredErrorExistsForThisOption = true;
                    productOption.find('input[type="radio"], input[type="checkbox"]').each(function () {
                        if ($(this).is(':checked')) {
                            requiredErrorExistsForThisOption = false;
                        }
                    });
                    if (requiredErrorExistsForThisOption) {
                        addError(requiredProductOption);
                        requiredErrorExists = true;
                        if (requiredProductOption.closest('div.product-option').find('.required-error').length == 0) {
                            requiredProductOption.closest('div.product-option').append('<span class="required-error"> ' + woocommerce_product_options_settings.required_error + '</span>');
                        }
                    }
                } else if (requiredProductOption.hasClass('product-options-image-upload')) {
                    if (requiredProductOption.val() == "" || requiredProductOption.val().indexOf(requiredProductOption.closest('.product-option').find('.product-option-default-file-name').val()) > 0) {
                        addError(requiredProductOption);
                        requiredErrorExists = true;
                        requiredProductOption.closest('div.product-option').append('<span class="required-error"> ' + woocommerce_product_options_settings.required_error + '</span>');
                    }
                } else {
                    if (requiredProductOption.val().length == 0) {
                        addError(requiredProductOption);
                        requiredErrorExists = true;
                        requiredProductOption.after('<span class="required-error"> ' + woocommerce_product_options_settings.required_error + '</span>');
                    }
                }
                /*if (requiredProductOption.attr('type') == 'checkbox' && !requiredProductOption.hasClass('checkboxes-checkbox')) {
                 if (requiredProductOption.closest('.product-option').find(':checked').length == 0) {
                 addError(requiredProductOption);
                 requiredErrorExists = true;
                 requiredProductOption.after('<span class="required-error"> ' + woocommerce_product_options_settings.required_error + '</span>');
                 }
                 }*/
            }
        });
        form.find('.product-option .min-selected').each(function () {
            var minSelected = parseInt($(this).val());
            var parent = $(this).closest('.product-option');
            parent.find('.min-checkboxes-error').remove();
            var numberSelected = parent.find('input[type=checkbox]:checked, option:selected').length;
            if (numberSelected < minSelected) {
                parent.find('label, select').last().after('<span class="min-checkboxes-error product-option-error"> ' + woocommerce_product_options_settings.checkboxes_min_error + '</span>');
                addError($(this));
                requiredErrorExists = true;
            }
        });
        form.find('.product-options').find('.number-as-text, .product-option-number .product-option-value').each(function () {
            var min = $(this).attr('min');
            var max = $(this).attr('max');
            var value = $(this).val();
            if (isNaN(value)) {
                addError($(this));
                requiredErrorExists = true;
                $(this).after('<span class="required-error product-option-error"> ' + woocommerce_product_options_settings.number_error + '</span>');
            } else {
                value = parseFloat(value);
                if (typeof min != 'undefined') {
                    min = parseFloat(min);
                    if (min > value) {
                        addError($(this));
                        requiredErrorExists = true;
                        $(this).after('<span class="required-error product-option-error"> ' + woocommerce_product_options_settings.min_error + min + '</span>');
                    }
                }
                if (typeof max != 'undefined') {
                    max = parseFloat(max);
                    if (max < value) {
                        addError($(this));
                        requiredErrorExists = true;
                        $(this).after('<span class="required-error product-option-error"> ' + woocommerce_product_options_settings.max_error + max + '</span>');
                    }
                }
            }
        });
        if (requiredErrorExists) {
            form.find('.add_to_cart_button, form.cart button, #place_order, #place-order').after('<span class="required-error product-option-error">' + woocommerce_product_options_settings.error_exists + '</span>');
            event.preventDefault();
            return false;
        }
        return true;
    }

    $('.woocommerce').on('click', '#place_order, #place-order', function (event) {
        if (!checkForErrorsBeforeCartSubmit($('.woocommerce'), event)) {
            return false;
        }
        return true;
    });

    $(document).on('change', '.woocommerce-cart .product-options input, .woocommerce-cart .product-options input', function () {
        $(document.body).trigger('shipping_method_selected');
    });

    $(document).on('change', '.woocommerce-checkout .product-options input, .woocommerce-checkout .product-options select', function () {
        $(document.body).trigger('update_checkout');
    });

    $(document.body).on('update_checkout', function () {
        addToCartButton = $(this);
        var product = $(this).closest('.product');
        if (product.length == 1) {
            if (!checkForErrorsBeforeCartSubmit(product, event)) {
                return false;
            }
        }
        var multipleSelectValues = {};
        $('.product-option-groups select, .product-options select').each(function () {
            var name = $(this).attr('name');
            multipleSelectValues[name] = new Array();
            var i = 0;
            $(this).find('option:selected').each(function () {
                multipleSelectValues[name][i] = $(this).val();
                i++;
            });
        });
        $('.product-option-groups, .product-options, input[name=fpd_product_price]').find('.product-option:hidden').each(function () {
            var productOptionId = $(this).find('.product-option-id').val();
            var productOptionPostId = $(this).find('.product-option-post-id').val();
            $('.product-options').last().append('<input type="hidden" name="product-options-hidden[' + productOptionPostId + '][' + productOptionId + ']" value="yes" />');
        });
        var serializedOptions = $('.product-option-groups, .product-options, input[name=fpd_product_price]').not('form.cart .product-option-groups, form.cart .product-options, form.cart input[name=fpd_product_price]').find(':input[name]').serialize();
        $('.remove-me').remove();
        $('form.checkout').append('<input type="hidden" name="product-options-serialized-data" class="remove-me" value="' + serializedOptions + '" />');
    });
    $(document.body).on('updated_checkout', function () {
        $('.product-options-delete-me').remove();
    });
    $(document.body).on('updated_shipping_method', function () {
        $('.product-options-delete-me').remove();
    });

    $('form.cart, li.product, .product').on('click', '.add_to_cart_button, .single_add_to_cart_button, form.cart button, form.cart input[type=submit]', function (event) {
        addToCartButton = $(this);
        var product = $(this).closest('.product');
        if (product.length == 1) {
            if (!checkForErrorsBeforeCartSubmit(product, event)) {
                return false;
            }
        }
        var multipleSelectValues = {};
        $('.product-option-groups select, .product-options select').each(function () {
            var name = $(this).attr('name');
            multipleSelectValues[name] = new Array();
            var i = 0;
            $(this).find('option:selected').each(function () {
                multipleSelectValues[name][i] = $(this).val();
                i++;
            });
        });
        product.find('.product-option-groups, .product-options, input[name=fpd_product_price]').find('.product-option:hidden').each(function () {
            var productOptionId = $(this).find('.product-option-id').val();
            var productOptionPostId = $(this).find('.product-option-post-id').val();
            $('.product-options').last().append('<input type="hidden" name="product-options-hidden[' + productOptionPostId + '][' + productOptionId + ']" value="yes" />');
        });
        var serializedOptions = product.find('.product-option-groups, .product-options, input[name=fpd_product_price]').find(':input[name]').serialize();
        $('.remove-me').remove();
        $(this).closest('form').append('<input type="hidden" name="product-options-serialized-data" class="remove-me" value="' + serializedOptions + '" />');
        return true;
    });

    $(window).load(function () {
        $('.product-option').each(function () {
            var element = $(this).find('input[type=color], input[type=text], .product-options-image-upload, input[type=number], input[type=radio], input[type=checkbox], select, textarea').first();
            ajax_update_option(element, null);
        });
    });
    $('.product-options .product-option-tooltip').tooltip({
        track: true
    });
    $(document).on('click', '.radio-image-label', function (event) {
        if ($(this).find('input[type=radio]').length > 0) {
            var isChecked = $(this).find('input[type=radio]').attr('checked');
            $(this).closest('.product-option').find('input[type=radio]').removeAttr('checked');
            $(this).closest('.product-option').find('.selected-radio-image')
                    .removeClass('selected-radio-image');
            if (typeof isChecked == 'undefined') {
                $(this).find('input[type=radio]').attr('checked', 'checked');
                $(this).addClass('selected-radio-image');
            }
            $(this).find('input[type=radio]').change();
        } else {
            var checkbox = $(this).find('input[type=checkbox]');
            if (checkbox.attr('checked') == 'checked') {
                checkbox.removeAttr('checked');
            } else {
                checkbox.attr('checked', 'checked');
            }
            checkbox.change();
            var productOption = $(this).closest('.product-option');
            ajax_update_option($(this), null);
            productOption.find('.selected-radio-image').removeClass('selected-radio-image');
            productOption.find('input[type=checkbox]:checked').closest('.radio-image-label').addClass('selected-radio-image');
            //checkForErrorsBeforeCartSubmit( productOption.closest('.summary, .product-top,  .product-option-summary-wrapper, .main-data, .product-info, li.product'), event );
        }
    });
    $('.product-option-combobox select').comboboxPRO();
    }

    //$('.product-option-number .product-option-value').spinner();

    function getValuesOfImageUploads() {
        var imageUploadProductOptions = {};
        $('.product-option-image_upload').each(function () {
            var productOptionPostId = $(this).find('.product-option-post-id').val();
            var productOptionId = $(this).find('.product-option-id').val();
            if (typeof (imageUploadProductOptions[productOptionPostId]) == 'undefined') {
                imageUploadProductOptions[productOptionPostId] = {};
            }
            imageUploadProductOptions[productOptionPostId][productOptionId] = true;
        });
        $.post(woocommerce_product_options_settings.ajaxurl, {
            'action': 'is_upload_image_option_empty',
            'image_upload_product_options': imageUploadProductOptions
        }, function (response) {
            var responseArray = $.parseJSON(response);
            $.each(responseArray, function (index, value) {
                $.each(value, function (i2, v2) {
                    var productOption = $('.product-options-' + index + ' .product-option-' + i2);
                    productOption.find('.required-error').remove();
                    if ($('.required-error').length == 1) {
                        $('.required-error').remove();
                    }
                    productOption.find('.product-options-image-upload').val(v2);
                    var img = $(this).closest('.radio-image-label').find('.radio-image-image');
                    if (productOption.find('.change-thumb').length > 0 && productOption.find('.change-thumb').val() == 'yes') {
                        var imageToChange;
                        if (productOption.closest('.product').find('img.woocommerce-main-image, .woocommerce-main-image img, .wp-post-image, #product-img-slider .product-slider-image, .thb-product-slideshow rsImg').length > 0) {
                            imageToChange = productOption.closest('.product').find('img.woocommerce-main-image, .woocommerce-main-image img, .wp-post-image, #product-img-slider .product-slider-image, .thb-product-slideshow rsImg');
                        } else {
                            imageToChange = productOption.closest('.product').find('.images').find('img').first().attr('src', img.attr('src'));
                        }
                        imageToChange.attr('src', v2.src);
                        imageToChange.removeAttr('srcset');
                        $('a.zoom, a[data-rel^=\'prettyPhoto\']').attr('href', imageToChange.attr('src'));
                    }
                });
            });
            setTimeout(function () {
                getValuesOfImageUploads();
            }, 1000);
        });
    }
    if ($('.product-option-image_upload').length > 0) {
        getValuesOfImageUploads();
    }

    $('.variations select').change();

    function updateSelectedBoxEffect() {
        $('.box-effect-label, .box-effect-label-no-icon').each(function () {
            if ($(this).find('input[type=checkbox], input[type=radio]').is(':checked')) {
                $(this).addClass('selected-box-effect-label');
            } else {
                $(this).removeClass('selected-box-effect-label');
            }
        });
    }
    updateSelectedBoxEffect();

    $('.box-effect').closest('.product-option').find('input[type=checkbox], input[type=radio]').closest('label').addClass('box-effect-label');
    $('.box-effect-no-icon').closest('.product-option').find('input[type=checkbox], input[type=radio]').closest('label').addClass('box-effect-label').addClass('box-effect-label-no-icon');

});