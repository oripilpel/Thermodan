jQuery(document).ready(function ($) {

    function updateAnyProduct(checkbox) {
        if (!checkbox.is(':checked')) {
            $('.not-any-product').show();
        } else {
            $('.not-any-product').hide();
        }
    }

    $(document).on('change','.any-product',function () {
        updateAnyProduct($(this));
    });
    updateAnyProduct($('.any-product'));


    $(document).on('change','.product-option-group-categories',function () {
        if ($(this).find(':selected').length > 0) {
            $('.product-option-group-query').hide();
        } else {
            $('.product-option-group-query').show();
        }
    });

});