jQuery(function() {
    jQuery('.form-table .forminp #woocommerce_currency').parents('tr').remove();
    jQuery('.form-table .forminp #woocommerce_currency_pos').parents('tr').remove();
});

