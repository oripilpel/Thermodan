jQuery(document).ready(function () {
    jQuery('#tabs_color, #font_color, #inactive_tabs_color, #completed_tabs_color, #buttons_bg_color, #buttons_font_color, #form_labels_color').wpColorPicker();
});