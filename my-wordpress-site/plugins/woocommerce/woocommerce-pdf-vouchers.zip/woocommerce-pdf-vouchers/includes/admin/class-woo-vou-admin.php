<?php
// Exit if accessed directly
if (!defined('ABSPATH'))
    exit;

/**
 * Admin Class
 *
 * Handles generic Admin functionality and AJAX requests.
 *
 * @package WooCommerce - PDF Vouchers
 * @since 1.0.0
 */
class WOO_Vou_Admin {

    var $scripts, $model, $render, $voumeta, $voucher;

    public function __construct() {

        global $woo_vou_scripts, $woo_vou_model, $woo_vou_voucher,
        $woo_vou_render, $woo_vou_admin_meta;

        $this->scripts = $woo_vou_scripts;
        $this->model = $woo_vou_model;
        $this->render = $woo_vou_render;
        $this->voumeta = $woo_vou_admin_meta;
        $this->voucher = $woo_vou_voucher;
    }

    /**
     * Adding Submenu Page
     * 
     * Handles to adding submenu page for
     * voucher extension
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    public function woo_vou_admin_submenu() {

        global $current_user, $woo_vou_vendor_role;

        $main_menu_slug = WOO_VOU_MAIN_MENU_NAME;

        //Current user role
        $user_roles = isset($current_user->roles) ? $current_user->roles : array();
        $user_role = array_shift($user_roles);

        //get voucher admins
        $voucher_admins = woo_vou_assigned_admin_roles();

        //Remove Voucher Template menu
        remove_menu_page('edit.php?post_type=' . WOO_VOU_POST_TYPE);

        if (in_array($user_role, $voucher_admins) || in_array($user_role, $woo_vou_vendor_role)) {

            if (current_user_can('manage_woocommerce')) { // administrator or shop manager
                //voucher codes page
                $voucher_page = add_submenu_page($main_menu_slug, __('Voucher Codes', 'woovoucher'), __('Voucher Codes', 'woovoucher'), 'read', 'woo-vou-codes', 'woo_vou_codes_page');
            } else {

                $main_menu_slug = 'woo-vou-codes';
                //add WooCommerce Page
                add_menu_page(__('WooCommerce', 'woovoucher'), __('WooCommerce', 'woovoucher'), 'read', $main_menu_slug, '');
                add_submenu_page($main_menu_slug, __('Voucher Codes', 'woovoucher'), __('Voucher Codes', 'woovoucher'), 'read', $main_menu_slug, 'woo_vou_codes_page');
                add_submenu_page($main_menu_slug, __('Voucher Templates', 'woovoucher'), __('Voucher Templates', 'woovoucher'), 'read', 'edit.php?post_type=' . WOO_VOU_POST_TYPE);
            }

            //add check voucher code page
            $check_voucher_page = add_submenu_page($main_menu_slug, __('Check Voucher Code', 'woovoucher'), __('Check Voucher Code', 'woovoucher'), 'read', 'woo-vou-check-voucher-code', 'woo_vou_check_voucher_code_page');
        }
    }

    /**
     * Add Custom meta boxs  for voucher templates post tpye
     * 
     * Handles to add custom meta boxs in voucher templates
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    public function woo_vou_editor_meta_box() {

        global $wp_meta_boxes;

        // add metabox for edtior
        add_meta_box('woo_vou_page_voucher', __('Voucher', 'woovoucher'), 'woo_vou_editor_control', WOO_VOU_POST_TYPE, 'normal', 'high', 1);

        // add metabox for style options
        add_meta_box('woo_vou_pdf_options', __('Voucher Options', 'woovoucher'), 'woo_vou_pdf_options_page', WOO_VOU_POST_TYPE, 'normal', 'high');
    }

    /**
     * Custom column
     * 
     * Handles the custom columns to voucher listing page
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    public function woo_vou_manage_custom_column($column_name, $post_id) {

        global $wpdb, $post;

        $prefix = WOO_VOU_META_PREFIX;

        switch ($column_name) {

            case 'voucher_preview' :
                $preview_url = woo_vou_get_preview_link($post_id);
                echo '<a href="' . $preview_url . '" class="woo-vou-pdf-preview" target="_blank">' . __('View Preview', 'woovoucher') . '</a>';
                break;
        }
    }

    /**
     * Add New Column to voucher listing page
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    function woo_vou_add_new_columns($new_columns) {

        unset($new_columns['date']);

        $new_columns['voucher_preview'] = __('View Preview', 'woovoucher');
        $new_columns['date'] = _x('Date', 'column name', 'woovoucher');

        return $new_columns;
    }

    /**
     * Add New Action For Create Duplicate
     * 
     * Handles to add new action for 
     * Create Duplicate link of that voucher
     *
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    public function woo_vou_dupd_action_new_link_add($actions, $post) {

        //check current user can have administrator rights
        //post type must have vouchers post type
        if (!current_user_can('manage_options') || $post->post_type != WOO_VOU_POST_TYPE)
            return $actions;

        // add new action for create duplicate
        $args = array('action' => 'woo_vou_duplicate_vou', 'woo_vou_dupd_vou_id' => $post->ID);
        $dupdurl = add_query_arg($args, admin_url('edit.php'));
        $actions['woo_vou_duplicate_vou'] = '<a href="' . wp_nonce_url($dupdurl, 'duplicate-vou_' . $post->ID) . '" title="' . __('Make a duplicate from this voucher', 'woovoucher')
                . '" rel="permalink">' . __('Duplicate', 'woovoucher') . '</a>';

        // return all actions
        return $actions;
    }

    /**
     * Add Preview Button
     * 
     * Handles to add preview button within
     * Publish meta box
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    function woo_vou_add_preview_button() {

        global $typenow, $post;

        if (!current_user_can('manage_options') || !is_object($post) || $post->post_type != WOO_VOU_POST_TYPE) {
            return;
        }

        if (isset($_GET['post'])) {

            $args = array('action' => 'woo_vou_duplicate_vou', 'woo_vou_dupd_vou_id' => absint($_GET['post']));
            $dupdurl = add_query_arg($args, admin_url('edit.php'));
            $notifyUrl = wp_nonce_url($dupdurl, 'duplicate-vou_' . $_GET['post']);
            ?>
            <div id="duplicate-action"><a class="submitduplicate duplication" href="<?php echo esc_url($notifyUrl); ?>"><?php _e('Copy to a new draft', 'woovoucher'); ?></a></div>
            <?php
        }

        $preview_url = woo_vou_get_preview_link($post->ID);
        echo '<a href="' . $preview_url . '" class="button button-secondary button-large woo-vou-pdf-preview-button" target="_blank">' . __('Preview', 'woovoucher') . '</a>';
    }

    /**
     * Add Voucher Details meta box within Order
     *
     * @package WooCommerce - PDF Vouchers
     * @since 1.1.0
     */
    public function woo_vou_order_meta_boxes() {

        add_meta_box('woo-vou-order-voucher-details', __('Voucher Details', 'woovoucher'), 'woo_vou_display_voucher_data', WOO_VOU_MAIN_SHOP_POST_TYPE, 'normal', 'default');
    }

    /**
     * Download Pdf by admin
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 2.0.3
     */
    public function woo_vou_admin_voucher_pdf_download() {

        global $current_user;

        if (!empty($_GET['download_file']) && !empty($_GET['key']) && !empty($_GET['woo_vou_admin']) && !empty($_GET['woo_vou_order_id'])) {

            if (current_user_can('moderate_comments')) {

                $product_id = (int) $_GET['download_file'];
                $email = sanitize_email(str_replace(' ', '+', $_GET['email']));
                $download_id = isset($_GET['key']) ? preg_replace('/\s+/', ' ', $_GET['key']) : '';
                $order_id = $_GET['woo_vou_order_id'];
                $item_id = isset($_GET['item_id']) ? $_GET['item_id'] : '';

                //Generate PDF
                $this->voucher->woo_vou_generate_pdf_voucher($email, $product_id, $download_id, $order_id, $item_id);
            } else {

                wp_die('<p>' . __('You are not allowed to access this URL.', 'woovoucher') . '</p>');
            }

            exit;
        }
    }

    /**
     * Send Gift notification email using cron jobs
     *
     * @package WooCommerce - PDF Vouchers
     * @since 2.8.1
     */
    public function woo_vou_send_gift_notification_email() {

        global $vou_order;

        //Get prefix
        $prefix = WOO_VOU_META_PREFIX;

        // get all orders	
        $woo_vou_get_all_orders = get_posts(array(
            'numberposts' => -1,
            'post_type' => 'shop_order',
            'post_status' => array('wc-processing', 'wc-completed')
                ));

        // loop through orders
        foreach ($woo_vou_get_all_orders as $woo_vou_order) {

            $order_id = $vou_order = $woo_vou_order->ID; // order id
            $cart_details = wc_get_order($order_id); // get order details
            $order_items = $cart_details->get_items(); // get order items
            $order_status = woo_vou_get_order_status($cart_details); // Get order status

            if ($order_status == 'processing' && get_option('woocommerce_downloads_grant_access_after_payment') == 'no') {
                continue;
            }

            // record the fact that the vouchers have been sent
            if (get_post_meta($order_id, $prefix . 'recipient_email_sent', true)) {
                continue;
            }

            if (!empty($order_items)) { //if item is empty
                foreach ($order_items as $product_item_key => $product_data) {

                    $product_id = isset($product_data['product_id']) ? $product_data['product_id'] : '';
                    $variation_id = isset($product_data['variation_id']) ? $product_data['variation_id'] : '';

                    //Initilize recipient detail
                    $recipient_details = array();

                    //Get product item meta
                    $product_item_meta = isset($product_data['item_meta']) ? $product_data['item_meta'] : array();

                    // get recipient details
                    $recipient_details = $this->model->woo_vou_get_recipient_data($product_item_meta);

                    $recipient_details['recipient_giftdate'] = !empty($recipient_details['recipient_giftdate']) ? $recipient_details['recipient_giftdate'] : '';
                    $recipient_details['recipient_giftdate'] = apply_filters('woo_vou_replace_giftdate', $recipient_details['recipient_giftdate'], $order_id, $product_item_key);

                    // if empty recipient giftdate then check next items
                    if (empty($recipient_details['recipient_giftdate'])) {
                        continue;
                    }

                    // today date
                    $woo_vou_today_date = $this->model->woo_vou_current_date('Y-m-d');

                    // recipient gift date
                    $woo_vou_order_gift_date = $recipient_details['recipient_giftdate'];

                    // if today date and gift date is same then send gift notification email
                    if (strtotime($woo_vou_today_date) == strtotime($woo_vou_order_gift_date)) {

                        $payment_user_info = $this->model->woo_vou_get_buyer_information($order_id); // Get payment information
				        $first_name = $payment_user_info['first_name']; // Get billing first name
				        $last_name = $payment_user_info['last_name']; // Get billing last name
                        $_product = apply_filters('woocommerce_order_item_product', $cart_details->get_product_from_item($product_data), $product_data);

                        if (!$_product) { //If product deleted
                            $download_file_data = array();
                        } else {
                            $download_file_data = $this->model->woo_vou_get_item_downloads_from_order($cart_details, $product_data);
                        }

                        $links = array();
                        $i = 0;
                        $attach_key = array();

                        foreach ($download_file_data as $key => $download_file) {

                            $check_key = strpos($key, 'woo_vou_pdf_');

                            if (!empty($download_file) && $check_key !== false) {

                                $attach_keys[] = $key;
                                $i++;
                                $links[] = '<small><a href="' . esc_url($download_file['download_url']) . '">' . sprintf(__('Download file%s', 'woovoucher'), ( count($download_file_data) > 1 ? ' ' . $i . ': ' : ': ')) . esc_html($download_file['name']) . '</a></small>';
                            }
                        }

                        $recipient_details['recipient_voucher'] = '<br/>' . implode('<br/>', $links);

                        // added filter to send extra emails on diferent email ids by other extensions
                        $woo_vou_extra_emails = false;
                        $woo_vou_extra_emails = apply_filters('woo_vou_pdf_recipient_email', $woo_vou_extra_emails, $product_id);

                        if (( isset($recipient_details['recipient_email']) && !empty($recipient_details['recipient_email']) ) ||
                                (!empty($woo_vou_extra_emails) )) {

                            $recipient_name = isset($recipient_details['recipient_name']) ? $recipient_details['recipient_name'] : '';
                            $recipient_email = isset($recipient_details['recipient_email']) ? $recipient_details['recipient_email'] : '';
                            $recipient_message = isset($recipient_details['recipient_message']) ? '"' . nl2br($recipient_details['recipient_message']) . '"' : '';
                            $recipient_voucher = isset($recipient_details['recipient_voucher']) ? $recipient_details['recipient_voucher'] : '';

                            // Get Extra email if passed through filter
                            $woo_vou_extra_emails = !empty($woo_vou_extra_emails) ? $woo_vou_extra_emails : '';

                            $attachments = array();

                            if (get_option('vou_attach_mail') == 'yes') { //If attachment enable
                                //Get product/variation ID
                                $product_id = !empty($product_data['variation_id']) ? $product_data['variation_id'] : $product_data['product_id'];

                                if (!empty($attach_keys)) {//attachments keys not empty
                                    foreach ($attach_keys as $attach_key) {

                                        $attach_pdf_file_name = get_option('attach_pdf_name');
                                        $attach_pdf_file_name = !empty($attach_pdf_file_name) ? $attach_pdf_file_name : 'woo-voucher-';

                                        // Replacing voucher pdf name with given value
                                        $orderdvoucode_key = str_replace('woo_vou_pdf_', $attach_pdf_file_name, $attach_key);

                                        //Voucher attachment path
                                        $vou_pdf_path = WOO_VOU_UPLOAD_DIR . $orderdvoucode_key . '-' . $product_id . '-' . $product_item_key . '-' . $order_id; // Voucher pdf path
                                        $vou_pdf_name = $vou_pdf_path . '.pdf';

                                        // If voucher pdf exist in folder
                                        if (file_exists($vou_pdf_name)) {

                                            // Adding the voucher pdf in attachment array
                                            $attachments[] = apply_filters('woo_vou_gift_email_attachments', $vou_pdf_name, $order_id, $product_data);
                                        } else { // If voucher pdf doesn't exist then we will generate that
                                            // Call function to generate Voucher PDF
                                            $attachments = apply_filters('woo_vou_gift_email_attachments', woo_vou_attach_voucher_to_email(array(), 'customer_processing_order', $cart_details), $order_id, $product_data);
                                        }
                                    }
                                }
                            }

                            //Get All Data for gift notify
                            $gift_data = array(
                                'first_name' => $first_name,
                                'last_name' => $last_name,
                                'recipient_name' => $recipient_name,
                                'recipient_email' => $recipient_email,
                                'recipient_message' => $recipient_message,
                                'voucher_link' => $recipient_voucher,
                                'attachments' => $attachments,
                                'woo_vou_extra_emails' => $woo_vou_extra_emails,
                                'order_id' => $order_id
                            );

                            // Fires when gift notify.
                            do_action('woo_vou_gift_email', $gift_data);
                        }

                        //Update post meta for email attachment issue
                        update_post_meta($order_id, $prefix . 'recipient_email_sent', true);
                    }
                }

                // Add action after gift email is sent
                do_action('woo_vou_after_gift_email', $order_id);
            }
        }
    }

    /**
     * Handles to insert html fieldsa on
     * coupon add / edit page
     *
     * @package WooCommerce - PDF Vouchers
     * @since 2.9.2
     */
    public function woo_vou_coupon_options() {

        global $post;

        $prefix = WOO_VOU_META_PREFIX;

        // Disable redeem voucher
        $redeem_days = array(
            'Monday' => __('Monday', 'woovoucher'),
            'Tuesday' => __('Tuesday', 'woovoucher'),
            'Wednesday' => __('Wednesday', 'woovoucher'),
            'Thursday' => __('Thursday', 'woovoucher'),
            'Friday' => __('Friday', 'woovoucher'),
            'Saturday' => __('Saturday', 'woovoucher'),
            'Sunday' => __('Sunday', 'woovoucher')
        );

        // Get coupon type
        $woo_vou_coupon_type = get_post_meta($post->ID, $prefix . 'coupon_type', true);

        // Start date
        woocommerce_wp_text_input(array('id' => $prefix . 'start_date', 'label' => __('Coupon start date', 'woovoucher'), 'placeholder' => _x('YYYY-MM-DD', 'placeholder', 'woovoucher'), 'description' => '', 'class' => 'date-picker', 'custom_attributes' => array('pattern' => "[0-9]{4}-(0[1-9]|1[012])-(0[1-9]|1[0-9]|2[0-9]|3[01])")));

        if (!empty($post)) { // if post is not empty
            $post_id = $post->ID; // Get post id
            // Get meta
            $coupon_type = get_post_meta($post_id, $prefix . 'coupon_type', true); // Get coupon type
        }
        ?>
        <p class="form-field"><label for="product_categories"><?php _e('Choose which days coupon can not be used', 'woovoucher'); ?></label>
            <select id="disable_redeem_days" name="<?php echo $prefix; ?>disable_redeem_days[]" style="width: 50%;"  class="wc-enhanced-select" multiple="multiple" data-placeholder="<?php esc_attr_e('Select days', 'woovoucher'); ?>">
        <?php
        $rest_days_meta = (array) get_post_meta($post->ID, $prefix . 'disable_redeem_day', true);

        if ($redeem_days)
            foreach ($redeem_days as $redeem_day_key => $redeem_day_val) {
                echo '<option value="' . $redeem_day_key . '"' . selected(in_array($redeem_day_key, $rest_days_meta), true, false) . '>' . $redeem_day_val . '</option>';
            }
        ?>
            </select> <?php echo wc_help_tip(__('If you want to restrict use of Coupon Code for specific days, you can select days here. Leave it blank for no restriction.', 'woovoucher')); ?></p>
        <?php
        // Coupon type
        if (!empty($woo_vou_coupon_type) && $woo_vou_coupon_type == 'voucher_code') {
            echo '<p class="form-field"><label for="product_categories">' . __('Coupon Type', 'woovoucher') . '</label>';
            echo '<span>' . __('Voucher Code', 'woovoucher') . '</span></p>';
        }
    }

    /**
     * Handles to add voucher price in product meta
     * under sale price
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 2.9.8
     */
    public function woo_vou_product_options_add_voucher_price() {

        $prefix = WOO_VOU_META_PREFIX; // Get prefix

        $price_options = get_option('vou_voucher_price_options'); // Get voucher price options
        // Check if price_option is set to voucher price
        if (!empty($price_options) && $price_options == 2) {

            // Add Voucher Price field below Sale Price field in product meta settings
            woocommerce_wp_text_input(array('id' => $prefix . 'voucher_price', 'label' => __('Voucher price', 'woovoucher') . ' (' . get_woocommerce_currency_symbol() . ')', 'data_type' => 'price'));
        }
    }

    /**
     * Adding Hooks
     *
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    public function add_hooks() {

        if (woo_vou_is_edit_page()) {

            //add content for import voucher codes in footer
            add_action('admin_footer', 'woo_vou_import_footer');
        }

        //add filter to add settings
        //add_filter( 'woocommerce_general_settings', array( $this->model, 'woo_vou_settings') );
        //add action to import csv file for codes with Ajaxform
        add_action('init', 'woo_vou_import_codes');

        //add submenu page
        add_action('admin_menu', array($this, 'woo_vou_admin_submenu'));

        //AJAX action for import code
        add_action('wp_ajax_woo_vou_import_code', 'woo_vou_import_code');
        add_action('wp_ajax_nopriv_woo_vou_import_code', 'woo_vou_import_code');

        //add new field to voucher listing page
        add_action('manage_' . WOO_VOU_POST_TYPE . '_posts_custom_column', array($this, 'woo_vou_manage_custom_column'), 10, 2);
        add_filter('manage_edit-' . WOO_VOU_POST_TYPE . '_columns', array($this, 'woo_vou_add_new_columns'));

        //add action to add custom metaboxes on voucher template post type
        add_action('add_meta_boxes', array($this, 'woo_vou_editor_meta_box'));

        //saving voucher meta on update or publish voucher template post type
        add_action('save_post', 'woo_vou_save_metadata');

        //ajax call to edit all controls
        add_action('wp_ajax_woo_vou_page_builder', array($this->render, 'woo_vou_page_builder'));
        add_action('wp_ajax_nopriv_woo_vou_page_builder', array($this->render, 'woo_vou_page_builder'));

        //add filter to add new action "duplicate" on admin vouchers page
        add_filter('post_row_actions', array($this, 'woo_vou_dupd_action_new_link_add'), 10, 2);

        //add action to add preview button after update button
        add_action('post_submitbox_start', array($this, 'woo_vou_add_preview_button'));

        //add action to create duplicate voucher
        add_action('admin_init', 'woo_vou_duplicate_process');

        //add filter to display vouchers by menu order with ascending order
        add_filter('posts_orderby', 'woo_vou_edit_posts_orderby');

        // Add product meta field in product price option
        add_action('woocommerce_product_options_pricing', array($this, 'woo_vou_product_options_add_voucher_price'));

        // Add Voucher settings in variation pricing option
        add_action('woocommerce_variation_options_pricing', 'woo_vou_variation_options_add_voucher_price', 10, 3);

        // add metabox in products
        add_action('woocommerce_product_write_panel_tabs', array($this->voumeta, 'woo_vou_product_write_panel_tab'));

        // To make compatible with previous versions of 3.0.0
        if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1) {
            // woocommerce_product_write_panels is deprecated since version 2.6!
            add_action('woocommerce_product_write_panels', array($this->voumeta, 'woo_vou_product_write_panel'));
        } else {
            add_action('woocommerce_product_data_panels', array($this->voumeta, 'woo_vou_product_write_panel'));
        }
        add_action('woocommerce_process_product_meta', 'woo_vou_product_save_data', 20, 2);

        //add action to display voucher history
        add_action('add_meta_boxes', array($this, 'woo_vou_order_meta_boxes'), 35);

        //add action to delete order meta when woocommerce order delete
        add_action('before_delete_post', 'woo_vou_order_delete');

        // add action to add an extra fields in edit user page
        add_action('edit_user_profile', 'woo_vou_user_edit_profile_fields');

        // add action to store user meta in database
        add_action('edit_user_profile_update', 'woo_vou_update_profile_fields');

        // Action for product variation meta
        add_action('woocommerce_product_after_variable_attributes', 'woo_vou_product_variable_meta', 10, 3);

        // Action to save product variation meta
        add_action('woocommerce_save_product_variation', 'woo_vou_product_save_variable_meta', 10, 2);

        // Action to flush the voucher upload dir
        add_action('woo_vou_flush_upload_dir_cron', 'woo_vou_flush_upload_dir');

        //File download access to admin
        add_action('init', array($this, 'woo_vou_admin_voucher_pdf_download'), 9);

        //Add downloadable option for Woocommerce-Booking plugin
        add_filter('product_type_options', 'woo_vou_booking_product_type_options');

        //add action for email templates classes for woo pdf vouchers
        add_filter('woocommerce_email_classes', 'woo_vou_add_email_classes');

        // Add action for delete voucher codes
        add_action('admin_init', 'woo_vou_delete_vou_codes');

        // Add action to send gift notification email ( daily cron )
        add_action('woo_vou_send_gift_notification', array($this, 'woo_vou_send_gift_notification_email'));

        // Add filter to change Order Status to 'on-hold', while checkout with COD, if PDF VOucher is enabled
        add_filter('woocommerce_cod_process_payment_order_status', 'woocommerce_cod_process_payment_order_status_func', 999, 2);

        // Add action to add custom fields on coupon page
        add_action('woocommerce_coupon_options', array($this, 'woo_vou_coupon_options'));

        // Add action to save custom fields on coupon page
        add_action('woocommerce_coupon_options_save', 'woo_vou_save_coupon_options', 15);

        // Add filter to modify get vouchers args
        add_filter('woo_vou_get_vouchers_args', 'woo_vou_get_vouchers_args_func', 10, 1);

        // Add action to modify custom query in post list
        add_action('parse_query', 'woo_vou_post_list_query_filter_func');

        // Add action to modify post variable before data gets saved
        add_filter('woocommerce_coupon_code', 'woo_vou_save_coupon_code');

        // Add filter for adding plugin settings
        add_filter('woocommerce_get_settings_pages', 'woo_vou_admin_settings_tab');

        // Ajax call to pre submit product start and end date validate
        add_action('wp_ajax_woo_vou_product_pre_submit_validation', 'woo_vou_product_pre_submit_validation');
        add_action('wp_ajax_nopriv_woo_vou_product_pre_submit_validation', 'woo_vou_product_pre_submit_validation');

        // Add action to allow only images in media uploader
        add_action('admin_footer-post-new.php', 'woo_vou_mediapanel_allow_only_images');
        add_action('admin_footer-post.php', 'woo_vou_mediapanel_allow_only_images');
    }
}
