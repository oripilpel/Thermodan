<?php 

// Exit if accessed directly
if ( !defined( 'ABSPATH' ) ) exit;

/**
 * Voucher Class
 * 
 * Handles generic voucher functions.
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 3.0.0
 */
class WOO_Vou_Voucher {

	var $model;

	public function __construct() {

		global $woo_vou_model;

		$this->model 	= $woo_vou_model;
	}

	/**
	 * Generate Random Letter
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.0.0
	 */
	public function woo_vou_get_random_letter( $len = 1 ) {

		$alphachar		= "abcdefghijklmnopqrstuvwxyz";
		$rand_string	= substr( str_shuffle( $alphachar ), 0, $len );
		
		return apply_filters( 'woo_vou_get_random_letter', $rand_string, $len );
	}
	
	/**
	 * Generate Capital Random Letter
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.3.7
	 */
	public function woo_vou_get_capital_random_letter( $len = 1 ) {

		$alphachar		= "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
		$rand_string	= substr( str_shuffle( $alphachar ), 0, $len );
		
		return apply_filters( 'woo_vou_get_capital_random_letter', $rand_string, $len );
	}

	/**
	 * Generate Random Number
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.0.0
	 */
	public function woo_vou_get_random_number( $len = 1 ) {

		$alphanum		= "0123456789";
		$rand_number	= substr( str_shuffle( $alphanum ), 0, $len );

		return apply_filters( 'woo_vou_get_random_number', $rand_number, $len );
	}

	/**
	 * Generate Random Pattern Code
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.0.0
	 */
	public function woo_vou_get_pattern_string( $pattern ) {

		$pattern_string = '';
		$pattern_length = strlen( trim( $pattern, ' ' ) );

		for ( $i = 0; $i < $pattern_length; $i++ ) {

			$pattern_code	= substr( $pattern, $i, 1 );

			if( $pattern_code == 'l' ) {
				$pattern_string .= $this->woo_vou_get_random_letter();
			} else if ( $pattern_code == 'L' ) {
				$pattern_string .= $this->woo_vou_get_capital_random_letter();
			} else if( strtolower( $pattern_code ) == 'd' ) {
				$pattern_string .= $this->woo_vou_get_random_number();
			}
		}

		return apply_filters( 'woo_vou_get_pattern_string', $pattern_string, $pattern );
	}

	/**
	 * Get all vouchers templates
	 * 
	 * Handles to return all vouchers templates
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.0.0
	 */
	public function woo_vou_get_vouchers( $args = array() ) {

		$vouargs = array( 'post_type' => WOO_VOU_POST_TYPE, 'post_status' => 'publish' );

		//return only id
		if(isset($args['fields']) && !empty($args['fields'])) {
			$vouargs['fields'] = $args['fields'];
		}

		//return based on meta query
		if(isset($args['meta_query']) && !empty($args['meta_query'])) {
			$vouargs['meta_query'] = $args['meta_query'];
		}

		//show how many per page records
		if(isset($args['posts_per_page']) && !empty($args['posts_per_page'])) {
			$vouargs['posts_per_page'] = $args['posts_per_page'];
		} else {
			$vouargs['posts_per_page'] = '-1';
		}

		//get by post parent records
		if(isset($args['post_parent']) && !empty($args['post_parent'])) {
			$vouargs['post_parent']	= $args['post_parent'];
		}

		//show per page records
		if(isset($args['paged']) && !empty($args['paged'])) {
			$vouargs['paged']	= $args['paged'];
		}

		//get order by records
		$vouargs['order']	= 'DESC';
		$vouargs['orderby']	= 'date';

		//Filter args
		$vouargs	= apply_filters( 'woo_vou_get_vouchers_args', $vouargs );

		//fire query in to table for retriving data
		$result = new WP_Query( $vouargs );

		if(isset($args['getcount']) && $args['getcount'] == '1') {
			$postslist = $result->post_count;
		}  else {
			//retrived data is in object format so assign that data to array for listing
			$postslist = $this->model->woo_vou_object_to_array($result->posts);
		}

		return $postslist;
	}

	/**
	 * Get all voucher details
	 * 
	 * Handles to return all voucher details
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.1.0
	 */
	public function woo_vou_get_voucher_details( $args = array() ) {
		
		$prefix = WOO_VOU_META_PREFIX;
		
		$post_status	= isset( $args['post_status'] ) ? $args['post_status'] : 'publish';

		$vouargs = array( 'post_type' => WOO_VOU_CODE_POST_TYPE, 'post_status' => $post_status );

		$vouargs = wp_parse_args( $args, $vouargs );

		//return only id
		if(isset($args['fields']) && !empty($args['fields'])) {
			$vouargs['fields'] = $args['fields'];
		}

		//return based on post ids
		if(isset($args['post__in']) && !empty($args['post__in'])) {
			$vouargs['post__in'] = $args['post__in'];
		}

		//return based on author
		if(isset($args['author']) && !empty($args['author'])) {
			$vouargs['author'] = $args['author'];
		}
		
		//return based on meta query
		if(isset($args['meta_query']) && !empty($args['meta_query'])) {
			$vouargs['meta_query'] = $args['meta_query'];
		}

		//show how many per page records
		if(isset($args['posts_per_page']) && !empty($args['posts_per_page'])) {
			$vouargs['posts_per_page'] = $args['posts_per_page'];
		} else {
			$vouargs['posts_per_page'] = '-1';
		}

		//get by post parent records
		if(isset($args['post_parent']) && !empty($args['post_parent'])) {
			$vouargs['post_parent']	=	$args['post_parent'];
		}

		//show per page records
		if(isset($args['paged']) && !empty($args['paged'])) {
			$vouargs['paged']	=	$args['paged'];
		}

		//get order by records
		$vouargs['order']	= 'DESC';
		$vouargs['orderby']	= 'date';

		//show how many per page records
		if(isset($args['order']) && !empty($args['order'])) {
			$vouargs['order'] = $args['order'];
		}

		//show how many per page records
		if(isset($args['orderby']) && !empty($args['orderby'])) {
			$vouargs['orderby'] = $args['orderby'];
		}

		//fire query in to table for retriving data
		$result = new WP_Query( $vouargs );		
		
		if(isset($args['getcount']) && $args['getcount'] == '1') {
			$postslist = $result->post_count;	
		} else {
			//retrived data is in object format so assign that data to array for listing
			$postslist = $this->model->woo_vou_object_to_array($result->posts);

			// if get list for voucher list then return data with data and total array
			if( isset($args['woo_vou_list']) && $args['woo_vou_list'] ) {

				$data_res	= array();

				$data_res['data'] 	= $postslist;

				//To get total count of post using "found_posts" and for users "total_users" parameter
				$data_res['total']	= isset($result->found_posts) ? $result->found_posts : '';

				return $data_res;
			}
		}

		return apply_filters( 'woo_vou_get_voucher_details', $postslist, $args );
	}

	/**
	 * Get all products by vouchers
	 * 
	 * Handles to return all products by vouchers
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.1.0
	 */
	public function woo_vou_get_products_by_voucher( $args = array() ) {

		$prefix = WOO_VOU_META_PREFIX;

		$args['fields'] = 'id=>parent';

		$voucodesdata = $this->woo_vou_get_voucher_details( $args );

		$product_ids =array();
		foreach ( $voucodesdata as $voucodes ) {

			if( !in_array( $voucodes['post_parent'], $product_ids ) ) {

				$product_ids[] = $voucodes['post_parent'];
			}
		}

		if( !empty( $product_ids ) ) { // Check products ids are not empty

			$vouargs = array( 'post_type' => WOO_VOU_MAIN_POST_TYPE, 'post_status' => 'publish', 'post__in' => $product_ids );

			//display based on per page
			if( isset( $args['posts_per_page'] ) && !empty( $args['posts_per_page'] ) ) {
				$vouargs['posts_per_page'] = $args['posts_per_page'];
			} else {
				$vouargs['posts_per_page'] = '-1';
			}

			//get order by records
			$vouargs['order']	= 'DESC';
			$vouargs['orderby']	= 'date';

			//fire query in to table for retriving data
			$result = new WP_Query( $vouargs );

			if( isset( $args['getcount'] ) && $args['getcount'] == '1' ) {
				$products = $result->post_count;
			}  else {
				//retrived data is in object format so assign that data to array for listing
				$products = $this->model->woo_vou_object_to_array( $result->posts );
			}
			return $products;
		} else {
			return array();
		}
	}

	/**
	 * Get purchased codes by product id
	 * 
	 * Handles to get purchased codes by product id
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.1.0
	 */
	public function woo_vou_get_purchased_codes_by_product_id( $product_id ) {

		global $woo_vou_vendor_role;

		//Check product id is empty
		if( empty( $product_id ) ) return array();

		global $current_user;

		$prefix = WOO_VOU_META_PREFIX;
		
		$args = array( 'post_parent' => $product_id, 'fields' => 'ids' );
		$args['meta_query'] = array(
										array(
													'key' 		=> $prefix . 'purchased_codes',
													'value' 	=> '',
													'compare' 	=> '!='
												),
										array(
													'key'     	=> $prefix . 'used_codes',
													'compare' 	=> 'NOT EXISTS'
												)
									);

		//Get User roles
		$user_roles	= isset( $current_user->roles ) ? $current_user->roles : array();
		$user_role	= array_shift( $user_roles );

		if( in_array( $user_role, $woo_vou_vendor_role ) ) { // Check vendor user role
			$args['author'] = $current_user->ID;
		}

		//add filter to group by order id
		add_filter( 'posts_groupby', array( $this->model, 'woo_vou_groupby_order_id' ) );
						
		$voucodesdata = $this->woo_vou_get_voucher_details( $args );

		//remove filter to group by order id
		remove_filter( 'posts_groupby', array( $this->model, 'woo_vou_groupby_order_id' ) );

		$vou_code_details = array();
		if( !empty( $voucodesdata ) && is_array( $voucodesdata ) ) {

			foreach ( $voucodesdata as $vou_codes_id ) {

				// get order id
				$order_id = get_post_meta( $vou_codes_id, $prefix.'order_id', true );

				// get order date
				$order_date = get_post_meta( $vou_codes_id, $prefix.'order_date', true );

				//buyer's first name who has purchased voucher code
				$first_name = get_post_meta( $vou_codes_id, $prefix . 'first_name', true );

				//buyer's last name who has purchased voucher code
				$last_name = get_post_meta( $vou_codes_id, $prefix . 'last_name', true );

				//buyer's name who has purchased voucher code
				$buyer_name =  $first_name. ' ' .$last_name;

				$args = array( 'post_parent' => $product_id, 'fields' => 'ids' );
				$args['meta_query'] = array(
												array(
															'key' 		=> $prefix . 'purchased_codes',
															'value' 	=> '',
															'compare' 	=> '!='
														),
												array(
															'key' 		=> $prefix . 'order_id',
															'value' 	=> $order_id
														),
												array(
															'key'     	=> $prefix . 'used_codes',
															'compare' 	=> 'NOT EXISTS'
												)
											);
				$vouorderdata = $this->woo_vou_get_voucher_details( $args );

				$purchased_codes = array();
				if( !empty( $vouorderdata ) && is_array( $vouorderdata ) ) {

					foreach ( $vouorderdata as $order_vou_id ) {

						// get purchased codes
						$purchased_codes[] = get_post_meta( $order_vou_id, $prefix.'purchased_codes', true );
					}
				}

				// Check purchased codes are not empty
				if( !empty( $purchased_codes ) ) {

					$vou_code_details[] = array(
														'order_id'			=> $order_id,
														'order_date' 		=> $order_date,
														'first_name' 		=> $first_name,
														'last_name' 		=> $last_name,
														'buyer_name' 		=> $buyer_name,
														'vou_codes'			=> implode( ', ', $purchased_codes )
													);
				}
			}
		}

		return apply_filters( 'woo_vou_get_purchased_codes_by_product_id', $vou_code_details, $product_id );
	}

	/**
	 * Get used codes by product id
	 * 
	 * Handles to get used codes by product id
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.1.0
	 */
	public function woo_vou_get_used_codes_by_product_id( $product_id ) {

		//Check product id is empty
		if( empty( $product_id ) ) return array();

		global $current_user, $woo_vou_vendor_role;

		$prefix = WOO_VOU_META_PREFIX;

		$args = array( 'post_parent' => $product_id, 'fields' => 'ids' );
		$args['meta_query'] = array(
										array(
													'key' 		=> $prefix . 'used_codes',
													'value' 	=> '',
													'compare' 	=> '!='
												)
									);

		//Get User roles
		$user_roles	= isset( $current_user->roles ) ? $current_user->roles : array();
		$user_role	= array_shift( $user_roles );

		if( in_array( $user_role, $woo_vou_vendor_role ) ) { // Check vendor user role
			$args['author'] = $current_user->ID;
		}

		//add filter to group by order id
		add_filter( 'posts_groupby', array( $this->model, 'woo_vou_groupby_order_id' ) );

		$voucodesdata = $this->woo_vou_get_voucher_details( $args );

		//remove filter to group by order id
		remove_filter( 'posts_groupby', array( $this->model, 'woo_vou_groupby_order_id' ) );

		$vou_code_details = array();
		if( !empty( $voucodesdata ) && is_array( $voucodesdata ) ) {

			foreach ( $voucodesdata as $vou_codes_id ) {

				// get order id
				$order_id = get_post_meta( $vou_codes_id, $prefix.'order_id', true );

				// get order date
				$order_date = get_post_meta( $vou_codes_id, $prefix.'order_date', true );

				//buyer's first name who has purchased voucher code
				$first_name = get_post_meta( $vou_codes_id, $prefix . 'first_name', true );

				//buyer's last name who has purchased voucher code
				$last_name = get_post_meta( $vou_codes_id, $prefix . 'last_name', true );

				//buyer's name who has purchased voucher code				
				$buyer_name =  $first_name. ' ' .$last_name;

				$args = array( 'post_parent' => $product_id, 'fields' => 'ids' );
				$args['meta_query'] = array(
												array(
															'key' 		=> $prefix . 'used_codes',
															'value' 	=> '',
															'compare' 	=> '!='
														),
												array(
															'key' 		=> $prefix . 'order_id',
															'value' 	=> $order_id
														)
											);
				$vouorderdata = $this->woo_vou_get_voucher_details( $args );

				$used_codes = $redeem_by = array();
				if( !empty( $vouorderdata ) && is_array( $vouorderdata ) ) {

					foreach ( $vouorderdata as $order_vou_id ) {

						// get purchased codes
						$used_codes[] = get_post_meta( $order_vou_id, $prefix.'used_codes', true );
						$redeem_by[]  = get_post_meta( $order_vou_id, $prefix.'redeem_by', true );
					}
				}

				// Check purchased codes are not empty
				if( !empty( $used_codes ) ) {

					$vou_code_details[] = array(
														'order_id'		=> $order_id,
														'order_date' 	=> $order_date,
														'first_name' 	=> $first_name,
														'last_name' 	=> $last_name,
														'buyer_name' 	=> $buyer_name,
														'vou_codes'		=> implode( ',', $used_codes ),
														'redeem_by'		=> implode( ',', $redeem_by )
													);
				}
			}
		}

		return apply_filters( 'woo_vou_get_used_codes_by_product_id', $vou_code_details, $product_id );
	}
	
	/**
	 * Restore voucher code to product
	 * 
	 * Handles to Restore voucher code to product again
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.4.0
	 */
	public function woo_vou_restore_order_voucher_codes( $order_id = '' ) {
		
		$prefix = WOO_VOU_META_PREFIX;
		
		if( !empty( $order_id ) ) {
			
			$args	= array( 
							'post_status'	=> array( 'pending' ),
							'meta_query'	=> array(
													array(
														'key'	=> $prefix . 'order_id',
														'value'	=> $order_id,
													)
												)
						);

			//Get vouchers code of this order
			$vochers	= $this->woo_vou_get_voucher_details( $args );

			if( !empty( $vochers ) ) {//If empty voucher codes

				//get order meta
				$meta_order_details	= get_post_meta( $order_id, $prefix.'meta_order_details', true );

				foreach ( $vochers as $vocher ) {

					//Initilize voucher codes array
					$salecode		= array();

					//Get voucher code ID
					$vou_codes_id	= isset( $vocher['ID'] ) ? $vocher['ID'] : '';

					//Get product ID
					$product_id		= isset( $vocher['post_parent'] ) ? $vocher['post_parent'] : '';

					//Get voucher codes
					$voucher_codes			= get_post_meta( $vou_codes_id, $prefix . 'purchased_codes', true );

					//meta detail of specific product
					$product_meta_detail	= isset( $meta_order_details[$product_id] ) ? $meta_order_details[$product_id] : array();

					//Voucher uses types
					$voucher_uses_type		= isset( $product_meta_detail['using_type'] ) ? $product_meta_detail['using_type'] : '';

					if( !empty( $voucher_codes ) && empty( $voucher_uses_type ) ) {//If voucher codes available and type is not unlimited

						$variation_id	= get_post_meta( $vou_codes_id, $prefix . 'vou_from_variation', true );

						if( !empty( $variation_id ) ) {

							//voucher codes
							$product_vou_codes = get_post_meta( $variation_id, $prefix . 'codes', true );

							//explode all voucher codes
							$salecode	= !empty( $product_vou_codes ) ? explode( ',', $product_vou_codes ) : array();

							//append sales code array
							$salecode[]	= $voucher_codes;

							//trim code
							foreach ( $salecode as $code_key => $code ) {

								$salecode[$code_key] = trim( $code );
							}

							//Total avialable voucher code
							$avail_total_codes	= count( $salecode );

							//update total voucher codes
							wc_update_product_stock( $variation_id,  $avail_total_codes );

							//after restore code in array update in code meta
							$lessvoucodes = implode( ',', $salecode );
							update_post_meta( $variation_id, $prefix.'codes', trim( $lessvoucodes ) );

						} else {

							//voucher codes
							$product_vou_codes = get_post_meta( $product_id, $prefix . 'codes', true );

							//explode all voucher codes
							$salecode	= !empty( $product_vou_codes ) ? explode( ',', $product_vou_codes ) : array();

							//append sales code array
							$salecode[]	= $voucher_codes;

							//trim code
							foreach ( $salecode as $code_key => $code ) {

								$salecode[$code_key] = trim( $code );
							}

							//Total avialable voucher code
							$avail_total_codes	= count( $salecode );

							//update total voucher codes
							update_post_meta( $product_id, $prefix.'avail_total', $avail_total_codes );

							//update total voucher codes
							wc_update_product_stock( $product_id,  $avail_total_codes );

							//after restore code in array update in code meta
							$lessvoucodes = implode( ',', $salecode );
							update_post_meta( $product_id, $prefix.'codes', trim( $lessvoucodes ) );
						}

						//delete voucher post
						wp_delete_post( $vou_codes_id, true );
					}
				}

				//delete voucher order details
				delete_post_meta( $order_id, $prefix.'order_details' );
				//delete voucher order details with all meta data
				delete_post_meta( $order_id, $prefix.'meta_order_details' );
			}
		}
	}

	/**
	 * Refund voucher code to product
	 * 
	 * Handles to Refund voucher code to product again
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.4.0
	 */
	public function woo_vou_refund_order_voucher_codes( $order_id ) {
		
		$prefix = WOO_VOU_META_PREFIX;
		
		if( !empty( $order_id ) ) {
			
			$args	= array( 
						'post_status'	=> array( 'pending', 'publish' ),
						'meta_query'	=> array(
												array(
													'key'	=> $prefix . 'order_id',
													'value'	=> $order_id,
												)
											)
						);

			//Get vouchers code of this order
			$vochers	= $this->woo_vou_get_voucher_details( $args );

			/**
             * Restore coupons when refund order
             */
            $coupon_args	= array( 
                                    'post_status'	=> array( 'pending', 'publish' ),
                                    'meta_query'	=> array(
                                                            array(
                                                                'key'	=> $prefix . 'order_id',
                                                                'value'	=> $order_id,
                                                            )
                                                        )
                                    );

            //Get vouchers code of this order
            $coupons = $this->woo_vou_get_coupon_details( $coupon_args );
            if( !empty( $coupons ) )
                $vochers	= array_merge( $vochers, $coupons );
    		
			if( !empty( $vochers ) ) {//If empty voucher codes

				foreach ( $vochers as $vocher ) {

					$vou_codes_id	= isset( $vocher['ID'] ) ? $vocher['ID'] : '';

					if( !empty( $vou_codes_id ) ) {

						$update_refund	= array(
												'ID'			=> $vou_codes_id,
												'post_status'	=> WOO_VOU_REFUND_STATUS
											);

						//set status refunded of voucher post
						wp_update_post( $update_refund );
					}
				}
			}
		}
	}
	
	/**
	 * Return voucher code status
	 * 
	 * "purchased"  - voucher code is purchased and still not expired or used
	 * "used" 		- voucher code is redeemed
	 * "expired"	- voucher code is expired and its not redeemed
	 * "invalid"	- voucher code not exist or invalid
	 *
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.6.4
	 */
	public function woo_vou_get_voucher_code_status( $voucode ) {
		
		global $current_user, $woo_vou_vendor_role;

		$prefix				= WOO_VOU_META_PREFIX;					
		$vou_code_status 	= 'invalid';
		$vou_code_args		= array();
		$used_code_args		= array();

		if( !empty( $voucode ) ) { // Check voucher code is not empty

			//Voucher Code
			$voucode = strtolower( $voucode );

			//Get User roles
			$user_roles	= isset( $current_user->roles ) ? $current_user->roles : array();
			$user_role	= array_shift( $user_roles );

			//voucher admin roles
			$admin_roles	= woo_vou_assigned_admin_roles();

			/* if( !in_array( $user_role, $admin_roles ) ) {// voucher admin can redeem all codes
				
				$vou_code_args['author']	= $current_user->ID;
				$used_code_args['author']	= $current_user->ID;
			}*/

			// arguments for get purchase voucher details
			$vou_code_args['fields']		= 'ids';
			$vou_code_args['meta_query']	= array(
													array(
														'key' 		=> $prefix . 'purchased_codes',
														'value' 	=> $voucode
													),
													array(
														'key'     	=> $prefix . 'used_codes',
														'compare' 	=> 'NOT EXISTS'
													)
												);

			// get purchsed voucher codes data
			$voucodedata = $this->woo_vou_get_voucher_details( $vou_code_args );
			
			if( !empty( $voucodedata ) && is_array( $voucodedata ) ) { // Check voucher code ids are not empty				
				
				// set voucher status to purchased
				$vou_code_status = 'purchased';
				
				// get voucher code id
				$voucodeid = isset( $voucodedata[0] ) ? $voucodedata[0] : '';							
				
				// get voucher expired date
				$expiry_date = get_post_meta( $voucodeid , $prefix . 'exp_date' ,true );
						
				// check voucher is expired or not		
				if( isset( $expiry_date ) && !empty( $expiry_date ) ) {

					if( $expiry_date < $this->model->woo_vou_current_date() ) {
						// set voucher status to expired
						$vou_code_status = 'expired';												
					}
				}								

			} else {
				
				// argunments array for used voucher code
				$used_code_args['fields']		= 'ids';
				$used_code_args['meta_query']	= array(
													array(
														'key' 		=> $prefix . 'used_codes',
														'value' 	=> $voucode
													)
												);

				// get used voucher code data
				$usedcodedata = $this->woo_vou_get_voucher_details( $used_code_args );
				
				if( !empty( $usedcodedata ) && is_array( $usedcodedata ) ) {
					// set voucher status to used
					$vou_code_status = 'used';	
				}
			}
			
			return $vou_code_status;			
		}
	}

	/**
	 * Get all users by vouchers
	 * 
	 * Handles to return all users by vouchers
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.6.4
	 */
	public function woo_vou_get_redeem_users_by_voucher( $args = array() ) {

		$prefix = WOO_VOU_META_PREFIX;

		$args['fields'] = 'id=>parent';

		$voucodesdata   = $this->woo_vou_get_voucher_details( $args );

		$users_data      = array();
		
		foreach ( $voucodesdata as $voucodes ) {
			
			$user_id = get_post_meta( $voucodes['ID'], $prefix.'redeem_by', true );
			
			if( !key_exists( $user_id, $users_data ) ){
				
				$user_detail          = get_userdata( $user_id );
				if ( ! empty ( $user_detail ) ) {
				    $user_display_name    = $user_detail->display_name;
				    $users_data[$user_id] = $user_display_name;
				}
			}
		}
		
		return $users_data;
	}

	/**
	 * Update Duplicate Post Metas
	 * 
	 * Handles to update all old vous meta to 
	 * duplicate meta
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.0.0
	 */
	public function woo_vou_dupd_post_meta( $old_id, $new_id ) {

		// set prefix for meta fields 
		$prefix = WOO_VOU_META_PREFIX;

		// get all post meta for vou
		$meta_fields = get_post_meta( $old_id );

		// take array to store metakeys of old vou
		$meta_keys = array();

		foreach ( $meta_fields as $metakey => $matavalues ) {
			// meta keys store in a array
			$meta_keys[] = $metakey;
		}

		foreach ( $meta_keys as $metakey ) {

			// get metavalue from metakey
			$meta_value = get_post_meta( $old_id, $metakey, true );

			// update meta values to new duplicate vou meta
			update_post_meta( $new_id, $metakey, $meta_value );
		}
	}

	/**
	 * Create Duplicate Voucher
	 * 
	 * Handles to create duplicate voucher
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.0.0
	 */
	public function woo_vou_dupd_create_duplicate_vou( $vou_id ) {

		// get the vou data
		$vou = get_post( $vou_id );

		$prefix = WOO_VOU_META_PREFIX;

		// start process to create a new vou
		$suffix = __( '(Copy)', 'woovoucher' );

		// get post table data
		$post_author   			= $vou->post_author;
		$post_date      		= current_time('mysql');
		$post_date_gmt 			= get_gmt_from_date($post_date);
		$post_type				= $vou->post_type;
		$post_parent			= $vou->post_parent;
		$post_content    		= str_replace("'", "''", $vou->post_content);
		$post_content_filtered 	= str_replace("'", "''", $vou->post_content_filtered);
		$post_excerpt    		= str_replace("'", "''", $vou->post_excerpt);
		$post_title      		= str_replace("'", "''", $vou->post_title).' '.$suffix;
		$post_name       		= str_replace("'", "''", $vou->post_name);
		$post_comment_status  	= str_replace("'", "''", $vou->comment_status);
		$post_ping_status     	= str_replace("'", "''", $vou->ping_status);

		// get the column keys
	    $post_data = array(
				            'post_author'			=>	$post_author,
				            'post_date'				=>	$post_date,
				            'post_date_gmt'			=>	$post_date_gmt,
				            'post_content'			=>	$post_content,
				            'post_title'			=>	$post_title,
				            'post_excerpt'			=>	$post_excerpt,
				            'post_status'			=>	'draft',
				            'post_type'				=>	WOO_VOU_POST_TYPE,
				            'post_content_filtered'	=>	$post_content_filtered,
				            'comment_status'		=>	$post_comment_status,
				            'ping_status'			=> 	$post_ping_status,
				            'post_password'			=>	$vou->post_password,
				            'to_ping'				=>	$vou->to_ping,
				            'pinged'				=>	$vou->pinged,
				            'post_modified'			=>	$post_date,
				            'post_modified_gmt'		=>	$post_date_gmt,
				            'post_parent'			=>	$post_parent,
				            'menu_order'			=>	$vou->menu_order,
				            'post_mime_type'		=>	$vou->post_mime_type
			       		);

		// returns the vou id if we successfully created that vou
		$post_id = wp_insert_post( $post_data );

		//update vous meta values
		$this->woo_vou_dupd_post_meta( $vou->ID, $post_id );

		// if successfully created vou than redirect to main page
		wp_redirect( add_query_arg( array( 'post_type' => WOO_VOU_POST_TYPE, 'action' => 'edit', 'post' => $post_id ), admin_url( 'post.php' ) ) );

		// to avoid junk
		exit;
	}

	/**
	 * Check Enable Voucher
	 * 
	 * Handles to check enable voucher using product id
	 *
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.0.0
	 */
	public function woo_vou_check_enable_voucher( $productid, $variation_id = false ) {

		$enable	= false;

		if( !empty( $productid ) ) { // Check product id is not empty

			$prefix = WOO_VOU_META_PREFIX;

			//enable voucher
			$enable_vou = get_post_meta( $productid, $prefix.'enable', true );

			// If variation id
			if(!empty($variation_id) ) {

				$is_downloadable = get_post_meta( $variation_id, '_downloadable', true );

			} else { // is downloadable

				$is_downloadable = get_post_meta( $productid, '_downloadable', true );
			}

			// Check enable voucher meta & product is downloadable
			// Check Voucher codes are not empty 
			if( $enable_vou == 'yes' && $is_downloadable == 'yes' ) { // Check enable voucher meta & product is downloadable

				$enable	= true;
			}
		}

		return apply_filters( 'woo_vou_check_enable_voucher', $enable, $productid, $variation_id );
	}

	/**
	 * Check product is expired/upcoming
	 * 
	 * Handles to check product is expired/upcoming based on start date and end date
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.4.2
	 */
	public function woo_vou_check_product_is_expired( $product ) {
		
		//Get Prefix
		$prefix		= WOO_VOU_META_PREFIX;
		
		// Get product ID
		$product_id = woo_vou_get_product_id( $product );
		
		// check voucher is enable
		$enabled = $this->woo_vou_check_enable_voucher( $product_id );	
		$expired = false;		
		// get expiration type
		$exp_type = get_post_meta( $product_id, $prefix.'exp_type', true );
		
		if( $enabled && $exp_type == 'specific_date' ) { // check expiration type is based on purchase
			
			// get start date
			$product_start_date = get_post_meta( $product_id, $prefix.'product_start_date', true );
			// get end date
		    $end_date  	= get_post_meta( $product_id, $prefix.'product_exp_date', true );
		    // get today date
		    $today_date	= date( 'Y-m-d H:i:s', current_time( 'timestamp' ) ); 
		    
		    if( empty( $product_start_date) && empty( $end_date ) ) {
		    	$expired = false;
		    } elseif ( !empty( $product_start_date ) && $product_start_date > $today_date ) {
		    	$expired = 'upcoming';
		    } elseif ( !empty( $end_date ) && $end_date < $today_date ) {
		    	$expired = 'expired';
		    }
		}
		
		return apply_filters( 'woo_vou_check_product_is_expired', $expired, $product );
	}

	/**
	 * Get Voucher Keys
	 * 
	 * Handles to get voucher keys
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.1.0
	 */
	public function woo_vou_get_multi_voucher_key( $order_id = '', $product_id = '', $item_id = '' ) {

		$voucher_keys	= array();
		$vouchers		= $this->woo_vou_get_multi_voucher( $order_id, $product_id, $item_id );

		if( !empty( $vouchers ) ) {

			$voucher_keys	= array_keys( $vouchers );
		}

		return apply_filters( 'woo_vou_get_multi_voucher_key', $voucher_keys, $order_id, $product_id, $item_id );
	}

	/**
	 * Get Vouchers
	 * 
	 * Handles to get vouchers
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.1.0
	 */
	public function woo_vou_get_multi_voucher( $order_id = '', $product_id = '', $item_id = '' ) {

		$prefix = WOO_VOU_META_PREFIX;

		//Get voucher codes
		$codes	= wc_get_order_item_meta( $item_id, $prefix.'codes' );

		$codes			= !empty( $codes ) ? explode( ', ', $codes ) : array();
		$vouchers		= array();

		if( !empty( $codes ) ) {

			$key	= 1;
			foreach ( $codes as $code ) {

				$vouchers['woo_vou_pdf_'.$key]	= $code;
				$key++;
			}
		}

		return apply_filters( 'woo_vou_get_multi_voucher', $vouchers, $order_id, $product_id, $item_id );
	}

	/**
	 * Check item is already exist in order
	 * 
	 * Handles to check the item is already exist in order or not
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.0
	 */
	public function woo_vou_generate_pdf_voucher( $email = '', $product_id = '', $download_id = '', $order_id = '', $item_id = '' ) {

		$prefix	= WOO_VOU_META_PREFIX;

		$vou_codes_key	= $this->woo_vou_get_multi_voucher_key( $order_id, $product_id, $item_id );

		//Get mutiple pdf option from order meta
		$multiple_pdf = empty( $order_id ) ? '' : get_post_meta( $order_id, $prefix . 'multiple_pdf', true );

		$orderdvoucodes = array();

		if( !empty( $multiple_pdf ) ) {

			$orderdvoucodes = $this->woo_vou_get_multi_voucher( $order_id , $product_id, $item_id );
		}

		// Check out voucher download key
		if( in_array( $download_id, $vou_codes_key ) || $download_id == 'woo_vou_pdf_1' ) {

			//product voucher pdf
			woo_vou_process_product_pdf( $product_id, $order_id, $item_id, $orderdvoucodes );
		}
	}

	/**
	 * Check to get voucher codes from variations or from product meta
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.6
	 */
	public function woo_vou_get_voucher_code( $productid, $variation_id = false ) {

		$prefix = WOO_VOU_META_PREFIX;
		$vou_codes = '';
		
		$productid = apply_filters( 'woo_vou_before_get_voucher_code', $productid );
						
		//get voucher codes
		$vou_codes = get_post_meta( $productid, $prefix.'codes', true );

		// If variation id
		if( !empty( $variation_id ) ) {

			$vou_is_var = get_post_meta( $productid, $prefix.'is_variable_voucher', true );

			// if voucher codes set at variation level then get it from there
			if( $vou_is_var ) {
				$variation_id = apply_filters( 'woo_vou_before_get_voucher_code', $variation_id );
				$vou_codes = get_post_meta( $variation_id, $prefix.'codes', true );
			}
		}

		//trim voucher codes
		$vou_codes = trim( $vou_codes );
		
		return apply_filters( 'woo_vou_get_voucher_code', $vou_codes, $productid, $variation_id );
	}

	/**
	 * Check and Update voucher codes into variations or in product meta
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.6
	 */
	public function woo_vou_update_voucher_code( $productid, $variation_id = false, $voucodes = '' ) {

		$prefix = WOO_VOU_META_PREFIX;
		$woo_vou_var_flag = false;

		// If variation id
		if( !empty( $variation_id ) ) {

			$vou_is_var = get_post_meta( $productid, $prefix.'is_variable_voucher', true );

			// if voucher codes set at variation level and get it from there
			if( $vou_is_var ) {
				$woo_vou_var_flag = true;
				$variation_id = apply_filters( 'woo_vou_before_update_voucher_code', $variation_id );				
				update_post_meta( $variation_id, $prefix.'codes', trim( $voucodes ) );

				$product = wc_get_product($productid);
				$variations = $product->get_visible_children();
			}
		}

		// if product is simple or variable but there is no voucher code set on variation level 
		if( $woo_vou_var_flag != true ) { 
			$productid = apply_filters( 'woo_vou_before_update_voucher_code', $productid );
			update_post_meta( $productid, $prefix.'codes', trim( $voucodes ) );
		}
	}

	/**
	 * Save partially redeem voucher code information
	 *
	 * @param string $voucode 		- voucher code
	 * @param array  $voucodeid 	- voucher code id
	 * @param string $redeem_amount - how much amount need to redeem
	 *
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.7.2
	 */
	public function woo_vou_save_partialy_redeem_voucher_code( $voucodeid, $redeem_amount, $voucode ) {
		
		global $current_user;
		
		$prefix = WOO_VOU_META_PREFIX;
		
		//Get user id
		$user_id = isset( $current_user->ID ) ? $current_user->ID : '';									
			
		// update used code date
		update_post_meta( $voucodeid, $prefix . 'redeem_method', 'partial' );
		
		// Insert new patially redeem voucher post to save voucher details
		$partial_redeem_codes_args = array(
			'post_author'   => $user_id,
			'post_content'	=>	'',
			'post_status'	=>	'publish',
			'post_type'		=>	WOO_VOU_PARTIAL_REDEEM_POST_TYPE,
			'post_parent'	=>	$voucodeid
		);

		$partial_redeem_post_id	= wp_insert_post( $partial_redeem_codes_args );
		
		// update redeem amount
		update_post_meta( $partial_redeem_post_id, $prefix . 'partial_redeem_amount', $redeem_amount );
					
		// update redeem by
		update_post_meta( $partial_redeem_post_id, $prefix . 'redeem_by', $user_id );
				
		// get current date
		$today = $this->model->woo_vou_current_date();
		
		// update used code date
		update_post_meta( $partial_redeem_post_id, $prefix . 'used_code_date', $today );						
		
		// get product id from voucher code id.
		$product_id = wp_get_post_parent_id( $voucodeid );
		
		update_post_meta( $partial_redeem_post_id, $prefix . 'product_id', $product_id  );
							
		update_post_meta( $partial_redeem_post_id, $prefix . 'purchased_codes', $voucode  );

		//after partialy voucher code
		do_action( 'woo_vou_partialy_redeemed_voucher_code', $partial_redeem_post_id, $voucodeid );	
	}

	/**
	 * Get total redeemed price for voucher code
	 *
	 * @param  string $voucodeid 			- voucher code post id
	 * @return string $total_redeemed_price - total redeemed price 
	 *
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.7.2
	 */
	public function woo_vou_get_total_redeemed_price_for_vouchercode( $voucodeid ) {
		
		$prefix = WOO_VOU_META_PREFIX;
		
		$total_redeemed_price = 0;
		
		// get all patially redeemed post for voucher code = $voucodeid
		$args = array(
			'post_type' 	=> WOO_VOU_PARTIAL_REDEEM_POST_TYPE,
			'post_parent'	=> $voucodeid,
			'posts_per_page' => -1,
			'meta_query' 	=> array(
									array(
										'key' => $prefix . 'partial_redeem_amount',
									),
								),
		);
		$partially_redeemed_posts = get_posts( $args );

		// if found any parially redeemed post, then calculate total redeemed price
		if ( !empty( $partially_redeemed_posts ) && is_array( $partially_redeemed_posts ) ) {
			
			foreach ( $partially_redeemed_posts as $key => $partially_redeemed_post ) {
				
				// get redeemed price
				$price = get_post_meta( $partially_redeemed_post->ID, $prefix . 'partial_redeem_amount', true );
				// add redeemed price to total
				$total_redeemed_price += $price;
			}
		}
		
		// return total redeemed price
		return $total_redeemed_price;
	}

	/**
	 * Get partially redeem voucher code information
	 *
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.7.2
	 */	 
	public function woo_vou_get_partially_redeem_details( $args = array() ) {
		
		$prefix = WOO_VOU_META_PREFIX;
		
		$post_status	= isset( $args['post_status'] ) ? $args['post_status'] : 'publish';

		$vouargs = array( 'post_type' => WOO_VOU_PARTIAL_REDEEM_POST_TYPE, 'post_status' => $post_status );

		$vouargs = wp_parse_args( $args, $vouargs );

		//return only id
		if(isset($args['fields']) && !empty($args['fields'])) {
			$vouargs['fields'] = $args['fields'];
		}

		//return based on post ids
		if(isset($args['post__in']) && !empty($args['post__in'])) {
			$vouargs['post__in'] = $args['post__in'];
		}

		//return based on author
		if(isset($args['author']) && !empty($args['author'])) {
			$vouargs['author'] = $args['author'];
		}

		//return based on meta query
		if(isset($args['meta_query']) && !empty($args['meta_query'])) {
			$vouargs['meta_query'] = $args['meta_query'];
		}

		//show how many per page records
		if(isset($args['posts_per_page']) && !empty($args['posts_per_page'])) {
			$vouargs['posts_per_page'] = $args['posts_per_page'];
		} else {
			$vouargs['posts_per_page'] = '-1';
		}

		//get by post parent records
		if(isset($args['post_parent']) && !empty($args['post_parent'])) {
			$vouargs['post_parent']	=	$args['post_parent'];
		}

		//show per page records
		if(isset($args['paged']) && !empty($args['paged'])) {
			$vouargs['paged']	=	$args['paged'];
		}

		//get order by records
		$vouargs['order']	= 'DESC';
		$vouargs['orderby']	= 'date';

		//show how many per page records
		if(isset($args['order']) && !empty($args['order'])) {
			$vouargs['order'] = $args['order'];
		}

		//show how many per page records
		if(isset($args['orderby']) && !empty($args['orderby'])) {
			$vouargs['orderby'] = $args['orderby'];
		}

		//fire query in to table for retriving data
		$result = new WP_Query( $vouargs );		
	
		if(isset($args['getcount']) && $args['getcount'] == '1') {
			$postslist = $result->post_count;	
		} else {
			//retrived data is in object format so assign that data to array for listing
			$postslist = $this->model->woo_vou_object_to_array($result->posts);

			// if get list for voucher list then return data with data and total array
			if( isset($args['woo_vou_list']) && $args['woo_vou_list'] ) {

				$data_res	= array();

				$data_res['data'] 	= $postslist;

				//To get total count of post using "found_posts" and for users "total_users" parameter
				$data_res['total']	= isset($result->found_posts) ? $result->found_posts : '';

				return $data_res;
			}
		}

		return apply_filters( 'woo_vou_get_partially_redeem_details', $postslist, $args );
	}

	/**
	 * Create new woocommerce coupon code or update meta if coupon code is exits as per voucher code
	 * Par: $voucherCode array with code, code amount and exp date, order object to redeem code if used in order
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.9.3
	 */	
	function woo_vou_create_wc_coupon_code( $voucherCode = array(), $order, $product_id = '' )  {

		// Declare global variables
		global $post_type;

		// Get prefix
		$prefix = WOO_VOU_META_PREFIX;

		// Declare variables
		$usability = 1;
		
		// If enable then set coupon usability to infinity
		$enable_partial_redeem = get_option( 'vou_enable_partial_redeem' );
		
		if ( $enable_partial_redeem == 'yes' ) {
			
			$usability = 0;
		}

		//Get post author
		$post_author 	= get_post_field( 'post_author', $product_id );

		// get active coupons
		$args = array(
					    'posts_per_page'   => -1,
					    'orderby'          => 'title',
					    'order'            => 'asc',
					    'post_type'        => 'shop_coupon',
					    'post_status'      => 'publish',
					);

		$coupons = get_posts( $args ); // Activate coupons
		
		// create an array of active couopon code
		$get_coupon_titles = array();
		
		foreach( $coupons as $coupon ) {
			$get_coupon_titles[] = 	$coupon->post_title;
		}
		
		$code 		= $voucherCode['vou_code']; 	  // coupon code
		$amount 	= $voucherCode['vou_amount'];	  // Amount
		$exp_date 	= !empty ( $voucherCode['vou_exp_date'] ) ? $voucherCode['vou_exp_date'] : '';   // Voucher expiry date
		$start_date = !empty ( $voucherCode['vou_start_date'] ) ? $voucherCode['vou_start_date'] : ''; // Voucher Start date
		$rest_days	= !empty ( $voucherCode['vou_rest_days'] ) ? $voucherCode['vou_rest_days'] : '';  // Voucher restriction days

		// Create WC coupon code if not exists
		if( ! in_array( $code, $get_coupon_titles ) ) {
			
			$discount_type 	= 'fixed_cart'; // Type: fixed_cart, percent, fixed_product, percent_product
									
			$coupon = array(
				'post_title' 	=> $code,
				'post_content' 	=> '',
				'post_status' 	=> 'publish',
				'post_author' 	=> $post_author,
				'post_type'		=> 'shop_coupon'
			);
								
			$new_coupon_id = wp_insert_post( $coupon );

			if( $new_coupon_id ) {
				
				// Add meta
				update_post_meta( $new_coupon_id, 'discount_type', $discount_type ); // Add discount type
				update_post_meta( $new_coupon_id, 'coupon_amount', $amount ); // Add Coupon amount
				update_post_meta( $new_coupon_id, 'individual_use', 'no' ); // Set usage type
				update_post_meta( $new_coupon_id, 'usage_limit', $usability ); // Set usage limit
				update_post_meta( $new_coupon_id, $prefix . 'start_date', $start_date ); // Set start date
				update_post_meta( $new_coupon_id, 'expiry_date', $exp_date ); // Set expiry date
				update_post_meta( $new_coupon_id, $prefix . 'disable_redeem_day', $rest_days ); // Set days only on which this can be used
				update_post_meta( $new_coupon_id, 'apply_before_tax', 'yes' );
				update_post_meta( $new_coupon_id, 'free_shipping', 'no' );
				update_post_meta( $new_coupon_id, $prefix . 'coupon_type', 'voucher_code' );
				update_post_meta( $new_coupon_id, $prefix . 'order_id', woo_vou_get_order_id($order) ); // Insert order id
					
				//reset variables blank					
				$code 		= "";
				$exp_date 	= "";
				$amount		= "";
			}				
		}

		unset ( $voucherCode ); // remove array value
	}

	public function woo_vou_get_coupon_details ( $args ) {
		
		$prefix 		= WOO_VOU_META_PREFIX;
		
		$post_status	= isset( $args['post_status'] ) ? $args['post_status'] : 'publish';

		$coupargs 		= array( 'post_type' => 'shop_coupon', 'post_status' => $post_status );

		$coupargs 		= wp_parse_args( $args, $coupargs );
		
		//return only id
		if(isset($args['fields']) && !empty($args['fields'])) {
			$coupargs['fields'] = $args['fields'];
		}
		
		//return based on meta query
		if(isset($args['meta_query']) && !empty($args['meta_query'])) {
			$coupargs['meta_query'] = $args['meta_query'];
		}
		
		//fire query in to table for retriving data
		$result = new WP_Query( $coupargs );		
		
		if(isset($args['getcount']) && $args['getcount'] == '1') {
			$postslist = $result->post_count;	
		} else {
			//retrived data is in object format so assign that data to array for listing
			$postslist = $this->model->woo_vou_object_to_array($result->posts);

			// if get list for voucher list then return data with data and total array
			if( isset($args['woo_vou_list']) && $args['woo_vou_list'] ) {

				$data_res	= array();

				$data_res['data'] 	= $postslist;

				//To get total count of post using "found_posts" and for users "total_users" parameter
				$data_res['total']	= isset($result->found_posts) ? $result->found_posts : '';

				return $data_res;
			}
		}

		return apply_filters( 'woo_vou_get_coupon_details', $postslist, $args );
	}

	/**
	 * Get downloadable vouchers files
	 * 
	 * Handles to get downloadable vouchers files
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.0.0
	 */
	public function woo_vou_get_vouchers_download_key( $order_id = '', $product_id = '', $item_id = '' ) {

		$prefix	= WOO_VOU_META_PREFIX;
		$downloadable_files	= array();

		//Get mutiple pdf option from order meta
		$multiple_pdf = empty( $order_id ) ? '' : get_post_meta( $order_id, $prefix . 'multiple_pdf', true );

		// Getting Voucher Delivery
		$woo_vou_all_ordered_data 	= $this->model->woo_vou_get_all_ordered_data( $order_id ); // Getting order meta data
		$product_data 				= wc_get_product( $product_id ); //Getting the product
		$parent_product_id 			= $this->model->woo_vou_get_item_productid_from_product( $product_data ); // Get parent id
        $vou_voucher_delivery_type 	= 'email'; // Declare Voucher Delivery

		// If this variation then get it's product id
		if( $product_data->is_type('variation') && (isset($woo_vou_all_ordered_data[$parent_product_id]['voucher_delivery']) && is_array($woo_vou_all_ordered_data[$parent_product_id]['voucher_delivery']) ) ){

		    $vou_voucher_delivery_type = $woo_vou_all_ordered_data[$parent_product_id]['voucher_delivery'][$product_id]; // Get voucher delivery type
		} elseif(isset($woo_vou_all_ordered_data[$product_id]['voucher_delivery'])) {

		    $vou_voucher_delivery_type = $woo_vou_all_ordered_data[$product_id]['voucher_delivery']; // Get voucher delievery type
		}

		// If backend is rendered
		if ( is_admin() ) {

			// Get current screen
			$get_current_screen = get_current_screen();

			// If page parent is woocommerce and post type is shop order
			if( !empty($get_current_screen) && $get_current_screen->parent_base == 'woocommerce' && $get_current_screen->post_type == 'shop_order' ){

				$vou_voucher_delivery_type = 'email';
			}
		}

		if( !empty( $order_id ) && ( $vou_voucher_delivery_type == 'email' ) ) {

			if( $multiple_pdf == 'yes' ) { //If multiple pdf is set

				$vouchercodes	= $this->woo_vou_get_multi_voucher_key( $order_id, $product_id, $item_id );

				foreach ( $vouchercodes as $codes ) {

					$downloadable_files[$codes] = array(
															'name' => woo_vou_voucher_download_text( $product_id ),
															'file' => get_permalink( $product_id )
														);
				}
			} else {

				// Set our vocher download file in download files
				$downloadable_files['woo_vou_pdf_1'] = array(
																'name' => woo_vou_voucher_download_text( $product_id ),
																'file' => get_permalink( $product_id )
															);
			}
		}

		return apply_filters( 'woo_vou_get_vouchers_download_key', $downloadable_files, $order_id, $product_id, $item_id );
	}

	/**
	 * Check Voucher Code
	 * 
	 * Handles to check voucher code
	 * is valid or invalid via ajax
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.1.0
	 */
	public function woo_vou_check_voucher_code() {

		global $current_user, $woo_vou_vendor_role;

		$prefix				= WOO_VOU_META_PREFIX;
		$product_name		= '';
		$product_id			= '';
		$expiry_Date		= '';
		$response['expire']	= false;
		$vou_code_args		= array();
		$used_code_args		= array();

		if( !empty( $_POST['voucode'] ) ) { // Check voucher code is not empty

			//Voucher Code
			$voucode = strtolower( $_POST['voucode'] );
			$voucode = trim( $voucode );

			//Get User roles
			$user_roles	= isset( $current_user->roles ) ? $current_user->roles : array();
			$user_role	= array_shift( $user_roles );

			//voucher admin roles
			$admin_roles	= woo_vou_assigned_admin_roles();

			if( !in_array( $user_role, $admin_roles ) ) {// voucher admin can redeem all codes

				$vou_code_args['author']	= $current_user->ID;
				$used_code_args['author']	= $current_user->ID;
			}

			// arguments for get purchased an used voucher code detail
			$vou_code_args['fields']		= 'ids';
			$vou_code_args['meta_query']	= array(
													array(
														'key' 		=> $prefix . 'purchased_codes',
														'value' 	=> $voucode
													),
													array(
														'key'     	=> $prefix . 'used_codes',
														'compare' 	=> 'NOT EXISTS'
													)
												);

			// this always return array
			$voucodedata = $this->woo_vou_get_voucher_details( apply_filters( 'woo_vou_get_primary_vendor_purchase_voucode_args', $vou_code_args ) );

			// argunments array for used voucher code
			$used_code_args['fields']		= 'ids';
			$used_code_args['meta_query']	= array(
													array(
														'key' 		=> $prefix . 'used_codes',
														'value' 	=> $voucode
													)
												);

			// for used voucher code
			$usedcodedata = $this->woo_vou_get_voucher_details( apply_filters( 'woo_vou_get_primary_vendor_used_voucode_args', $used_code_args ) );

			//Make meta args for secondary vendor
			$secvendor_args	= array(
										  'key'     => $prefix.'sec_vendor_users',
										  'value'   => $current_user->ID,
										  'compare'	=> 'LIKE'
									);

			//Argument for second query voucher code
			unset( $vou_code_args['author'] );
			$vou_code_args['meta_query'][] = $secvendor_args; 

			//Combined both result in main voucher code
			$voucodedata2	= $this->woo_vou_get_voucher_details( $vou_code_args );
			$voucodedata	= array_unique( array_merge( $voucodedata, $voucodedata2 ) );

			//Argument for second query voucher code
			unset( $used_code_args['author'] );
			$used_code_args['meta_query'][] = $secvendor_args; 

			//Combined both result in main voucher code
			$usedcodedata2	= $this->woo_vou_get_voucher_details( $used_code_args );
			$usedcodedata	= array_unique( array_merge( $usedcodedata, $usedcodedata2 ) );

			if( !empty( $voucodedata ) && is_array( $voucodedata ) ) { // Check voucher code ids are not empty

				$voucodeid = isset( $voucodedata[0] ) ? $voucodedata[0] : '';
				
				if( !empty( $voucodeid ) ) {

					//get vouchercodes data 
					$voucher_data	= get_post( $voucodeid );
					$order_id		= get_post_meta( $voucodeid , $prefix.'order_id' , true );
					$cart_details	= new Wc_Order( $order_id );
					$order_items	= $cart_details->get_items();

					foreach ( $order_items as $item_id => $download_data ) {

						$voucher_codes	= wc_get_order_item_meta( $item_id, $prefix.'codes' );
						$voucher_codes	= !empty( $voucher_codes ) ? explode(',',$voucher_codes) : array();
						$voucher_codes	= array_map( 'trim', $voucher_codes );
						$voucher_codes  = array_map( 'strtolower', $voucher_codes );

						if( in_array( $voucode, $voucher_codes ) ) {

							//get product data
							$product_name = $download_data['name'];
							$product_id  = $download_data['product_id'];
						}
					}
				}
				
				//voucher start date
				$start_Date = get_post_meta( $voucodeid , $prefix .'start_date' ,true );
				
				//voucher expired date
				$expiry_Date = get_post_meta( $voucodeid , $prefix .'exp_date' ,true );
				
				$response['success'] = apply_filters( 'woo_vou_voucher_code_valid_message', sprintf( __( 'Voucher code is valid and this voucher code has been bought for %s. ' . "\n" . 'If you would like to redeem voucher code, Please click on the redeem button below:', 'woovoucher' ), $product_name ), $product_name );								
				
				if( !empty( $product_id) ) {				
					$disable_redeem_days = get_post_meta( $voucodeid, $prefix.'disable_redeem_day', true );				
					if( !empty($disable_redeem_days ) ) { // check days are selected					
						$current_day = date('l');
						
						if( in_array( $current_day, $disable_redeem_days ) ) { // check current day redeem is enable or not
							$message = implode(", ", $disable_redeem_days );
	
						 	$response['success'] = apply_filters( 'woo_vou_voucher_code_disabled_message', sprintf( __( 'Sorry, voucher code is not allowed to be used on %s. ' . "\n" ,'woovoucher'), $message ,$product_name ));
						 	$response['allow_redeem_expired_voucher'] = "no";
						 	$response['expire'] = true;
						}
					}
				}				
				
				if( isset( $start_Date ) && !empty( $start_Date ) ) {

					if( $start_Date > $this->model->woo_vou_current_date() ) {
						
						$response['before_start_date'] = true;
						$response['success'] = apply_filters( 'woo_vou_voucher_code_before_start_message', sprintf( __( 'Voucher code cannot be redeemed before %s for %s.' . "\n" ,'woovoucher'), $this->model->woo_vou_get_date_format( $start_Date , true ) ,$product_name ), $product_name, $start_Date );		
					}
				}
				
				if( isset( $expiry_Date ) && !empty( $expiry_Date ) ) {

					if( $expiry_Date < $this->model->woo_vou_current_date() ) {
						
						$response['expire'] = true;
						
						// check need to allow redeem for expired vouchers
						$allow_redeem_expired_voucher = get_option('vou_allow_redeem_expired_voucher');
						if( $allow_redeem_expired_voucher == "yes" )
							$response['allow_redeem_expired_voucher'] = "yes";
						else
							$response['allow_redeem_expired_voucher'] = "no";
							
						$response['success'] = apply_filters( 'woo_vou_voucher_code_expired_message', sprintf( __( 'Voucher code was expired on %s for %s. ' . "\n" ,'woovoucher'), $this->model->woo_vou_get_date_format( $expiry_Date , true ) ,$product_name ), $product_name, $expiry_Date );		
					}
				}
				
				$response['product_detail'] = $this->woo_vou_get_product_detail( $order_id, $voucode, $voucodeid );

			} else if (!empty( $usedcodedata ) && is_array( $usedcodedata ) ) { // Check voucher code is used or not

				$voucodeid = isset( $usedcodedata[0] ) ? $usedcodedata[0] : '';

				if( !empty( $voucodeid ) ) { //if voucher code id is not empty

					$voucher_data 		= get_post( $voucodeid );
					$order_id 			= get_post_meta( $voucodeid , $prefix.'order_id' , true );
					$cart_details 		= new Wc_Order( $order_id );
					$order_items 		= $cart_details->get_items();

					foreach ( $order_items as $item_id => $download_data ) {

						$voucher_codes	= wc_get_order_item_meta( $item_id, $prefix.'codes' );
						$voucher_codes	= !empty( $voucher_codes ) ? explode(',',$voucher_codes) : array();
						$voucher_codes	= array_map( 'trim', $voucher_codes );
						$voucher_codes	= array_map( 'strtolower', $voucher_codes );

						$check_code		= trim( $voucode );
						$check_code		= strtolower( $check_code );

						if( in_array( $check_code, $voucher_codes ) ) {

							//get product data
							$product_name 		= $download_data['name'];
						}
					}
				}

				// get used code date
				$used_code_date = get_post_meta( $voucodeid, $prefix.'used_code_date', true );
				$response['used'] = apply_filters( 'woo_vou_voucher_code_used_message', sprintf( __( 'Voucher code is invalid, was used on %s for %s.', 'woovoucher' ), $this->model->woo_vou_get_date_format( $used_code_date, true ), $product_name ), $product_name, $used_code_date );

			} else {
				$response['error'] = apply_filters( 'woo_vou_voucher_code_invalid_message', __( 'Voucher code doesn\'t exist.', 'woovoucher' ) );
			}

			if( isset( $_POST['ajax'] ) && $_POST['ajax'] == true ) {  // if request through ajax
				echo json_encode( $response );
				exit;	
			} else {
				return $response;
			}
		}
	}

	/**
	 * Get Product Detail From Order ID
	 * 
	 * Handles to get product detail
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.6.2
	 */
	public function woo_vou_get_product_detail( $order_id, $voucode, $voucodeid = '' ) {

		ob_start();
		require( WOO_VOU_ADMIN . '/forms/woo-vou-check-code-product-info.php' );
		$html = ob_get_clean();
		
		return apply_filters( 'woo_vou_get_product_detail', $html, $order_id, $voucode, $voucodeid );
	}

	/**
	 * Save Voucher Code
	 * 
	 * Handles to save voucher code via ajax
	 *
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.1.0
	 */
	public function woo_vou_save_voucher_code( $coupon = '', $order = '' ) {

		$prefix = WOO_VOU_META_PREFIX;

		global $woo_vou_vendor_role, $current_user;

		if( !empty( $_POST['voucode'] ) ) { // Check voucher code is not empty

			//Voucher Code
			$voucode = $_POST['voucode'];
			
			// Get partial redeem global settings
			$enable_partial_redeem = get_option( 'vou_enable_partial_redeem' );
			
			$usage_limit = $usage_count = $redeem_method = '';

			if( $enable_partial_redeem == "yes" ) {
				
				if ( isset( $_POST['ajax'] ) && $_POST['ajax'] == true ) {
					// redeem Amount
					$redeem_amount = isset( $_POST['vou_partial_redeem_amount'] ) && !empty( $_POST['vou_partial_redeem_amount'] ) ? $_POST['vou_partial_redeem_amount'] : '';
					// redeem Method  
					$redeem_method = isset( $_POST['vou_redeem_method'] ) && !empty( $_POST['vou_redeem_method'] ) ? $_POST['vou_redeem_method'] : '';
					// total price
					$total_price = isset( $_POST['vou_code_total_price'] ) && !empty( $_POST['vou_code_total_price'] ) ? $_POST['vou_code_total_price'] : '';
					// redeemed price
					$total_redeemed_price = isset( $_POST['vou_code_total_redeemed_price'] ) && !empty( $_POST['vou_code_total_redeemed_price'] ) ? $_POST['vou_code_total_redeemed_price'] : '';
					// remaining redeem price
					$remaining_redeem_price = isset( $_POST['vou_code_remaining_redeem_price'] ) && !empty( $_POST['vou_code_remaining_redeem_price'] ) ? $_POST['vou_code_remaining_redeem_price'] : '';
					
					// in case if javascript validation fail then this will prevent from redeem wrong amount
					if( $redeem_method == 'partial' && ( $redeem_amount == '' || $redeem_amount > $remaining_redeem_price ) ) {
						return;
					}
				} else {
					
				    if ( $order ) {
    					// redeem Amount
    					$redeem_amount = $order->get_subtotal();
    					// redeem Method  
    					$redeem_method = 'partial';
    					// remaining redeem price
    					//$remaining_redeem_price = isset( $_POST['vou_code_remaining_redeem_price'] ) && !empty( $_POST['vou_code_remaining_redeem_price'] ) ? $_POST['vou_code_remaining_redeem_price'] : '';
				    } else {
				        // Redeem method
				        $redeem_method = $_POST['vou_redeem_method'];
				        // Remainning Redeem Price
				        $remaining_redeem_price = $_POST['vou_code_remaining_redeem_price'];
				        // Redeem Amount
				        $redeem_amount = $_POST['vou_partial_redeem_amount'];
				    }
				}
			}

			//Check voucher code
			$args	= array();

			//Get User roles
			$user_roles	= isset( $current_user->roles ) ? $current_user->roles : array();

			//Get user id
			$user_id	= isset( $current_user->ID ) ? $current_user->ID : '';

			//Get user role
			$user_role	= array_shift( $user_roles );

			//get voucher admin roles
			$admin_roles	= woo_vou_assigned_admin_roles();

			if( !in_array( $user_role, $admin_roles ) ) {// voucher admin can redeem all voucher codes
				$args['author'] = $user_id;
			}
			
			$args['fields']		= 'ids';
			$args['meta_query']	= array(
										array(
												'key' 		=> $prefix . 'purchased_codes',
												'value' 	=> $voucode
											),
										array(
												'key'     	=> $prefix . 'used_codes',
												'compare' 	=> 'NOT EXISTS'
										)
									);

			$voucodedata = $this->woo_vou_get_voucher_details( $args );

			//Make meta args for secondary vendor
			$secvendor_args	= array(
										  'key'     => $prefix.'sec_vendor_users',
										  'value'   => $user_id,
										  'compare'	=> 'LIKE'
									);

			//Argument for second query voucher code
			unset( $args['author'] );
			$args['meta_query'][] = $secvendor_args; 

			//Combined both result in main voucher code
			$voucodedata2	= $this->woo_vou_get_voucher_details( $args );
			$voucodedata	= array_unique( array_merge( $voucodedata, $voucodedata2 ) );

			// arguments for getting coupon id
			$args = array(
							'fields'		=> 'ids',
							'name' 			=> strtolower( $voucode ),
							array(
									'key' 		=> $prefix . 'coupon_type',
									'value' 	=> 'voucher_code'
								),
							/*array(
									'key'     	=> 'usage_count',
									'compare' 	=> 'NOT EXISTS'
							)*/
						);
			
			// Get Coupon code data
			$coupon_code_data = $this->woo_vou_get_coupon_details( $args );
			
			if ( !empty ( $coupon_code_data ) ) {
				
				foreach ( $coupon_code_data as $coupon_code ) {
					
					// Get coupon_type
					$coupon_type = get_post_meta( $coupon_code, $prefix . 'coupon_type', true );

					// Get coupon amount
					$coupon_amount = get_post_meta( $coupon_code, 'coupon_amount', true );

					// Get usage limit for coupon
					$usage_limit = get_post_meta ( $coupon_code, 'usage_limit', true );
					
					// Get usage count
					$usage_count = get_post_meta ( $coupon_code, 'usage_count', true );
				}
			}

			if( !empty( $voucodedata ) && is_array( $voucodedata ) && ( empty( $usage_limit ) || ( $usage_count + 1 ) <= $usage_limit ) ) { // Check voucher code ids are not empty
				
				//current date
				$today = $this->model->woo_vou_current_date();								

				// if partial redeem is enabled then process parial redeem
				if( $enable_partial_redeem == "yes" && !empty( $redeem_method ) && $redeem_method == 'partial' ) {
					
					foreach ( $voucodedata as $voucodeid ) {
						
						if ( !empty ( $order ) ) { // If order is not empty
						
							$_coupons = $order->get_items( 'coupon' ); // Get coupon items
							
							foreach ( $_coupons as $item_id => $item ) {

								$discount = $item['discount_amount']; // Get coupon discount amount
							}

							// If coupon type is 'voucher_code' and coupon_amount is empty
							if ( $coupon_type == 'voucher_code' && !empty( $coupon_amount ) ) {

								// Assign discount amount
								$redeem_amount = $discount;
								$remaining_redeem_price = $coupon_amount - $discount;
							}
						}

						$this->woo_vou_save_partialy_redeem_voucher_code( $voucodeid, $redeem_amount, $voucode );	
						
						if( $remaining_redeem_price == 0 ) { // need to save full redeem data
							
							// update used codes
							update_post_meta( $voucodeid, $prefix.'used_codes', $voucode );
		
							// update redeem by
							update_post_meta( $voucodeid, $prefix.'redeem_by', $user_id );
		
							// update used code date
							update_post_meta( $voucodeid, $prefix.'used_code_date', $today );
		
							//after redeem voucher code
							do_action( 'woo_vou_redeemed_voucher_code', $voucodeid );		
						}
						
						// break is neccessary so if 2 code found then only 1 get marked as completed.
						break;
					}

					foreach ( $coupon_code_data as $coupon_code ) {

						$redeemable_price = $coupon_amount - $redeem_amount;

						// Update coupon amount
						update_post_meta( $coupon_code, 'coupon_amount', $redeemable_price );

						if ( empty ( $coupon ) ) { // Only update usage_count if voucher code is not redeemed from online store
							
							// Update meta for 'usage_count'
							update_post_meta( $coupon_code, 'usage_count', $usage_count+1 );
						}
						
						if ( empty ( $redeemable_price ) ) { // If redeemable price is empty then update usage_limit to maximum usage_count

							// Update usage_limit to maximum number of usages
							update_post_meta( $coupon_code, 'usage_limit', $usage_count+1 );
							
							// Update meta for '_used_by'
							add_post_meta( $coupon_code, '_used_by', $user_id );
						}
					}
										
				} else {															
	
					foreach ( $voucodedata as $voucodeid ) {
						
						if( $redeem_method == 'full' ) {														

							$this->woo_vou_save_partialy_redeem_voucher_code( $voucodeid, $remaining_redeem_price ,$voucode );
						}
	
						// update used codes
						update_post_meta( $voucodeid, $prefix.'used_codes', $voucode );
	
						// update redeem by
						update_post_meta( $voucodeid, $prefix.'redeem_by', $user_id );
	
						// update used code date
						update_post_meta( $voucodeid, $prefix.'used_code_date', $today );

						//after redeem voucher code
						do_action( 'woo_vou_redeemed_voucher_code', $voucodeid );
						
						// break is neccessary so if 2 code found then only 1 get marked as completed.
						break;
					}
						
					foreach ( $coupon_code_data as $coupon_code ) {

						if ( empty ( $coupon ) ) { // Only update usage_count if voucher code is not redeemed from online store
							
							// Update meta for 'usage_count'
							update_post_meta( $coupon_code, 'usage_count', $usage_count+1 );
							
							// Update meta for '_used_by'
							add_post_meta( $coupon_code, '_used_by', $user_id );
						}
						
						// Update coupon amount
						update_post_meta( $coupon_code, 'coupon_amount', 0 );
						
						if ( empty ( $usage_limit ) ) { // If $usage_limit is 0 then update it to maximum usage_count

							// Update usage_limit to maximum number of usages
							update_post_meta( $coupon_code, 'usage_limit', $usage_count+1 );
						}
					}
				}
			} else {

				$used_code_args['fields']		= 'ids';
				$used_code_args['meta_query']	= array(
														array(
																'key' 		=> $prefix . 'purchased_codes',
																'value' 	=> $voucode
															)
													);

				$voucodedata = $this->woo_vou_get_voucher_details( $used_code_args );

				foreach ( $voucodedata as $voucodeid ) {

					if( !empty( $voucodeid ) ) { //if voucher code id is not empty

						$voucher_data 		= get_post( $voucodeid );
						$order_id 			= get_post_meta( $voucodeid , $prefix.'order_id' , true );
						$cart_details 		= new Wc_Order( $order_id );
						$order_items 		= $cart_details->get_items();

						foreach ( $order_items as $item_id => $download_data ) {
	
							$voucher_codes	= wc_get_order_item_meta( $item_id, $prefix.'codes' );
							$voucher_codes	= !empty( $voucher_codes ) ? explode(',',$voucher_codes) : array();
							$voucher_codes	= array_map( 'trim', $voucher_codes );
							$voucher_codes	= array_map( 'strtolower', $voucher_codes );
	
							$check_code		= trim( $voucode );
							$check_code		= strtolower( $check_code );
	
							if( in_array( $check_code, $voucher_codes ) ) {
	
								//get product data
								$product_name 		= $download_data['name'];
							}
						}
					}

					// get used code date
					$used_code_date = get_post_meta( $voucodeid, $prefix.'used_code_date', true );
				}
				
				$response['fail'] = 'fail';
				$response['error_message'] = apply_filters( 'woo_vou_voucher_code_used_message', sprintf( __( 'Voucher code is invalid, was used on %s for %s.', 'woovoucher' ), $this->model->woo_vou_get_date_format( $used_code_date, true ), $product_name ), $product_name, $used_code_date );;
				echo json_encode( $response );
				exit;
			}

			if( isset( $_POST['ajax'] ) && $_POST['ajax'] == true ) { // if request through ajax
				$response['success'] = 'success';
				echo json_encode( $response );
				exit;
			} else {
				return 'success';
			}
		}
	}

	/**
	 * AJAX call 
	 * 
	 * Handles to show details of with ajax
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.8.1
	 */
	public function woo_vou_used_voucher_codes_ajax() {

		if ( is_user_logged_in() ) {
			ob_start();
			//do action to load used voucher codes html via ajax
			do_action( 'woo_vou_used_voucher_codes' );
			echo ob_get_clean();
			exit;
		} else {
			return __( 'You have no Used Voucher Codes yet.', 'woocommerce' );
		}
	}
	
	/**
	 * AJAX call 
	 * 
	 * Handles to show details for purchased voucher codes with ajax
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.8.1
	 */
	public function woo_vou_purchased_voucher_codes_ajax() {
	    
	    if ( is_user_logged_in() ) {
			ob_start();
			//do action to load used voucher codes html via ajax
			do_action( 'woo_vou_purchased_voucher_codes' );
			echo ob_get_clean();
			exit;
		} else {
			return __( 'You have no Used Voucher Codes yet.', 'woocommerce' );
		}
	}

	/**
	 * Restore Voucher Code
	 * 
	 * Handles to restore voucher codes
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 1.6.2
	 */
	public function woo_vou_restore_voucher_codes( $order_id, $old_status, $new_status ) {

		//Get prefix
		$prefix	= WOO_VOU_META_PREFIX;

		if( $new_status == 'cancelled' ) { //If status cancelled, failed
			$this->woo_vou_restore_order_voucher_codes( $order_id );
		}

		if( $new_status == 'refunded' ) { //If status refunded
			$this->woo_vou_refund_order_voucher_codes( $order_id );
		}
	}

	/**
	 * Restore Voucher When Resume Order
	 * 
	 * Handle to restore old deduct voucher
	 * when item overwite in meta field
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 2.4.0
	 */
	public function woo_vou_resume_order_voucher_codes( $order_id ) {
		
		$this->woo_vou_restore_order_voucher_codes( $order_id );
	}
	
	public function woo_vou_generate_posts_from_vou_codes($allcodes, $order_id, $vou_code_post_data){

		$prefix	= WOO_VOU_META_PREFIX; //Get prefix
		
		extract($vou_code_post_data);
		$all_vou_codes = !empty($allcodes) ? explode(', ', $allcodes) : array();
        $sec_vendor_users = get_post_meta($productid, $prefix.'sec_vendor_users', true); //Secondary vendors

        foreach ($all_vou_codes as $vou_code) {

            $vou_code = trim($vou_code, ',');
            $vou_code = trim($vou_code);

            //Insert voucher details into custom post type with seperate voucher code
            $vou_codes_args = array(
                'post_title' => $order_id,
                'post_content' => '',
                'post_status' => 'pending',
                'post_type' => WOO_VOU_CODE_POST_TYPE,
                'post_parent' => $productid
            );

            if (!empty($vendor_user)) { // Check vendor user is not empty
                $vou_codes_args['post_author'] = $vendor_user;
            }

            $vou_codes_id = wp_insert_post($vou_codes_args);

            if ($vou_codes_id) { // Check voucher codes id is not empty
                // update buyer first name
                update_post_meta($vou_codes_id, $prefix . 'first_name', $userfirstname);
                // update buyer last name
                update_post_meta($vou_codes_id, $prefix . 'last_name', $userlastname);
                // update order id
                update_post_meta($vou_codes_id, $prefix . 'order_id', $order_id);
                // update order date
                update_post_meta($vou_codes_id, $prefix . 'order_date', $order_date);
                // update start date
                update_post_meta($vou_codes_id, $prefix . 'start_date', $start_date);
                // update expires date
                update_post_meta($vou_codes_id, $prefix . 'exp_date', $exp_date);
                // update disable redeem days
                update_post_meta($vou_codes_id, $prefix . 'disable_redeem_day', $disable_redeem_days);
                // update purchased codes
                update_post_meta($vou_codes_id, $prefix . 'purchased_codes', $vou_code);
                //update secondary vendors
                $sec_vendors = !empty($sec_vendor_users) ? implode(',', $sec_vendor_users) : '';
                update_post_meta($vou_codes_id, $prefix . 'sec_vendor_users', $sec_vendors);

                $vou_from_variation = get_post_meta($productid, $prefix . 'is_variable_voucher', true);

                if (!empty($vou_from_variation)) {

                    // update purchased codes
                    update_post_meta($vou_codes_id, $prefix . 'vou_from_variation', $data_id);
                }

                do_action('woo_vou_update_voucher_code_meta', $vou_codes_id, $order_id, $item_id, $productid);
            }
        }
	}

	/**
	 * Return voucher code id from voucher code
	 *
	 * @package WooCommerce - PDF Vouchers
	 * @since 3.2.3
	 */
	public function woo_vou_get_voucodeid_from_voucode($voucode){

		// Get prefix
		$prefix		= WOO_VOU_META_PREFIX;

		// Declare variable
		$voucode_id = 0;

		// arguments for get purchase voucher details
		$vou_code_args['fields']		= 'ids';
		$vou_code_args['meta_query']	= array(
												array(
													'key' 		=> $prefix . 'purchased_codes',
													'value' 	=> $voucode
												)
											);

		// get purchsed voucher codes data
		$voucodedata = $this->woo_vou_get_voucher_details( $vou_code_args );

		if(!empty($voucodedata)){

			$voucode_id = $voucodedata[0];
		}

		// Return voucher code
		return $voucode_id;
	}

	/**
	 * Change Voucher Code Expiry Date
	 * 
	 * Handles to change voucher code expiry date
	 * is valid or invalid via ajax
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 3.2.3
	 */
	public function woo_vou_change_voucher_expiry_date() {
		
		global $model;
		$prefix = WOO_VOU_META_PREFIX;
		
		// Declare variables
		$voucher_id 			= $_POST['voucher_id'];
		$order_id 				= get_post_meta( $voucher_id, $prefix.'order_id', true ); 
		$voucher_parent_id 		= wp_get_post_parent_id( $voucher_id );
		$purchased_codes 	 	= get_post_meta( $voucher_id, $prefix.'purchased_codes', true );
		$voucher_expiry_date 	= $_POST['voucher_expiry_date'];
		$voucher_old_exp_date	= get_post_meta( $voucher_id, $prefix.'exp_date', true );
		$voucher_new_exp_date 	= !empty($voucher_expiry_date)? date('Y-m-d H:i:s', strtotime( $voucher_expiry_date )) : '';
		
        $meta_order_details 	= get_post_meta( $order_id, $prefix . 'meta_order_details', true);
        
        $meta_order_details[$voucher_parent_id]['exp_date'] = $voucher_new_exp_date;
        //$meta_order_details = $model->woo_vou_get_all_ordered_data($order_id);
        
		$response['success'] 	 = false;
        if( !empty($order_id) && !empty($voucher_parent_id) ){
			$response['success'] 	 = true;
			
			update_post_meta( $voucher_id, $prefix.'exp_date', $voucher_new_exp_date );
			update_post_meta( $order_id, $prefix.'exp_date', $voucher_new_exp_date );
			update_post_meta( $order_id, $prefix.'meta_order_details', $meta_order_details );

			// Getting the coucher codes from order id
			$woo_shop_coupon_posts_args = array(
				'post_type'  	 => 'shop_coupon',
				'posts_per_page' => -1,
				'title'	 		 => $purchased_codes,
				'meta_query' 	 => array(
						'relation' => 'AND',
						array(
							'key'     => $prefix.'order_id',
							'value'   => $order_id,
							'compare' => '=',
						),
						array(
							'key'     => $prefix.'coupon_type',
							'value'   => 'voucher_code',
							'compare' => '=',
						),
				),
			);
			$woo_shop_coupon_posts = get_posts( $woo_shop_coupon_posts_args );
			
			if( !empty( $woo_shop_coupon_posts ) ){
				
				foreach ( $woo_shop_coupon_posts as $woo_shop_coupon_post_data ){
					
					$woo_shop_coupon_id = $woo_shop_coupon_post_data->ID;
					
					$woo_shop_coupon_expiry_date = get_post_meta( $woo_shop_coupon_id, 'expiry_date', true );
					update_post_meta( $woo_shop_coupon_id, 'expiry_date', $voucher_new_exp_date, $woo_shop_coupon_expiry_date );
				}
			}
				
				
        }
		$response['error_msg']	 = __( 'Sorry, voucher code expiry date not changed. ', 'woovoucher');
		$response['success_msg'] = __( 'Voucher code expiry date has changed. ', 'woovoucher');
		
		echo json_encode( $response );
		exit();
	}

	/**
	 * Get Voucher Code Expiry Date
	 * 
	 * Handles to getting voucher code expiry date
	 * is valid or invalid via ajax
	 * 
	 * @package WooCommerce - PDF Vouchers
	 * @since 3.2.3
	 */
	public function woo_vou_get_voucher_expiry_date() {
		
		$prefix = WOO_VOU_META_PREFIX;

		// Declare variables
		$voucher_id 		 = $_POST['voucher_id'];
		$purchased_codes 	 = get_post_meta( $voucher_id, $prefix.'purchased_codes', true );
		$voucher_exp_date	 = get_post_meta( $voucher_id, $prefix.'exp_date', true );
		$voucher_start_date	 = get_post_meta( $voucher_id, $prefix.'start_date', true );
		
		// Set response data
		$response['success'] 		 = ( !empty($purchased_codes) || !empty($voucher_id) )? true : false;
		$response['voucher_id'] 	 = ( !empty($voucher_id) )? $voucher_id : '';
		$response['purchased_codes'] = ( !empty($purchased_codes) )? $purchased_codes : '';
		$response['start_date']		 = ( !empty($voucher_start_date) )? date('d-m-Y h:i a', strtotime( $voucher_start_date )) : date('d-m-Y'); //.' 00:00';
		$response['exp_date']		 = ( !empty($voucher_exp_date) )? date('d-m-Y h:i a', strtotime( $voucher_exp_date )) : '';
		
		echo json_encode( $response );
		exit();
	}
}