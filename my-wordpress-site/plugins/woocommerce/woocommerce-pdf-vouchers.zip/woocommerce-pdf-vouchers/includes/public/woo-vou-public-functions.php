<?php
// Exit if accessed directly
if (!defined('ABSPATH'))
    exit;

/**
 * Add Capability to vendor role
 * 
 * Handle to add capability to vendor role
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 1.0.0
 */
function woo_vou_initilize_role_capabilities() {

    global $woo_vou_vendor_role;

    $class_exist = apply_filters('woo_vou_initilize_role_capabilities', class_exists('WC_Vendors'));

    //Return if class not exist 
    if (!$class_exist)
        return;

    foreach ($woo_vou_vendor_role as $vendor_role) {

        //get vendor role
        $vendor_role_obj = get_role($vendor_role);

        if (!empty($vendor_role_obj)) { // If vendor role is exist 
            if (!$vendor_role_obj->has_cap(WOO_VOU_VENDOR_LEVEL)) { //If capabilty not exist
                //Add vucher level capability to vendor roles
                $vendor_role_obj->add_cap(WOO_VOU_VENDOR_LEVEL);
            }
        }
    }
}

/**
 * Handles to update voucher details in order data
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 1.0.0
 */
function woo_vou_product_purchase($order_id) {
	
	global $woo_vou_model, $woo_vou_voucher;

    //Get Prefix
    $prefix = WOO_VOU_META_PREFIX;

    $changed = false;
    $voucherdata = $vouchermetadata = $recipient_order_meta = array();

    $order = wc_get_order($order_id);

    //Get user data from order
    $userdata = $woo_vou_model->woo_vou_get_buyer_information($order_id);

    //Get buyers information
    $userfirstname = isset($userdata['first_name']) ? trim($userdata['first_name']) : '';
    $userlastname = isset($userdata['last_name']) ? trim($userdata['last_name']) : '';
    $useremail = isset($userdata['email']) ? $userdata['email'] : '';
    $buyername = str_replace(' ', '_', $userfirstname);

    $order_items = $order->get_items();
    $order_date = $woo_vou_model->woo_vou_get_order_date_from_order($order);

    if (is_array($order_items)) {

        // Check cart details
        foreach ($order_items as $item_id => $item) {

            //get product id
            $productid = $item['product_id'];

            //get product quantity
            $productqty = apply_filters('woo_vou_order_item_qty', $item['qty'], $item);

            // Taking variation id
            $variation_id = !empty($item['variation_id']) ? $item['variation_id'] : '';

            // If product is variable product take variation id else product id
            $data_id = (!empty($variation_id) ) ? $variation_id : $productid;

            //Get voucher code from item meta "Now we store voucher codes in item meta fields"
            $codes_item_meta = wc_get_order_item_meta($item_id, $prefix.'codes');

            if (empty($codes_item_meta)) {// If voucher data are not empty so code get executed once only
                //voucher codes
                $vou_codes = $woo_vou_voucher->woo_vou_get_voucher_code($productid, $variation_id);

                //vendor user
                $vendor_user = get_post_meta($productid, $prefix.'vendor_user', true);

                //get vendor detail
                $vendor_detail = $woo_vou_model->woo_vou_get_vendor_detail($productid, $variation_id, $vendor_user );

                //using type of voucher
                $using_type = isset($vendor_detail['using_type']) ? $vendor_detail['using_type'] : '';

                $allow_voucher_flag = true;

                // if using type is one time and voucher code is empty or quantity is zero
                if (empty($using_type) && (empty($vou_codes) )) { // || $avail_total_codes == '0'
                    $allow_voucher_flag = false;
                }

                //check enable voucher & is downlable & total codes are not empty
                if ($woo_vou_voucher->woo_vou_check_enable_voucher($productid, $variation_id) && $allow_voucher_flag == true) {

					$start_date = get_post_meta($productid, $prefix.'start_date', true); // start date
                    $start_date = !empty($start_date) ? date('Y-m-d H:i:s', strtotime($start_date)) : ''; // format start date
                    $manual_expire_date = get_post_meta($productid, $prefix.'exp_date', true); // expiration date
                    $exp_date = !empty($manual_expire_date) ? date('Y-m-d H:i:s', strtotime($manual_expire_date)) : ''; // format exp date
                    $disable_redeem_days = get_post_meta($productid, $prefix.'disable_redeem_day', true); // Disable redeem days
                    
                    if (empty($disable_redeem_days))
                        $disable_redeem_days = '';

                    $exp_type = get_post_meta($productid, $prefix . 'exp_type', true); //get expiration tpe
                    $custom_days = $allcodes = ''; //custom days

                    if ($exp_type == 'based_on_purchase') { //If expiry type based in purchase
                        //get days difference
                        $days_diff = get_post_meta($productid, $prefix.'days_diff', true);

                        if ($days_diff == 'cust') {
                            $custom_days = get_post_meta($productid, $prefix . 'custom_days', true);
                            $custom_days = isset($custom_days) ? $custom_days : '';

                            if (!empty($custom_days)) {

                                $add_days = '+' . $custom_days . ' days';
                                $exp_date = date('Y-m-d H:i:s', strtotime($order_date . $add_days));
                            } else {

                            	$exp_date = '';
                            }
                        } else {
                            $custom_days = $days_diff;
                            $add_days = '+' . $custom_days . ' days';
                            $exp_date = date('Y-m-d H:i:s', strtotime($order_date . $add_days));
                        }
                    } else if( ($exp_type == 'default')) { // If product meta is set to default

	                    $exp_type = get_option('vou_exp_type'); //get expiration type 
	                    
	                    if($exp_type == 'specific_date') { //If expiry type specific date

	                    	$start_date = get_option('vou_start_date'); // start date
		                    $start_date = !empty($start_date) ? date('Y-m-d H:i:s', strtotime($start_date)) : ''; // format start date
		                    $manual_expire_date = get_option('vou_exp_date'); // expiration date
		                    $exp_date = !empty($manual_expire_date) ? date('Y-m-d H:i:s', strtotime($manual_expire_date)) : ''; // format exp date

	                    } else if ($exp_type == 'based_on_purchase') { //If expiry type based in purchase

	                        //get days difference
	                        $days_diff = get_option('vou_days_diff');
	
	                        if ($days_diff == 'cust') {
	                            $custom_days = get_option('vou_custom_days');
	                            $custom_days = isset($custom_days) ? $custom_days : '';

	                            if (!empty($custom_days)) {
	                                $add_days = '+' . $custom_days . ' days';
	                                $exp_date = date('Y-m-d H:i:s', strtotime($order_date . $add_days));
	                            } else {
	                                $exp_date = date('Y-m-d H:i:s', current_time('timestamp'));
	                            }
	                        } else {
	                            $custom_days = $days_diff;
	                            $add_days = '+' . $custom_days . ' days';
	                            $exp_date = date('Y-m-d H:i:s', strtotime($order_date . $add_days));
	                        }
	                    }
                    }

                    $vouchercodes = trim($vou_codes, ','); //voucher code
                    $salecode = !empty($vouchercodes) ? explode(',', $vouchercodes) : array(); //explode all voucher codes

                    // trim code
                    foreach ($salecode as $code_key => $code) {
                        $salecode[$code_key] = trim($code);
                    }

                    //if voucher using type is more than one time then generate voucher codes
                    if (!empty($using_type)) {

                        //if user buy more than 1 quantity of voucher
                        if (isset($productqty) && $productqty > 1) {
                            for ($i = 1; $i <= $productqty; $i++) {

                                $voucode = $code_prefix = '';

                                if ( !empty($salecode) ) {
                                	//make voucher code
	                                $randcode = array_rand($salecode);

	                                if (!empty($salecode[$randcode])) {
	                                    $code_prefix = $salecode[$randcode];
	                                }
                                }

                                $vou_argument = array(
                                    'buyername' => $buyername,
                                    'code_prefix' => $code_prefix,
                                    'order_id' => $order_id,
                                    'data_id' => $data_id,
                                    'item_id' => $item_id,
                                    'counter' => $i
                                );
                                $voucode = woo_vou_unlimited_voucher_code_pattern($vou_argument);
                                $allcodes .= $voucode . ', ';
                            }
                        } else {

                            $voucode = $code_prefix = '';

                            if ( !empty($salecode) ) {
	                            //make voucher code when user buy single quantity
	                            $randcode = array_rand($salecode);
	
	                            if (!empty($salecode[$randcode]) && trim($salecode[$randcode]) != '') {
	                                $code_prefix = trim($salecode[$randcode]);
	                            }
                            }

                            //voucher codes arguments for create unlinited voucher
                            $vou_argument = array(
                                'buyername' => $buyername,
                                'code_prefix' => $code_prefix,
                                'order_id' => $order_id,
                                'data_id' => $data_id,
                                'item_id' => $item_id
                            );

                            $voucode = woo_vou_unlimited_voucher_code_pattern($vou_argument);

                            $allcodes .= $voucode . ', ';
                        }
                    } else {
                        for ($i = 0; $i < $productqty; $i++) {

                            //get first voucher code
                            $voucode = $salecode[$i];

                            //unset first voucher code to remove from all codes
                            unset($salecode[$i]);
                            $allcodes .= $voucode . ', ';
                        }

                        //after unsetting first code make one string for other codes
                        $lessvoucodes = implode(',', $salecode);
                        $woo_vou_voucher->woo_vou_update_voucher_code($productid, $variation_id, $lessvoucodes);

                        //Reduce stock quantity when order created and voucher deducted
                        $woo_vou_model->woo_vou_update_product_stock($productid, $variation_id, $salecode);
                    }

                    $allcodes = trim($allcodes, ', ');

                    //add voucher codes item meta "Now we store voucher codes in item meta fields"
                    //And Remove "order_details" array from here
                    wc_add_order_item_meta($item_id, $prefix.'codes', $allcodes);

                    // Getting Voucher Delivery
                    $voucher_delivery        = get_post_meta($data_id, $prefix . 'voucher_delivery', true);
                    $global_voucher_delivery = get_option('vou_voucher_delivery_options'); // Getting voucher delivery option

                    // Checking the product is variation then set data into array with variation id
                    if(!empty($variation_id)){

                    	// Declare variables
                        $pdf_template_data = $voucher_delivery_data = $vendor_detail_data = array();

                        // If product id is already set in voucher meta data
                        if(isset($vouchermetadata[$productid])){

                            $pdf_template_data 		= $vouchermetadata[$productid]['pdf_template']; // Get pdf template
                            $voucher_delivery_data 	= $vouchermetadata[$productid]['voucher_delivery']; // Get voucher delivery
                            $vendor_detail_data 	= $vouchermetadata[$productid]['vendor_address']; // Get vendor address
                        }

                        $pdf_template_data[$variation_id] 		= $vendor_detail['pdf_template']; // Insert new value to pdf template array
                        $voucher_delivery_data[$variation_id] 	= ($voucher_delivery)? $voucher_delivery: ( !empty( $global_voucher_delivery ) ? $global_voucher_delivery : 'email' ); // Insert new value to voucher delivery array
                        $vendor_detail_data[$variation_id] 		= $vendor_detail['vendor_address']; // Insert new value to vendor address array
                    } else {

                        $pdf_template_data 		= $vendor_detail['pdf_template']; // Set pdf template
                        $voucher_delivery_data 	= ($voucher_delivery)? $voucher_delivery: ( !empty( $global_voucher_delivery ) ? $global_voucher_delivery : 'email' ); // Set voucher delivery
                        $vendor_detail_data 	= $vendor_detail['vendor_address']; // Set vendor address
                    }

                    //Append for voucher meta data into order
                    $productvoumetadata = array(
                        'user_email' 		=> $useremail,
                        'pdf_template' 		=> $pdf_template_data,
                        'vendor_logo' 		=> $vendor_detail['vendor_logo'],
                        'start_date' 		=> $start_date,
                        'exp_date' 			=> $exp_date,
                        'exp_type' 			=> $exp_type,
                        'custom_days' 		=> $custom_days,
                        'using_type' 		=> $using_type,
                        'voucher_delivery' 	=> $voucher_delivery_data,
                        'vendor_address' 	=> $vendor_detail_data,
                        'website_url' 		=> $vendor_detail['vendor_website'],
                        'redeem' 			=> $vendor_detail['how_to_use'],
                        'avail_locations' 	=> $vendor_detail['avail_locations']
                    );

                    $vouchermetadata[$productid] = apply_filters( 'woo_vou_meta_order_voucher_detail', $productvoumetadata, $order_id, $item_id, $productid );
                    
                    $vou_code_post_data = array(
                    	'productid' => $productid,
                    	'vendor_user' => $vendor_user,
                    	'userfirstname' => $userfirstname,
                    	'userlastname' => $userlastname,
                    	'order_date' => $order_date,
                    	'start_date' => $start_date,
                    	'exp_date' => $exp_date,
                    	'disable_redeem_days' => $disable_redeem_days,
                    	'item_id' => $item_id,
                    	'data_id' => $data_id
                    );
                    $woo_vou_voucher->woo_vou_generate_posts_from_vou_codes($allcodes, $order_id, $vou_code_post_data);
                }
            }
        }

        //Get custom meta data of order
        $custom_metadata = get_post_custom($order_id);

        if (!isset($custom_metadata['multiple_pdf'])) { // Multipdf is already updated
            //update If setting is set for multipdf or not
            $multiple_pdf = get_option('multiple_pdf');

            //update multipdf option in ordermeta
            update_post_meta($order_id, $prefix . 'multiple_pdf', $multiple_pdf);
        }

        if (!empty($vouchermetadata)) { // Check voucher meta data are not empty
            //update voucher order details with all meta data
            update_post_meta($order_id, $prefix . 'meta_order_details', $vouchermetadata);
        }
    }

    // If coupon codes are present
    if ($order->get_used_coupons()) {

        $used_coupons = array();

        foreach ($order->get_used_coupons() as $coupon) {

            $_POST['voucode'] = $coupon;

            // check coupon code is valid or not
            $check_voucher_code = $woo_vou_voucher->woo_vou_check_voucher_code($coupon);

            // Get voucher code status
            $isSuccess = isset($check_voucher_code['success']) ? $check_voucher_code['success'] : 0;

            if (!empty($isSuccess)) { // If coupon code is valid
                // Redeem voucher code
                $redeemCode = $woo_vou_voucher->woo_vou_save_voucher_code($coupon, $order);
            }
        }
    }
}

/**
 * Add custom email notification to woocommerce
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.3.4
 */
function woo_vou_add_email_notification($email_actions) {

    $email_actions[] = 'woo_vou_vendor_sale_email';
    $email_actions[] = 'woo_vou_gift_email';

    return apply_filters('woo_vou_add_email_notification', $email_actions);
}

/**
 * Insert pdf voucher files
 * 
 * Handles to insert pdf voucher
 * files in database
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 1.0.0
 */
function woo_vou_insert_downloadable_files($order_id) {
	
	global $woo_vou_voucher, $woo_vou_model;

    $prefix = WOO_VOU_META_PREFIX;
    $downloadable_files = array();
    $order = wc_get_order($order_id); //Get Order

    if (sizeof($order->get_items()) > 0) { //Get all items in order
        foreach ($order->get_items() as $item_id => $item) {

            $_product = $order->get_product_from_item($item); //Get product from Item ( It is required otherwise multipdf voucher link not work and global $woo_vou_item_id will not work )
            $variation_id = !empty($item['variation_id']) ? $item['variation_id'] : ''; // Taking variation id

            if ($_product && $_product->exists()) { // && $_product->is_downloadable()

                $product_id = $woo_vou_model->woo_vou_get_item_productid_from_product($_product);
                $data_id = (!empty($variation_id) ) ? $variation_id : $product_id; // If product is variable product take variation id else product id

                if ($woo_vou_voucher->woo_vou_check_enable_voucher($product_id, $variation_id)) {//Check voucher is enabled or not

                    $downloadable_files = $woo_vou_voucher->woo_vou_get_vouchers_download_key($order_id, $data_id, $item_id); //Get vouchers downlodable pdf files

                    foreach (array_keys($downloadable_files) as $download_id) {

                        //Insert pdf vouchers in downloadable table
                        wc_downloadable_file_permission($download_id, $data_id, $order);
                    }
                }
            }
        }
    }

    // Status update from pending to publish when voucher is get completed or processing
    $args = array(
        'post_status' => array('pending'),
        'meta_query' => array(
            array(
                'key' => $prefix.'order_id',
                'value' => $order_id,
            )
        )
    );

    // Get vouchers code of this order
    $purchased_vouchers = $woo_vou_voucher->woo_vou_get_voucher_details($args);

    if (!empty($purchased_vouchers)) { // If not empty voucher codes
        //For all possible vouchers
        foreach ($purchased_vouchers as $voucher) {

            // Get voucher data
            $current_post = get_post($voucher['ID'], 'ARRAY_A');
            //Change voucher status
            $current_post['post_status'] = 'publish';
            //Update voucher post
            wp_update_post($current_post);
        }
    }
}

/**
 * Download Process
 *
 * Handles to product process
 *
 * @package WooCommerce - PDF Vouchers
 * @since 1.0.0
 */
function woo_vou_download_process($email, $order_key, $product_id, $user_id, $download_id, $order_id) {
	
	global $woo_vou_model, $woo_vou_voucher;

    if (!empty($_GET['item_id'])) {

        $item_id = $_GET['item_id'];
        $woo_vou_voucher->woo_vou_generate_pdf_voucher($email, $product_id, $download_id, $order_id, $item_id); //Generate PDF

        // Added support for download pdf count
        $downlod_data = $woo_vou_model->woo_vou_get_download_data(array(
            'product_id' => $product_id,
            'order_key' => wc_clean($_GET['order']),
            'email' => sanitize_email(str_replace(' ', '+', $_GET['email'])),
            'download_id' => wc_clean(isset($_GET['key']) ? preg_replace('/\s+/', ' ', $_GET['key']) : '')
        ));

        $woo_vou_model->woo_vou_count_download($downlod_data);
        exit;
    }
}

/**
 * Allow admin access to vendor user
 *
 * Handles to allow admin access to vendor user
 *
 * @package WooCommerce - PDF Vouchers
 * @since 1.1.0
 */
function woo_vou_prevent_admin_access($prevent_access) {

    global $current_user, $woo_vou_vendor_role;

    //Get User roles
    $user_roles = isset($current_user->roles) ? $current_user->roles : array();
    $user_role = array_shift($user_roles);

    if (in_array($user_role, $woo_vou_vendor_role)) { // Check vendor user role
        $prevent_access = false;
    }

    return apply_filters('woo_vou_prevent_admin_access', $prevent_access);
}

/**
 * Set Order As Global Variable
 * 
 * Handles to set order as global variable
 * when order links displayed in email
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 1.1.0
 */
function woo_vou_email_before_order_table($order) {

    global $vou_order;

    //Create global varible for order
    $vou_order = woo_vou_get_order_id($order);
}

/**
 * Set Order Product As Global Variable
 * 
 * Handles to set order product as global variable
 * when complete order mail fired or Order Details page is at front side
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 1.6
 */
function woo_vou_order_item_product($product, $item) {

    global $woo_vou_order_item;

    $woo_vou_order_item = $item; // Making global of order product item

    return $product;
}

/**
 * Display Recipient HTML
 * 
 * Handles to display the Recipient HTML after/before add to cart button
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 3.0.0
 */
function woo_vou_after_before_add_to_cart_button() {

    do_action('woo_vou_product_recipient_fields');

}

/**
 * add to cart in item data
 * 
 * Handles to add to cart in item data
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.0
 */
function woo_vou_woocommerce_add_cart_item_data($cart_item_data, $product_id, $variation_id) {
	
	global $woo_vou_model;

    $data_id = !empty($variation_id) ? $variation_id : $product_id;

    //Get prefix
    $prefix = WOO_VOU_META_PREFIX;

    if (isset($_POST[$prefix.'recipient_name'])) {//If recipient name is set
        $cart_item_data[$prefix.'recipient_name'] = $woo_vou_model->woo_vou_escape_slashes_deep($_POST[$prefix.'recipient_name'][$data_id]);
    }

    if (isset($_POST[$prefix.'recipient_email'])) {//If recipient email is set
        $cart_item_data[$prefix.'recipient_email'] = $woo_vou_model->woo_vou_escape_slashes_deep($_POST[$prefix.'recipient_email'][$data_id]);
    }

    if (isset($_POST[$prefix.'recipient_message'])) {//If recipient message is set
        $cart_item_data[$prefix.'recipient_message'] = $woo_vou_model->woo_vou_escape_slashes_deep($_POST[$prefix.'recipient_message'][$data_id]);
    }

    if (isset($_POST[$prefix.'recipient_giftdate'])) {//If recipient message is set
        $cart_item_data[$prefix.'recipient_giftdate'] = $woo_vou_model->woo_vou_get_cart_date_format($_POST[$prefix.'recipient_giftdate'][$data_id]);
    }

    if (isset($_POST[$prefix.'pdf_template_selection'])) {//If pdf template is set
        $cart_item_data[$prefix.'pdf_template_selection'] = $woo_vou_model->woo_vou_escape_slashes_deep($_POST[$prefix.'pdf_template_selection'][$data_id]);
    }

    return $cart_item_data;
}

/**
 * add to cart in item data from session
 * 
 * Handles to add to cart in item data from session
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.0
 */
function woo_vou_get_cart_item_from_session($cart_item, $values) {

    //Get prefix
    $prefix = WOO_VOU_META_PREFIX;

    if (!empty($values[$prefix.'recipient_name'])) {//Recipient Name
        $cart_item[$prefix.'recipient_name'] = $values[$prefix.'recipient_name'];
    }

    if (!empty($values[$prefix.'recipient_email'])) {//Recipient Email
        $cart_item[$prefix.'recipient_email'] = $values[$prefix.'recipient_email'];
    }

    if (!empty($values[$prefix.'recipient_message'])) {//Recipient Message
        $cart_item[$prefix.'recipient_message'] = $values[$prefix.'recipient_message'];
    }

    if (!empty($values[$prefix.'recipient_giftdate'])) {//Recipient Message
        $cart_item[$prefix.'recipient_giftdate'] = $values[$prefix.'recipient_giftdate'];
    }

    if (!empty($values[$prefix.'pdf_template_selection'])) {//PDF Template Selection
        $cart_item[$prefix.'pdf_template_selection'] = $values[$prefix.'pdf_template_selection'];
    }

    return $cart_item;
}

/**
 * Get to cart in item data to display in cart page
 * 
 * Handles to get to cart in item data to display in cart page
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.0
 */
function woo_vou_woocommerce_get_item_data($data, $item) {
	
	global $woo_vou_model, $woo_vou_voucher;

    //Get prefix
    $prefix = WOO_VOU_META_PREFIX;

    //Get Product ID
    $product_id = isset($item['product_id']) ? $item['product_id'] : '';

    //Get product recipient meta setting
    $recipient_data = $woo_vou_model->woo_vou_get_product_recipient_meta($product_id);

    //recipient name lable
    $recipient_name_label = $recipient_data['recipient_name_lable'];

    //recipient email lable
    $recipient_email_label = $recipient_data['recipient_email_label'];

    //recipient message lable
    $recipient_message_label = $recipient_data['recipient_message_label'];

    //recipient message lable
    $recipient_giftdate_label = $recipient_data['recipient_giftdate_label'];

    //pdf template selection label
    $pdf_template_selection_label = $recipient_data['pdf_template_selection_label'];

    if (!empty($item[$prefix.'recipient_name'])) {

        $data[] = array(
            'name' => $recipient_name_label,
            'display' => $item[$prefix.'recipient_name'],
            'hidden' => false,
            'value' => ''
        );
    }

    if (!empty($item[$prefix.'recipient_email'])) {

        $data[] = array(
            'name' => $recipient_email_label,
            'display' => $item[$prefix.'recipient_email'],
            'hidden' => false,
            'value' => ''
        );
    }

    if (!empty($item[$prefix.'recipient_message'])) {

        $data[] = array(
            'name' => $recipient_message_label,
            'display' => $item[$prefix.'recipient_message'],
            'hidden' => false,
            'value' => ''
        );
    }

    if (!empty($item[$prefix.'recipient_giftdate'])) {

        $data[] = array(
            'name' => $recipient_giftdate_label,
            'display' => $item[$prefix.'recipient_giftdate'],
            'hidden' => false,
            'value' => ''
        );
    }

    if (!empty($item[$prefix.'pdf_template_selection'])) {

        $data[] = array(
            'name' => $pdf_template_selection_label,
            'display' => $item[$prefix.'pdf_template_selection'],
            'hidden' => true,
            'value' => ''
        );

        // enable display
        $enable_template_display = woo_vou_enable_template_display_features();

        if ($enable_template_display) { // if enabling the display template selection
            // pdf template preview image
            $pdf_template_preview_img = wp_get_attachment_url(get_post_thumbnail_id($item[$prefix.'pdf_template_selection']));

            if (empty($pdf_template_preview_img)) { // if preview image not available
                $pdf_template_preview_img = WOO_VOU_IMG_URL.'/no-preview.png';
            }

            $pdf_template_preview_img_title = get_the_title($item[$prefix.'pdf_template_selection']);

            $data[] = array(
                'name' => $pdf_template_selection_label,
                'display' => '<img src="' . $pdf_template_preview_img . '" style="width:50px !important;height:50px !important;cursor:pointer;" title="' . $pdf_template_preview_img_title . '">',
                'hidden' => false,
                'value' => ''
            );
        }
    }

    return $data;
}

/**
 * add cart item to the order.
 * 
 * Handles to add cart item to the order.
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.0
 */
function woo_vou_add_order_item_meta($item, $cart_item_key, $values, $order) {
	
	global $woo_vou_model, $woo_vou_voucher;

    //Get prefix
    $prefix = WOO_VOU_META_PREFIX;

    //Initilize recipients labels
    $woo_vou_recipient_labels = array();

    //Get product ID
    $_product_id = isset($values['variation_id']) && !empty($values['variation_id']) ? $values['variation_id'] : $values['product_id'];

    $recipient_labels = $woo_vou_model->woo_vou_get_product_recipient_meta($_product_id);

    // Get voucher price 
    $voucher_price = woo_vou_get_voucher_price($cart_item_key, $_product_id, $values);
	
	if (!empty($voucher_price)) { // Add voucher price in order item meta

        $item->add_meta_data( $prefix.'voucher_price', $voucher_price, true );
    }

    if (!empty($values[$prefix . 'recipient_name'])) {//Add recipient name field

        $item->add_meta_data( $prefix.'recipient_name', array(
            'label' => $recipient_labels['recipient_name_lable'],
            'value' => $values[$prefix . 'recipient_name']
        ), true );
        
        $item->add_meta_data( $recipient_labels['recipient_name_lable'], $values[$prefix . 'recipient_name'], true );
    }

    if (!empty($values[$prefix . 'recipient_email'])) {//Add recipient email field
        
        $item->add_meta_data( $prefix.'recipient_email', array(
            'label' => $recipient_labels['recipient_email_label'],
            'value' => $values[$prefix . 'recipient_email']
        ), true );
        
        $item->add_meta_data( $recipient_labels['recipient_email_label'], $values[$prefix . 'recipient_email'], true );
    }

    if (!empty($values[$prefix . 'recipient_message'])) {//Add recipient message field

        $item->add_meta_data( $prefix.'recipient_message', array(
            'label' => $recipient_labels['recipient_message_label'],
            'value' => $values[$prefix . 'recipient_message']
        ), true );
        
        $item->add_meta_data( $recipient_labels['recipient_message_label'], $values[$prefix . 'recipient_message'], true );
    }

    if (!empty($values[$prefix . 'recipient_giftdate'])) {//Add recipient giftdate field

        $item->add_meta_data( $prefix.'recipient_giftdate', array(
            'label' => $recipient_labels['recipient_giftdate_label'],
            'value' => $values[$prefix . 'recipient_giftdate']
        ), true );
        
        $item->add_meta_data( $recipient_labels['recipient_giftdate_label'], $values[$prefix . 'recipient_giftdate'], true );
    }

    if (!empty($values[$prefix . 'pdf_template_selection'])) {//Add pdf template selection field

        $item->add_meta_data( $prefix.'pdf_template_selection', array(
            'label' => $recipient_labels['pdf_template_selection_label'],
            'value' => $values[$prefix . 'pdf_template_selection']
        ), true );

        // check if template display is anable or not
        $enable_display_template = woo_vou_enable_template_display_features();

        if ($enable_display_template) { // if enable template preview image display
            //pdf template preview image
            $pdf_template_preview_img = wp_get_attachment_url(get_post_thumbnail_id($values[$prefix . 'pdf_template_selection']));

            if (empty($pdf_template_preview_img)) {
                $pdf_template_preview_img = WOO_VOU_IMG_URL . '/no-preview.png';
            }

            $pdf_template_preview_img_title = get_the_title($values[$prefix . 'pdf_template_selection']);

            //$item->add_meta_data( $recipient_labels['pdf_template_selection_label'], '<img src="' . $pdf_template_preview_img . '" style="width:50px !important;height:50px !important;cursor:pointer;" title="' . $pdf_template_preview_img_title . '">', true );
            $item->add_meta_data( $recipient_labels['pdf_template_selection_label'], $pdf_template_preview_img_title, true );
        }
    }
}

/**
 * Hide Recipient Itemmeta
 * 
 * Handle to hide recipient itemmeta
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.0
 */
function woo_vou_hide_recipient_itemmeta($item_meta = array()) {

    $prefix = WOO_VOU_META_PREFIX;

    $item_meta[] = $prefix . 'recipient_name';
    $item_meta[] = $prefix . 'recipient_email';
    $item_meta[] = $prefix . 'recipient_message';
    $item_meta[] = $prefix . 'recipient_giftdate';
    $item_meta[] = $prefix . 'recipient_gift_method';
    $item_meta[] = $prefix . 'pdf_template_selection';
    $item_meta[] = $prefix . 'voucher_price';
    $item_meta[] = $prefix . 'codes';

    return $item_meta;
}

/**
 * Handles the functionality to attach the voucher pdf in mail
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.0
 */
function woo_vou_attach_voucher_to_email($attachments, $status, $order) {

	// Global variables
    global $post, $woo_vou_voucher, $woo_vou_model;

    $prefix = WOO_VOU_META_PREFIX;

    // Declare variables
    $order_id = '';

    // Taking status array
    $vou_status = apply_filters('woo_vou_add_email_attachment_order_status', array('customer_processing_order', 'customer_completed_order', 'customer_invoice'));

    // Taking order status array
    $vou_order_status = array('wc-completed', 'completed'); // 'completed' status added for adding WC 3.0 compatibility
    // If woocommerce version is less than 3.0.0
    if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1) {

        //get product id from prduct data
        $order_status = !empty($order->post_status) ? $order->post_status : ''; // Order status
        $order_id = !empty($order->id) ? $order->id : ''; // Taking order id
    } else { // If version is greater than 3.0.0

        if (is_array($order)) { // If order is an array

            if (isset($order['order_id'])) { // If order_id is set in order array ( Happens when order is created through REST )

                $order_id = $order['order_id'];
            } else if(is_object($post)) {

                $order_id = $post->ID;
            }

            if($order_id){
	            $_order = wc_get_order($order_id);
	            $order_status = $_order->get_status();
            }
            
        } else if (is_object($order)) {

            $order_status = $order->get_status();
            $order_id = method_exists( $order, 'get_id' ) ? $order->get_id() : ''; // Taking order id
        }
    }

    if(!$order_id) {
    	return;
    }

    $vou_attach_mail = get_option('vou_attach_mail'); // Getting voucher attach option
    $grant_access_after_payment = get_option('woocommerce_downloads_grant_access_after_payment'); // Woocommerce grant access after payment

    if ($vou_attach_mail == 'yes' && !empty($order) && ( (in_array($status, $vou_status) && in_array($order_status, $vou_order_status)) || ($status == 'customer_processing_order' && $grant_access_after_payment == 'yes' && $order_status != 'wc-on-hold') )) {

        $vou_attachments = array();
        $cart_details = wc_get_order($order_id);
        $order_items = $cart_details->get_items();

        if (!empty($order_items)) {//not empty items
            //foreach items
            foreach ($order_items as $item_id => $download_data) {

                $product_id = !empty($download_data['product_id']) ? $download_data['product_id'] : '';
                $variation_id = !empty($download_data['variation_id']) ? $download_data['variation_id'] : '';

                //Get data id vriation id or product id
                $data_id = !empty($variation_id) ? $variation_id : $product_id;

                //Check voucher enable or not
                $enable_voucher = $woo_vou_voucher->woo_vou_check_enable_voucher($product_id, $variation_id);

                // Declare Voucher Delivery
                $vou_voucher_delivery_type = 'email';

                // Getting the order meta data
                $order_all_data = $woo_vou_model->woo_vou_get_all_ordered_data( $order_id );

                // If this variation then get it's product id
                $variation_pro      = wc_get_product( $data_id );
                $parent_product_id	= $woo_vou_model->woo_vou_get_item_productid_from_product( $variation_pro );
                if( !empty($variation_id) && isset($order_all_data[$parent_product_id]['voucher_delivery']) && is_array($order_all_data[$parent_product_id]['voucher_delivery']) ){

                    $vou_voucher_delivery_type 	= $order_all_data[$parent_product_id]['voucher_delivery'][$variation_id];
                } elseif( isset($order_all_data[$product_id]['voucher_delivery']) ) {

                    $vou_voucher_delivery_type 	= $order_all_data[$product_id]['voucher_delivery'];
                }
                if( ($enable_voucher) && ($vou_voucher_delivery_type == 'email') ) {

                    // Get mutiple pdf option from order meta
                    $multiple_pdf = !empty($order_id) ? get_post_meta($order_id, $prefix.'multiple_pdf', true) : '';

                    $orderdvoucodes = array();

                    if ($multiple_pdf == 'yes') {
                        $orderdvoucodes = $woo_vou_voucher->woo_vou_get_multi_voucher($order_id, $data_id, $item_id);
                    } else {
                        $orderdvoucodes['woo_vou_pdf_1'] = '';
                    }

                    // If order voucher codes are not empty
                    if (!empty($orderdvoucodes)) {

                        foreach ($orderdvoucodes as $orderdvoucode_key => $orderdvoucode_val) {

                            if (!empty($orderdvoucode_key)) {

                                $attach_pdf_file_name = get_option('attach_pdf_name');
                                $attach_pdf_file_name = isset($attach_pdf_file_name) ? $attach_pdf_file_name : 'woo-voucher-';

                                //Get Pdf Key
                                $pdf_vou_key = $orderdvoucode_key;

                                // Replacing voucher pdf name with given value
                                $orderdvoucode_key = str_replace('woo_vou_pdf_', $attach_pdf_file_name, $orderdvoucode_key);

                                // Voucher pdf path and voucher name
                                $vou_pdf_path = WOO_VOU_UPLOAD_DIR . $orderdvoucode_key . '-' . $data_id . '-' . $item_id . '-' . $order_id; // Voucher pdf path
                                $vou_pdf_name = $vou_pdf_path . '.pdf';

                                // If voucher pdf does not exist in folder
                                if (!file_exists($vou_pdf_name)) {

                                    $pdf_args = array(
                                        'pdf_vou_key' => $pdf_vou_key,
                                        'pdf_name' => $vou_pdf_path,
                                        'save_file' => true
                                    );

                                    //Generatin pdf
                                    woo_vou_process_product_pdf($data_id, $order_id, $item_id, $orderdvoucodes, $pdf_args);
                                }

                                // If voucher pdf exist in folder
                                if (file_exists($vou_pdf_name)) {
                                    $attachments[] = apply_filters('woo_vou_email_attachments', $vou_pdf_name, $order_id, $item_id, $download_data); // Adding the voucher pdf in attachment array
                                }
                            }
                        }
                    } // End of orderdvoucodes
                }
            }
        } // End of order item
    }

    return $attachments;
}

/**
 * Check voucher code using qrcode and barcode
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.0.3
 */
function woo_vou_check_qrcode() {

    if (isset($_GET['woo_vou_code']) && !empty($_GET['woo_vou_code'])) {

        // Add action to add check voucher code from
        do_action('woo_vou_check_qrcode_content');
    }
}

/**
 * Add Voucher When Add Order Manually
 * 
 * Haldle to add voucher codes
 * when add order manually from backend
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.2.1
 */
function woo_vou_process_shop_order_manually($order_id) {

    if (!empty($_POST['order_item_id'])) {//If order item are not empty
        //Process voucher code functionality
        woo_vou_product_purchase($order_id);
    }
}

/**
 * Hide recipient variation from product name field
 * 
 * Handle to hide recipient variation from product name field
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.3.0
 */
function woo_vou_hide_recipients_item_variations($product_variations = array(), $product_item_meta = array()) {
	
	global $woo_vou_model, $woo_vou_voucher;

    $prefix = WOO_VOU_META_PREFIX;

    $recipient_string = '';

    //Get product ID
    $product_id = isset($product_item_meta['_product_id']) ? $product_item_meta['_product_id'] : '';

    //Get product recipient lables
    $product_recipient_lables = $woo_vou_model->woo_vou_get_product_recipient_meta($product_id);

    if (isset($product_item_meta[$prefix . 'recipient_name']) && !empty($product_item_meta[$prefix . 'recipient_name'])) {

        $recipient_name_label = isset($product_item_meta[$prefix . 'recipient_name']['label']) ? $product_item_meta[$prefix . 'recipient_name']['label'] : $product_recipient_lables['recipient_name_lable'];
        if (isset($product_variations[$recipient_name_label])) {
            unset($product_variations[$recipient_name_label]);
        }
    }

    if (isset($product_item_meta[$prefix . 'recipient_email']) && !empty($product_item_meta[$prefix . 'recipient_email'])) {

        $recipient_email_label = isset($product_item_meta[$prefix . 'recipient_email']['label']) ? $product_item_meta[$prefix . 'recipient_email']['label'] : $product_recipient_lables['recipient_email_label'];
        if (isset($product_variations[$recipient_email_label])) {
            unset($product_variations[$recipient_email_label]);
        }
    }

    if (isset($product_item_meta[$prefix . 'recipient_message']) && !empty($product_item_meta[$prefix . 'recipient_message'])) {

        $recipient_msg_label = isset($product_item_meta[$prefix . 'recipient_message']['label']) ? $product_item_meta[$prefix . 'recipient_message']['label'] : $product_recipient_lables['recipient_message_label'];
        if (isset($product_variations[$recipient_msg_label])) {
            unset($product_variations[$recipient_msg_label]);
        }
    }

    if (isset($product_item_meta[$prefix . 'pdf_template_selection']) && !empty($product_item_meta[$prefix . 'pdf_template_selection'])) {

        $pdf_temp_selection_label = isset($product_item_meta[$prefix . 'pdf_template_selection']['label']) ? $product_item_meta[$prefix . 'pdf_template_selection']['label'] : $product_recipient_lables['pdf_template_selection_label'];
        if (isset($product_variations[$pdf_temp_selection_label])) {
            unset($product_variations[$pdf_temp_selection_label]);
        }
    }

    if (isset($product_item_meta[$prefix . 'recipient_giftdate']) && !empty($product_item_meta[$prefix . 'recipient_giftdate'])) {

        $recipient_giftdate_selection_label = isset($product_item_meta[$prefix . 'recipient_giftdate']['label']) ? $product_item_meta[$prefix . 'recipient_giftdate']['label'] : $product_recipient_lables['recipient_giftdate_label'];
        if (isset($product_variations[$recipient_giftdate_selection_label])) {
            unset($product_variations[$recipient_giftdate_selection_label]);
        }
    }

    return $product_variations;
}

/**
 * Set Global Item ID For Voucher Key Generater
 * 
 * Handle to Set global item id for voucher key generater
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 3.0.2
 */
function woo_vou_set_global_item_id($product, $item) {

    global $woo_vou_item_id;

    //Get prefix
    $prefix = WOO_VOU_META_PREFIX;

    $product_item_meta = isset($item['item_meta']) ? $item['item_meta'] : array();

    $voucher_codes = isset($product_item_meta[$prefix . 'codes']) ? $product_item_meta[$prefix . 'codes'] : '';

    if (!empty($voucher_codes)) {

        $item_id = $item->get_id();

        //Get voucher codes
        $codes = wc_get_order_item_meta($item_id, $prefix . 'codes');

        if ($codes == $voucher_codes) {//If voucher code matches
            $woo_vou_item_id = $item_id;
        }
    }

    return $product;
}

/**
 * Add downlodable files for woocommerce version >= 3.0
 * 
 * Add Item Id In generate pdf download URL	 
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.3.0
 */
function woo_vou_get_item_pdf_downloads($files, $item, $abs_order) {

    global $woo_vou_item_id, $woo_vou_voucher;

    //Get prefix
    $prefix = WOO_VOU_META_PREFIX;

    // for woocommere version >= 3.0. If older version then 3.0, not call this
    if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") != -1) {

        $product = $item->get_product();

        if (!( $product && $abs_order && $product->is_downloadable() && $abs_order->is_download_permitted() ))
            return;

        // Taking product/variation id
        $variation_id = !empty($item['variation_id']) ? $item['variation_id'] : $item['product_id'];

        //Get vouchers download files
        $pdf_downloadable_files = $woo_vou_voucher->woo_vou_get_vouchers_download_key($abs_order->get_id(), $variation_id, $woo_vou_item_id);

        if (!empty($pdf_downloadable_files)) {

            foreach ($pdf_downloadable_files as $pdf_key => $pdf_file_array) {

            	$vou_codes 			= $item->get_meta($prefix.'codes', true); // Get voucher codes from meta
            	$vou_code 			= explode(',', $vou_codes); // Explode voucher code in case it is having multiple voucher codes
				$vou_code_id 		= $woo_vou_voucher->woo_vou_get_voucodeid_from_voucode($vou_code[0]); // Get voucher code id
				$vou_expiry_date 	= ''; // Declare variable
				if(!empty($vou_code_id)){

					// Get voucher expiry date
					$vou_expiry_date = get_post_meta($vou_code_id, $prefix.'exp_date', true);
				}
            	
                // Add download url to voucher downlodable files
                $pdf_downloadable_files[$pdf_key]['download_url'] = $item->get_item_download_url($pdf_key);
                $pdf_downloadable_files[$pdf_key]['id'] = $pdf_key;
                $pdf_downloadable_files[$pdf_key]['access_expires'] = $vou_expiry_date;
                $pdf_downloadable_files[$pdf_key]['downloads_remaining'] = '';

                // Merge downlodable file to files
                $files = array_merge($files, array($pdf_key => $pdf_downloadable_files[$pdf_key]));
            }
        }
    }

    // Add item id in download pdf url
    if (!empty($files)) { //If files not empty
        foreach ($files as $file_key => $file_data) {

            //Check key is for pdf voucher
            $check_key = strpos($file_key, 'woo_vou_pdf_');

            if ($check_key !== false) {

                //Get download URL
                $download_url = isset($files[$file_key]['download_url']) ? $files[$file_key]['download_url'] : '';

                //Add item id in download URL
                $download_url = add_query_arg(array('item_id' => $woo_vou_item_id), $download_url);

                //Store download URL agaiin
                $files[$file_key]['download_url'] = $download_url;

                // add filter to remove voucher download link
                $files = apply_filters('woo_vou_remove_download_link', $files, $file_key, $woo_vou_item_id);
            }
        }
    }

    return $files;
}

/**
 * Adding Hooks
 * 
 * Adding proper hoocks for the discount codes
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.3.1
 */
function woo_vou_my_pdf_vouchers_download_link($downloads = array()) {

	global $woo_vou_model, $woo_vou_voucher;
	
    //get prefix
    $prefix = WOO_VOU_META_PREFIX;

    if (is_user_logged_in()) {//If user is logged in
        //Get user ID
        $user_id = get_current_user_id();

        //Get User Order Arguments
        $args = array(
            'numberposts' => -1,
            'meta_key' => '_customer_user',
            'meta_value' => $user_id,
            'post_type' => WOO_VOU_MAIN_SHOP_POST_TYPE,
            'post_status' => array('wc-completed'),
            'meta_query' => array(
                array(
                    'key' => $prefix . 'meta_order_details',
                    'compare' => 'EXISTS',
                )
            )
        );

        //user orders
        $user_orders = get_posts($args);

        if (!empty($user_orders)) {//If orders are not empty
            foreach ($user_orders as $user_order) {

                //Get order ID
                $order_id = isset($user_order->ID) ? $user_order->ID : '';

                if (!empty($order_id)) {//Order it not empty
                    global $vou_order;

                    //Set global order ID
                    $vou_order = $order_id;

                    //Get cart details
                    $cart_details = wc_get_order($order_id);
                    $order_items = $cart_details->get_items();
                    $order_date = $woo_vou_model->woo_vou_get_order_date_from_order($cart_details); // Get order date
                    $order_date = date('F j, Y', strtotime($order_date));

                    if (!empty($order_items)) {// Check cart details are not empty
                        foreach ($order_items as $item_id => $product_data) {

                            //Get product from Item ( It is required otherwise multipdf voucher link not work and global $woo_vou_item_id will not work )
                            $_product = apply_filters('woocommerce_order_item_product', $cart_details->get_product_from_item($product_data), $product_data);

                            if (!$_product) {//If product deleted
                                $download_file_data = array();
                            } else {
                                $download_file_data = $woo_vou_model->woo_vou_get_item_downloads_from_order($cart_details, $product_data);
                            }

                            //Get voucher codes
                            $codes = wc_get_order_item_meta($item_id, $prefix.'codes');

                            if (!empty($download_file_data) && !empty($codes)) {//If download exist and code is not empty
                                foreach ($download_file_data as $key => $download_file) {

                                    //check download key is voucher key or not
                                    $check_key = strpos($key, 'woo_vou_pdf_');

                                    //get voucher number
                                    $voucher_number = str_replace('woo_vou_pdf_', '', $key);

                                    if (empty($voucher_number)) {//If empty voucher number
                                        $voucher_number = 1;
                                    }

                                    if (!empty($download_file) && $check_key !== false) {

                                        //Get download URL
                                        $download_url = $download_file['download_url'];

                                        //add arguments array
                                        $add_arguments = array('item_id' => $item_id);

                                        //PDF Download URL
                                        $download_url = add_query_arg($add_arguments, $download_url);

                                        // To make compatible with previous versions of 3.0.0
                                        if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1) {
                                            //Get product ID
                                            $product_id = isset($_product->post->ID) ? $_product->post->ID : '';
                                            //get product name
                                            $product_name = isset($_product->post->post_title) ? $_product->post->post_title : '';
                                        } else {
                                            //Get product ID
                                            $product_id = $_product->get_id();
                                            //get product name
                                            $product_name = $_product->get_title();
                                        }

                                        $vou_codes 			= $codes; // Get voucher codes from meta
						            	$vou_code 			= explode(',', $vou_codes); // Explode voucher code in case it is having multiple voucher codes
										$vou_code_id 		= $woo_vou_voucher->woo_vou_get_voucodeid_from_voucode($vou_code[0]); // Get voucher code id
										$vou_expiry_date 	= ''; // Declare variable
										if(!empty($vou_code_id)){
						
											// Get voucher expiry date
											$vou_expiry_date = get_post_meta($vou_code_id, $prefix.'exp_date', true);
										}

                                        //Download file arguments
                                        $download_args = array(
                                            'product_id' => $product_id,
                                            'product_name' => $product_name,
                                            'download_url' => $download_url,
                                            'download_name' => $product_name . ' - ' . $download_file['name'] . ' ' . $voucher_number . ' ( ' . $order_date . ' )',
                                            'downloads_remaining' => '',
                                            'access_expires' => $vou_expiry_date,
                                            'file' => array(
                                                'name' => $download_file['name'],
                                                'file' => $download_file['file'],
                                            ),
                                        );

                                        //append voucher download to downloads array
                                        $downloads[] = $download_args;
                                    }
                                }
                            }
                        }
                    }

                    //reset global order ID
                    $vou_order = 0;
                }
            }
        }
    }

    return $downloads;
}

/**
 * Update product stock as per voucher codes when woocommerce deduct stock
 * 
 * As woocommrece reduce stock quantity on product purchase and so we have to update stock
 * to no of voucher codes
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.4.0
 */
function woo_vou_update_order_stock($order) {
	
	global $woo_vou_voucher, $woo_vou_model;

    $prefix = WOO_VOU_META_PREFIX;

    // loop for each item
    foreach ($order->get_items() as $item) {

        if ($item['product_id'] > 0) {

            //Get product from Item ( It is required otherwise multipdf voucher link not work and global $woo_vou_item_id will not work )
            $_product = $order->get_product_from_item($item);

            if ($_product && $_product->exists() && $_product->managing_stock()) {

                $product_id = $item['product_id'];
                $variation_id = isset($item['variation_id']) ? $item['variation_id'] : '';

                // check voucher is enabled for this product
                if ($woo_vou_voucher->woo_vou_check_enable_voucher($product_id, $variation_id)) {

                    //vendor user
                    $vendor_user = get_post_meta($product_id, $prefix . 'vendor_user', true);

                    //get vendor detail
                    $vendor_detail = $woo_vou_model->woo_vou_get_vendor_detail($product_id, $variation_id, $vendor_user);

                    //using type of voucher
                    $using_type = isset($vendor_detail['using_type']) ? $vendor_detail['using_type'] : '';

                    // if using type is one time only
                    if (empty($using_type)) {

                        //voucher codes
                        $vou_codes = $woo_vou_voucher->woo_vou_get_voucher_code($product_id, $variation_id);

                        // convert voucher code comma seperate string into array
                        $vou_codes = !empty($vou_codes) ? explode(',', $vou_codes) : array();

                        // update stock quanity
                        $woo_vou_model->woo_vou_update_product_stock($product_id, $variation_id, $vou_codes);
                    }
                }
            }
        }
    }
}

/**
 * Expired/Upcoming product on shop page
 * 
 * Handles to Remove add to cart product button on shop page when product is upcomming or expired
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.4.2
 */
function woo_vou_shop_add_to_cart($add_to_cart_html) {

    global $product, $woo_vou_voucher;

    $expired = $woo_vou_voucher->woo_vou_check_product_is_expired($product);

    if ($expired == 'upcoming' || $expired == 'expired') {
        return ''; // do not display add to cart button
    }

    return $add_to_cart_html;
}

/**
 * Remove voucher download link
 * 
 * Hanles to remove voucher download link if voucher is
 * "used" 		- voucher code is redeemed
 * "exipred" 	- voucher date is expired and its not used
 *
 * @package WooCommerce - PDF Vouchers
 * @since 2.6.4
 */
function woo_vou_remove_voucher_download_link($files, $file_key, $woo_vou_item_id) {

	global $woo_vou_voucher;
	
    //get prefix
    $prefix = WOO_VOU_META_PREFIX;

    $multiple_pdf = get_option('multiple_pdf');
    $revoke_voucher_download_link_access = get_option('revoke_voucher_download_link_access');

    // check multiple voucher and remove download voucher link is enabled
    if ($multiple_pdf == "yes" && $revoke_voucher_download_link_access == "yes") {

        /**
         ** Code to determine voucher code from file_key
         ** Get id from $file_key, i.e. Get 1 from woo_vou_pdf_1
         ** Get code from order line item id
         ** Voucher Code will be id position in array of codes				
         **/
        $codes = wc_get_order_item_meta($woo_vou_item_id, $prefix . 'codes'); // Get voucher codes for order item id
        $code_arr = explode(', ', $codes); // Convert $codes to array for codes
        $file_key_arr = explode('_', $file_key); // Explode $file_key to get download id
        $code_id = end($file_key_arr); // Get Download ID
        // get voucher code status
        $voucher_code_status = $woo_vou_voucher->woo_vou_get_voucher_code_status($code_arr[$code_id - 1]);
        if ($voucher_code_status === 'expired' || $voucher_code_status === 'used') {
            unset($files[$file_key]); // remove voucher download link
        }
    }

    return $files;
}

/**
 * Allow To add Admin email in BCC
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.6.8
 */
function woo_vou_allow_admin_to_bcc($headers, $object) {

    $admin_email = get_option('admin_email');
    $admin_premission = get_option('vou_allow_bcc_to_admin');

    if ($admin_premission == "yes" && !empty($admin_email)) {

        switch ($object) {
            case 'customer_processing_order':
            case 'customer_completed_order':
            case 'woo_vou_gift_notification':
                $headers .= 'Bcc: ' . $admin_email . "\r\n";
                break;
            default:
        }
    }

    return apply_filters('woo_vou_allow_admin_to_bcc', $headers, $object);
}

/**
 * Validate Coupon
 * 
 * Handles to validate coupon on Cart and Checkout page
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.9.2
 */
function woo_vou_validate_coupon($valid, $coupon) {
	
	global $woo_vou_model;

    // Get prefix
    $prefix = WOO_VOU_META_PREFIX;

    if ($coupon) {

        // Get coupon_id
        $coupon_id = $woo_vou_model->woo_vou_get_coupon_id_from_coupon($coupon);

        // Get Coupon's start date
        $coupon_start_date = get_post_meta($coupon_id, $prefix . 'start_date', true);

        // Get coupon's restriction days
        $coupon_rest_days = get_post_meta($coupon_id, $prefix . 'disable_redeem_day', true);

        // Check start date validation
        if ($coupon_start_date && current_time('timestamp') < strtotime($coupon_start_date)) {

            throw new Exception($error_code = $prefix . 'start_date_err'); // throw error
            return false; // return false
        }

        // Check coupon restriction days
        if (!empty($coupon_rest_days)) {

            // Get current day
            $current_day = date('l');

            // check current day redeem is enable or not
            if (in_array($current_day, $coupon_rest_days)) {

                throw new Exception($error_code = $prefix . 'day_err'); // Throw error
                return false; // Return false
            }
        }
    }

    // Return
    return $valid;
}

/**
 * Get order details and coupon details then send it to create WC coupon code
 * If voucher code is used as copuon code, redeem it. 
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.9.3
 */
function woo_vou_generate_couponcode_from_vouchercode($order_id) {

	global $woo_vou_voucher, $woo_vou_model;
	
    $prefix = WOO_VOU_META_PREFIX; // Get prefix
    // Get "Generate Coupon Code" option
    $generate_coupon_code = get_option('vou_enable_coupon_code');

    // If enable then generate coupon code from voucher code
    if ($generate_coupon_code == "yes") {

        $order = wc_get_order($order_id); // Get order details
        // Declare variables
        $vou_code_array = array();
        $product_qty = 0;
        $voucode = $vou_amount = $exp_date = $start_date = "";

        foreach ($order->get_items() as $item_id => $item) {

            //Get product from Item ( It is required otherwise multipdf voucher link not work and global $woo_vou_item_id will not work )
            $_product = $order->get_product_from_item($item);

            // Taking variation id
            $variation_id = !empty($item['variation_id']) ? $item['variation_id'] : '';

            if ($_product && $_product->exists()) { // && $_product->is_downloadable()
                if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1) {
                    //get product id from prduct data
                    $product_id = isset($_product->id) ? $_product->id : '';
                } else {
                    if ( $_product->is_type( 'variable' ) || $_product->is_type( 'variation' ) ) {
                        $product_id = $_product->get_parent_id();
                    } else {
                        $product_id = $_product->get_id();    
                    }
                }

                // If product is variable product take variation id else product id
                $data_id = (!empty($variation_id) ) ? $variation_id : $product_id;

                if ($woo_vou_voucher->woo_vou_check_enable_voucher($product_id, $variation_id)) {//Check voucher is enabled or not
                    $product_qty = $item['qty'];       // Get order quantity
                    $voucode = $item['woo_vou_codes'];     // Get used voucher/coupon code
                    $vou_amount = $woo_vou_model->woo_vou_get_product_price( $order_id, $item_id, $item ); // Get voucher amount
                    $vou_amount = apply_filters('woo_vou_get_voucher_coupon_price', $vou_amount, $variation_id, $item);

                    // Check product quantity
                    if ($product_qty > 1) {

                        $woo_vou_codes = explode(',', $voucode); // If order qty greater then 1, get value in array
                    } else {

                        $woo_vou_codes[] = $voucode; // Get Voucher codes in an array
                    }

                    // loop through voucher code
                    foreach ($woo_vou_codes as $woo_vou_code) {

                        $vou_code_array['vou_code'] = trim($woo_vou_code); // Get voucher codes
                        $vou_code_array['vou_amount'] = $vou_amount; // Get voucher amount
                        // Generate args to get voucher code id
                        $vou_code_args['fields'] = 'ids';
                        $vou_code_args['meta_query'] = array(
                            array(
                                'key' => $prefix . 'purchased_codes',
                                'value' => $woo_vou_code
                            ),
                            array(
                                'key' => $prefix . 'used_codes',
                                'compare' => 'NOT EXISTS'
                            )
                        );

                        // This always return array
                        $voucodedata = $woo_vou_voucher->woo_vou_get_voucher_details($vou_code_args);

                        if (!empty($voucodedata)) {

                            // Get voucher and product id
                            $voucher_code_id = $voucodedata[0];
                            $product_id = wp_get_post_parent_id($voucher_code_id);

                            $voucher_start_date = get_post_meta($voucher_code_id, $prefix . 'start_date', true); // Get Voucher start date
                            $voucher_exp_date = get_post_meta($voucher_code_id, $prefix . 'exp_date', true); // Get voucher expiry date
                            $disable_redeem_day = get_post_meta($product_id, $prefix . 'disable_redeem_day', true); // Get voucher restriction days

                            $start_date = !empty($voucher_start_date) ? $voucher_start_date : ""; // Convert start date to specified format
                            $exp_date = !empty($voucher_exp_date) ? $voucher_exp_date : ""; // Convert expiry date to specified format
                            // Assign data to array
                            $vou_code_array['vou_start_date'] = $start_date;
                            $vou_code_array['vou_exp_date'] = $exp_date;
                            $vou_code_array['vou_rest_days'] = $disable_redeem_day;
                        }

                        //Create WC coupon code
                        $woo_vou_voucher->woo_vou_create_wc_coupon_code($vou_code_array, $order, $product_id);
                    }
                }
            }
        }
    }
}

/**
 * Changing the Recipient Form Position on Selecting Check Box
 * Adding it below the Add to Cart Button
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.9.4
 */
function woo_vou_enable_after_add_to_cart_button() {
	
    $prefix = WOO_VOU_META_PREFIX; // Get prefix
    // Enable to change the position
    $vou_recipient_form_position = get_option('vou_recipient_form_position');

    // If enable to change the for position
    if (!empty($vou_recipient_form_position) && $vou_recipient_form_position == 2) {

        //remove custom html to single product page before add to cart button
        remove_action('woocommerce_before_add_to_cart_button', 'woo_vou_after_before_add_to_cart_button');

        // Add Recipient form below cart button
        add_action('woocommerce_after_add_to_cart_button', 'woo_vou_after_before_add_to_cart_button');
    }
}

/**
 * Adding hook to allow images to display on thankyou page,
 * removed in WC 3.0
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 3.1.0
 */
function woo_vou_display_item_meta($html, $item, $args) {

	/**
	 * Code from woocommerce/includes/wc-template-functions.php
	 * Function Name ;- wc_display_item_meta
	 */	
	$strings = array();

	foreach ( $item->get_formatted_meta_data() as $meta_id => $meta ) {
		$value = $args['autop'] ? wp_kses_post( $meta->display_value ) : wp_kses_post( make_clickable( trim( $meta->display_value ) ) );
		$strings[] = '<strong class="wc-item-meta-label">' . wp_kses_post( $meta->display_key ) . ':</strong> ' . $value;
	}

	if ( $strings ) {
		$html = $args['before'] . implode( $args['separator'], $strings ) . $args['after'];
	}
	
	return apply_filters('woo_vou_display_item_meta', $html, $item, $args);
}

/**
 * Adding hook to modify author args for voucher code pages
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 3.1.0
 */
function woo_vou_check_vendor_author_args($args) {

	// Get global variables
	global $current_user, $woo_vou_vendor_role;
	
	// Get "Enable Vendor to access all Voucher Codes" option
    $vou_enable_vendor_access_all_voucodes = get_option('vou_enable_vendor_access_all_voucodes');

    // If option for "Enable Vendor to access all Voucher Codes" is set
    if(!empty($vou_enable_vendor_access_all_voucodes) && $vou_enable_vendor_access_all_voucodes == 'yes') {
    
		// Get user role
		$user_roles	= isset( $current_user->roles ) ? $current_user->roles : array();
		$user_role	= array_shift( $user_roles );
	
		// Get voucher admin roles
		$admin_roles	= woo_vou_assigned_admin_roles();
	
		if( !in_array( $user_role, $admin_roles ) && in_array( $user_role, $woo_vou_vendor_role ) ) {
	
			unset($args['author']);
		}
    }

    // return $args
	return $args;
}

/**
 * Locate woocommerce template in plugins
 * 
 * @param string $template
 * @param type $template_name 
 * @param type $template_path 
 * @return string
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 3.2.2
 */
function woo_vou_woocommerce_locate_template( $template, $template_name, $template_path ) {    
        
    $_template = $template;
    
    if ( ! $template_path ) {
		$template_path = WC()->template_path();
	}
    
    $plugin_path = WOO_VOU_DIR . '/includes/woocommerce/';
  
    // Look within passed path within the theme � this is priority    
	$template = locate_template(
		array(
			trailingslashit( $template_path ) . $template_name,
			$template_name,
		)
	);
    
    // Modification: Get the template from this plugin, if it exists
    if ( ! $template && file_exists( $plugin_path . $template_name ) ) {
        $template = $plugin_path . $template_name;
    }

    // Use default template
    if ( ! $template ) {
        $template = $_template;
    }

    // Return what we found
    return $template;
}

/**
 * Removed woocommerce_email_order_details action
 * Added custom function to display order downloads in email
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 3.2.4
 */
function woo_vou_email_order_details( $order, $sent_to_admin, $plain_text, $email ){
    
    $downloads = $order->get_downloadable_items();
    if( !empty( $downloads ) ) {
        
        $remove_action = false;
        foreach ( $downloads as $key => $download ) {
            if( strpos( $download['download_id'], 'woo_vou_pdf_' ) !== false ) {
                $remove_action  = true;
                break;
            }
        }
        
        if( $remove_action ) {
            $mailer = WC()->mailer(); // get the instance of the WC_Emails class
            remove_action( 'woocommerce_email_order_details', array( $mailer, 'order_downloads' ), 10, 4 );    
            add_action( 'woocommerce_email_order_details', 'woo_vou_order_downloads', 9, 4 );
        }        
    }   
}

/**
 * Show order downloads in a table.
 * Override function WC_Emails->order_downloads()
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 3.2.4
 */
function woo_vou_order_downloads( $order, $sent_to_admin = false, $plain_text = false, $email = '' ) {

    // Get order status
    if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1) {
        $order_status = $order->post_status;
    } else {
        $order_status = $order->get_status();
    }

    $grant_access_after_payment = get_option('woocommerce_downloads_grant_access_after_payment');
    // If order has voucher code and downloadsble permissions are given
    if( $order_status == 'completed' || $order_status == 'wc-completed' 
    	|| ( $order_status == 'processing' && $grant_access_after_payment == "yes" ) ) {
        
        $downloads = $order->get_downloadable_items();
        $columns   = apply_filters( 'woocommerce_email_downloads_columns', array(
            'download-product' => __( 'Product', 'woocommerce' ),
            'download-expires' => __( 'Expires', 'woocommerce' ),
            'download-file'    => __( 'Download', 'woocommerce' ),
        ) );

        if ( $plain_text ) {
            wc_get_template( 'emails/plain/email-downloads.php', array( 'order' => $order, 'sent_to_admin' => $sent_to_admin, 'plain_text' => $plain_text, 'email' => $email, 'downloads' => $downloads, 'columns' => $columns ) );
        } else {
            wc_get_template( 'emails/email-downloads.php', array( 'order' => $order, 'sent_to_admin' => $sent_to_admin, 'plain_text' => $plain_text, 'email' => $email, 'downloads' => $downloads, 'columns' => $columns ) );
        }
    }
}