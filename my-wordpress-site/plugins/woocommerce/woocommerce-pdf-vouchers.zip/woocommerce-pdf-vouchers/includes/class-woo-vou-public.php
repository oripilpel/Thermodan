<?php
// Exit if accessed directly
if (!defined('ABSPATH'))
    exit;

/**
 * Public Pages Class
 * 
 * Handles all the different features and functions
 * for the front end pages.
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 1.0.0
 */
class WOO_Vou_Public {

    public $model;
    public $voucher;

    public function __construct() {

        global $woo_vou_model, $woo_vou_voucher;

        $this->model = $woo_vou_model;
        $this->voucher = $woo_vou_voucher;
    }

    /**
     * Display Check Code Html
     * 
     * Handles to display check code html for user and admin
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    public function woo_vou_check_code_content() {

        global $current_user, $woo_vou_vendor_role;

        //Get User roles
        $user_roles = isset($current_user->roles) ? $current_user->roles : array();
        $user_role = array_shift($user_roles);

        //voucher admin roles
        $admin_roles = woo_vou_assigned_admin_roles();
        ?>

        <table class="form-table woo-vou-check-code">
            <tr>
                <th>
                    <label for="woo_vou_voucher_code"><?php _e('Enter Voucher Code', 'woovoucher') ?></label>
                </th>
                <td>
                    <input type="text" id="woo_vou_voucher_code" name="woo_vou_voucher_code" value="" />
                    <input type="button" id="woo_vou_check_voucher_code" name="woo_vou_check_voucher_code" class="button-primary" value="<?php _e('Check It', 'woovoucher') ?>" />
                    <div class="woo-vou-loader woo-vou-check-voucher-code-loader"><img src="<?php echo WOO_VOU_IMG_URL; ?>/ajax-loader.gif"/></div>
                    <div class="woo-vou-voucher-code-msg"></div>
                </td>
            </tr>
        <?php if (in_array($user_role, $admin_roles) || in_array($user_role, $woo_vou_vendor_role)) {// voucher admin can redeem all codes  ?>
                <tr class="woo-vou-voucher-code-submit-wrap">
                    <th>
                    </th>
                    <td>
            <?php echo apply_filters('woo_vou_voucher_code_submit', '<input type="submit" id="woo_vou_voucher_code_submit" name="woo_vou_voucher_code_submit" class="button-primary" value="' . __("Redeem", "woovoucher") . '"/>'); ?>
                        <div class="woo-vou-loader woo-vou-voucher-code-submit-loader"><img src="<?php echo WOO_VOU_IMG_URL; ?>/ajax-loader.gif"/></div>
                    </td>
                </tr>
        <?php } do_action('woo_vou_inner_check_code_table'); ?>
        </table><?php
        do_action('woo_vou_after_check_code_content');
    }

    /**
     * This is used to ensure any required user input fields are supplied
     * 
     * Handles to This is used to ensure any required user input fields are supplied
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 2.0
     */
    public function woo_vou_add_to_cart_validation($valid, $product_id, $quantity, $variation_id = '', $variations = array(), $cart_item_data = array()) {

        //Get prefix
        $prefix = WOO_VOU_META_PREFIX;
        $_product_id = $variation_id ? $variation_id : $product_id;
        $product = wc_get_product($_product_id);

        //voucher enable or not
        $voucher_enable = $this->voucher->woo_vou_check_enable_voucher($product_id, $variation_id);

        if ($voucher_enable) {//If voucher enable
            //Get product recipient meta setting
            $recipient_data = $this->model->woo_vou_get_product_recipient_meta($product_id);

            if (isset($_POST[$prefix . 'recipient_name'][$_product_id])) {//Strip recipient name
                $_POST[$prefix . 'recipient_name'][$_product_id] = $this->model->woo_vou_escape_slashes_deep(trim($_POST[$prefix . 'recipient_name'][$_product_id]));
            }
            if (isset($_POST[$prefix . 'recipient_email'][$_product_id])) {//Strip recipient email
                $_POST[$prefix . 'recipient_email'][$_product_id] = $this->model->woo_vou_escape_slashes_deep(trim($_POST[$prefix . 'recipient_email'][$_product_id]));
            }
            if (isset($_POST[$prefix . 'recipient_message'][$_product_id])) {//Strip recipient message
                $_POST[$prefix . 'recipient_message'][$_product_id] = $this->model->woo_vou_escape_slashes_deep(trim($_POST[$prefix . 'recipient_message'][$_product_id]));
            }
            if (isset($_POST[$prefix . 'pdf_template_selection'][$_product_id])) {//Strip pdf template selection
                $_POST[$prefix . 'pdf_template_selection'][$_product_id] = $this->model->woo_vou_escape_slashes_deep(trim($_POST[$prefix . 'pdf_template_selection'][$_product_id]));
            }

            //recipient name field validation
            if ($recipient_data['enable_recipient_name'] == 'yes' && $recipient_data['recipient_name_is_required'] == 'yes' && empty($_POST[$prefix . 'recipient_name'][$_product_id])) {
                wc_add_notice('<p class="woo-vou-recipient-error">' . __("Field", 'woovoucher') . ' ' . $recipient_data['recipient_name_lable'] . ' ' . __("is required.", 'woovoucher') . '</p>', 'error');
                $valid = false;
            }

            // Check if Email is Selected or not in Delivery Choice
            $rec_email_err_enable = apply_filters('woo_vou_recipient_email_error_enable', $_product_id);

            //recipient email field validation
            if ($recipient_data['enable_recipient_email'] == 'yes' && $recipient_data['recipient_email_is_required'] == 'yes' && empty($_POST[$prefix . 'recipient_email'][$_product_id]) && $rec_email_err_enable) {
                wc_add_notice('<p class="woo-vou-recipient-error">' . __("Field", 'woovoucher') . ' ' . $recipient_data['recipient_email_label'] . ' ' . __("is required.", 'woovoucher') . '</p>', 'error');
                $valid = false;
            } elseif (!empty($_POST[$prefix . 'recipient_email'][$_product_id]) && !is_email($_POST[$prefix . 'recipient_email'][$_product_id])) { //recipient email valid email validation
                wc_add_notice('<p class="woo-vou-recipient-error">' . __("Please Enter Valid", 'woovoucher') . ' ' . $recipient_data['recipient_email_label'] . '.</p>', 'error');
                $valid = false;
            }

            //recipient message validation
            if ($recipient_data['enable_recipient_message'] == 'yes' && $recipient_data['recipient_message_is_required'] == 'yes' && empty($_POST[$prefix . 'recipient_message'][$_product_id])) {
                wc_add_notice('<p class="woo-vou-recipient-error">' . __("Field", 'woovoucher') . ' ' . $recipient_data['recipient_message_label'] . ' ' . __("is required.", 'woovoucher') . '</p>', 'error');
                $valid = false;
            }

            //recipient email valid email validation
            if ($recipient_data['enable_recipient_giftdate'] == 'yes' && $recipient_data['recipient_giftdate_is_required'] == 'yes' && empty($_POST[$prefix . 'recipient_giftdate'][$_product_id]) && $rec_email_err_enable) {
                wc_add_notice('<p class="woo-vou-recipient-error">' . __("Field", 'woovoucher') . ' ' . $recipient_data['recipient_giftdate_label'] . ' ' . __("is required.", 'woovoucher') . '</p>', 'error');
                $valid = false;
            } elseif (!empty($_POST[$prefix . 'recipient_giftdate'][$_product_id])) { //recipient gift date validation
                if ($this->model->woo_vou_check_date($_POST[$prefix . 'recipient_giftdate'][$_product_id])) {
                    wc_add_notice('<p class="woo-vou-recipient-error">' . __("Please Enter Valid", 'woovoucher') . ' ' . $recipient_data['recipient_giftdate_label'] . '.</p>', 'error');
                    $valid = false;
                } elseif (strtotime($this->model->woo_vou_current_date('d-M-Y')) > strtotime($_POST[$prefix . 'recipient_giftdate'][$_product_id])) {
                    wc_add_notice('<p class="woo-vou-recipient-error">' . __("Please Enter Valid", 'woovoucher') . ' ' . $recipient_data['recipient_giftdate_label'] . '.</p>', 'error');
                    $valid = false;
                }
            }

            //pdf template selection validation
            if ($recipient_data['enable_pdf_template_selection'] == 'yes' && empty($_POST[$prefix . 'pdf_template_selection'][$_product_id])) {
                wc_add_notice('<p class="woo-vou-recipient-error">' . __("Field", 'woovoucher') . ' ' . $recipient_data['pdf_template_selection_label'] . ' ' . __("is required.", 'woovoucher') . '</p>', 'error');
                $valid = false;
            }
        }

        return $valid;
    }

    /**
     * This is used to send an email after order completed to recipient user
     * 
     * Handles to send an email after order completed
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 2.0
     */
    public function woo_vou_payment_process_or_complete($order_id) {

        global $wpdb;

        $prefix = WOO_VOU_META_PREFIX; // Get prefix
        $cart_details = wc_get_order($order_id); // Get order
        $order_status = woo_vou_get_order_status($cart_details); // Get order status

        if ($order_status == 'processing' && get_option('woocommerce_downloads_grant_access_after_payment') == 'no') {
            return;
        }

        // record the fact that the vouchers have been sent
        if (get_post_meta($order_id, $prefix.'recipient_email_sent', true)) {
            return;
        }

        $recipient_gift_email_send = true;
        $order_items = $cart_details->get_items();
        $payment_user_info = $this->model->woo_vou_get_buyer_information($order_id); // Get payment information
        $first_name = $payment_user_info['first_name']; // Get billing first name
        $last_name = $payment_user_info['last_name']; // Get billing last name

        if (!empty($order_items)) {//if item is empty
            foreach ($order_items as $product_item_key => $product_data) {

                $recipient_gift_email_send = true;

                //Get product from Item ( It is required otherwise multipdf voucher link not work and global $woo_vou_item_id will not work )
                $_product = apply_filters('woocommerce_order_item_product', $cart_details->get_product_from_item($product_data), $product_data);
			 	$download_file_data = $this->model->woo_vou_get_item_downloads_from_order($cart_details, $product_data); // Get downloadable files
                $product_id = isset($product_data['product_id']) ? $product_data['product_id'] : '';
                $variation_id = isset($product_data['variation_id']) ? $product_data['variation_id'] : '';

                //vendor sale notification
                $this->model->woo_vou_vendor_sale_notification($product_id, $variation_id, $product_item_key, $product_data, $order_id, $cart_details);

                //Initilize recipient detail and other variables
                $recipient_details = $links = $attach_key = array();

                //Get product item meta
                $product_item_meta = isset($product_data['item_meta']) ? $product_data['item_meta'] : array();
                $recipient_details = $this->model->woo_vou_get_recipient_data($product_item_meta);
                $i = 0;

                if( !empty($download_file_data) ){

	                foreach ($download_file_data as $key => $download_file) {
	
	                    $check_key = strpos($key, 'woo_vou_pdf_');
	
	                    if (!empty($download_file) && $check_key !== false) {
	
	                        $attach_keys[] = $key;
	                        $i++;
	                        $links[] = '<small><a href="' . esc_url($download_file['download_url']) . '">' . sprintf(__('Download file%s', 'woovoucher'), ( count($download_file_data) > 1 ? ' ' . $i . ': ' : ': ')) . esc_html($download_file['name']) . '</a></small>';
	                    }
	                }
                }

                $recipient_details['recipient_voucher'] = '<br/>' . implode('<br/>', $links);

                // added filter to send extra emails on diferent email ids by other extensions
                $woo_vou_extra_emails = false;
                $woo_vou_extra_emails = apply_filters('woo_vou_pdf_recipient_email', $woo_vou_extra_emails, $product_id);

                if (( isset($recipient_details['recipient_email']) && !empty($recipient_details['recipient_email']) ) ||
                        (!empty($woo_vou_extra_emails) )) {

                    $recipient_name = isset($recipient_details['recipient_name']) ? $recipient_details['recipient_name'] : '';
                    $recipient_email = isset($recipient_details['recipient_email']) ? $recipient_details['recipient_email'] : '';
                    $recipient_message = isset($recipient_details['recipient_message']) ? '"' . nl2br($recipient_details['recipient_message']) . '"' : '';
                    $recipient_voucher = isset($recipient_details['recipient_voucher']) ? $recipient_details['recipient_voucher'] : '';

                    // Get Extra email if passed through filter
                    $woo_vou_extra_emails = !empty($woo_vou_extra_emails) ? $woo_vou_extra_emails : '';

                    $attachments = array();

                    if (get_option('vou_attach_mail') == 'yes') { //If attachment enable
                        //Get product/variation ID
                        $product_id = !empty($product_data['variation_id']) ? $product_data['variation_id'] : $product_data['product_id'];

                        if (!empty($attach_keys)) {//attachments keys not empty
                            foreach ($attach_keys as $attach_key) {

                                $attach_pdf_file_name = get_option('attach_pdf_name');
                                $attach_pdf_file_name = !empty($attach_pdf_file_name) ? $attach_pdf_file_name : 'woo-voucher-';

                                // Replacing voucher pdf name with given value
                                $orderdvoucode_key = str_replace('woo_vou_pdf_', $attach_pdf_file_name, $attach_key);

                                // Voucher attachment path
                                $vou_pdf_path = WOO_VOU_UPLOAD_DIR . $orderdvoucode_key . '-' . $product_id . '-' . $product_item_key . '-' . $order_id; // Voucher pdf path
                                $vou_pdf_name = $vou_pdf_path . '.pdf';

                                // If voucher pdf exist in folder
                                if (file_exists($vou_pdf_name)) {

                                    // Adding the voucher pdf in attachment array
                                    $attachments[] = apply_filters('woo_vou_gift_email_attachments', $vou_pdf_name, $order_id, $product_data);
                                }
                            }
                        }
                    }

                    // Get Recipient gift date
                    $recipient_giftdate = !empty($recipient_details['recipient_giftdate']) ? $recipient_details['recipient_giftdate'] : '';
                    $recipient_giftdate = apply_filters('woo_vou_replace_giftdate', $recipient_giftdate, $order_id, $product_item_key);

                    // Getting Voucher Delivery
                    $woo_vou_all_ordered_data = $this->model->woo_vou_get_all_ordered_data($order_id);
                    if( !empty($variation_id) ){ // If this variation then get it's product id

                    	$_variation_pro 	= wc_get_product($variation_id);
                        $parent_product_id 	= $_variation_pro->get_parent_id();
                        $vou_voucher_delivery_type = $woo_vou_all_ordered_data[$parent_product_id]['voucher_delivery'][$variation_id];
                    } else {

                        $vou_voucher_delivery_type = $woo_vou_all_ordered_data[$product_id]['voucher_delivery'];
                    }

                    // Check if voucher delivery set 
                    if( $vou_voucher_delivery_type == 'offline' ) {
                        $recipient_gift_email_send = true;
                        continue;
                        
                    // check if gift date is set. If yes, then no need to send email right now.
                    // Will send email on selected gift date    
                    } elseif (!empty($recipient_giftdate)) {                        
                        $recipient_gift_email_send = false;
                        continue;
                    } else {

                        //Get All Data for gift notify
                        $gift_data = array(
                            'first_name' => $first_name,
                            'last_name' => $last_name,
                            'recipient_name' => $recipient_name,
                            'recipient_email' => $recipient_email,
                            'recipient_message' => $recipient_message,
                            'voucher_link' => $recipient_voucher,
                            'attachments' => $attachments,
                            'woo_vou_extra_emails' => $woo_vou_extra_emails,
                            'order_id' => $order_id
                        );

                        // Fires when gift notify.
                        do_action('woo_vou_gift_email', $gift_data);
                    }
                }
            } //end foreach
            // Add action after gift email is sent
            do_action('woo_vou_after_gift_email', $order_id);
        }

        if ($recipient_gift_email_send) {
            //Update post meta for email attachment issue
            update_post_meta($order_id, $prefix . 'recipient_email_sent', true);
        }
    }

    /**
     * Prevent product from being added to cart (free or priced) with ?add-to-cart=XXX
     * When product expired or upcoming
     *
     * @package WooCommerce - PDF Vouchers
     * @since 2.4.0
     */
    public function woo_vou_prevent_product_add_to_cart($passed, $product_id) {

        // Get complete product details from product id
        $product = wc_get_product($product_id);

        $expired = $this->voucher->woo_vou_check_product_is_expired($product);

        if ($expired == 'upcoming') {
            wc_add_notice(__('You can not add upcoming products to cart.', 'woovoucher'), 'error');
            $passed = false;
        } elseif ($expired == 'expired') {
            wc_add_notice(__('You can not add expired products to cart.', 'woovoucher'), 'error');
            $passed = false;
        }

        return $passed;
    }

    /**
     * Valiate product added in cart is expired/upcoming
     * 
     * Handles to display error if proudct added in cart is expired/upcoming
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 2.4.0
     */
    public function woo_vou_woocommerce_checkout_process() {

        // get added products in cart
        $cart_details = WC()->session->cart;
        if (!empty($cart_details)) { // if cart is not empty
            foreach ($cart_details as $key => $product_data) {

                // get product id
                $product_id = $product_data['product_id'];

                // Get complete product details from product id
                $product = wc_get_product($product_id);

                // check product is expired/upcoming
                $expired = $this->voucher->woo_vou_check_product_is_expired($product);
                if ($expired == 'upcoming') {
                    if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1)
                        wc_add_notice(sprintf(__('%s is no longer available.', 'woovoucher'), $product->post->post_title), 'error');
                    else
                        wc_add_notice(sprintf(__('%s is no longer available.', 'woovoucher'), $product->get_title()), 'error');
                    return;
                } elseif ($expired == 'expired') {
                    if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1)
                        wc_add_notice(sprintf(__('%s is no longer available.', 'woovoucher'), $product->post->post_title), 'error');
                    else
                        wc_add_notice(sprintf(__('%s is no longer available.', 'woovoucher'), $product->get_title()), 'error');
                    return;
                }
            }
        }
    }

    /**
     * Error message
     * 
     * Handles to throw custom error message
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 2.9.2
     */
    public function woo_vou_coupon_err_message($err, $err_code, $coupon) {

        //get prefix
        $prefix = WOO_VOU_META_PREFIX;

        if ($coupon) {

            $coupon_id = $this->model->woo_vou_get_coupon_id_from_coupon($coupon); // Get coupon id
            $coupon_start_date = get_post_meta($coupon_id, $prefix . 'start_date', true); // Get coupon start date
            $coupon_rest_days = get_post_meta($coupon_id, $prefix . 'disable_redeem_day', true); // Get coupon restriction days

            // Check error code for start date
            if ($err_code == $prefix . 'start_date_err') {

                $err = sprintf(__('This Coupon Code cannot be used before %s', 'woovoucher'), date('Y-m-d H:i:s', strtotime($coupon_start_date))); // Throw error message				
            }

            // Check error for restriction days
            if ($err_code == $prefix . 'day_err') {

                $message = implode(", ", $coupon_rest_days); // Get all days
                $err = sprintf(__('Sorry, coupon Code cannot be used on %s.', 'woovoucher'), $message); // Throw error message
            }
        }

        // Return error
        return $err;
    }

    /**
     * Adding Hooks
     * 
     * Adding proper hoocks for the discount codes
     * 
     * @package WooCommerce - PDF Vouchers
     * @since 1.0.0
     */
    public function add_hooks() {

        //add capabilities to user roles
        add_action('init', 'woo_vou_initilize_role_capabilities', 100);

        //add action to save voucher in order
        add_action('woocommerce_checkout_update_order_meta', 'woo_vou_product_purchase');

        //add action for add custom notifications
        add_filter('woocommerce_email_actions', 'woo_vou_add_email_notification');

        //insert pdf vouchers in woocommerce downloads fiels table
        add_action('woocommerce_grant_product_download_permissions', 'woo_vou_insert_downloadable_files');

        //add action to product process
        add_action('woocommerce_download_product', 'woo_vou_download_process', 10, 6);

        //add filter to add admin access for vendor role
        add_filter('woocommerce_prevent_admin_access', 'woo_vou_prevent_admin_access');

        //ajax call to edit all controls
        add_action('wp_ajax_woo_vou_check_voucher_code', array($this->voucher, 'woo_vou_check_voucher_code'));
        add_action('wp_ajax_nopriv_woo_vou_check_voucher_code', array($this->voucher, 'woo_vou_check_voucher_code'));

        //ajax call to save voucher code
        add_action('wp_ajax_woo_vou_save_voucher_code', array($this->voucher, 'woo_vou_save_voucher_code'));
        add_action('wp_ajax_nopriv_woo_vou_save_voucher_code', array($this->voucher, 'woo_vou_save_voucher_code'));

        // add action to add html for check voucher code
        add_action('woo_vou_check_code_content', array($this, 'woo_vou_check_code_content'));

        // add action to set order as a global variable
        add_action('woocommerce_email_before_order_table', 'woo_vou_email_before_order_table');

        //filter to set order product data as a global variable
        add_filter('woocommerce_order_item_product', 'woo_vou_order_item_product', 10, 2);

        //restore voucher codes if order is failed or cancled
        add_action('woocommerce_order_status_changed', array($this->voucher, 'woo_vou_restore_voucher_codes'), 10, 3);

        //add custom html to single product page before add to cart button
        add_action('woocommerce_before_add_to_cart_button', 'woo_vou_after_before_add_to_cart_button');

        //add to cart in item data
        add_filter('woocommerce_add_cart_item_data', 'woo_vou_woocommerce_add_cart_item_data', 10, 3);

        // add to cart in item data from session
        add_filter('woocommerce_get_cart_item_from_session', 'woo_vou_get_cart_item_from_session', 10, 2);

        // get to cart in item data to display in cart page
        add_filter('woocommerce_get_item_data', 'woo_vou_woocommerce_get_item_data', 10, 2);

        //add filter to validate custom fields of product page
        add_filter('woocommerce_add_to_cart_validation', array($this, 'woo_vou_add_to_cart_validation'), 10, 6);

        // add action when order status goes to complete
        add_action('woocommerce_order_status_completed_notification', array($this, 'woo_vou_payment_process_or_complete'), 100);
        add_action('woocommerce_order_status_pending_to_processing_notification', array($this, 'woo_vou_payment_process_or_complete'), 100);

        //add action to hide recipient in order meta
        add_filter('woocommerce_hidden_order_itemmeta', 'woo_vou_hide_recipient_itemmeta');

        //filter to attach the voucher pdf in mail
        add_filter('woocommerce_email_attachments', 'woo_vou_attach_voucher_to_email', 10, 3);

        //add action to check qrcode
        add_action('init', 'woo_vou_check_qrcode');

        //Add order manually from backend
        add_action('woocommerce_process_shop_order_meta', 'woo_vou_process_shop_order_manually');

        // To make compatible with previous versions of 3.0.0
        if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1) {
            //add filter to merge voucher pdf with product files
            add_filter('woocommerce_product_files', 'woo_vou_downloadable_files_26_deprecated', 10, 2);

            //Set global item id for voucher key generater
            add_filter('woocommerce_get_product_from_item', 'woo_vou_set_global_item_id_26_deprecated', 10, 3);
            
            // add action to add cart item to the order.
        	add_action('woocommerce_add_order_item_meta', 'woo_vou_add_order_item_meta_26_deprecated', 10, 2);
        	
        	//Hide recipient variation from product name field
        	add_filter('woo_vou_hide_recipient_variations', 'woo_vou_hide_recipients_item_variations_26_deprecated', 10, 2);
        } else {
            //Set global item id for voucher key generater
            add_filter('woocommerce_order_item_product', 'woo_vou_set_global_item_id', 10, 2);
            
            // add action to add cart item to the order.
        	add_action('woocommerce_checkout_create_order_line_item', 'woo_vou_add_order_item_meta', 10, 4);
        	
        	// Add filter to add image on thankyou page, removed by woocommerce 3.0
        	add_filter('woocommerce_display_item_meta', 'woo_vou_display_item_meta', 10, 3);
        	
        	//Hide recipient variation from product name field
        	add_filter('woo_vou_hide_recipient_variations', 'woo_vou_hide_recipients_item_variations', 10, 2);
        }

        // Add downlodable files and add Item ID in generated pdf download URL
        add_filter('woocommerce_get_item_downloads', 'woo_vou_get_item_pdf_downloads', 10, 3);

        //Add voucher download links to my account page
        add_action('woocommerce_customer_get_downloadable_products', 'woo_vou_my_pdf_vouchers_download_link');

        //restore old voucher code again when resume old order due to overwrite item
        add_action('woocommerce_resume_order', array($this->voucher, 'woo_vou_resume_order_voucher_codes'));

        // add action to update stock as per no. of voucher codes
        add_action('woocommerce_reduce_order_stock', 'woo_vou_update_order_stock');

        // add filter to remove add to cart button on shop page for expire product
        add_action('woocommerce_loop_add_to_cart_link', 'woo_vou_shop_add_to_cart', 10, 1);

        // prevent add to cart product if some one try directly using url	
        add_filter('woocommerce_add_to_cart_validation', array($this, 'woo_vou_prevent_product_add_to_cart'), 10, 2);

        // add action on place order check product is expired/upcoming in checkout page
        add_action('woocommerce_checkout_process', array($this, 'woo_vou_woocommerce_checkout_process'), 10);

        //ajax pagination for used voucher codes
        add_action('wp_ajax_woo_vou_used_codes_next_page', array($this->voucher, 'woo_vou_used_voucher_codes_ajax'));
        add_action('wp_ajax_nopriv_woo_vou_used_codes_next_page', array($this->voucher, 'woo_vou_used_voucher_codes_ajax'));

        //ajax pagination for purchased voucher codes
        add_action('wp_ajax_woo_vou_purchased_codes_next_page', array($this->voucher, 'woo_vou_purchased_voucher_codes_ajax'));
        add_action('wp_ajax_nopriv_woo_vou_purchased_codes_next_page', array($this->voucher, 'woo_vou_purchased_voucher_codes_ajax'));

        // add filter to remove voucher download link
        add_filter('woo_vou_remove_download_link', 'woo_vou_remove_voucher_download_link', 10, 3);

        // allow to add admin email in bcc
        add_filter('woocommerce_email_headers', 'woo_vou_allow_admin_to_bcc', 10, 2);

        // Add filter to validate extra fields
        add_filter('woocommerce_coupon_is_valid', 'woo_vou_validate_coupon', 10, 2);

        // Add filter to add custom coupon error message
        add_filter('woocommerce_coupon_error', array($this, 'woo_vou_coupon_err_message'), 10, 3);

        // Add action to generate coupon code when order status gets processing
        add_action('woocommerce_grant_product_download_permissions', 'woo_vou_generate_couponcode_from_vouchercode', 20);

        // Add action to enable recipient form below add to cart button
        add_action('wp', 'woo_vou_enable_after_add_to_cart_button');

        // Add action to add change used listing arguments for "Used Voucher Code" page
        add_filter('woo_vou_get_used_vou_list_args', 'woo_vou_check_vendor_author_args');

        // Add action to add change used listing arguments for "Purchased Voucher Code" page
        add_filter('woo_vou_get_purchased_vou_list_args', 'woo_vou_check_vendor_author_args');

        // Add action to add change used listing arguments for "Purchased Voucher Code" page
        add_filter('woo_vou_get_partial_vou_list_args', 'woo_vou_check_vendor_author_args');

        // Add action to add change used listing arguments for "Expire Voucher Code" page
        add_filter('woo_vou_get_expire_vou_list_args', 'woo_vou_check_vendor_author_args');

        // Add action to add change used listing arguments for "Check Voucher Code" purchased codes
        add_filter('woo_vou_get_primary_vendor_purchase_voucode_args', 'woo_vou_check_vendor_author_args');

        // Add action to add change used listing arguments for "Check Voucher Code" used codes
        add_filter('woo_vou_get_primary_vendor_used_voucode_args', 'woo_vou_check_vendor_author_args');
        
        // To make compatible with versions of 3.2.0 or greater
        if (version_compare(WOOCOMMERCE_VERSION, "3.2.0") != -1) {
            // Added woocommerce template filter to override templates from plugin
            add_filter('woocommerce_locate_template', 'woo_vou_woocommerce_locate_template', 10, 5 );

            // Add action to add downlodable files list in emails
            add_action( 'woocommerce_email_order_details', 'woo_vou_email_order_details', 5, 4 );
        }

        //ajax call to update voucher expiry date
        add_action('wp_ajax_woo_vou_change_voucher_expiry_date', array($this->voucher, 'woo_vou_change_voucher_expiry_date'));
        add_action('wp_ajax_nopriv_woo_vou_change_voucher_expiry_date', array($this->voucher, 'woo_vou_change_voucher_expiry_date'));

        //ajax call to get voucher expiry date
        add_action('wp_ajax_woo_vou_get_voucher_expiry_date', array($this->voucher, 'woo_vou_get_voucher_expiry_date') );
        add_action('wp_ajax_nopriv_woo_vou_get_voucher_expiry_date', array($this->voucher, 'woo_vou_get_voucher_expiry_date') );
    }

}