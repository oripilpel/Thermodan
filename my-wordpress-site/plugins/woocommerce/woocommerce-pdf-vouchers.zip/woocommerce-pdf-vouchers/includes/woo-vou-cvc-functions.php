<?php
// Exit if accessed directly
if (!defined('ABSPATH'))
    exit;
    
/**
 * Display Reddem information
 * Like Redeem by, Redeem date
 * 
 * Handles to display information related to redeem
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.7.2
 */
function woo_vou_display_redeem_info_html($vouchercodeid, $order_id, $type = 'html', $default_tab = 'used') {
	
	global $woo_vou_model;

    $prefix = WOO_VOU_META_PREFIX;

    $redeem_details_html = '';

    $user_id = get_post_meta($vouchercodeid, $prefix . 'redeem_by', true);
    $user_detail = get_userdata($user_id);

    $user_profile = add_query_arg(array('user_id' => $user_id), admin_url('user-edit.php'));
    $display_name = isset($user_detail->display_name) ? $user_detail->display_name : '';

    if (!empty($display_name)) {
        $display_name = '<a href="' . $user_profile . '">' . $display_name . '</a>';
    } else {
        $display_name = __('N/A', 'woovoucher');
    }

    $redeem_date = get_post_meta($vouchercodeid, $prefix . 'used_code_date', true);
    $redeem_date = !empty($redeem_date) ? $woo_vou_model->woo_vou_get_date_format($redeem_date, true) : '';

    if ($type == 'csv' && $default_tab == 'partially') {

        // get redeem amount 
        $redeem_amount = get_post_meta($vouchercodeid, $prefix . 'partial_redeem_amount', true);
        $redeem_details_html .= 'Redeem By: ' . $display_name . "\n";
        $redeem_details_html .= 'Redeem Time: ' . $redeem_date . "\n";
        $redeem_details_html .= 'Redeem Amount: ' . strip_tags($redeem_amount);
    } else if ($default_tab == 'partially') {

        $order = new Wc_Order($order_id);
        // get redeem amount 
        $redeem_amount = get_post_meta($vouchercodeid, $prefix . 'partial_redeem_amount', true);
        $redeem_amount = wc_price($redeem_amount, array('currency' => woo_vou_get_order_currency($order)));
        $redeem_details_html .= '<table>';
        $redeem_details_html .= '<tr><td style="font-weight:bold;">' . __('Redeem By:', 'woovoucher') . '</td><td>' . $display_name . '</td></tr>';
        $redeem_details_html .= '<tr><td style="font-weight:bold;">' . __('Redeem Time:', 'woovoucher') . '</td><td>' . $redeem_date . '</td></tr>';
        $redeem_details_html .= '<tr><td style="font-weight:bold;">' . __('Redeem Amount:', 'woovoucher') . '</td><td>' . strip_tags($redeem_amount) . '</td></tr>';
        $redeem_details_html .= '</table>';
    } else { // type is 'html'
        $enable_partial_redeem = get_option('vou_enable_partial_redeem');
        if ($enable_partial_redeem == "yes" && $type == 'html') {
            $partially_redeem_data = get_posts(array(
                'post_parent' => $vouchercodeid,
                'post_status' => 'publish',
                'post_type' => WOO_VOU_PARTIAL_REDEEM_POST_TYPE
                    ));
            if (!empty($partially_redeem_data)) {

                $partially_redeem_data_url = add_query_arg(
                        array(
                    'page' => 'woo-vou-codes',
                    'vou-data' => 'partially-redeemed',
                    'voucherid' => $vouchercodeid
                        ), admin_url('admin.php')
                );
                $check_redeem_list = '<tr>
										<td style="font-weight:bold;" colspan="2">
											<a href="' . $partially_redeem_data_url . '">' . __('Check Partially used data', 'woovoucher') . '</a>
										</td>
									 </tr>';
            }
        }

        $check_redeem_list = !empty($check_redeem_list) ? $check_redeem_list : '';

        $redeem_details_html .= '<table>';
        $redeem_details_html .= '<tr><td style="font-weight:bold;">' . __('Redeem By:', 'woovoucher') . '</td><td>' . $display_name . '</td></tr>';
        $redeem_details_html .= '<tr><td style="font-weight:bold;">' . __('Redeem Time:', 'woovoucher') . '</td><td>' . $redeem_date . '</td></tr>';
        $redeem_details_html .= $check_redeem_list;
        $redeem_details_html .= '</table>';
    }

    return apply_filters('woo_vou_display_redeem_info_html', $redeem_details_html, $vouchercodeid, $order_id, $type, $default_tab);
}

/**
 * Display Order information
 * 
 * Handles to display buyers information
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.3.6
 */
function woo_vou_display_order_info_html($order_id, $type = 'html') {
	
	global $woo_vou_model;

    $order_details_html = '';

    //get order Don't use Wc_Order( $order_id ) as it will thorow fatal error if order not exist
    $order = wc_get_order($order_id);
    if (!empty($order)) {
        if (version_compare(WOOCOMMERCE_VERSION, "3.0.0") == -1) {
            // Order discount
            $order_discount = wc_price($order->get_total_discount(), array('currency' => $order->get_order_currency()));
        } else {
            // Order discount
            $order_discount = wc_price($order->get_total_discount(), array('currency' => $order->get_currency()));
        }
        
        $order_date = $woo_vou_model->woo_vou_get_order_date_from_order($order); // Get order date
        $payment_method = $woo_vou_model->woo_vou_get_payment_method_from_order($order); // Get payment method

        // format order date
        $order_date = !empty($order_date) ? $woo_vou_model->woo_vou_get_date_format($order_date, true) : '';

        //Order title
        $order_total = esc_html(strip_tags($order->get_formatted_order_total()));

        if ($type == 'html')
            $order_id_url = '<a href="' . esc_url(admin_url('post.php?post=' . absint($order_id) . '&action=edit')) . '">' . $order_id . '</a>';
        if ($type == 'pdf')
            $order_id_url = $order_id;

        if ($type == 'csv') {

            $order_details_html .= 'ID : ' . $order_id . "\n";
            $order_details_html .= 'Order Date : ' . $order_date . "\n";
            $order_details_html .= 'Payment Method : ' . $payment_method . "\n";
            $order_details_html .= 'Order Total : 	' . $order_total . "\n";
            $order_details_html .= 'Order Discount :' . strip_tags($order_discount);
        } else {

            $order_details_html .= '<table>';
            $order_details_html .= '<tr><td style="font-weight:bold;">' . __('ID:', 'woovoucher') . '</td><td>' . $order_id_url . '</td></tr>';
            $order_details_html .= '<tr><td style="font-weight:bold;">' . __('Order Date:', 'woovoucher') . '</td><td>' . $order_date . '</td></tr>';
            $order_details_html .= '<tr><td style="font-weight:bold;">' . __('Payment Method:', 'woovoucher') . '</td><td>' . $payment_method . '</td></tr>';
            $order_details_html .= '<tr><td style="font-weight:bold;">' . __('Order Total:', 'woovoucher') . '</td><td>' . $order_total . '</td></tr>';
            $order_details_html .= '<tr><td style="font-weight:bold;">' . __('Order Discount:', 'woovoucher') . '</td><td>' . $order_discount . '</td></tr>';
            $order_details_html .= '</table>';
        }
    }

    return apply_filters('woo_vou_display_order_info_html', $order_details_html, $order_id, $type);
}

/**
 * Display product information
 * 
 * Handles to display buyers information
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.3.6
 */
function woo_vou_display_product_info_html($order_id, $voucode = '', $type = 'html') {
	
	global $woo_vou_model;

    $prefix = WOO_VOU_META_PREFIX; // Get prefix

    $product_details_html = ''; // Declare variables

    if (!empty($order_id) && !empty($voucode)) {//If not empty order id and voucher code
        //get order // don't use WC_Order as it will thow fatal error if order not exist			
        $order = wc_get_order($order_id);

        if (!empty($order)) {
            //get order items
            $order_items = $order->get_items();

            $check_code = trim($voucode);
            $item_array = $woo_vou_model->woo_vou_get_item_data_using_voucher_code($order_items, $check_code);

            $item = isset($item_array['item_data']) ? $item_array['item_data'] : array();
            $item_id = isset($item_array['item_id']) ? $item_array['item_id'] : array();

            //Get product from Item ( It is required otherwise multipdf voucher link not work and global $woo_vou_item_id will not work )
            $_product = $order->get_product_from_item($item);

            //initilize variables
            $product_name = $product_price = $product_sku = '';

            if ($_product) {
                if ($_product && $_product->get_sku()) {
                    $product_sku = esc_html($_product->get_sku());
                }
                if ($type == 'html') {
                    $product_id = $woo_vou_model->woo_vou_get_item_productid_from_product( $_product );
                    $product_name .= '<a target="_blank" href="' . esc_url(admin_url('post.php?post=' . absint($product_id) . '&action=edit')) . '">' . esc_html($item['name']) . '</a>';
                } else {
                    $product_name .= esc_html($item['name']) . "\n";
                }
            } else {
                $product_name .= isset($item['name']) ? esc_html($item['name']) : '';
            }

            //Get product item meta
            $product_item_meta = isset($item['item_meta']) ? $item['item_meta'] : array();

            //Display product variations
            $product_name .= $woo_vou_model->woo_vou_display_product_item_name($product_item_meta, $_product);
            // Get Voucher price
            $vou_price = $woo_vou_model->woo_vou_get_product_price($order_id, $item_id, $item);
            //$vou_price = woo_vou_get_voucher_price_by_order_item($item, $item_id);
            $product_price = wc_price($vou_price);

            if ($type == 'csv') {

                $product_details_html .= __('Name:', 'woovoucher') . strip_tags($product_name) . "\n";
                $product_details_html .= __('Price:', 'woovoucher') . strip_tags($product_price) . "\n";
                if (!empty($product_sku))
                    $product_details_html .= __('SKU:', 'woovoucher') . $product_sku;
            } else {

                $product_details_html .= '<table>';
                $product_details_html .= '<tr><td width="22%;" style="font-weight:bold;">' . __('Name:', 'woovoucher') . '</td><td width="77%;">' . $product_name . '</td></tr>';
                $product_details_html .= '<tr><td width="22%" style="font-weight:bold;">' . __('Price:', 'woovoucher') . '</td><td width="77%;">' . $product_price . '</td></tr>';
                if (!empty($product_sku))
                    $product_details_html .= '<tr><td width="22%" style="font-weight:bold;">' . __('SKU:', 'woovoucher') . '</td><td width="77%;">' . $product_sku . '</td></tr>';
                $product_details_html .= '</table>';
            }
        }
    }

    return apply_filters('woo_vou_display_product_info_html', $product_details_html, $order_id, $voucode, $type);
}

/**
 * Display Buyer's information
 * 
 * Handles to display buyers information
 * 
 * @package WooCommerce - PDF Vouchers
 * @since 2.3.6
 */
function woo_vou_display_buyer_info_html($buyers_information = array(), $display = false) {

    $buyer_info_columns = apply_filters('woo_vou_buyer_info_columns', array(
        'buyer_name' => __('Name:', 'woovoucher'),
        'buyer_email' => __('Email:', 'woovoucher'),
        'buyer_address' => __('Address:', 'woovoucher'),
        'buyer_phone' => __('Address:', 'woovoucher'),
            ));

    $first_name = isset($buyers_information['first_name']) ? $buyers_information['first_name'] : '';
    $last_name = isset($buyers_information['last_name']) ? $buyers_information['last_name'] : '';
    $email = isset($buyers_information['email']) ? $buyers_information['email'] : '';
    $address_1 = isset($buyers_information['address_1']) ? $buyers_information['address_1'] : '';
    $address_2 = isset($buyers_information['address_2']) ? $buyers_information['address_2'] : '';
    $city = isset($buyers_information['city']) ? $buyers_information['city'] : '';
    $state = isset($buyers_information['state']) ? $buyers_information['state'] : '';
    $country = isset($buyers_information['country']) ? $buyers_information['country'] : '';
    $postcode = isset($buyers_information['postcode']) ? $buyers_information['postcode'] : '';
    $phone = isset($buyers_information['phone']) ? $buyers_information['phone'] : '';

    $buyer_details_html = '<table class="woo-vou-buyer-info-table">';

    if (!empty($buyer_info_columns)) {

        foreach ($buyer_info_columns as $col_key => $column) {

            switch ($col_key) {

                case 'buyer_name':
                    $buyer_details_html .= '<tr>';
                    $buyer_details_html .= '<td width="20%" style="font-weight:bold;">' . __('Name:', 'woovoucher') . '</td>';
                    $buyer_details_html .= '<td width="80%">' . $first_name . ' ' . $last_name . '</td>';
                    $buyer_details_html .= '</tr>';
                    break;

                case 'buyer_email' :
                    $buyer_details_html .= '<tr>';
                    $buyer_details_html .= '<td width="20%" style="font-weight:bold;">' . __('Email:', 'woovoucher') . '</td>';
                    $buyer_details_html .= '<td width="80%" style="word-break: break-all;">' . $email . '</td>';
                    $buyer_details_html .= '</tr>';
                    break;

                case 'buyer_address' :
                    $buyer_details_html .= '<tr>';
                    $buyer_details_html .= '<td width="20%" style="font-weight:bold;">' . __('Address:', 'woovoucher') . '</td>';
                    $buyer_details_html .= '<td width="80%">' . $address_1 . ' ' . $address_2 . '<br />' . $city . ' ' . $state . ' ' . $country . ' - ' . $postcode . '</td>';
                    $buyer_details_html .= '</tr>';
                    break;

                case 'buyer_phone' :
                    $buyer_details_html .= '<tr>';
                    $buyer_details_html .= '<td width="20%" style="font-weight:bold;">' . __('Phone:', 'woovoucher') . '</td>';
                    $buyer_details_html .= '<td width="80%">' . $phone . '</td>';
                    $buyer_details_html .= '</tr>';
                    break;

                default :
                    $buyer_details_html .= apply_filters('woo_vou_buyer_info_columns_value', '', $col_key, $buyers_information);
                    break;
            }
        }
    }

    $buyer_details_html .= '</table>';

    $html = apply_filters('woo_vou_display_buyer_info_html', $buyer_details_html, $buyers_information);

    if ($display) {
        echo $html;
    } else {
        return $html;
    }
}