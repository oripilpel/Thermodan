jQuery( document ).ready( function( $ ) {

	//Media Uploader
	$( document ).on( 'click', '.woo-vou-upload-button', function() {
	
		var imgfield,showfield;
		imgfield = jQuery(this).prev('input').attr('id');
		showfield = jQuery(this).parents('td').find('.woo-vou-img-view');
    	
		if(typeof wp == "undefined" || WooVouAdminSettings.new_media_ui != '1' ){// check for media uploader
				
			tb_show('', 'media-upload.php?type=image&amp;TB_iframe=true');
	    	
			window.original_send_to_editor = window.send_to_editor;
			window.send_to_editor = function(html) {
				
				if(imgfield)  {
					
					var mediaurl = $('img',html).attr('src');
					$('#'+imgfield).val(mediaurl);
					showfield.html('<img src="'+mediaurl+'" />');
					tb_remove();
					imgfield = '';
					
				} else {
					
					window.original_send_to_editor(html);
					
				}
			};
	    	return false;
			  
		} else {
			
			var file_frame;
			//window.formfield = '';
			
			//new media uploader
			var button = jQuery(this);
	
			//window.formfield = jQuery(this).closest('.file-input-advanced');
		
			// If the media frame already exists, reopen it.
			if ( file_frame ) {
				//file_frame.uploader.uploader.param( 'post_id', set_to_post_id );
				file_frame.open();
			  return;
			}
	
			// Create the media frame.
			file_frame = wp.media.frames.file_frame = wp.media({
				frame: 'post',
				state: 'insert',
				//title: button.data( 'uploader_title' ),
				/*button: {
					text: button.data( 'uploader_button_text' ),
				},*/
				multiple: false  // Set to true to allow multiple files to be selected
			});
	
			file_frame.on( 'menu:render:default', function(view) {
		        // Store our views in an object.
		        var views = {};
	
		        // Unset default menu items
		        view.unset('library-separator');
		        view.unset('gallery');
		        view.unset('featured-image');
		        view.unset('embed');
	
		        // Initialize the views in our view object.
		        view.set(views);
		    });
	
			// When an image is selected, run a callback.
			file_frame.on( 'insert', function() {
	
				// Get selected size from media uploader
				var selected_size = $('.attachment-display-settings .size').val();
				
				var selection = file_frame.state().get('selection');
				selection.each( function( attachment, index ) {
					attachment = attachment.toJSON();
					
					// Selected attachment url from media uploader
					var attachment_url = attachment.sizes[selected_size].url;
					var attachment_id = attachment.id;
					
					if(index == 0){
						// place first attachment in field
						$('#'+imgfield).val(attachment_url);
						showfield.html('<img src="'+attachment_url+'" />');
						
					} else{
						$('#'+imgfield).val(attachment_url);
						showfield.html('<img src="'+attachment_url+'" />');
					}
				});
			});
	
			// Finally, open the modal
			file_frame.open();			
		}
		
	});
	
	// function to display/hide pdf fonts
	function woo_vou_display_pdf_fonts() {
		// check if pdf font addon is active
		if( WooVouAdminSettings.is_pdf_fonts_plugin_active ) {
			if( $('#vou_char_support').is(':checked') ) {
				$('#vou_char_support').parents('tr').next().show();				
			} else {
				$('#vou_char_support').parents('tr').next().hide();
			}
		}
	}
	
	// call to function to hide/show pdf fonts
	woo_vou_display_pdf_fonts();	
	
	// on click display/hide pdf fonts
	$("#vou_char_support").on( 'click', function() {		
		woo_vou_display_pdf_fonts();		
	});
	
	// function to toggle remove voucher dowload link option
	function woo_vou_toggle_remove_voucher_download_link_option() {
		
		if( $("input[name='multiple_pdf']").is(':checked') ) {
			$("#revoke_voucher_download_link_access").parents('tr').fadeIn();
		} else {
			$("#revoke_voucher_download_link_access").parents('tr').fadeOut();
		}
	}
	
	// Setting page onload show/hide remove voucher download link option
	woo_vou_toggle_remove_voucher_download_link_option();
	
	// Setting page toggle remove voucher download link on click multiple voucher checkbox
	$(document).on('click', "input[name='multiple_pdf']", function() {
		woo_vou_toggle_remove_voucher_download_link_option();
	});
	
	// Disable coupon fields if coupon is 'voucher_code' type
	if ( WooVouAdminSettings.coupon_type == 'voucher_code' ) {
		
		$('#discount_type').prop('disabled', true);			// Disable Cart Discount type
		$('#coupon_amount').prop('disabled', true);         // Disable Coupon Amount
		$('#usage_limit').prop('disabled', true);           // Disable Usage Limit
		$('#expiry_date').prop('disabled', true);           // Disable expiry date field
		$('#_woo_vou_start_date').prop('disabled', true);   // Disable start date field
		$('#disable_redeem_days').prop('disabled', true);   // Disable product restriction days field
		$('#_woo_vou_coupon_type').prop('disabled', true);  // Disable coupon type field
	}
woo_vou_toggle_exp_type();
	$(document).on("change","#vou_exp_type",function(){

    	woo_vou_toggle_exp_type();
	});

	
	$(document).on('change', '#vou_days_diff', function(){

		woo_vou_toggle_days_no();
	});

	jQuery('.woo-vou-meta-datetime').each( function() {

		var jQuerythis  = jQuery(this),
	    format = jQuerythis.attr('rel'),
	    id = jQuerythis.attr('id');

	  	if( id == 'vou_start_date' ) {

		  	var expire_date = jQuery('#vou_exp_date');
	  		jQuerythis.datetimepicker({
				ampm: true,
				dateFormat : format,
				showTime: false,
				onSelect: function (selectedDateTime){
					console.log(jQuerythis.datetimepicker('getDate'));
					expire_date.datetimepicker('option', 'minDate', jQuerythis.datetimepicker('getDate') );
				}
			});
	  	} else if( id == 'vou_exp_date' ) {
  			var start_date = jQuery('#vou_start_date');
  	  		jQuerythis.datetimepicker({
				ampm: true,
				dateFormat : format,
				showTime: false,
				onSelect: function (selectedDateTime){
					start_date.datetimepicker('option', 'maxDate', jQuerythis.datetimepicker('getDate') );
				}
			});
	  	} else {  	        	
	      	jQuerythis.datetimepicker({ampm: true,dateFormat : format });//,timeFormat:'hh:mm:ss',showSecond:true
  	  	}
	});
	
	function woo_vou_toggle_exp_type(){

		var vou_type = $("#vou_exp_type").val();
		if(vou_type == 'specific_date'){

			$("#vou_exp_type").parents('tr').show();
			$("#vou_exp_type").parents('tr').next().show();
			$("#vou_exp_type").parents('tr').next().next().show();
			$("#vou_exp_type").parents('tr').next().next().next().hide();
			$("#vou_exp_type").parents('tr').next().next().next().next().hide();
		} else {

			$("#vou_exp_type").parents('tr').show();
			$("#vou_exp_type").parents('tr').next().hide();
			$("#vou_exp_type").parents('tr').next().next().hide();
			$("#vou_exp_type").parents('tr').next().next().next().show();
			woo_vou_toggle_days_no();
		}
	}

	function woo_vou_toggle_days_no(){

		var days_diff = $('#vou_days_diff').val();
		$('#vou_days_diff').parents('tr').next().hide();
		if(days_diff == 'cust'){

			$('#vou_days_diff').parents('tr').next().show();
		}
	}
	
	$( document ).on( 'click', '.view_redeem_info > .woo-vou-code-expiry-date', function() {
		
		var woo_voucher_id = $( this ).data( 'voucherid' );
		var data = {
					action		: 'woo_vou_get_voucher_expiry_date',
					voucher_id	: woo_voucher_id,
					ajax		: true,
				};

		//call ajax to chcek voucher code
		jQuery.post( WooVouAdminSettings.ajaxurl, data, function( response ) {
			
			var response_data = jQuery.parseJSON(response);
			// Check if response will be success
			if( response_data['success'] ){

				// Declare variables
				var woo_voucher_id 			= response_data['voucher_id'];
				var woo_voucher_code 		= response_data['purchased_codes'];
				var woo_voucher_start_date 	= ( response_data['start_date'].length != 0 )? response_data['start_date']: 0;
				var woo_voucher_expiry_date = response_data['exp_date'];
				
				$('#woo_vou_voucher_expiry_date .woo-vou-voucher-code').html( woo_voucher_code );
				$('#woo_vou_voucher_expiry_date #woo_voucher_id').val( woo_voucher_id );
				$('#woo_vou_voucher_expiry_date #woo_vou_exp_datetime').val( woo_voucher_expiry_date );

				// Date Time picker Field
				$('#woo_vou_voucher_expiry_date #woo_vou_exp_datetime').each( function() {
			      
					var jQuerythis  = jQuery(this),
						format = jQuerythis.attr('rel');
						
						jQuerythis.datetimepicker({
							
							dateFormat : format,
							timeFormat: "hh:mm tt",
							changeMonth: true,
							changeYear: true,
							minDate: woo_voucher_start_date,
							yearRange: "-100:+0",
							showTime: false,
						});
			    });

				$('.woo-vou-popup-content.woo-vou-expiry-date-content').fadeIn();
				$('.woo-vou-popup-overlay.woo-vou-expiry-date-overlay').show();
			}
			
		});
		
	});
	
	//on click of close button or overlay
	$( document ).on( "click", ".woo-vou-popup-overlay.woo-vou-expiry-date-overlay, .woo-vou-expiry-date-content .woo-vou-close-button", function() {
		
		//common code for both popup of voucher codes used and import csv file
		$('.woo-vou-popup-content.woo-vou-expiry-date-content').hide();
		$('.woo-vou-popup-overlay.woo-vou-expiry-date-overlay').hide();
		$('#woo_vou_voucher_expiry_date .woo-vou-voucher-code').html( '' );
		$('#woo_vou_voucher_expiry_date #woo_voucher_id').val( '' );
		$('#woo_vou_voucher_expiry_date #woo_vou_exp_datetime').val( '' );
		$('.woo-vou-expiry-date-content .woo-vou-expiry-errors').hide();
		$('.woo-vou-expiry-date-content .woo-vou-expiry-errors').html('');
		$('.woo-vou-expiry-date-content .woo-vou-expiry-errors').removeClass('woo-vou-expiry-success');
	});
	
	//on click of change expiry date button
	$( document ).on( "click", ".woo-vou-expiry-date-content .woo-vou-voucher-expiry-btn", function() {
		
		var woo_voucher_expiry_date = $('#woo_vou_voucher_expiry_date #woo_vou_exp_datetime').val();
		var woo_voucher_id = $('#woo_vou_voucher_expiry_date #woo_voucher_id').val();
		var data = {
						action				: 'woo_vou_change_voucher_expiry_date',							
						voucher_expiry_date	: woo_voucher_expiry_date,
						voucher_id			: woo_voucher_id,
						ajax				: true,
					};
		//call ajax to change voucher code expiry date
		jQuery.post( WooVouAdminSettings.ajaxurl, data, function( response ) {
			
			var response_data = jQuery.parseJSON(response);
			if( response_data['success'] ){
				$('.woo-vou-expiry-date-content .woo-vou-expiry-errors').html( response_data['success_msg'] );
				$('.woo-vou-expiry-date-content .woo-vou-expiry-errors').addClass( 'woo-vou-expiry-success' );
			} else {
				$('.woo-vou-expiry-date-content .woo-vou-expiry-errors').html( response_data['error_msg'] );
				$('.woo-vou-expiry-date-content .woo-vou-expiry-errors').removeClass( 'woo-vou-expiry-success' );
			}
			$('.woo-vou-expiry-date-content .woo-vou-expiry-errors').show();
			setTimeout(function(){
				location.reload();
			 }, 1000);
			
		});
	});
});