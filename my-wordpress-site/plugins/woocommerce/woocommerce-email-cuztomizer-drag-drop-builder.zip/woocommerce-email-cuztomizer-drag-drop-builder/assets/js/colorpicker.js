jQuery(document).ready(function($){
    $('.color_picker_wooemail').wpColorPicker();
});