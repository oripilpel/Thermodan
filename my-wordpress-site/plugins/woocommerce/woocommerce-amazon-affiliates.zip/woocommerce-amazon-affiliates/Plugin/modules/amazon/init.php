<?php
/**
 * Init Amazon
 * http://www.aa-team.com
 * =======================
 *
 * @author		Andrei Dinca, AA-Team
 * @version		0.1
 */

require_once( 'product-tabs.php' );
