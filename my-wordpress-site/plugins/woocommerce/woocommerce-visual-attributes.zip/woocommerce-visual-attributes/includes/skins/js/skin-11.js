jQuery(document).ready(function ($) {
 
    /*
  jQuery Document ready
*/
    $(function()
    {   

        $('#wvas-select-img').ddslick(
        {
            //callback function: do anything with selectedData
            onSelected: function(data)
            {
                var select_value = data.selectedData.value;
                var select_value_label=data.selectedData.label;
                var dropdown_id=data.selectedData.id;
                wvas_set_selected_value(dropdown_id, select_value_label, select_value);

                /*
                    we are calling custom created function.
                    that function will display selected option detail.
                */
                displaySelectedData("Callback Function on Dropdown Selection" , data);
            }
        });
        
        
        /*
            callback function when selection made
            demoIndex : 
                heading for result
            ddData :
                drop down selected object
        */
        function displaySelectedData(demoIndex, ddData)
        {
            /*
                add heading to div
            */
            $('#dd-display-data').html("<h3>Data from Demo " + demoIndex + "</h3>");
            /*
                append selected drop down index to result.
                also added code so you can check
                in browser console for selected object
            */
            $('#dd-display-data').append('<strong>selectedIndex:</strong> ' + ddData.selectedIndex + '<br/><strong>selectedItem:</strong> Check your browser console for selected "li" html element');
            
            /*
                check if selection made.
            */
            if (ddData.selectedData)
            {
                /*
                    appeding more data to result div.
                */
                $('#dd-display-data').append
                (
                    '<br/><strong>Value:</strong>  ' + ddData.selectedData.value +
                    '<br/><strong>Description:</strong>  ' + ddData.selectedData.description +
                    '<br/><strong>ImageSrc:</strong>  ' + ddData.selectedData.imageSrc
                );
            }
            /*
                browser console code
            */
            //console.log(ddData);
        }
    });
    
        function wvas_is_variation_valid(name, selected_value)
        {
            $(".wvas_item[data-id!='"+name+"']").hide();
            var data=$("form.variations_form").data("product_variations");
                $.each(data, function( index, value ) {
                    if(value.attributes["attribute_"+name]!=selected_value)
                        return true;
                    $.each(value.attributes, function( attr_index, attr_value ) {
                        if(attr_index=="attribute_"+name)
                            return true;
                        var usable_attr_index=attr_index.replace("attribute_", "");
                        $(".wvas_item[data-id='"+usable_attr_index+"'][data-val='"+attr_value+"']").show();
                    });
                });
        }

        function wvas_set_selected_value(dropdown_id, select_value_label, select_value)
        {

            var attr_dropdown = $('#' + dropdown_id);
            //var variation_form = attr_dropdown.closest('.variations_form');
            if (attr_dropdown.find("option[value='" + select_value + "']").length === 0)
            {
                var to_append = '<option value="' + select_value + '" class="attached enabled">' + select_value_label + '</option>';
                attr_dropdown.append(to_append);
                attr_dropdown.val(select_value);
            } else
                attr_dropdown.val(select_value).change();            
            
            wvas_is_variation_valid(dropdown_id, select_value);
//            console.log();
            
        }

//    function wvas_set_selected_value(dropdown_id, select_value_label, select_value)
//            {
//                
//                var attr_dropdown = $('#' + dropdown_id);
//                
//                if(attr_dropdown.find("option[value='"+select_value+"']").length === 0)
//                {
//                    var to_append='<option value="'+select_value+'" class="attached enabled">'+select_value_label+'</option>';
//                    attr_dropdown.append(to_append);
//                    attr_dropdown.val(select_value);
//                }
//                else
//                    attr_dropdown.val(select_value).change();
//            }
});
