jQuery( document ).ready(function( $ ) {
	$('.skin-9-child').fancySelect();

    $('.skin-9-child').fancySelect().on('change.fs', function () {
    	
    	var select_value = $(this).val();
    	var selected_element=$(this).parent('.fancy-select').find(".skin-9-child option[value='"+select_value+"']");
    	var dropdown_id = selected_element.data("id");
        var select_value_label=selected_element.data("label");
        wvas_set_selected_value(dropdown_id, select_value_label, select_value);
	});

    function wvas_is_variation_valid(name, selected_value)
        {
            $(".wvas_item[data-id!='"+name+"']").hide();
            var data=$("form.variations_form").data("product_variations");
                $.each(data, function( index, value ) {
                    if(value.attributes["attribute_"+name]!=selected_value)
                        return true;
                    $.each(value.attributes, function( attr_index, attr_value ) {
                        if(attr_index=="attribute_"+name)
                            return true;
                        var usable_attr_index=attr_index.replace("attribute_", "");
                        $(".wvas_item[data-id='"+usable_attr_index+"'][data-val='"+attr_value+"']").show();
                    });
                });
        }

        function wvas_set_selected_value(dropdown_id, select_value_label, select_value)
        {

            var attr_dropdown = $('#' + dropdown_id);
            //var variation_form = attr_dropdown.closest('.variations_form');
            if (attr_dropdown.find("option[value='" + select_value + "']").length === 0)
            {
                var to_append = '<option value="' + select_value + '" class="attached enabled">' + select_value_label + '</option>';
                attr_dropdown.append(to_append);
                attr_dropdown.val(select_value);
            } else
                attr_dropdown.val(select_value).change();            
            
            wvas_is_variation_valid(dropdown_id, select_value);
//            console.log();
            
        }

});
  