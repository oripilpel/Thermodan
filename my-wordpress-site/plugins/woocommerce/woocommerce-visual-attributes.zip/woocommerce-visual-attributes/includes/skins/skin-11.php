<?php

/**
 * Name: My Skin 11
 * Screenshot: Bing
 * Type: Image
 */

wp_enqueue_script("wvas-dd-slick-js", plugin_dir_url(__FILE__) . 'js/jquery-ddslick.js',  array('jquery'), null, false);

ob_start();
?>
<table class="wvas_variations skin-11-container {variation-container-class}" cellspacing="0">
	<tbody>
		<tr class="">

			<td class="label wvas_item_label">
				<label>{variation-label}</label>
			</td>
			<td class="value"> 
				<!-- <div class="variations_data_selected wvas_item_selected_container">
	                <span class="wvas_item_selected" style="background-image: url('{attribute-selected-image}')"></span>
	                <span class="wvas_item_selected_label">Choose value</span>
	                <span class="wvas_show_items_ico"></span>
	            </div> -->
				<select id="wvas-select-img" class="variations_data wvas_item_container">
					<option data-description="" data-imagesrc="" value="">Choose value</option>
                    {attributes}
				</select>
			</td>
			
		</tr>
	</tbody>
</table>
<?php
$global_tpl=  ob_get_contents();
ob_end_clean();

ob_start();
?>
<option class="wvas_item" data-value="{attribute-value}" data-id="{attributes-id}" data-label="{attribute-label}" {attribute-selected} data-description="" data-imagesrc="{attribute-image}" value="{attribute-value}">{attribute-label}</option>

<?php
$attribute_tpl=  ob_get_contents();
ob_end_clean();