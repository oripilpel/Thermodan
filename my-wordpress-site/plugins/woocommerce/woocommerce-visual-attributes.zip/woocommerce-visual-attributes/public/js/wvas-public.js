(function ($) {
    'use strict';

    jQuery(document).ready(function ($) {

        $("[data-original-title]").tooltip();
        //Select
        $(document).on('change', '.wvas-variation-select', function () {
            var select_value = $(this).val();
            var selected_element = $(this).find("option[value='" + select_value + "']");
            var dropdown_id = selected_element.data("id");
            var select_value_label = selected_element.data("label");
            wvas_set_selected_value(dropdown_id, select_value_label, select_value);
        });

        //Radio
        $(document).on('change', '.wvas-radio', function () {
            var select_value = $(this).val();
            var dropdown_id = this.dataset.id;
            var select_value_label = this.dataset.label;
            wvas_set_selected_value(dropdown_id, select_value_label, select_value);
        });

        //Span
        $(document).on('touchstart click', '.variations_data span', function () {
            var dropdown_id = $(this).data('id');
            var select_value = $(this).data('val');
            var select_value_label = $(this).attr('title');
            wvas_set_selected_value(dropdown_id, select_value_label, select_value);

            $(this).parent().find(".selected_wvas").removeClass("selected_wvas");
            $(this).addClass("selected_wvas");

        });
        
        function wvas_is_variation_valid(name, selected_value)
        {
            var data=$("form.variations_form").data("product_variations");
            var $use_ajax = data === false;
            var form = $(this);
            if ($use_ajax) {
                
             }else{
                $(".wvas_item[data-id!='"+name+"']").hide();
                
                $.each(data, function( index, value ) {
                    if( value.attributes["attribute_"+name] && value.attributes["attribute_"+name]!=selected_value){
                        return true;
                    }else{
                      $.each(value.attributes, function( attr_index, attr_value ) {
                        if(attr_index=="attribute_"+name){
                            return true;
                        }else{
                        var usable_attr_index=attr_index.replace("attribute_", "");
                        if(!attr_value){
                            $(".wvas_item[data-id='"+usable_attr_index+"'][data-val!='"+attr_value+"']").show(); 
                        }else{
                            $(".wvas_item[data-id='"+usable_attr_index+"'][data-val='"+attr_value+"']").show(); 
                        }  
                        }
                        
                    });  
                    } 
                    
                });
             }

        }
        
        $('.variations select').val('');

        function wvas_set_selected_value(dropdown_id, select_value_label, select_value)
        {

            var attr_dropdown = $('#' + dropdown_id);
            //var variation_form = attr_dropdown.closest('.variations_form');
            if (attr_dropdown.find("option[value='" + select_value + "']").length === 0)
            {
                var to_append = '<option value="' + select_value + '" class="attached enabled">' + select_value_label + '</option>';
                attr_dropdown.append(to_append);
                attr_dropdown.val(select_value);
            } else
                attr_dropdown.val(select_value).change();            
            
            wvas_is_variation_valid(dropdown_id, select_value);            
        }

    });
})(jQuery);
